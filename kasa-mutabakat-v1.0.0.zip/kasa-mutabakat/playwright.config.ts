import fs from 'node:fs';
import path from 'node:path';
import dotenv from 'dotenv';
import { defineConfig } from '@playwright/test';

dotenv.config({ path: path.join(__dirname, '.env') });

const API_PORT = 4010;
const WEB_PORT = 5174;
const systemChromePath = '/usr/bin/google-chrome';
const executablePath =
  process.env.PLAYWRIGHT_CHROME_PATH ??
  (fs.existsSync(systemChromePath) ? systemChromePath : undefined);

export default defineConfig({
  testDir: './e2e',
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 60_000,
  expect: {
    timeout: 15_000,
  },
  reporter: [['list']],
  globalSetup: './e2e/global-setup.ts',
  use: {
    baseURL: `http://127.0.0.1:${WEB_PORT}`,
    locale: 'tr-TR',
    timezoneId: 'Europe/Istanbul',
    headless: true,
    actionTimeout: 15_000,
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    ...(executablePath ? { launchOptions: { executablePath } } : {}),
  },
  webServer: [
    {
      command: `PORT=${API_PORT} NODE_ENV=test CORS_ORIGIN=http://127.0.0.1:${WEB_PORT} UPLOAD_STORAGE_DIR=./storage/receipts-e2e pnpm --filter @kasa/api start`,
      url: `http://127.0.0.1:${API_PORT}/api/v1/health`,
      reuseExistingServer: false,
      timeout: 30_000,
      env: {
        ...process.env,
        NODE_ENV: 'test',
        PORT: String(API_PORT),
        CORS_ORIGIN: `http://127.0.0.1:${WEB_PORT}`,
        UPLOAD_STORAGE_DIR: './storage/receipts-e2e',
        ...(process.env.TEST_DATABASE_URL ? { DATABASE_URL: process.env.TEST_DATABASE_URL } : {}),
      },
    },
    {
      command: `VITE_API_PROXY_TARGET=http://127.0.0.1:${API_PORT} pnpm --filter @kasa/web exec vite preview --port ${WEB_PORT} --host 127.0.0.1 --strictPort`,
      url: `http://127.0.0.1:${WEB_PORT}/giris`,
      reuseExistingServer: false,
      timeout: 30_000,
      env: {
        ...process.env,
        VITE_API_PROXY_TARGET: `http://127.0.0.1:${API_PORT}`,
      },
    },
  ],
});
