---
trigger: always_on
description: TypeScript, React, Express, Prisma ve test kodlama standartları.
---

# Kodlama Standartları (`coding_standards`)

## 1. TypeScript ve Tip Güvenliği
- Tüm paketlerde `"strict": true` aktiftir. `any` kullanımından kaçın; bilinmeyen dış girdilerde `unknown` + `Zod` doğrulaması kullan.
- Ortak DTO, enum ve doğrulama şemalarını `packages/shared` içinde tanımla; frontend ve backend aynı sözleşmeyi tüketir.
- Kod sembolleri (dosya adları, fonksiyonlar, sınıflar, Prisma modelleri, API alanları) açık ve tutarlı İngilizce; kullanıcıya dönen etiketler ve mesajlar Türkçe olur.

## 2. Backend (Node.js + Express + TypeScript)
- Katman ayrımı: `routes` (HTTP yönlendirme + middleware) -> `controller` (istek/yanıt eşleme) -> `service` (iş mantığı, yetkilendirme kontrolü, finansal hesaplama, audit) -> `prisma` (veri erişimi).
- Tüm HTTP girişleri (`body`, `query`, `params`) Zod şemalarıyla doğrulanmadan iş mantığına iletilmez.
- Hatalar merkezi hata sınıfları (`AppError`, `UnauthorizedError`, `ForbiddenError`, `ValidationError`, `ConflictError`, `NotFoundError`) ile fırlatılır ve global hata yakalayıcıda tutarlı Türkçe JSON formatında döner; üretim ortamında stack trace sızdırılmaz.
- Konsola ham `console.log` yerine yapılandırılmış `pino` logger kullan; parola, çerez, token veya tam dekont ham içeriğini loglama.

## 3. Frontend (React + TypeScript + Tailwind CSS)
- Özellik bazlı klasörleme (`apps/web/src/features/<modül>`).
- Sunucu durumu için TanStack Query, form doğrulaması için React Hook Form + Zod kullan.
- Frontend'de hiçbir finansal mutabakat veya fark hesabı karar kaynağı olarak yapılmaz; yalnızca backend'den dönen string/ondalık değerler `formatCurrencyTRY` ile biçimlendirilir.
- Tüm etkileşimli öğelerde erişilebilir etiketler (`label`, `aria-*`), anlamlı `id` değerleri ve responsive (masaüstü + mobil) yerleşim sağla.

## 4. Test ve Dokümantasyon
- Yeni veya değişen her iş kuralı için otomatik test yaz; özellikle finansal hesaplama, rol/mağaza izolasyonu ve dekont mükerrer kuralları test olmadan tamamlanmaz.
- Var olan faydalı yorum ve docstring'leri ilgisiz değişikliklerde koru.
