---
trigger: model_decision
description: PostgreSQL ve Prisma şema tasarımı, migration kuralları, ondalık para alanları ve silme koruması standartları.
---

# Veritabanı Kuralları (`database_rules`)

## 1. Parasal Alanlar ve Veri Tipleri
- Tüm parasal kolonlar `DECIMAL(14, 2)` (`@db.Decimal(14, 2)`) olarak tanımlanır. `Float`, `Double` veya `REAL` finansal alanlarda kesinlikle yasaktır.
- Güven skorları `DECIMAL(5, 2)`, iş günleri `DATE` (`@db.Date`), zaman damgaları `TIMESTAMPTZ` olarak saklanır.

## 2. Geçmiş Koruması ve Silme Davranışı
- Finansal kayıtlar (`cash_sessions`, `cash_transactions`, `transfer_receipts`, `receipt_ocr_results`, `receipt_verifications`, `central_reconciliations`, `reconciliation_items`, `financial_adjustments`, `audit_logs`) fiziksel olarak silinemez (`ON DELETE RESTRICT`).
- `stores` ve `users` kayıtları fiziksel olarak silinmez; `is_active = false` ile pasifleştirilir.
- Hatalı kasa hareketi yalnızca oturum açıkken `is_voided = true` ve zorunlu `void_reason` ile iptal edilir.
- Onaylı/kilitli kayıtlar doğrudan güncellenmez; düzeltmeler `financial_adjustments` ve `audit_logs` ile kayıt altına alınır.

## 3. İndeksleme ve Benzersizlik
- Kasiyer oturumu: `UNIQUE(store_id, cashier_id, business_date, shift_no)`.
- Merkez mutabakatı: `UNIQUE(store_id, business_date)`.
- Onaylı dekontlarda kısmi benzersizlik indeksleri (PostgreSQL partial unique index): aynı `file_sha256` ve boş olmayan aynı `reference_number` birden fazla `APPROVED` dekontta bulunamaz.
- Sık filtrelenen rapor sütunlarında (`store_id`, `cashier_id`, `business_date`, `status`, `created_at`) bileşik indeksler tanımlanır.

## 4. Migration Disiplini
- Her şema değişikliği `prisma migrate dev` (veya üretimde `prisma migrate deploy`) ile sürümlü migration dosyası üretir.
- Veri kaybı riski taşıyan migration (`DROP COLUMN`, `DROP TABLE`, tip daraltma) kullanıcı onayı olmadan uygulanmaz.
- Her migration sonrasında `docs/DATABASE_SCHEMA.md` güncellenir.
