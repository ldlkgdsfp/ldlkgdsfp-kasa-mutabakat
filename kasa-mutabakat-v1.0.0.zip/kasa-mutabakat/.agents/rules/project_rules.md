---
trigger: always_on
description: Proje mimarisi, modül sınırları, çalışma disiplinleri ve gelecekteki değişiklik protokolü.
---

# Proje Kuralları (`project_rules`)

## 1. Temel Çalışma İlkeleri
- Önce planla, sonra uygula. Büyük mimari veya veritabanı değişikliklerinde önce etki analizi sun.
- Her zaman gerçek çalışan backend, gerçek PostgreSQL veritabanı ve doğrulanmış testlerle teslimat yap.
- Sahte finansal veri (ör. sahte satış, sahte kasa kapanışı, sahte banka onayı) üretme.
- Gerçek banka API entegrasyonu varmış gibi davranma; banka teyidi ayrı bir manuel merkez kontrol adımıdır.
- API anahtarlarını kaynak koduna yazma veya uydurma; tüm anahtarlar `.env` üzerinden okunur ve `.env.example` şablonunda yalnızca boş yer tutucular bulunur.
- Test edilmemiş hiçbir özelliği tamamlandı olarak raporlama.

## 2. Modüler Sınırlar
- Monorepo yapısı: `apps/api` (REST API), `apps/web` (React SPA), `packages/shared` (ortak tip/şema/format sabitleri).
- Backend modülleri (`apps/api/src/modules/*`) kendi `router`, `controller`, `service`, `repository` (gerekirse) ve `schema` sınırlarına saygı duyar; başka bir modülün iç veritabanı sorgularına doğrudan atlamak yerine o modülün servis sözleşmesini kullanır.
- Gereksiz karmaşıklıktan, erken mikroservis bölünmesinden ve ölü koddan kaçın.

## 3. Gelecekteki Değişiklik Protokolü
Kullanıcı Türkçe olarak modül güncellemesi, yeni özellik veya hata düzeltmesi istediğinde:
1. `docs/BLUEPRINT.md` ve `docs/MODULE_MAP.md` dosyalarını oku.
2. İlgili `.agents/skills/<ad>/SKILL.md` dosyasını oku.
3. Etkilenecek modülleri listele; ilgisiz modülleri değiştirme.
4. Şema değişikliği gerekiyorsa Prisma migration oluştur; üretim verisini silen/bozan komutları kullanıcı onayı olmadan çalıştırma.
5. İlgili birim, entegrasyon ve regresyon testlerini çalıştır.
6. İlgili `docs/` belgelerini ve `docs/CHANGELOG.md` kaydını güncelle.
7. Kullanıcı açıkça onaylamadan GitHub'a `git push` yapma.

## 4. Dil ve Yerelleştirme
- Tüm kullanıcı arayüzü metinleri, hata mesajları, rapor başlıkları ve dokümantasyon **Türkçe** olmalıdır.
- Para birimi **Türk Lirası (`₺` / `TRY`)**, tarih formatı **Türkiye formatı (`GG.AA.YYYY`)**, varsayılan zaman dilimi **`Europe/Istanbul`** olmalıdır.
