---
trigger: always_on
description: Kimlik doğrulama, RBAC, mağaza izolasyonu, dosya yükleme güvenliği, XSS/CSRF/SQLi ve denetim kuralları.
---

# Güvenlik Kuralları (`security_rules`)

## 1. Kimlik Doğrulama ve Oturum Güvenliği
- Parolalar yalnızca `crypto.scrypt` (benzersiz rastgele salt + zaman-sabit `timingSafeEqual` doğrulama) ile saklanır; düz metin veya zayıf hash (MD5/SHA1) yasaktır.
- Oturumlar veritabanında (`user_sessions`) hash'lenmiş token ile izlenir; tarayıcıya `HttpOnly`, `SameSite=Lax`, üretimde `Secure` çerez olarak verilir.
- Ardışık başarısız giriş denemelerinde hesap geçici kilitleme (`failed_login_attempts`, `locked_until`) ve IP/hesap bazlı rate limiting zorunludur.
- Tüm durum değiştiren API isteklerinde (`POST`, `PUT`, `PATCH`, `DELETE`) CSRF token doğrulaması zorunludur (login hariç).

## 2. Yetkilendirme (RBAC) ve Mağaza Bazlı Veri İzolasyonu
- Her korumalı uç noktada önce kimlik doğrulama (`requireAuth`), ardından rol kontrolü (`requireRole`) ve mağaza kapsamı kontrolü (`enforceStoreScope`) uygulanır.
- `STORE_MANAGER` ve `CASHIER` rolleri yalnızca kendi `store_id` kayıtlarına erişebilir. `CASHIER` ayrıca yalnızca kendi `cashier_id` oturumlarını ve dekontlarını yönetir.
- API istek gövdesinden gelen `cashierId` veya `storeId` değerine asla körü körüne güvenilmez; oturumdaki kullanıcı kimliğinden ve yetki kapsamından türetilir/doğrulanır.

## 3. Dosya Yükleme ve Depolama Güvenliği
- Yalnızca `JPG`, `JPEG`, `PNG` ve `PDF` kabul edilir. Uzantı ve MIME başlığına ek olarak **dosya magic-bytes (imza) doğrulaması** zorunludur.
- Maksimum dosya boyutu sistem ayarları/env ile sınırlandırılır (varsayılan 10 MB).
- Yüklenen dosyalar rastgele UUID dosya adıyla web kökünün dışında (`storage/receipts/YYYY/MM/`) saklanır; asla doğrudan herkese açık statik dizinden sunulmaz.
- Dosya önizleme/indirme yalnızca kimlik doğrulamalı ve mağaza yetkisi kontrol edilen API uç noktasından `Content-Security-Policy: sandbox` ve `X-Content-Type-Options: nosniff` başlıklarıyla yapılır.

## 4. Veri ve Enjeksiyon Koruması
- Tüm veritabanı sorguları Prisma parametreli sorguları üzerinden yapılır; ham SQL gerektiğinde yalnızca etiketli güvenli parametreler (`Prisma.sql`) kullanılır.
- CSV dışa aktarımlarında `=`, `+`, `-`, `@`, `\t`, `\r` ile başlayan metin hücreleri formül enjeksiyonuna karşı etkisizleştirilir.
- Sırlar (DB parolası, session secret, harici OCR API anahtarı) asla koda veya git geçmişine yazılmaz.
- Her kritik güvenlik ve finansal olay (giriş/çıkış, başarısız giriş, yetki değişikliği, kapanış onayı, dekont onayı/reddi, düzeltme kaydı) `audit_logs` tablosuna yazılır.
