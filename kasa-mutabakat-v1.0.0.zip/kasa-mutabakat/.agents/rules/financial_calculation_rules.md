---
trigger: always_on
description: Günlük kasa, nakit farkı, ödeme yöntemi izolasyonu ve IBAN dekont mutabakat hesaplama kuralları.
---

# Finansal Hesaplama Kuralları (`financial_calculation_rules`)

## 1. Tek Doğruluk Kaynağı ve Ondalık Kesinlik
- Tüm finansal hesaplamalar **yalnızca backend tarafında** (`apps/api/src/modules/reconciliation/calculator.ts`) `Decimal.js` (`ROUND_HALF_UP`, 2 ondalık basamak) kullanılarak yapılır.
- JavaScript `Number` türüyle parasal toplama, çıkarma veya yuvarlama yapmak yasaktır.
- Frontend yalnızca backend tarafından döndürülen string ondalık değerleri görüntüler.

## 2. Ödeme Yöntemi İzolasyonu
- Sistemde yalnızca **3 ana ödeme yöntemi** vardır:
  1. `CASH` (Nakit)
  2. `CREDIT_CARD` (Kredi Kartı)
  3. `BANK_TRANSFER` (Havale / EFT)
- Kredi kartı tahsilatları ve kart iadeleri **asla** beklenen nakit hesabına eklenmez veya düşülmez.
- Havale / EFT tutarları **asla** beklenen nakit hesabına eklenmez.

## 3. Zorunlu Kasa ve Mutabakat Formülleri
- **Beklenen Nakit (Kasiyer Oturumu):**
  `expected_cash = opening_cash + cash_sales_total + other_cash_in_total - cash_refund_total - other_cash_out_total`
- **Kasiyer Kasa Farkı:**
  `cash_difference = declared_cash - expected_cash`
  - `< 0`: Kasa Açığı | `> 0`: Kasa Fazlası | `= 0`: Kasa Eşit
- **Merkez Mutabakat Farkları:**
  - `cash_variance = central_verified_cash - expected_cash_total`
  - `declared_vs_central_diff = central_verified_cash - declared_cash_total`
- **Net Satış Toplamı:**
  `grand_sales_total = (cash_sales_total + credit_card_sales_total + approved_transfer_total) - (cash_refund_total + card_refund_total + transfer_refund_total)`

## 4. IBAN / Havale Dekontu Kuralları
- **Bakiye Dışlama:** Dekont üzerindeki hesap bakiyesi (`Bakiye`, `Kullanılabilir Bakiye`, `Son Bakiye`, `Güncel Bakiye`, `İşlem Sonrası Bakiye`) kesinlikle transfer tutarı olarak kabul edilmez.
- **Çoklu Tutar Şüphesi:** Dekontta birden fazla tutar varsa açık etiketli transfer tutarı seçilir; belirsizlik varsa kayıt otomatik `MANUAL_REVIEW_REQUIRED` durumuna alınır.
- **OCR Doğrulama Değildir:** OCR sonucu tek başına kesin finansal kayıt oluşturmaz; kullanıcı/merkez onayı zorunludur.
- **Mükerrer ve Çift Sayım Engeli:** Yalnızca `status === 'APPROVED'` ve `is_duplicate === false` olan dekontlar günlük Havale/EFT toplamına tek seferde dahil edilir. Sistem ayarlarında `require_bank_verification_for_reconciliation = true` ise `bank_account_verified === true` şartı da aranır.
- **Kilitli Kayıt Değişmezliği:** `CENTRAL_APPROVED` veya `LOCKED` durumundaki oturumlar ve mutabakatlar doğrudan değiştirilemez; yalnızca gerekçeli `financial_adjustments` kaydıyla düzeltilebilir.
