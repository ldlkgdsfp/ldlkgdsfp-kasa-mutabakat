---
name: project-architecture
description: Monorepo mimarisi, modül sınırları, klasör yapısı ve teknoloji kararlarını yönetir. Yeni modül eklerken, mimari değişiklik yaparken veya sistem katmanlarını gözden geçirirken kullan.
---

# Project Architecture Skill

## Skill'in Amacı
Mağaza ve Merkez Günlük Kasa Takip ve Mutabakat Sistemi'nin pnpm monorepo mimarisini (`apps/api`, `apps/web`, `packages/shared`), modül sınırlarını ve bağımlılık yönlerini tutarlı tutmak.

## Ne Zaman Kullanılacağı
- Yeni bir iş modülü veya paket eklendiğinde
- Modüller arası sözleşme (`packages/shared`) veya API sınırları değiştiğinde
- Mimari refactor veya performans/ölçekleme iyileştirmesi planlandığında

## İzlenecek Adımlar
1. `docs/BLUEPRINT.md`, `docs/SYSTEM_ARCHITECTURE.md` ve `docs/MODULE_MAP.md` belgelerini oku.
2. Önerilen değişikliğin hangi katmanları (`shared`, `api`, `web`, `prisma`) etkilediğini çıkar.
3. Döngüsel bağımlılık oluşmadığını doğrula (`web` ve `api` yalnızca `shared`'a bağımlı olabilir).
4. Yeni modül için standart klasör yapısını oluştur (`routes`, `controller`, `service`, `schema`, testler).
5. `docs/SYSTEM_ARCHITECTURE.md`, `docs/MODULE_MAP.md` ve `docs/BLUEPRINT.md` belgelerini güncelle.

## Uyulması Gereken Kurallar
- Gereksiz mikroservis veya aşırı soyutlama ekleme; modüler monolit sınırlarını koru.
- İş mantığını ve finansal hesaplamaları yalnızca backend servislerinde tut.
- Ortak enum, Zod şeması ve DTO tiplerini `packages/shared` altında paylaş.

## Etkilenecek Modüller
- `packages/shared`, `apps/api/src/modules/*`, `apps/web/src/features/*`, `docs/BLUEPRINT.md`, `docs/SYSTEM_ARCHITECTURE.md`, `docs/MODULE_MAP.md`

## Test Gereksinimleri
- Tüm çalışma alanında `pnpm typecheck`, `pnpm build` ve mevcut integration testleri yeşil geçmelidir.

## Tamamlanma Kriterleri
- Modül sınırları net, döngüsel bağımlılık yok, tüm paketler hatasız derleniyor ve mimari dokümanlar güncel.
