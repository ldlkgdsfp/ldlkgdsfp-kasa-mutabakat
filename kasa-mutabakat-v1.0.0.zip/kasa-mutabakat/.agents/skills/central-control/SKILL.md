---
name: central-control
description: Merkez muhasebe ve kontrol panelini, mağaza kapanış onay/iade akışını, beyan vs merkez teslim farkını ve banka teyidini yönetir.
---

# Central Control Skill

## Skill'in Amacı
Merkez muhasebe personelinin tüm mağazaların günlük satışlarını, nakit teslimlerini, açık/fazla tutarlarını ve IBAN dekontlarını tek ekrandan doğrulayıp onaylamasını veya düzeltme için geri göndermesini sağlamak.

## Ne Zaman Kullanılacağı
- Merkez kontrol paneli, mağaza kapanış onay/ret/iade akışı, gerçek teslim edilen nakit girişi veya finansal düzeltme ekranı geliştirildiğinde/değiştirildiğinde

## İzlenecek Adımlar
1. Üç mağazanın günlük özetini (satış, nakit, kart, Havale/EFT, beklenen nakit, teslim edilen nakit, açık/fazla, onay bekleyen kapanış/dekont, hatalı/mükerrer dekont) tek sorguda veya optimize servisle topla.
2. Merkez doğrulama kaydında şu alanları zorunlu tut: `declared_cash_total`, `central_verified_cash`, farklar, açıklama, `checked_by`, `checked_at`, onay/iade durumu.
3. Onay verildiğinde `central_reconciliations` ve bağlı `cash_sessions` kayıtlarını kilitle (`is_locked = true`) ve `audit_logs` kaydı oluştur.
4. Düzeltme için geri gönderimde (`RETURNED_FOR_CORRECTION`) gerekçe zorunlu kıl.
5. Onaylı kayıtta sonradan değişiklik gerekiyorsa doğrudan düzenleme yerine gerekçeli `financial_adjustments` akışını çalıştır.

## Uyulması Gereken Kurallar
- Yalnızca `CENTRAL_ACCOUNTING` (ve denetim görüntülemesinde `SYSTEM_ADMIN`) tüm mağazaların merkez paneline erişebilir.
- Onaylı kayıt doğrudan değiştirilemez.

## Etkilenecek Modüller
- `apps/api/src/modules/reconciliation/*`, `apps/web/src/features/central/*`, `central_reconciliations`, `financial_adjustments`

## Test Gereksinimleri
- Merkez onay ve kilitleme testi, düzeltme için iade testi, kilitli kaydı doğrudan değiştirme reddi testi, gerekçeli düzeltme kaydı ve audit log testi.

## Tamamlanma Kriterleri
- Merkez paneli tüm zorunlu metrikleri gerçek veriden üretiyor, onay/iade ve düzeltme akışları uçtan uca doğrulandı.
