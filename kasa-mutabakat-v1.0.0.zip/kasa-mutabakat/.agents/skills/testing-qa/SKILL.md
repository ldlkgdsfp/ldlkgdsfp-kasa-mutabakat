---
name: testing-qa
description: Unit, integration, finansal hesaplama, regresyon ve Playwright E2E test stratejisini ve yürütümünü yönetir.
---

# Testing & QA Skill

## Skill'in Amacı
Özellikle finansal hesaplamalar, rol/mağaza izolasyonu ve IBAN dekont kuralları başta olmak üzere tüm sistemin gerçek veritabanı ve tarayıcı testleriyle güvenilirliğini kanıtlamak.

## Ne Zaman Kullanılacağı
- Yeni özellik eklendiğinde, hata düzeltildiğinde veya aşama/sürüm kapanışında regresyon doğrulaması yapılırken

## İzlenecek Adımlar
1. `docs/TEST_PLAN.md` belgesini incele.
2. Finansal hesaplama ve dekont ayrıştırma için saf unit testleri çalıştır (`pnpm --filter @kasa/api test:unit`).
3. Gerçek PostgreSQL test veritabanı üzerinde API integration testlerini çalıştır (`pnpm --filter @kasa/api test:integration`).
4. Frontend tip kontrolü, derleme ve bileşen testlerini çalıştır (`pnpm --filter @kasa/web test`).
5. Kritik kullanıcı akışları için Playwright E2E testlerini çalıştır (`pnpm test:e2e`).
6. Başarısız olan her senaryoda kök nedeni gider, regresyon testi ekle ve tüm paketi yeniden çalıştır.

## Uyulması Gereken Kurallar
- Test edilmemiş hiçbir özelliği tamamlandı olarak işaretleme.
- Finansal hesaplamaları ve mükerrer kontrollerini test etmeden teslim etme.
- Test sonuçlarını uydurma; yalnızca gerçekten çalıştırıp gözlemlediğin sonuçları raporla.

## Etkilenecek Modüller
- `apps/api/src/tests/*`, `apps/web/src/**/*.test.tsx`, `e2e/*`, `docs/TEST_PLAN.md`

## Test Gereksinimleri
- Tüm unit, integration, finansal kesinlik ve E2E test paketleri sıfır hata ile geçmelidir.

## Tamamlanma Kriterleri
- Tüm test suiteleri yeşil, regresyon tespit edilmedi ve `docs/TEST_PLAN.md` sonuçları güncel.
