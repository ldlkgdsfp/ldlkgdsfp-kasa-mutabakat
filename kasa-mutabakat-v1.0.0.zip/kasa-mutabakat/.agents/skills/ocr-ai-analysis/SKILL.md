---
name: ocr-ai-analysis
description: Yüklenen IBAN/Havale dekontlarından OCR ve opsiyonel AI Vision sağlayıcılarıyla alan çıkarımı, bakiye dışlama, güven skoru ve şüpheli kayıt yönlendirmesini yönetir.
---

# OCR & AI Analysis Skill

## Skill'in Amacı
Yüklenen JPG, JPEG, PNG ve PDF banka dekontlarından transfer tutarı, tarih, saat, gönderen/alıcı, banka, IBAN, referans no, açıklama ve güven skorunu finansal kurallara uygun biçimde çıkarmak.

## Ne Zaman Kullanılacağı
- OCR adaptörü, PDF metin çıkarımı veya Türk banka dekont ayrıştırıcısı geliştirildiğinde/iyileştirildiğinde
- Yeni banka dekont şablonu eklendiğinde veya güven skoru kuralları güncellendiğinde

## İzlenecek Adımlar
1. `docs/BLUEPRINT.md` ve `.agents/rules/financial_calculation_rules.md` kurallarını oku.
2. `OcrProvider` arayüzü üzerinden varsayılan `LocalOcrProvider` (PDF `pdftotext`/`pdftoppm` + görsel `sharp` ön işleme + `tesseract -l tur+eng`) veya `.env` tanımlı opsiyonel `AiVisionOcrProvider` çalıştır.
3. Ham metni `TurkishBankReceiptParser` ile ayrıştır:
   - Tüm para tutarlarını satır bağlamıyla birlikte tespit et.
   - `"Bakiye"`, `"Kullanılabilir Bakiye"`, `"Son Bakiye"`, `"Güncel Bakiye"`, `"İşlem Sonrası Bakiye"` bağlamındaki tutarları **kesinlikle dışla** ve `excluded_balance_amounts_json` içinde sakla.
   - Masraf/komisyon/BSMV tutarlarını işlem tutarından ayır.
   - Birden fazla aday tutar varsa veya net transfer etiketi yoksa kaydı `MANUAL_REVIEW_REQUIRED` durumuna al.
4. Okunamayan zorunlu alanları `warnings_json` olarak kaydet ve kullanıcıya açıkça bildir.
5. Tüm çıktıyı `receipt_ocr_results` tablosunda versiyonlu olarak sakla; `transfer_receipts.status` değerini güncelle.

## Uyulması Gereken Kurallar
- Hesap bakiyesi **asla** transfer tutarı kabul edilmez.
- OCR sonucu **asla** kesin doğrulanmış veya bankaya geçmiş işlem sayılmaz.
- API anahtarı tanımlı değilse harici AI çağrısı yapma veya sahte sonuç üretme; yerel OCR motorunu kullan.

## Etkilenecek Modüller
- `apps/api/src/modules/receipts/ocr/*`, `apps/api/src/modules/receipts/parser.ts`, `receipt_ocr_results`

## Test Gereksinimleri
- Çoklu tutar içeren dekont testi, hesap bakiyesi dışlama testi, bozuk/okunamayan görselde `FAILED_OCR` / `MANUAL_REVIEW_REQUIRED` testi, gerçek PDF ve PNG dekont ayrıştırma testleri.

## Tamamlanma Kriterleri
- Bakiye dışlama, çoklu tutar algılama, düşük güven uyarısı ve PDF/görsel OCR testlerinin tamamı yeşil.
