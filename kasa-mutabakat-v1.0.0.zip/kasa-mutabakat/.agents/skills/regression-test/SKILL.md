---
name: regression-test
description: İş akışı (Workflow): Tüm monorepo genelinde tip kontrolü, finansal hesaplama testleri, API integration, frontend build ve E2E regresyon paketini çalıştırır.
---

# Workflow: Regression Test (`/regression-test`)

## Amaç
Yapılan son değişikliklerin mevcut çalışan hiçbir modülü, finansal hesaplamayı veya güvenlik sınırını bozmadığını kanıtlamak.

## Ne Zaman Kullanılacağı
- Aşama kapanışlarında, kritik değişiklikler sonrasında veya commit/release öncesinde

## İzlenecek Adımlar
1. `pnpm typecheck` çalıştır.
2. `pnpm --filter @kasa/api test` (unit + finansal kesinlik + DB integration) çalıştır.
3. `pnpm --filter @kasa/web test` ve `pnpm --filter @kasa/web build` çalıştır.
4. Mevcutsa `pnpm test:e2e` (Playwright) çalıştır.
5. Herhangi bir kırılma varsa kök nedeni düzelt ve tüm paketi baştan çalıştır.

## Uyulması Gereken Kurallar
- Hata alan testi atlama (`skip`) veya silme kesinlikle yasaktır.

## Etkilenecek Modüller
- Tüm depo (`packages/shared`, `apps/api`, `apps/web`, `e2e`).

## Test Gereksinimleri
- Tüm otomatik test katmanlarının eksiksiz geçmesi zorunludur.

## Tamamlanma Kriterleri
- Sıfır tip hatası, sıfır derleme hatası, tüm unit/integration/E2E testleri yeşil.
