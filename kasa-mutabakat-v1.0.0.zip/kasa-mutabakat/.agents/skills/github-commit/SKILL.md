---
name: github-commit
description: İş akışı (Workflow): Değişiklikleri denetler, gizli dosya kontrolü yapar, atomik commit planı hazırlar ve push öncesinde kullanıcı onayı bekler.
---

# Workflow: GitHub Commit (`/github-commit`)

## Amaç
Değişiklikleri temiz, doğrulanmış ve güvenli commit'ler halinde paketlemek ve kullanıcı onayı olmadan uzak depoya push yapmamak.

## Ne Zaman Kullanılacağı
- Kullanıcı "GitHub" veya commit/push hazırlığı istediğinde, ya da bir aşama/özellik tamamlandığında

## İzlenecek Adımlar
1. `.agents/skills/github-management/SKILL.md` dosyasını oku.
2. `git status` ve `git diff --stat` ile tüm değişen dosyaları incele.
3. `.env`, gerçek dekont dosyaları (`storage/`), loglar veya derleme artıklarının stage edilmediğini doğrula.
4. `pnpm typecheck` ve ilgili testlerin geçtiğini doğrula.
5. Mantıklı gruplara ayrılmış atomik commit planını (mesajlar + dosya listesi) kullanıcıya sun.
6. Kullanıcı onayladıktan sonra commit'leri oluştur; `git push` için ayrıca açık kullanıcı onayı al.

## Uyulması Gereken Kurallar
- Kullanıcı onayı olmadan `git push` kesinlikle yapılmaz.
- `--no-verify` veya `--force` kullanılmaz.

## Etkilenecek Modüller
- Git deposu, `.gitignore`, `.env.example`, `docs/CHANGELOG.md`.

## Test Gereksinimleri
- Commit öncesi tip kontrolü ve testler yeşil olmalıdır.

## Tamamlanma Kriterleri
- Gizli veri sızıntısı yok, commit'ler temiz, push yalnızca açık kullanıcı onayı ile yapıldı.
