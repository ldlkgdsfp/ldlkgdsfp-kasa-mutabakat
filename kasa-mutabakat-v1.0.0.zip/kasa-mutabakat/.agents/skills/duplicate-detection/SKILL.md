---
name: duplicate-detection
description: Aynı IBAN dekontunun veya aynı banka transferinin sisteme birden fazla kez eklenmesini ve günlük toplama çift yazılmasını engelleyen 4 katmanlı mükerrer tespit sistemini yönetir.
---

# Duplicate Detection Skill

## Skill'in Amacı
Aynı dosyanın, aynı ekran görüntüsünün kırpılmış kopyasının veya aynı banka referans/tutar-tarih bilgisinin mükerrer olarak kaydedilmesini ve Havale/EFT toplamına iki kez eklenmesini engellemek.

## Ne Zaman Kullanılacağı
- Mükerrer kontrol kuralları, eşik değerleri veya veritabanı benzersizlik kısıtları geliştirildiğinde/güncellendiğinde
- Şüpheli mükerrer inceleme ekranı değiştirildiğinde

## İzlenecek Adımlar
1. Yükleme anında **Katman 1 (Kesin):** `file_sha256` ile mevcut dekontları karşılaştır -> eşleşme varsa otomatik `DUPLICATE` işaretle ve `duplicate_of_receipt_id` bağla.
2. OCR çıkarımı sonrası **Katman 2 (Kesin):** Normalize edilmiş `reference_number` (boş değilse) ile mevcut reddedilmemiş dekontları kontrol et -> eşleşme varsa `DUPLICATE` işaretle.
3. **Katman 3 (Algısal):** Görsellerde `perceptual_hash` (Hamming mesafesi eşiği) eşleşmesi varsa şüpheli mükerrer uyarısı ekle ve `MANUAL_REVIEW_REQUIRED` durumuna zorla.
4. **Katman 4 (Bileşik Alan):** Aynı tutar + aynı tarih + yapılandırılabilir saat penceresi (±10 dk) + benzer gönderen adı veya IBAN eşleşmesi varsa şüpheli mükerrer uyarısı ekle ve `MANUAL_REVIEW_REQUIRED` durumuna zorla.
5. Onay anında veritabanı kısmi benzersiz indekslerinin (`APPROVED` kayıtlar için `file_sha256` ve `reference_number`) son güvenlik ağı olarak çalıştığını doğrula.

## Uyulması Gereken Kurallar
- `is_duplicate = true` veya `status = DUPLICATE` olan hiçbir dekont günlük mutabakat toplamına eklenemez.
- Mükerrer tespit edilen orijinal dosya denetim izi için saklanmaya devam eder, silinmez.

## Etkilenecek Modüller
- `apps/api/src/modules/receipts/duplicate-detector.ts`, `transfer_receipts`, `apps/web/src/features/receipts/`

## Test Gereksinimleri
- Aynı dosya tekrar yükleme testi, farklı dosya / aynı referans numarası testi, aynı tutar+tarih+gönderen şüpheli mükerrer testi, mükerrer kaydın mutabakat toplamına eklenmediğini doğrulayan test.

## Tamamlanma Kriterleri
- Tüm 4 katman unit ve integration testleriyle doğrulanmış, çift sayım hem servis hem DB katmanında imkânsız hale getirilmiş.
