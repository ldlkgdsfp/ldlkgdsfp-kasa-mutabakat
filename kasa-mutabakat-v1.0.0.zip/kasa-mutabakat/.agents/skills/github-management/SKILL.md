---
name: github-management
description: Git dal stratejisi, temiz commit geçmişi, değişiklik incelemesi ve kullanıcı onaylı GitHub aktarımı süreçlerini yönetir.
---

# GitHub Management Skill

## Skill'in Amacı
Sürüm kontrol geçmişini temiz, izlenebilir ve güvenli tutmak; `.env` veya gizli dosyaların repoya sızmasını engellemek ve GitHub'a yalnızca kullanıcı onayıyla push yapmak.

## Ne Zaman Kullanılacağı
- Commit planı hazırlanırken, dal birleştirilirken, değişiklikler gözden geçirilirken veya GitHub deposuna aktarım planlanırken

## İzlenecek Adımlar
1. `git status` ve `git diff` ile tüm değişiklikleri gözden geçir.
2. `.gitignore` dosyasının `.env`, `storage/`, `node_modules/`, `dist/`, test loglarını hariç tuttuğunu doğrula.
3. Çalışma alanında testlerin (`pnpm test`) ve derlemenin (`pnpm build`) yeşil olduğunu doğrula.
4. Mantıklı, atomik ve Türkçe/Conventional Commit uyumlu bir commit planı hazırla.
5. `docs/CHANGELOG.md` dosyasının güncel olduğunu kontrol et.
6. Kullanıcıdan açık onay almadan `git push` veya remote değişikliği yapma.

## Uyulması Gereken Kurallar
- Kullanıcı onayı olmadan **asla** `git push` yapma.
- Force push, geçmiş silme veya `.env` dosyasını commit etme yasaktır.

## Etkilenecek Modüller
- `.gitignore`, `.env.example`, `docs/CHANGELOG.md`, Git geçmişi

## Test Gereksinimleri
- Commit öncesi tüm testler ve `typecheck` geçmelidir.

## Tamamlanma Kriterleri
- Temiz `git status`, gizli dosya sızıntısı yok, commit planı onaylandı ve (onay verildiyse) push başarıyla tamamlandı.
