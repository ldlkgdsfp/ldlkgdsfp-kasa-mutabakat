---
name: store-management
description: Mağaza ve merkez ofis tanımlama, dinamik ad/bilgi güncelleme, pasifleştirme ve mağaza bazlı veri izolasyonunu yönetir.
---

# Store Management Skill

## Skill'in Amacı
Üç mağaza ve bir merkez ofis ile başlayan yapıyı, ileride yeni mağaza eklenebilir ve mevcut mağaza isimleri yönetim panelinden değiştirilebilir şekilde yönetmek.

## Ne Zaman Kullanılacağı
- Mağaza oluşturma, yeniden adlandırma, pasifleştirme veya mağaza kapsam izolasyonu geliştirildiğinde/değiştirildiğinde

## İzlenecek Adımlar
1. `stores` tablosu ve `StoreScopeGuard` middleware'ini incele.
2. Mağaza oluşturma ve düzenleme işlemlerini yalnızca `SYSTEM_ADMIN` rolüyle sınırla.
3. Mağaza adı değiştiğinde geçmiş finansal kayıtların `store_id` üzerinden tutarlı biçimde bağlandığını ve değişikliğin `audit_logs` tablosuna yazıldığını doğrula.
4. Mağazaların fiziksel olarak silinmediğini, yalnızca `is_active = false` ile pasifleştirildiğini garanti et.

## Uyulması Gereken Kurallar
- Mağaza kodları (`code`) benzersizdir; ad (`name`) her zaman yönetim panelinden güncellenebilir.
- Mağaza yöneticisi ve kasiyer yalnızca kendi `store_id` verisine erişebilir.

## Etkilenecek Modüller
- `apps/api/src/modules/stores/*`, `apps/api/src/middlewares/store-scope.ts`, `apps/web/src/features/stores/`

## Test Gereksinimleri
- Sistem yöneticisinin mağaza adı güncelleme testi, mağaza yöneticisinin yetkisiz mağaza düzenleme reddi testi, çapraz mağaza okuma/yazma izolasyon testi.

## Tamamlanma Kriterleri
- Mağazalar dinamik yönetilebiliyor, izolasyon delinemiyor ve tüm değişiklikler denetim kaydına düşüyor.
