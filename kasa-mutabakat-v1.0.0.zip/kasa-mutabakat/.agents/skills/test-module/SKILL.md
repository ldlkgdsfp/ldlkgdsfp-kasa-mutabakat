---
name: test-module
description: İş akışı (Workflow): Belirli bir modülün unit, integration, finansal kesinlik ve arayüz testlerini çalıştırır ve eksikleri tamamlar.
---

# Workflow: Test Module (`/test-module`)

## Amaç
Tek bir modülün tüm iş kurallarını, yetki sınırlarını ve kenar durumlarını gerçek veritabanı ve otomatik testlerle doğrulamak.

## Ne Zaman Kullanılacağı
- Bir modül geliştirildikten veya değiştirildikten hemen sonra

## İzlenecek Adımlar
1. `.agents/skills/testing-qa/SKILL.md` ve `docs/TEST_PLAN.md` belgelerini incele.
2. Modülün unit testlerini çalıştır.
3. Modülün API integration testlerini gerçek test PostgreSQL veritabanı üzerinde çalıştır.
4. Yetkisiz rol, çapraz mağaza ve geçersiz girdi senaryolarının kapsandığını doğrula.
5. Eksik test senaryoları varsa ekle ve tekrar çalıştır; sonuçları raporla.

## Uyulması Gereken Kurallar
- Test çıktısı gözlemlenmeden "geçti" raporu yazılmaz.

## Etkilenecek Modüller
- Hedef modülün test dosyaları (`apps/api/src/tests/*`, `apps/web/src/**/*.test.tsx`).

## Test Gereksinimleri
- Hedef modülün tüm testleri %100 yeşil olmalıdır.

## Tamamlanma Kriterleri
- Tüm senaryolar geçti, kenar durumlar kapsandı, test sonuçları raporlandı.
