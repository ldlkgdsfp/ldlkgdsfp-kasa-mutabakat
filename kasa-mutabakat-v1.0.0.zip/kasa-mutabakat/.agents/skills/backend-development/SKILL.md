---
name: backend-development
description: Node.js, TypeScript, Express ve Prisma ile güvenli REST API, iş mantığı, yetkilendirme ve denetim kaydı geliştirir. Yeni endpoint veya servis eklerken kullan.
---

# Backend Development Skill

## Skill'in Amacı
Temiz katmanlı, Zod doğrulamalı, RBAC + mağaza izolasyonlu ve denetim izli REST API modülleri geliştirmek.

## Ne Zaman Kullanılacağı
- Yeni REST API uç noktası eklendiğinde veya değiştirildiğinde
- İş mantığı, durum makinesi veya servis katmanı güncellendiğinde
- Hata yönetimi, middleware veya rate limiting düzenlendiğinde

## İzlenecek Adımlar
1. `docs/API_DOCUMENTATION.md` ve `docs/MODULE_MAP.md` belgelerini kontrol et.
2. İstek/yanıt şemalarını `packages/shared` ve modül `schema.ts` içinde Zod ile tanımla.
3. Route üzerinde `requireAuth`, `requireRole`, `enforceStoreScope` ve mutasyonlarda `csrfProtection` zincirini bağla.
4. İş mantığını `service.ts` içinde Prisma transaction (`prisma.$transaction`) kullanarak atomik biçimde uygula.
5. Tüm kritik yazma işlemlerinde `auditService.log(...)` çağrısını aynı işlem kapsamında veya garantili şekilde kaydet.
6. `docs/API_DOCUMENTATION.md` dosyasını güncelle.

## Uyulması Gereken Kurallar
- İstemciden gelen `storeId` veya `cashierId` alanlarına yetki doğrulaması yapmadan güvenme.
- Parasal işlemlerde yalnızca `Decimal.js` kullan.
- Hassas alanları (`passwordHash`, `tokenHash`, dosya sistem tam yolu) API yanıtında asla döndürme.

## Etkilenecek Modüller
- `apps/api/src/modules/*`, `apps/api/src/middlewares/*`, `packages/shared`, `docs/API_DOCUMENTATION.md`

## Test Gereksinimleri
- Servis unit testleri + Supertest ile gerçek test PostgreSQL veritabanı üzerinde yetkili/yetkisiz API integration testleri.

## Tamamlanma Kriterleri
- Endpoint Zod doğrulamalı, RBAC/izole, denetim kayıtlı, belgelenmiş ve testleri yeşil.
