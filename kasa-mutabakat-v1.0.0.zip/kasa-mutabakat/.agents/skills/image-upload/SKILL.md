---
name: image-upload
description: IBAN dekont dosyalarının (JPG, JPEG, PNG, PDF) güvenli yüklenmesi, magic-bytes doğrulaması, SHA-256 özeti ve erişim kontrollü saklanmasını yönetir.
---

# Image Upload Skill

## Skill'in Amacı
Kasiyerlerin yüklediği banka transfer dekontlarını (JPG, JPEG, PNG, PDF) zararlı dosyalara karşı doğrulayarak güvenli biçimde depolamak ve yalnızca yetkili kişilere önizletmek.

## Ne Zaman Kullanılacağı
- Dekont yükleme uç noktası, dosya doğrulama veya depolama katmanı geliştirildiğinde/değiştirildiğinde
- Dosya boyutu, dosya tipi veya önizleme güvenliği güncellendiğinde

## İzlenecek Adımlar
1. Yükleyen kullanıcının kimliğini, aktif mağazasını ve açık kasa oturumunu oturumdan doğrula.
2. Dosya boyutunu `system_settings` / env limitine (varsayılan 10 MB) göre denetle.
3. Dosya uzantısı ve MIME tipine ek olarak gerçek **magic bytes** imzasını kontrol et (`FF D8 FF` JPEG, `89 50 4E 47` PNG, `%PDF-` PDF).
4. Dosyanın `SHA-256` özetini ve görsellerde algısal özetini (`dHash`) hesapla.
5. Orijinal dosyayı rastgele UUID adıyla web kökünün dışındaki `storage/receipts/YYYY/MM/` klasörüne kaydet.
6. Önizleme endpoint'inde yetki ve mağaza izolasyonu kontrolü yap; `X-Content-Type-Options: nosniff` ve `Content-Security-Policy: sandbox` başlıklarıyla servis et.

## Uyulması Gereken Kurallar
- Orijinal dekont dosyası hiçbir durumda silinmez.
- Yüklenen dosyalar asla herkese açık statik klasörden sunulmaz.
- Yürütülebilir dosya, SVG, HTML, sahte uzantılı içerik kesinlikle reddedilir.

## Etkilenecek Modüller
- `apps/api/src/modules/receipts/storage.ts`, `apps/api/src/modules/receipts/upload.ts`, `apps/web/src/features/receipts/`

## Test Gereksinimleri
- Geçerli JPG/PNG/PDF yükleme testi, sahte uzantılı/zararlı dosya reddi testi, boyut aşımı testi ve çapraz mağaza önizleme engeli testi.

## Tamamlanma Kriterleri
- Dosya güvenliği testlerle kanıtlanmış, SHA-256 ve orijinal saklama garantilenmiş.
