---
name: add-new-feature
description: İş akışı (Workflow): Mevcut çalışan sistemi bozmadan yeni bir özelliği analiz, plan, uygulama, test ve dokümantasyon zinciriyle ekler.
---

# Workflow: Add New Feature (`/add-new-feature`)

## Amaç
Kullanıcının yeni özellik talebini (ör. yeni rapor, kasiyer ekranı geliştirmesi, merkez paneli iyileştirmesi) kontrollü ve izlenebilir biçimde hayata geçirmek.

## Ne Zaman Kullanılacağı
- Mevcut çalışan uygulamaya yeni bir kullanıcı veya sistem özelliği eklendiğinde

## İzlenecek Adımlar
1. `docs/BLUEPRINT.md` ve ilgili alan Skill'ini oku.
2. Etki analizini çıkar; yalnızca gerekli modülleri kapsam içine al.
3. Gerekliyse veritabanı migration'ını hazırla.
4. Backend ve frontend değişikliklerini uygula.
5. Yeni özellik testlerini ve mevcut regresyon testlerini çalıştır.
6. `docs/BLUEPRINT.md`, `docs/API_DOCUMENTATION.md`, `docs/MODULE_MAP.md` ve `docs/CHANGELOG.md` dosyalarını güncelle.

## Uyulması Gereken Kurallar
- Mevcut çalışan özellikleri bozma; sahte veri kullanma; test etmeden tamamlama.

## Etkilenecek Modüller
- Özelliğin dokunduğu `shared`, `api`, `web` modülleri ve `docs/`.

## Test Gereksinimleri
- Yeni özellik testleri + tam regresyon testi yeşil geçmelidir.

## Tamamlanma Kriterleri
- Özellik gerçek DB ve API ile doğrulanmış, regresyon yok, dokümantasyon güncel.
