---
name: cashier-management
description: Kasiyer kullanıcı hesapları, vardiya/oturum bazlı günlük kasa takibi, gün içi tahsilatlar ve kasiyer bazlı açık/fazla hesaplamasını yönetir.
---

# Cashier Management Skill

## Skill'in Amacı
Her finansal işlemi sisteme kayıtlı bir kasiyer hesabına bağlamak; aynı mağazada aynı gün birden fazla kasiyerin bağımsız kasa kapanışlarını ve açık/fazla durumlarını kesin olarak takip etmek.

## Ne Zaman Kullanılacağı
- Kasiyer paneli, günlük kasa oturumu açma/kapatma, tahsilat girişi veya kasiyer bazlı fark takibi geliştirildiğinde/değiştirildiğinde

## İzlenecek Adımlar
1. Kasiyer bilgisinin serbest metin olmadığını, mutlaka `users` tablosundaki aktif hesaptan (`req.user.id` veya yetkili mağaza içi seçim) geldiğini doğrula.
2. `cash_sessions` oturumunu `(store_id, cashier_id, business_date, shift_no)` benzersiz anahtarıyla yönet.
3. Gün içi tahsilatları (`SALE`, `REFUND`, `CASH_IN`, `CASH_OUT`) yalnızca 3 ödeme yöntemiyle (`CASH`, `CREDIT_CARD`, `BANK_TRANSFER`) kaydet.
4. Oturum özetini her değişiklikte backend `ReconciliationCalculator` (`Decimal.js`) ile yeniden hesapla.
5. Gün sonunda kasiyer teslim beyanını (`declared_cash`) al, `cash_difference` değerini hesapla ve durumu `CASHIER_SUBMITTED` yap; mağaza yöneticisi kontrolüne gönder.

## Uyulması Gereken Kurallar
- Kasiyer yalnızca kendi mağazasındaki kendi oturumlarını ve kendi dekontlarını görebilir/işleyebilir.
- Kasiyer serbest metinle isim girerek işlem yapamaz.
- Onaylanmış veya kilitli oturuma yeni işlem eklenemez, mevcut işlem iptal edilemez.

## Etkilenecek Modüller
- `apps/api/src/modules/cash-sessions/*`, `apps/api/src/modules/cash-transactions/*`, `apps/web/src/features/cash/`

## Test Gereksinimleri
- Aynı mağazada aynı gün 2 farklı kasiyerin bağımsız oturum açma/kapama testi, kasa açığı/fazlası/eşitlik testi, kasiyerin başka kasiyer verisine erişememe testi.

## Tamamlanma Kriterleri
- Kasiyer bazlı tüm toplamlar ve açık/fazla tutarları doğru hesaplanıyor, mağaza yöneticisi ve merkez ekranlarına eksiksiz yansıyor.
