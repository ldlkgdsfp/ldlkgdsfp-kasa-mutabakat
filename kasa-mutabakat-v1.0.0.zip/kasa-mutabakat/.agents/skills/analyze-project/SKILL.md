---
name: analyze-project
description: İş akışı (Workflow): Mevcut proje yapısını, modülleri, veritabanı şemasını, test durumunu ve teknik borçları kod değiştirmeden analiz eder.
---

# Workflow: Analyze Project (`/analyze-project`)

## Amaç
Kod tabanını, modüller arası bağımlılıkları, veritabanı şemasını ve güvenlik/test durumunu **hiçbir kod değiştirmeden** bütüncül olarak incelemek.

## Ne Zaman Kullanılacağı
- Bir değişiklik öncesi proje durumunu netleştirmek için
- Kullanıcı "Proje analizi" veya "Mevcut projeyi analiz et" dediğinde

## İzlenecek Adımlar
1. `docs/BLUEPRINT.md`, `docs/SYSTEM_ARCHITECTURE.md`, `docs/DATABASE_SCHEMA.md` ve `docs/MODULE_MAP.md` dosyalarını oku.
2. `apps/api/prisma/schema.prisma`, `apps/api/src/modules/` ve `apps/web/src/features/` dizinlerini gerçek dosya ağacıyla karşılaştır.
3. Dokümantasyon ile gerçek kod arasında sapma olup olmadığını denetle.
4. Mevcut testlerin ve tip kontrolünün durumunu salt-okunur biçimde raporla.
5. Kod değişikliği yapmadan Türkçe özet rapor sun.

## Uyulması Gereken Kurallar
- Bu iş akışında kaynak koda veya veritabanına yazma/değiştirme yapılmaz.

## Etkilenecek Modüller
- Salt-okunur: tüm depo (`apps/api`, `apps/web`, `packages/shared`, `docs/`).

## Test Gereksinimleri
- Gerekirse yalnızca mevcut test komutları salt-okunur doğrulama için çalıştırılır.

## Tamamlanma Kriterleri
- Modüller, eksikler, riskler ve doküman uyumu net bir Türkçe raporda sunulmuştur.
