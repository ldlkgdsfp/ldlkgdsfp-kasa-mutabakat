---
name: frontend-development
description: React, TypeScript ve Tailwind CSS arayüz geliştirme, Türkçe yerelleştirme, erişilebilirlik ve responsive tasarım standartlarını uygular. Yeni ekran, form, tablo veya tasarım değişikliği yaparken kullan.
---

# Frontend Development Skill

## Skill'in Amacı
Kurumsal, hızlı, erişilebilir, mobil/masaüstü uyumlu ve tamamen Türkçe kullanıcı arayüzü geliştirmek.

## Ne Zaman Kullanılacağı
- Yeni sayfa, panel, form, grafik veya tablo oluşturulduğunda
- Kullanıcı deneyimi, navigasyon veya tasarım iyileştirildiğinde
- Dekont önizleme, filtreleme veya durum göstergesi eklendiğinde

## İzlenecek Adımlar
1. `docs/BLUEPRINT.md` ve ilgili backend API sözleşmesini (`docs/API_DOCUMENTATION.md`) incele.
2. `packages/shared` içindeki Zod şemaları ve tip tanımlarını kullan.
3. Öncelikle `modern-web-guidance` ile ilgili HTML/CSS/erişilebilirlik kurallarını doğrula.
4. Rol tabanlı görünürlük kontrollerini uygula (asıl güvenlik backend'dedir, UI yalnızca yetkili ekranları sunar).
5. Masaüstü ve mobil kırılım noktalarında taşma/kırılma olmadığını ve klavye/ekran okuyucu erişilebilirliğini kontrol et.

## Uyulması Gereken Kurallar
- Tüm etiketler, mesajlar, butonlar ve tarih/para formatları Türkçe (`₺`, `GG.AA.YYYY`) olmalıdır.
- Frontend'de finansal mutabakat hesabı üretme; yalnızca backend'den gelen değerleri formatlayıp göster.
- Açık (kırmızı), fazla (kehribar/mavi) ve eşit (yeşil) durum göstergeleri renk yanında metin/ikonla da ayırt edilmelidir.
- Form hataları kullanıcı etkileşimi sonrası erişilebilir (`aria-invalid`, `role="alert"`) biçimde sunulur.

## Etkilenecek Modüller
- `apps/web/src/features/*`, `apps/web/src/components/*`, `apps/web/src/app/*`, `packages/shared`

## Test Gereksinimleri
- `pnpm --filter @kasa/web typecheck`, `pnpm --filter @kasa/web build`, bileşen testleri ve ilgili Playwright E2E senaryoları geçmelidir.

## Tamamlanma Kriterleri
- Responsive, Türkçe, erişilebilir, tip hatasız ve gerçek API ile çalışan arayüz teslim edilmiştir.
