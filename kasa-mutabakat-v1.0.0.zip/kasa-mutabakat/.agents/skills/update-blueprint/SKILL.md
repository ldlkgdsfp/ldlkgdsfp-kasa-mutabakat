---
name: update-blueprint
description: İş akışı (Workflow): Gerçek koda ve son değişikliklere göre BLUEPRINT.md ve tüm docs/*.md teknik belgelerini eşitler.
---

# Workflow: Update Blueprint (`/update-blueprint`)

## Amaç
`docs/` altındaki mimari, şema, API, modül haritası, güvenlik, test ve değişiklik günlüğü belgelerinin gerçek kodla birebir tutarlı kalmasını sağlamak.

## Ne Zaman Kullanılacağı
- Her aşama tamamlandığında veya kullanıcı "Planı güncelle" dediğinde

## İzlenecek Adımlar
1. Mevcut `apps/api/prisma/schema.prisma`, `apps/api/src/modules/`, `apps/web/src/features/` ve test sonuçlarını incele.
2. `docs/BLUEPRINT.md`, `docs/SYSTEM_ARCHITECTURE.md`, `docs/DATABASE_SCHEMA.md`, `docs/API_DOCUMENTATION.md`, `docs/MODULE_MAP.md`, `docs/SECURITY_PLAN.md`, `docs/TEST_PLAN.md` belgelerini gerçek kodla karşılaştırıp güncelle.
3. `docs/CHANGELOG.md` dosyasına tarihli yeni değişiklik maddesini ekle.
4. Mevcut olmayan hiçbir özelliği varmış gibi yazmadığını doğrula.

## Uyulması Gereken Kurallar
- Dokümantasyon daima gerçek çalışan kodu yansıtmalıdır; planlanan maddeler açıkça "Planlanan" etiketiyle ayrılmalıdır.

## Etkilenecek Modüller
- `docs/*.md`, `AGENTS.md`.

## Test Gereksinimleri
- Belgelerdeki komutların ve dosya yollarının gerçek dosyalarla eşleştiği doğrulanır.

## Tamamlanma Kriterleri
- Tüm 8 teknik doküman ve `WORKFLOWS_INDEX.md` gerçek kodla senkronizedir.
