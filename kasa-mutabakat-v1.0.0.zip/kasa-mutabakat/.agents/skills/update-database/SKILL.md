---
name: update-database
description: İş akışı (Workflow): PostgreSQL/Prisma şema değişikliklerini veri kaybı analizi, migration, indeks kontrolü ve test veritabanı doğrulamasıyla güvenli şekilde uygular.
---

# Workflow: Update Database (`/update-database`)

## Amaç
Veritabanına yeni tablo, alan, indeks veya kısıt eklerken finansal veri bütünlüğünü ve geri dönülebilirliği korumak.

## Ne Zaman Kullanılacağı
- Kullanıcı "Veritabanına yeni alan ekle" dediğinde veya yeni özellik şema değişikliği gerektirdiğinde

## İzlenecek Adımlar
1. `.agents/skills/database-management/SKILL.md` ve `docs/DATABASE_SCHEMA.md` belgelerini oku.
2. Şema değişikliğini ve veri kaybı/kilit riskini raporla; yıkıcı değişiklik varsa kullanıcı onayı al.
3. `apps/api/prisma/schema.prisma` dosyasını güncelle (`DECIMAL(14,2)`, `ON DELETE RESTRICT`).
4. `prisma migrate dev --name <ad>` ile migration oluştur ve üretilen SQL'i gözden geçir.
5. Test veritabanında `prisma migrate deploy` ve tüm integration testlerini çalıştır.
6. `docs/DATABASE_SCHEMA.md` ve `docs/CHANGELOG.md` dosyalarını güncelle.

## Uyulması Gereken Kurallar
- Üretim verisini silen/sıfırlayan komutlar kullanıcı onayı olmadan yasaktır.

## Etkilenecek Modüller
- `apps/api/prisma/*`, ilgili backend servisleri, `docs/DATABASE_SCHEMA.md`.

## Test Gereksinimleri
- Migration temiz DB'ye uygulanabilmeli ve tüm integration testleri geçmelidir.

## Tamamlanma Kriterleri
- Migration ve Prisma Client güncel, test DB yeşil, şema dokümantasyonu eşlenmiş.
