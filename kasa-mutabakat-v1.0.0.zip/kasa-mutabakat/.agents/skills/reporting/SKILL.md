---
name: reporting
description: 9 finansal raporun (günlük mağaza, mağaza karşılaştırma, kasiyer farkı, ödeme dağılımı, IBAN, onay bekleyenler, açık/fazla, tarih aralığı, aylık özet) üretimi, grafikler ve Excel/CSV dışa aktarımını yönetir.
---

# Reporting Skill

## Skill'in Amacı
Yönetim ve muhasebe için doğru, filtrelenebilir, sıralanabilir ve Excel (`.xlsx`) / CSV (`.csv`) olarak dışa aktarılabilir 9 profesyonel finansal rapor üretmek.

## Ne Zaman Kullanılacağı
- Yeni rapor eklendiğinde, mevcut rapor filtresi/sıralaması güncellendiğinde veya Excel/CSV dışa aktarım biçimi değiştirildiğinde

## İzlenecek Adımlar
1. Raporun rol ve mağaza kapsamını doğrula (`STORE_MANAGER` sadece kendi mağazasını, `CASHIER` sadece kendi özetini, `CENTRAL_ACCOUNTING` ve `SYSTEM_ADMIN` tüm mağazaları görebilir).
2. Verileri PostgreSQL toplama sorguları ve backend `Decimal.js` hesaplamalarıyla üret; sahte veri kullanma.
3. Tarih aralığı, mağaza, kasiyer, durum ve sıralama parametrelerini Zod ile doğrula.
4. Excel (`.xlsx`) dışa aktarımında `exceljs` ile Türkçe başlıklar, para biçimi (`#,##0.00 ₺`) ve sütun genişlikleri uygula.
5. CSV dışa aktarımında UTF-8 BOM (`\uFEFF`) ekle ve formül enjeksiyonuna (`=`, `+`, `-`, `@`) karşı hücre sanitizasyonu uygula.
6. Frontend'de Recharts grafiklerini ve erişilebilir responsive tabloları bağla.

## Uyulması Gereken Kurallar
- Rapor toplamları `cash_sessions` ve `central_reconciliations` hesaplama kurallarıyla %100 tutarlı olmalıdır.
- Mükerrer veya onaylanmamış dekontlar IBAN onaylı toplamlarına karıştırılmamalıdır.

## Etkilenecek Modüller
- `apps/api/src/modules/reports/*`, `apps/web/src/features/reports/*`

## Test Gereksinimleri
- Tüm 9 rapor endpoint'i için veri doğruluğu testi, mağaza izolasyonu testi, XLSX/CSV üretimi ve CSV formula-injection koruması testi.

## Tamamlanma Kriterleri
- 9 raporun tamamı filtrelenebiliyor, sıralanabiliyor, grafikleri doğru ve XLSX/CSV dosyaları bozulmadan açılıyor.
