---
name: develop-module
description: İş akışı (Workflow): Onaylanmış bir modülü küçük, kontrollü ve test edilmiş adımlarla (shared -> DB -> backend -> frontend -> docs) geliştirir.
---

# Workflow: Develop Module (`/develop-module`)

## Amaç
Belirli bir iş modülünü mimari sınırları koruyarak ve her katmanda doğrulama yaparak geliştirmek.

## Ne Zaman Kullanılacağı
- Yeni bir modül geliştirilirken veya mevcut bir modüle kapsamlı yetenek eklenirken

## İzlenecek Adımlar
1. `docs/BLUEPRINT.md` ve ilgili alan Skill'ini oku.
2. `packages/shared` içinde tipler ve Zod şemalarını tanımla.
3. Gerekliyse `update-database` iş akışıyla Prisma şemasını ve migration'ı hazırla.
4. Backend (`schema`, `service`, `controller`, `routes`) katmanını RBAC, Store Scope Guard, `Decimal.js` ve audit kaydıyla yaz.
5. Backend unit ve integration testlerini yaz ve çalıştır.
6. Frontend ekranını Türkçe, responsive ve erişilebilir biçimde geliştir.
7. `docs/` belgelerini güncelle ve regresyon testlerini çalıştır.

## Uyulması Gereken Kurallar
- İlgisiz modülleri değiştirme; finansal hesaplamayı asla frontend'e taşıma.

## Etkilenecek Modüller
- Hedef modül (`packages/shared`, `apps/api/src/modules/<modül>`, `apps/web/src/features/<modül>`, `docs/`).

## Test Gereksinimleri
- Hedef modülün unit + integration + frontend build/testleri ve regresyon kontrolü geçmelidir.

## Tamamlanma Kriterleri
- Modül uçtan uca çalışıyor, testler yeşil ve dokümantasyon güncel.
