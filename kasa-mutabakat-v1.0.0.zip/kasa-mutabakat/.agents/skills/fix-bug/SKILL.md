---
name: fix-bug
description: İş akışı (Workflow): Hatanın kök nedenini yeniden üretilebilir testle saptar, kapsamlı biçimde düzeltir ve regresyonu doğrular.
---

# Workflow: Fix Bug (`/fix-bug`)

## Amaç
Bir yazılım veya finansal hesaplama hatasını geçici yama yerine kök nedeninden çözmek ve aynı hatanın tekrar oluşmasını kalıcı testle engellemek.

## Ne Zaman Kullanılacağı
- Kullanıcı "Bir hatayı düzelt" dediğinde veya test/kullanım sırasında beklenmedik davranış saptandığında

## İzlenecek Adımlar
1. `docs/BLUEPRINT.md` ve ilgili alan Skill'ini oku.
2. Hatayı yeniden üreten minimal bir unit/integration/E2E testi yaz ve fail ettiğini doğrula.
3. Kök nedeni saptayıp yalnızca ilgili modülde temiz düzeltme uygula.
4. Yeni testin ve tüm regresyon testlerinin geçtiğini doğrula.
5. Gerekliyse `docs/CHANGELOG.md` ve ilgili teknik dokümanları güncelle.

## Uyulması Gereken Kurallar
- Hata ayıklarken güvenlik kontrollerini, tip kontrollerini veya finansal doğrulamaları gevşetme.

## Etkilenecek Modüller
- Hatanın kaynağı olan modül ve ilgili test dosyaları.

## Test Gereksinimleri
- Hatayı yakalayan regresyon testi + tam modül test paketi geçmelidir.

## Tamamlanma Kriterleri
- Kök neden giderilmiş, regresyon testi eklenmiş ve tüm testler yeşil.
