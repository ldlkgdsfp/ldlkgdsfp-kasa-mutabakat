---
name: security-audit
description: Kimlik doğrulama, RBAC, mağaza izolasyonu, dosya yükleme, XSS/CSRF/SQLi, rate limiting ve gizli bilgi güvenliği denetimi yürütür.
---

# Security Audit Skill

## Skill'in Amacı
Uygulamanın OWASP standartlarına ve proje güvenlik kurallarına tam uyumunu sistematik olarak doğrulamak ve zafiyetleri gidermek.

## Ne Zaman Kullanılacağı
- Yeni bir modül tamamlandığında, kimlik doğrulama/yetkilendirme/dosya yükleme değiştiğinde veya sürüm öncesi güvenlik taramasında

## İzlenecek Adımlar
1. `.agents/rules/security_rules.md` ve `docs/SECURITY_PLAN.md` belgelerini kontrol et.
2. Tüm API route'larını tarayarak eksik `requireAuth`, `requireRole`, `enforceStoreScope` veya `csrfProtection` olup olmadığını doğrula.
3. Dosya yükleme ve önizleme uç noktalarında magic-byte kontrolü, boyut sınırı, path traversal engeli ve erişim kontrolünü test et.
4. Kaynak kodda hardcoded sır, API anahtarı veya parola kalmadığını `rg` ile tara.
5. Rate limiting, hesap kilitleme, güvenlik başlıkları (`helmet`), SQLi/XSS ve CSV enjeksiyonu testlerini çalıştır.
6. Bulguları `docs/SECURITY_PLAN.md` ve ilgili düzeltme kayıtlarıyla belgele.

## Uyulması Gereken Kurallar
- Hiçbir güvenlik kontrolü test geçsin diye gevşetilmez veya kapatılmaz.
- Üretim sırları asla loglanmaz veya repoya eklenmez.

## Etkilenecek Modüller
- `apps/api/src/middlewares/*`, `apps/api/src/modules/auth/*`, `apps/api/src/modules/receipts/*`, `apps/api/src/config/*`, `docs/SECURITY_PLAN.md`

## Test Gereksinimleri
- Otomatik güvenlik entegrasyon testleri (yetkisiz erişim 401/403, çapraz mağaza reddi, CSRF reddi, zararlı dosya reddi, rate limit testi) geçmelidir.

## Tamamlanma Kriterleri
- Kritik veya yüksek seviye açık bulgu yok, tüm güvenlik testleri yeşil ve `docs/SECURITY_PLAN.md` güncel.
