---
name: reconciliation
description: Backend Decimal.js finansal hesaplama motorunu, günlük beklenen nakit, kasa açığı/fazlası ve onaylı Havale/EFT mutabakat hesabını yönetir.
---

# Reconciliation Skill

## Skill'in Amacı
Mağaza ve kasiyer bazlı günlük mutabakat hesaplamalarını tam ondalık kesinlikle (`Decimal.js`), ödeme yöntemlerini karıştırmadan ve yalnızca backend tarafında gerçekleştirmek.

## Ne Zaman Kullanılacağı
- Günlük mutabakat formülleri, kasa farkı hesabı veya onaylı dekont toplamı mantığı geliştirildiğinde/güncellendiğinde

## İzlenecek Adımlar
1. `.agents/rules/financial_calculation_rules.md` kurallarını oku.
2. Tüm hesaplamaları `apps/api/src/modules/reconciliation/calculator.ts` içinde saf (pure) fonksiyonlarla `Decimal.js` kullanarak yaz.
3. Beklenen nakit formülünü uygula: `opening_cash + cash_sales + other_cash_in - cash_refunds - other_cash_out`.
4. Kredi kartı ve Havale/EFT tutarlarını nakit hesabından kesinlikle ayrı tut.
5. Havale/EFT toplamına yalnızca `status = APPROVED` ve `is_duplicate = false` (ve sistem ayarı aktifse `bank_account_verified = true`) dekontları dahil et.
6. Kasa farkını hesapla (`declared_cash - expected_cash` ve merkez için `central_verified_cash - expected_cash`).

## Uyulması Gereken Kurallar
- Kayan noktalı `Number` aritmetiği yasaktır (`0.1 + 0.2` sapması olmamalı).
- Hesaplamalar yalnızca backend'de yapılır; frontend hesaplamaya güvenilmez.
- Onaylı/kilitli mutabakatlar doğrudan güncellenmez; `financial_adjustments` kaydı oluşturulur.

## Etkilenecek Modüller
- `apps/api/src/modules/reconciliation/*`, `cash_sessions`, `central_reconciliations`, `reconciliation_items`, `financial_adjustments`

## Test Gereksinimleri
- Kuruş yuvarlama testleri, kredi kartının nakde karışmadığı testi, mükerrer/onaysız dekontun toplama girmediği testi, açık/fazla/eşit sınır testi, kilitli mutabakat değişiklik engeli testi.

## Tamamlanma Kriterleri
- Tüm finansal hesaplama unit ve integration testleri %100 yeşil.
