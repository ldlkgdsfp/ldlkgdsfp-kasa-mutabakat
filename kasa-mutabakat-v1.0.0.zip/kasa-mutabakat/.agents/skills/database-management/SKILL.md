---
name: database-management
description: PostgreSQL ve Prisma şema tasarımı, migration hazırlama, indeks yönetimi, seed ve yedekleme/geri yükleme süreçlerini yönetir. Veritabanına tablo, kolon veya kısıt eklerken kullan.
---

# Database Management Skill

## Skill'in Amacı
PostgreSQL 16 + Prisma ORM şemasının finansal bütünlüğünü, ondalık kesinliğini, silme korumasını ve güvenli migration süreçlerini sağlamak.

## Ne Zaman Kullanılacağı
- Yeni tablo, alan, ilişki, enum veya indeks eklendiğinde
- Migration veya başlangıç seed verisi güncellendiğinde
- Yedekleme, geri yükleme veya sorgu performansı iyileştirildiğinde

## İzlenecek Adımlar
1. `docs/DATABASE_SCHEMA.md` ve `apps/api/prisma/schema.prisma` dosyalarını incele.
2. Değişikliğin veri kaybı riski taşıyıp taşımadığını kontrol et; risk varsa önce kullanıcı onayı al.
3. Parasal alanların `@db.Decimal(14, 2)`, silme davranışlarının `onDelete: Restrict` olduğundan emin ol.
4. `pnpm --filter @kasa/api prisma migrate dev --name <aciklayici_ad>` ile migration oluştur; kısmi benzersizlik indeksleri veya CHECK kısıtları gerekiyorsa SQL migration dosyasına ekle.
5. `prisma generate` çalıştır, test veritabanına migration uygula ve integration testlerini koş.
6. `docs/DATABASE_SCHEMA.md` ve `docs/CHANGELOG.md` belgelerini güncelle.

## Uyulması Gereken Kurallar
- Finansal kolonlarda `Float`/`Double` kesinlikle yasaktır.
- Finansal tablolar, mağazalar ve kullanıcılar fiziksel olarak silinmez.
- `seed.ts` yalnızca referans verilerini (roller, ödeme yöntemleri, mağazalar, ayarlar, başlangıç kullanıcıları) içerir; sahte finansal işlem üretmez.
- Kullanıcı onayı olmadan üretim verisini silen veya sıfırlayan komut çalıştırma.

## Etkilenecek Modüller
- `apps/api/prisma/schema.prisma`, `apps/api/prisma/migrations/*`, `apps/api/prisma/seed.ts`, `scripts/db-*.sh`, `docs/DATABASE_SCHEMA.md`

## Test Gereksinimleri
- Temiz test veritabanında `prisma migrate deploy` + `seed` + integration test paketi hatasız çalışmalıdır.

## Tamamlanma Kriterleri
- Migration tekrarlanabilir şekilde uygulanıyor, Prisma tipleri güncel, kısıtlar ve indeksler doğrulanmış, şema dokümantasyonu eşlenmiş.
