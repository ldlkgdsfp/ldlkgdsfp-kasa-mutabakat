---
name: plan-feature
description: İş akışı (Workflow): Yeni bir özellik veya modül değişikliği için BLUEPRINT ve ilgili Skill tabanlı etki analizi ve küçük adımlı uygulama planı hazırlar.
---

# Workflow: Plan Feature (`/plan-feature`)

## Amaç
Herhangi bir kod değişikliğine başlamadan önce etkilenen modülleri, veritabanı gereksinimlerini, finansal/güvenlik risklerini ve test senaryolarını netleştirmek.

## Ne Zaman Kullanılacağı
- Kullanıcı yeni bir özellik, rapor, ekran veya iş kuralı talep ettiğinde

## İzlenecek Adımlar
1. `docs/BLUEPRINT.md` ve `docs/MODULE_MAP.md` dosyalarını oku.
2. İsteğe karşılık gelen alan Skill'ini (`.agents/skills/<ad>/SKILL.md`) oku.
3. Etkilenecek tabloları, API endpoint'lerini, frontend ekranlarını ve paylaşılacak `packages/shared` sözleşmelerini çıkar.
4. Kapsam dışı modülleri açıkça belirt (gereksiz modüllere dokunma).
5. Veritabanı migration, finansal hesaplama ve güvenlik gereksinimlerini listele.
6. Test planı ve kabul kriterleriyle birlikte kullanıcı onayına sun.

## Uyulması Gereken Kurallar
- Plan onaylanmadan kritik şema veya finansal kural değişikliği uygulanmaz.

## Etkilenecek Modüller
- Yalnızca planlanan özelliğin kapsadığı modüller.

## Test Gereksinimleri
- Planda unit, integration ve gerekirse E2E test senaryoları açıkça tanımlanmalıdır.

## Tamamlanma Kriterleri
- Onaylanabilir, küçük adımlı, etki analizi tamamlanmış uygulama planı hazırdır.
