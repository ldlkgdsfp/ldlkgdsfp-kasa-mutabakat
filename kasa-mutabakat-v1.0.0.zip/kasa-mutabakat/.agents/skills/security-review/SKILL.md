---
name: security-review
description: İş akışı (Workflow): RBAC, mağaza izolasyonu, dosya yükleme, CSRF/XSS/SQLi, rate limiting ve gizli bilgi güvenliği incelemesi yapar.
---

# Workflow: Security Review (`/security-review`)

## Amaç
Kod tabanını güvenlik açıklarına, yetki atlamalarına ve veri sızıntılarına karşı sistematik olarak incelemek.

## Ne Zaman Kullanılacağı
- Kimlik doğrulama, yetki, dosya yükleme veya yeni API uç noktası eklendikten sonra ve sürüm öncesi

## İzlenecek Adımlar
1. `.agents/skills/security-audit/SKILL.md` ve `.agents/rules/security_rules.md` dosyalarını oku.
2. Tüm route tanımlarında `requireAuth`, `requireRole`, `enforceStoreScope` ve `csrfProtection` zincirini denetle.
3. Dosya yükleme ve önizleme katmanında magic-bytes, boyut sınırı, path traversal ve erişim kontrolünü kontrol et.
4. Hardcoded sır, token veya parola taraması yap (`rg`).
5. Güvenlik testlerini çalıştır ve bulguları `docs/SECURITY_PLAN.md` içinde güncelle.

## Uyulması Gereken Kurallar
- Kritik veya yüksek riskli bulgu çözülmeden sürüm onaylanmaz.

## Etkilenecek Modüller
- `apps/api/src/middlewares/*`, tüm API route'ları, dosya depolama katmanı, `docs/SECURITY_PLAN.md`.

## Test Gereksinimleri
- Güvenlik integration test paketi %100 yeşil geçmelidir.

## Tamamlanma Kriterleri
- Tüm güvenlik maddeleri doğrulandı, açık bulgu kalmadı.
