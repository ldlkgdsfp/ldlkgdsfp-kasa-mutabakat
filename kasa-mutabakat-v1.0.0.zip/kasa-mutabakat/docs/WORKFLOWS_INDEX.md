# Antigravity Workflows ve Skills Dizini

Güncel Google Antigravity sürümünde (2.0+) eski `.agents/workflows/*.md` dizini 19 Ekim 2026 itibarıyla kullanımdan kaldırılmıştır. Tüm tekrarlanabilir iş akışları (Workflows) ve alan becerileri (Skills), Antigravity'nin native `/slash-komut` ve anlamsal keşif standardı olan `.agents/skills/<ad>/SKILL.md` yapısında konumlandırılmıştır.

## Proje Kuralları (`.agents/rules/` + `AGENTS.md`)

| Dosya | Tetikleyici (`trigger`) | Kapsam |
| :--- | :--- | :--- |
| `AGENTS.md` | Her zaman aktif | Kök proje kuralları ve değişiklik protokolü |
| `.agents/rules/project_rules.md` | `always_on` | Mimari ilkeler, modül sınırları, Türkçe yerelleştirme |
| `.agents/rules/coding_standards.md` | `always_on` | TypeScript, Express, React, Zod, test standartları |
| `.agents/rules/security_rules.md` | `always_on` | Auth, RBAC, mağaza izolasyonu, dosya ve enjeksiyon güvenliği |
| `.agents/rules/database_rules.md` | `model_decision` | PostgreSQL `DECIMAL(14,2)`, silme koruması, migration disiplini |
| `.agents/rules/financial_calculation_rules.md` | `always_on` | `Decimal.js` formülleri, ödeme yöntemi izolasyonu, bakiye dışlama |

## İş Akışları (Workflows — `/komut` olarak çağrılabilir)

| Komut | Dosya | Amaç |
| :--- | :--- | :--- |
| `/analyze-project` | `.agents/skills/analyze-project/SKILL.md` | Kod değiştirmeden tam proje ve modül analizi |
| `/plan-feature` | `.agents/skills/plan-feature/SKILL.md` | Etki analizi ve küçük adımlı uygulama planı |
| `/develop-module` | `.agents/skills/develop-module/SKILL.md` | Katmanlı ve testli modül geliştirme |
| `/update-database` | `.agents/skills/update-database/SKILL.md` | Güvenli Prisma şema ve migration süreci |
| `/add-new-feature` | `.agents/skills/add-new-feature/SKILL.md` | Mevcut sistemi bozmadan yeni özellik ekleme |
| `/fix-bug` | `.agents/skills/fix-bug/SKILL.md` | Kök neden analizi + regresyon testi ile hata giderme |
| `/test-module` | `.agents/skills/test-module/SKILL.md` | Tek modül unit + integration test doğrulaması |
| `/regression-test` | `.agents/skills/regression-test/SKILL.md` | Tüm monorepo regresyon ve E2E test paketi |
| `/security-review` | `.agents/skills/security-review/SKILL.md` | Güvenlik denetimi ve OWASP kontrolü |
| `/update-blueprint` | `.agents/skills/update-blueprint/SKILL.md` | `docs/*.md` belgelerini gerçek kodla eşitleme |
| `/github-commit` | `.agents/skills/github-commit/SKILL.md` | Gizli dosya kontrolü, commit planı ve onaylı push |

## Alan Becerileri (Domain Skills — 15 Adet)

`project-architecture`, `database-management`, `frontend-development`, `backend-development`, `image-upload`, `ocr-ai-analysis`, `duplicate-detection`, `cashier-management`, `store-management`, `reconciliation`, `central-control`, `reporting`, `security-audit`, `testing-qa`, `github-management`.
