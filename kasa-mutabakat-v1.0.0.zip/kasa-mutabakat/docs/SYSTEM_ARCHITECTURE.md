# Sistem Mimarisi (`SYSTEM_ARCHITECTURE`)

## 1. Mimari Model
**pnpm Monorepo – Modüler Monolit REST API + React SPA + Ortak Sözleşmeler**

- `packages/shared` (`@kasa/shared`): Ortak TypeScript tipleri, Zod doğrulama şemaları, rol/durum sabitleri, Türkçe `₺` ve `GG.AA.YYYY` formatlayıcılar.
- `apps/api` (`@kasa/api`): Node.js 22 + TypeScript + Express + Prisma ORM + PostgreSQL 16 + `Decimal.js` + Pino.
- `apps/web` (`@kasa/web`): React 19 + TypeScript + Vite + Tailwind CSS + React Router + TanStack Query + Recharts.

## 2. Katmanlı Backend Tasarımı
`HTTP İstek -> Security Middlewares (Helmet, CORS, Rate Limit, Cookie, Auth, CSRF, RBAC, Store Scope) -> Zod Validation -> Controller -> Service (Decimal.js + Prisma Transaction + Audit Log) -> PostgreSQL 16`

## 3. Oturum ve Güvenlik Mimarisi
- Sunucu taraflı oturumlar `user_sessions` tablosunda SHA-256 hash'li token ile saklanır.
- Tarayıcıya `HttpOnly`, `SameSite=Lax` (üretimde `Secure`) çerezi ve her mutasyon isteğinde `X-CSRF-Token` başlığı ile doğrulanan CSRF token'ı verilir.
- Rol veya mağaza değişikliği oturum sorgusunda anında geçerli olur.

## 4. Dosya Depolama ve OCR Mimarisi (Aktif)
- Orijinal dekontlar web kökünün dışında `storage/receipts/YYYY/MM/<uuid>.<ext>` yolunda saklanır ve asla silinmez.
- `OcrProvider` arayüzü varsayılan yerel OCR (`pdftotext`/`pdftoppm` + `sharp` + `tesseract -l tur+eng`) ve `.env` ile etkinleşen opsiyonel harici AI Vision adaptörünü destekler.
- `TurkishBankReceiptParser` hesap bakiyesini ve masrafları dışlar; 4 katmanlı `detectDuplicateReceipt` + PostgreSQL kısmi benzersiz indeksleri çift sayımı engeller.

## 5. Finansal Hesaplama, Mutabakat ve Raporlama Mimarisi (Aktif)
- Tüm parasal hesaplamalar yalnızca backend'de `Decimal.js` (`ROUND_HALF_UP`) ve PostgreSQL `DECIMAL(14,2)` ile yapılır.
- Onaylanan mutabakatlar `is_locked = true` ile kilitlenir; sonradan değişiklik yalnızca gerekçeli `financial_adjustments` ve `audit_logs` üzerinden yapılır.
- 9 finansal rapor `reports.service.ts` üzerinden gerçek veriden hesaplanır; `exceljs` (`.xlsx`) ve UTF-8 BOM + OWASP formül korumalı `.csv` olarak dışa aktarılır.
