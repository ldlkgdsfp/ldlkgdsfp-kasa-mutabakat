# API Dokümantasyonu (`API_DOCUMENTATION`)

**Taban Yol:** `/api/v1`  
**Kimlik Doğrulama:** `HttpOnly` oturum çerezi (`kasa_session`)  
**CSRF Koruması:** Tüm `POST`, `PUT`, `PATCH`, `DELETE` isteklerinde (giriş hariç) `X-CSRF-Token` başlığı zorunludur.

## Sağlık Kontrolü
- `GET /api/v1/health` — Sunucu ve PostgreSQL bağlantı durumu.

## Kimlik Doğrulama (`/api/v1/auth`)
- `POST /api/v1/auth/login` — Kullanıcı adı veya e-posta + parola ile giriş; 5 ardışık hatalı denemede 15 dk hesap kilitleme.
- `GET /api/v1/auth/me` — Aktif kullanıcı, rol, mağaza ve geçerli `csrfToken`.
- `POST /api/v1/auth/logout` — Mevcut oturumu veritabanında iptal eder (`X-CSRF-Token`).
- `POST /api/v1/auth/logout-all` — Kullanıcının tüm aktif oturumlarını iptal eder (`X-CSRF-Token`).

## Mağaza Yönetimi (`/api/v1/stores`)
- `GET /api/v1/stores` — Yetki kapsamına göre mağaza listesi.
- `GET /api/v1/stores/:storeId` — Tekil mağaza detayı (mağaza kapsam kontrolü zorunlu).
- `POST /api/v1/stores` — Yeni mağaza/birim oluşturma (`SYSTEM_ADMIN`, `X-CSRF-Token`).
- `PATCH /api/v1/stores/:storeId` — Dinamik mağaza adı, telefon, adres ve aktiflik güncelleme (`SYSTEM_ADMIN`, `X-CSRF-Token`, audit log).

## Personel ve Rol Yönetimi (`/api/v1/users`)
- `GET /api/v1/users/roles` — 4 sabit rol listesi.
- `GET /api/v1/users` — Rol/mağaza kapsamlı personel listesi (`storeId`, `roleCode`, `onlyActive` filtreleri).
- `POST /api/v1/users` — Yeni personel/kasiyer oluşturma (`SYSTEM_ADMIN`, mağaza rolleri için aktif `STORE` zorunlu).
- `PATCH /api/v1/users/:userId` — Personel bilgisi, rol/mağaza, aktiflik veya parola sıfırlama (`SYSTEM_ADMIN`; pasifleştirme ve parola değişiminde aktif oturumlar anında iptal edilir).

## Sistem Ayarları (`/api/v1/settings`)
- `GET /api/v1/settings` — Sistem eşik ve yapılandırma ayarları (`SYSTEM_ADMIN`, `CENTRAL_ACCOUNTING`).
- `PATCH /api/v1/settings/:key` — Ayar güncelleme (`SYSTEM_ADMIN`, audit log).

## Günlük Kasa Oturumları ve Hareketleri (`/api/v1/cash-sessions`)
- `GET /api/v1/cash-sessions` — Tarih (`businessDate` veya `startDate`/`endDate`), `storeId`, `cashierId`, `status` filtreli kasa oturumları + `Decimal.js` genel toplam (`totals`), mağaza özeti (`byStore`) ve kasiyer bazlı fark özeti (`byCashier`).
- `POST /api/v1/cash-sessions` — Kasiyer bazlı yeni günlük kasa oturumu açma (aynı mağazada aynı gün birden fazla kasiyer bağımsız oturum açabilir; kasiyer hesaptan gelir, serbest metin yasak).
- `GET /api/v1/cash-sessions/:sessionId` — Kasa oturumu detayı ve tüm hareketler.
- `POST /api/v1/cash-sessions/:sessionId/transactions` — Kasa hareketi ekleme (`CASH`: `SALE`/`REFUND`/`CASH_IN`/`CASH_OUT`; `CREDIT_CARD`: `SALE`/`REFUND`; `BANK_TRANSFER`: manuel satış engelli, yalnızca `REFUND`). Atomik `Decimal.js` yeniden hesaplama yapılır.
- `POST /api/v1/cash-sessions/:sessionId/transactions/:txId/void` — Gerekçeli hareket iptali (`is_voided = true`, fiziksel silme yok).
- `POST /api/v1/cash-sessions/:sessionId/submit` — Kasiyer gün sonu teslim edilen gerçek nakit (`declaredCash`) beyanı; açık/fazla/eşit hesaplanır.
- `POST /api/v1/cash-sessions/:sessionId/store-approve` — Mağaza yöneticisi kontrolü ve merkeze gönderim (`STORE_MANAGER_APPROVED`).
- `POST /api/v1/cash-sessions/:sessionId/return` — Gerekçeli düzeltme iadesi (`RETURNED_FOR_CORRECTION`).

## IBAN / Havale Dekontları ve OCR (`/api/v1/receipts`)
- `GET /api/v1/receipts` — Rol/mağaza kapsamlı dekont listesi (`storeId`, `cashSessionId`, `cashierId`, `status`, `isDuplicate`, `bankAccountVerified`, `startDate`, `endDate`) + özet toplamlar (`approvedTotal`, `bankVerifiedTotal`).
- `POST /api/v1/receipts/upload` — `multipart/form-data` (`file`: JPG/JPEG/PNG/PDF, `cashSessionId`). Magic-bytes doğrulama, SHA-256 + görsel dHash, yerel Poppler/Tesseract TR OCR, bakiye dışlamalı Türk banka ayrıştırıcı ve 4 katmanlı mükerrer kontrolü uygular. Orijinal dosya asla silinmez.
- `GET /api/v1/receipts/:receiptId` — Dekont detayı, tüm `receipt_ocr_results` geçmişi (dışlanan bakiyeler, uyarılar, güven skoru) ve `receipt_verifications` kayıtları.
- `GET /api/v1/receipts/:receiptId/file` — Yetki ve mağaza izolasyonlu orijinal dekont önizleme/indirme (`X-Content-Type-Options: nosniff`, `Content-Security-Policy: sandbox`).
- `POST /api/v1/receipts/:receiptId/confirm` — Kasiyer veya mağaza yöneticisi OCR alanlarını kontrol edip düzenleyerek `PENDING_CENTRAL_APPROVAL` aşamasına gönderir; referans no değiştiyse mükerrer kontrolü tekrar çalışır.
- `POST /api/v1/receipts/:receiptId/central-review` — Merkez muhasebe / sistem yöneticisi kararı (`APPROVE`, `REJECT`, `MARK_DUPLICATE`, `SEND_TO_MANUAL_REVIEW`). Onayda `includedInReconciliation = true` olur, onaylı `BANK_TRANSFER` hareketi bağlanır ve `cash_sessions.bankTransferTotal` atomik güncellenir.
- `POST /api/v1/receipts/:receiptId/bank-verify` — Merkez muhasebe tarafından ayrı banka hesabı ekstresi teyidi (`bankAccountVerified`).
- `POST /api/v1/receipts/:receiptId/reprocess-ocr` — Orijinal dosya üzerinden OCR işlemini yeniden çalıştırıp yeni geçmiş kaydı ekler.

## Merkez Kontrol Paneli ve Mutabakat (`/api/v1/reconciliations`)
- `GET /api/v1/reconciliations/dashboard?businessDate=YYYY-MM-DD` — Merkez muhasebe ve sistem yöneticisi için 3+ mağazanın günlük canlı satış, ödeme dağılımı, beklenen/beyan/merkez nakit, açık/fazla, bekleyen kapanış ve bekleyen/sorunlu dekont kuyrukları.
- `GET /api/v1/reconciliations` — Tarih/mağaza/durum filtreli mutabakat listesi (`STORE_MANAGER` yalnızca kendi mağazasını görür).
- `GET /api/v1/reconciliations/:reconciliationId` — Mutabakat detayı, `reconciliation_items` kırılımı ve `financial_adjustments` düzeltme geçmişi.
- `POST /api/v1/reconciliations/verify` — Merkezin gerçek teslim aldığı nakit (`centralVerifiedCash`) girişi ve karar (`SAVE_REVIEW`, `APPROVE`, `RETURN`, `DISPUTE`). `APPROVE` hem mutabakatı hem bağlı kasiyer oturumlarını kilitler (`isLocked = true`).
- `POST /api/v1/reconciliations/:reconciliationId/adjustments` — Onaylı ve kilitli mutabakat kaydında doğrudan düzenleme yerine gerekçeli (en az 10 karakter), delta hesaplı ve denetim izli finansal düzeltme kaydı oluşturur.

## Raporlama ve Dışa Aktarma (`/api/v1/reports`)
- `GET /api/v1/reports/:reportType` — 9 finansal rapordan birini JSON + grafik verisi + özet toplamlarla döndürür (`startDate`, `endDate`, `storeId`, `cashierId`, `sortBy`, `sortDir`; tam rol ve mağaza izolasyonlu).
  - Rapor türleri: `daily-store`, `store-comparison`, `cashier-variance`, `payment-distribution`, `iban-transfers`, `pending-approvals`, `shortage-surplus`, `date-range`, `monthly-summary`.
- `GET /api/v1/reports/:reportType/export?format=xlsx|csv&...` — Biçimlendirilmiş Excel (`.xlsx`) veya UTF-8 BOM + OWASP formül enjeksiyonu korumalı CSV (`.csv`) indirir; dışa aktarma `audit_logs` (`REPORT_EXPORTED`) tablosuna kaydedilir.

## Denetim Kayıtları (`/api/v1/audit-logs`)
- `GET /api/v1/audit-logs` — Kapsam kontrollü denetim kayıtları (`SYSTEM_ADMIN`, `CENTRAL_ACCOUNTING`, `STORE_MANAGER`).
