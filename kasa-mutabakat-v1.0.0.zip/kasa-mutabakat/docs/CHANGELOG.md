# Değişiklik Günlüğü (`CHANGELOG`)

## [1.0.0] - 24.11.2026 (Aşama 8 – Final Dokümantasyon, Sürüm Eşitleme ve Git Hazırlığı)
- Sıfırdan kurulum, mimari, rol/yetki matrisi, finansal kurallar, OCR/mükerrer kontrolü, 9 rapor, test ve yedekleme/geri yükleme kılavuzlarını kapsayan kök `README.md` oluşturuldu.
- `.env.example` kod tabanındaki tüm zorunlu ve opsiyonel ortam değişkenleriyle (`VITE_API_PROXY_TARGET`, `E2E_TEST_PASSWORD`, `PLAYWRIGHT_CHROME_PATH` dahil) eksiksiz eşitlendi.
- Tüm monorepo paket sürümleri (`kasa-mutabakat`, `@kasa/shared`, `@kasa/api`, `@kasa/web`) ve `docs/` belgeleri `1.0.0` olarak eşitlendi.
- Gizli bilgi / `.gitignore` doğrulaması sonrası temiz, atomik yerel Git commit geçmişi `main` dalında hazırlandı (GitHub push kullanıcı onayına bağlıdır).

## [0.7.0] - 24.11.2026 (Aşama 7 – Test, Playwright E2E, Güvenlik Denetimi ve Optimizasyon)
- Kapsamlı güvenlik denetimi ve negatif test paketi (`stage7-security-audit.test.ts`, `file-security.test.ts`) eklendi: 36 uç noktada 401, 19 mutasyonda CSRF 403, tam 4 rol RBAC matrisi, çapraz mağaza ve kasiyerler arası IDOR 403, path traversal / null byte / SVG / bozuk PNG / UUID SQLi engeli ve kilitli mutabakat 409 koruması doğrulandı.
- Playwright E2E test altyapısı (`playwright.config.ts`, `e2e/global-setup.ts`, `e2e/seed-e2e.ts`, `e2e/full-workflow.spec.ts`) eklendi; gerçek Chrome, gerçek üretim frontend bundle (`vite preview`), gerçek Express API, gerçek Poppler PDF OCR ve gerçek PostgreSQL üzerinde tam uçtan uca akış ve mobil responsive (390x844) doğrulandı.
- E2E ve güvenlik denetimi sırasında yakalanan 3 kök neden giderildi:
  - `ModalDialog.tsx`: Programatik `open={true -> false}` kapatmalarında native `<dialog>` `close` olayının yanlışlıkla `onClose` tetiklemesi düzeltildi ve `ModalDialog.test.tsx` regresyon testi eklendi.
  - Test DB/Depolama İzolasyonu: `env.ts`, `prisma.ts` (`datasourceUrl`) ve `vitest.config.ts` ile `NODE_ENV=test` ortamında geliştirme DB (`kasa_mutabakat`) ve `storage/receipts` dizinine yazım kesin olarak engellendi.
  - Güvenlik sertleştirme: `seed.ts` ve `docker-compose.yml` içindeki sabit parola geri dönüşleri kaldırıldı, `resolveStoredReceiptPath` sıkılaştırıldı, `sharp@0.35.5` (3 high CVE) ve `multer@2.5.0` güncellendi.
- `apps/web/vite.config.ts` içinde `manualChunks` (`vendor-react`, `vendor-charts`, `vendor-ui`) eklenerek üretim bundle boyut uyarısı giderildi (`index-*.js` 211 kB).
- `scripts/db-backup.sh` ve `scripts/db-restore.sh` gerçek PostgreSQL 16 üzerinde SHA-256 doğrulaması ve geçici veritabanına geri yükleme ile uçtan uca test edildi.

## [0.6.0] - 24.11.2026 (Aşama 6 – Raporlama, Grafikler ve Excel/CSV Dışa Aktarma)
- 9 finansal raporun tamamı (`daily-store`, `store-comparison`, `cashier-variance`, `payment-distribution`, `iban-transfers`, `pending-approvals`, `shortage-surplus`, `date-range`, `monthly-summary`) rol/mağaza izolasyonu, filtreleme ve sıralamayla geliştirildi.
- `exceljs` tabanlı biçimlendirilmiş `.xlsx` ve UTF-8 BOM + OWASP formül enjeksiyonu korumalı `.csv` dışa aktarma eklendi (`audit_logs` kayıtlı).
- `recharts` grafikleriyle Raporlar (`/raporlar`) ekranı ve canlı günlük verilerle güncellenmiş Genel Bakış (`/`) dashboard ekranı tamamlandı.

## [0.5.0] - 24.11.2026 (Aşama 5 – Merkez Kontrol Paneli ve Mutabakat)
- Tüm mağazaların günlük satış, ödeme dağılımı, beklenen/beyan/merkez nakit, açık/fazla, bekleyen kapanış ve dekont kuyruklarını gösteren Merkez Kontrol Paneli (`/merkez`) geliştirildi.
- Merkez doğrulama akışı (gerçek teslim tutarı girişi, beyan–merkez ve beklenen–merkez fark hesaplaması, kasiyer kırılımı `reconciliation_items`, onay/kilitleme, düzeltme için iade ve uyuşmazlık kaydı) eklendi.
- Onaylı ve kilitli kayıtların doğrudan değiştirilmesi engellendi; gerekçeli ve denetim izli `financial_adjustments` mekanizması geliştirildi ve test edildi.

## [0.4.0] - 24.11.2026 (Aşama 4 – IBAN Dekont, Gerçek OCR ve Mükerrer Kontrolü)
- Magic-bytes doğrulamalı (JPG/JPEG/PNG/PDF), SHA-256 ve görsel algısal özet (`dHash`) hesaplayan, web kökü dışında saklamalı dosya güvenliği katmanı geliştirildi.
- Yerel Türkçe OCR ve PDF motoru (`pdftotext`, `pdftoppm`, `sharp`, `tesseract -l tur+eng`) + bakiye dışlamalı, çoklu tutar algılamalı ve IBAN MOD-97 doğrulamalı Türk banka dekont ayrıştırıcısı geliştirildi.
- 4 katmanlı mükerrer tespit (SHA-256, referans no, algısal görsel dHash, bileşik alan eşleşmesi) ve PostgreSQL kısmi benzersiz indeks koruması entegre edildi.
- 9 durumlu dekont iş akışı, orijinal dekont önizleme ekranı, kasiyer/mağaza teyidi, merkez onayı/reddi ve ayrı banka hesabı ekstresi teyidi (`bank_account_verified`) eklendi.

## [0.3.0] - 24.11.2026 (Aşama 3 – Temel Modüller)
- Backend `Decimal.js` finansal hesaplama motoru (`reconciliation/calculator.ts`) geliştirildi ve kuruş kesinliği / ödeme yöntemi izolasyonu testleriyle doğrulandı.
- Mağaza Yönetimi (dinamik ad düzenleme, yeni mağaza oluşturma, pasifleştirme) backend ve frontend ekranları eklendi.
- Personel ve Rol Yönetimi (yeni personel/kasiyer ekleme, mağaza/rol atama, pasifleştirmede anında oturum iptali) backend ve frontend ekranları eklendi.
- Sistem Ayarları yönetim API ve arayüzü eklendi.
- Kasiyer bazlı günlük kasa oturumları, gün içi tahsilat/iade/nakit giriş-çıkış hareketleri, gerekçeli iptal (`is_voided`), gün sonu teslim beyanı, açık/fazla hesaplaması, mağaza yöneticisi kontrol/merkeze gönderim ve düzeltme iadesi akışları tamamlandı.

## [0.2.0] - 24.11.2026 (Aşama 2 – Temel Altyapı)
- `AGENTS.md`, 5 proje kuralı (`.agents/rules/`), 15 alan Skill'i ve 11 modern Workflow Skill'i (`.agents/skills/`) oluşturuldu.
- 8 teknik dokümantasyon dosyası ve `docs/WORKFLOWS_INDEX.md` oluşturuldu.
- pnpm monorepo (`packages/shared`, `apps/api`, `apps/web`), Docker Compose PostgreSQL 16 ortamı ve `.env.example` kuruldu.
- 15 tablolu Prisma şeması (`DECIMAL(14,2)`, `ON DELETE RESTRICT`, kısmi benzersizlik indeksleri), ilk migration ve referans seed (sahte finansal verisiz) oluşturuldu.
- Sunucu taraflı oturum kimlik doğrulaması (`scrypt`, `HttpOnly` cookie, CSRF, brute-force kilitleme), 4 rol RBAC, mağaza izolasyonu ve `audit_logs` servisi geliştirildi ve test edildi.
- Türkçe, responsive, erişilebilir React + Tailwind CSS giriş ekranı ve rol duyarlı uygulama kabuğu (sol menü + üst bilgi çubuğu) geliştirildi.

## [0.1.0] - 24.11.2026 (Aşama 1 – Mimari ve Planlama)
- Ortam kontrolü, mimari kararlar, 15 tablolu veritabanı tasarımı, Antigravity Rules/Skills/Workflows planı ve 8 aşamalı yol haritası hazırlandı ve onaylandı.
