# Güvenlik Planı (`SECURITY_PLAN`)

**Son Denetim Tarihi:** 24.11.2026 (Aşama 7 – Kapsamlı Güvenlik Denetimi)

## 1. Uygulanan Kontroller (Aşama 2–7)
- **Parola Güvenliği:** Node.js `crypto.scrypt` (`N=16384, r=8, p=1`, 64 byte çıktı, 16 byte rastgele salt) + `crypto.timingSafeEqual`. `apps/api/prisma/seed.ts` ve `docker-compose.yml` dahil tüm kod tabanında sabit (hardcoded) parola geri dönüşleri kaldırılmış, gizli değerler yalnızca `.env` üzerinden zorunlu kılınmıştır.
- **Oturum Yönetimi:** 256-bit kriptografik rastgele oturum anahtarı, DB'de yalnızca `SHA-256` özeti saklanır; tarayıcıya `HttpOnly`, `SameSite=Lax`, üretimde `Secure` çerez ile iletilir. Kullanıcı pasifleştirme veya parola sıfırlamada tüm aktif oturumlar anında iptal edilir.
- **Brute-Force Koruması:** Giriş uç noktasında rate limiting + 5 ardışık başarısız denemede 15 dakika hesap kilitleme (`failed_login_attempts`, `locked_until`).
- **CSRF Koruması:** Oturuma bağlı 256-bit `csrfToken`; tüm 19 durum değiştiren `POST`/`PATCH` uç noktasında `X-CSRF-Token` başlığı zaman-sabit doğrulanır.
- **RBAC ve Mağaza/Kasiyer İzolasyonu:** `requireAuth` -> `requireRole` -> `assertStoreAccess` / `resolveScopedStoreId` katmanları. Mağaza yöneticisi ve kasiyer yalnızca kendi `store_id` verisine, kasiyer ayrıca yalnızca kendi oturum ve dekontlarına erişebilir.
- **Dosya Yükleme ve Depolama Güvenliği:**
  - Yalnızca JPG, JPEG, PNG ve PDF kabul edilir; uzantı ve MIME başlığına ek olarak **magic-bytes** imzası ve görsellerde `sharp` metadata doğrulaması zorunludur (SVG, HTML, EXE ve bozuk görseller `400` ile reddedilir).
  - Maksimum dosya boyutu sınırlandırılır (`max_upload_file_size_mb`, varsayılan 10 MB).
  - Orijinal dosyalar rastgele UUID adıyla web kökü dışında (`storage/receipts/YYYY/MM/`) saklanır; `resolveStoredReceiptPath` boş yol, `.` (baseDir öz-çözümü), mutlak yol, `..` traversal ve null byte (`\0`) girişimlerini reddeder; orijinal dosyalar asla silinmez.
  - Önizleme/indirme yalnızca kimlik ve mağaza/kasiyer yetki kontrolünden geçen `/api/v1/receipts/:receiptId/file` uç noktasından `X-Content-Type-Options: nosniff`, `Content-Security-Policy: sandbox` ve `Cache-Control: private, no-store` başlıklarıyla yapılır.
- **HTTP Güvenliği & Denetim Kayıtları:** `helmet`, `X-Powered-By` kapalı, kısıtlı CORS, `express.json({ limit: '1mb' })`, Zod doğrulama, değiştirilemez `audit_logs` ve `X-Request-Id` izleme başlığı.
- **CSV / Excel Formül Enjeksiyonu Koruması:** `=`, `+`, `-`, `@`, `\t`, `\r` ile başlayan metin hücreleri tek tırnak (`'`) ile nötralize edilir; CSV UTF-8 BOM ile güvenli indirilir; tüm rapor dışa aktarmaları `REPORT_EXPORTED` olarak denetim kaydına yazılır.
- **Veritabanı & Test İzolasyonu:** `NODE_ENV=test` durumunda `env.ts`, `prisma.ts` (`datasourceUrl`) ve `vitest.config.ts` üç katmanlı olarak `TEST_DATABASE_URL` (`kasa_mutabakat_test`) ve ayrı depolama dizini (`storage/receipts-test` / `storage/receipts-e2e`) kullanır; geliştirme veritabanına test verisi sızması engellenmiştir.

## 2. Aşama 7 Güvenlik Denetimi Sonuçları (24.11.2026)
- **Otomatik Güvenlik Test Matrisi (`stage7-security-audit.test.ts` + `file-security.test.ts`):**
  - 36 korumalı API uç noktasında kimlik doğrulamasız erişim -> `401 Unauthorized` doğrulandı.
  - 19 durum değiştiren (`POST`/`PATCH`) uç noktada eksik ve yanlış `X-CSRF-Token` -> `403 Forbidden` doğrulandı.
  - 4 rol (`SYSTEM_ADMIN`, `CENTRAL_ACCOUNTING`, `STORE_MANAGER`, `CASHIER`) tam RBAC matrisi -> yetkisiz işlemler `403 Forbidden` doğrulandı.
  - Çapraz mağaza IDOR ve aynı mağazada başka kasiyerin oturum/dekontuna erişim denemeleri -> `403 Forbidden` doğrulandı.
  - Onaylı/kilitli mutabakat ve kasa oturumunda doğrudan değişiklik girişimleri -> `409 Conflict` doğrulandı.
  - Path traversal, null byte, SVG/HTML/bozuk PNG yüklemeleri ve UUID SQLi girişimleri -> `400 Bad Request` doğrulandı.
- **Gizli Bilgi / Anahtar Taraması (`rg`):** `apps/`, `packages/`, `scripts/`, `docs/`, `AGENTS.md`, `.agents/`, `.env.example`, `docker-compose.yml` taramasında sabit API anahtarı, özel anahtar veya parola sızıntısı bulunmadı (`SECRET_SCAN_CLEAN`).
- **Bağımlılık Güvenlik Denetimi (`pnpm audit --prod`):**
  - Denetim sırasında tespit edilen 3 adet yüksek seviye `sharp` (libvips/libheif/librsvg) açığı `sharp@0.35.5` yükseltmesiyle, eski `multer@1.4.x` ise `multer@2.5.0` yükseltmesiyle giderildi.
  - Kalan 2 bildirim değerlendirmesi:
    1. `zod <4.6.6` (High — aşırı büyük koleksiyonlarda bellek tüketimi): Tüm HTTP gövdeleri `express.json({ limit: '1mb' })` ve sabit üst sınırlı şemalarla sınırlandırılmıştır; Zod v4 majör geçişi sonraki planlı yükseltmede ele alınacaktır.
    2. `exceljs > uuid <11.1.1` (Moderate — v3/v5/v6 `buf` sınır kontrolü): Uygulamamız `uuid` v3/v5/v6 kullanmaz (yerleşik `crypto.randomUUID()` kullanılır), yalnızca `exceljs` alt bağımlılığıdır.
- **Yedekleme ve Geri Yükleme Doğrulaması:** `scripts/db-backup.sh` ve `scripts/db-restore.sh` gerçek PostgreSQL 16 üzerinde çalıştırıldı; SHA-256 doğrulaması geçti, `--confirm-overwrite` olmadan geri yükleme reddedildi, geçici `kasa_mutabakat_restore_test` veritabanına geri yükleme sonrası tüm 15 tablo ve referans satır sayıları kaynakla birebir eşleşti.
