# Modül Haritası (`MODULE_MAP`)

| Modül | Backend Yolu (`apps/api/src/`) | Frontend Yolu (`apps/web/src/`) | İlgili Skill | Durum |
| :--- | :--- | :--- | :--- | :--- |
| Ortak Sözleşmeler | `packages/shared/src/` | `packages/shared/src/` | `project-architecture` | Aktif (Aşama 2–3) |
| Kimlik Doğrulama & Oturum | `modules/auth/` | `features/auth/` | `security-audit`, `backend-development` | Aktif (Aşama 2) |
| RBAC & Mağaza İzolasyonu | `middlewares/auth.ts`, `middlewares/rbac.ts`, `middlewares/store-scope.ts`, `middlewares/csrf.ts` | `App.tsx`, `app/AppLayout.tsx` | `security-audit` | Aktif (Aşama 2) |
| Denetim Kayıtları (Audit) | `modules/audit/` | `features/dashboard/OverviewPage.tsx` | `security-audit` | Aktif (Aşama 2) |
| Mağaza Yönetimi | `modules/stores/` | `features/stores/StoresPage.tsx` | `store-management` | Aktif (Aşama 3) |
| Personel & Rol Yönetimi | `modules/users/` | `features/users/UsersPage.tsx` | `cashier-management` | Aktif (Aşama 3) |
| Sistem Ayarları | `modules/settings/` | `features/settings/SettingsPage.tsx` | `backend-development` | Aktif (Aşama 3) |
| Finansal Hesaplama Motoru | `modules/reconciliation/calculator.ts` | — *(yalnızca backend)* | `reconciliation` | Aktif (Aşama 3) |
| Günlük Kasa & Kapanış | `modules/cash-sessions/` | `features/cash/CashSessionsPage.tsx`, `CashSessionDetailPage.tsx` | `cashier-management`, `reconciliation` | Aktif (Aşama 3) |
| IBAN Dekont & OCR | `modules/receipts/` (`file-security.ts`, `parser.ts`, `ocr-provider.ts`, `duplicate-detector.ts`, `receipts.service.ts`, `receipts.routes.ts`) | `features/receipts/ReceiptsPage.tsx`, `ReceiptDetailPage.tsx` | `image-upload`, `ocr-ai-analysis`, `duplicate-detection` | Aktif (Aşama 4) |
| Merkez Kontrol & Mutabakat | `modules/reconciliation/` (`calculator.ts`, `reconciliation.service.ts`, `reconciliation.routes.ts`) | `features/central/CentralControlPage.tsx` | `reconciliation`, `central-control` | Aktif (Aşama 5) |
| Raporlama & Export | `modules/reports/` (`reports.service.ts`, `export.ts`, `reports.routes.ts`) | `features/reports/ReportsPage.tsx`, `features/dashboard/OverviewPage.tsx` | `reporting` | Aktif (Aşama 6) |
| Güvenlik Denetimi & Testler | `tests/unit/`, `tests/integration/stage7-security-audit.test.ts` | `e2e/full-workflow.spec.ts`, `playwright.config.ts` | `security-audit`, `testing-qa` | Aktif (Aşama 7) |
