# Test Planı (`TEST_PLAN`)

## 1. Test Katmanları
- **Unit Testler (Vitest):** Parola hash/doğrulama, CSRF/token yardımcıları, `Decimal.js` finansal hesaplamalar (Aşama 3+), Türk banka dekont ayrıştırıcı & bakiye dışlama (Aşama 4+).
- **Integration Testler (Vitest + Supertest + Gerçek PostgreSQL Test DB):**
  - Aşama 2: Giriş/çıkış, başarısız giriş kilitleme, oturum iptali, CSRF koruması, 4 rol RBAC matrisi, çapraz mağaza izolasyonu, denetim kayıtları.
  - Aşama 3–6: Kasa oturumu, tahsilat/iade, dekont yükleme + OCR + 4 katmanlı mükerrer engeli, merkez mutabakat ve kilitli kayıt koruması, 9 rapor ve XLSX/CSV dışa aktarma.
- **Frontend Testleri (Vitest + Testing Library + Vite Build):** Tip kontrolü, form/erişilebilirlik ve üretim derlemesi.
- **End-to-End Testler (Playwright — Aşama 7):** Gerçek tarayıcıda tüm rollerle uçtan uca akışlar.

## 2. Test Veritabanı Politikası
- Integration testleri geliştirme veritabanından izole ayrı `kasa_mutabakat_test` PostgreSQL veritabanında çalışır.
- Test sonuçları her aşama sonunda bu belgeye gerçek çalıştırma çıktılarıyla işlenir.

## 3. Gözlemlenen Test Sonuçları

### Aşama 2 Doğrulaması (24.11.2026)
- `pnpm typecheck`: `@kasa/shared`, `@kasa/api`, `@kasa/web` — **Başarılı (0 hata)**
- `pnpm build`: `@kasa/shared`, `@kasa/api`, `@kasa/web` (`vite build`) — **Başarılı**
- `@kasa/shared` (Vitest): **2/2 test geçti** (`formatters.test.ts`)
- `@kasa/api` (Vitest + Supertest + Gerçek PostgreSQL `kasa_mutabakat_test`): **6/6 test geçti** (`password.test.ts` 2/2, `auth-rbac-isolation.test.ts` 4/4)
- `@kasa/web` (Vitest + Testing Library): **1/1 test geçti** (`LoginPage.test.tsx`)
- Veritabanı doğrulaması: 15 tablo, `cash_transactions_amount_positive` CHECK kısıtı ve 2 onaylı dekont kısmi benzersizlik indeksi PostgreSQL 16 üzerinde doğrulandı.

### Aşama 3 Doğrulaması (24.11.2026)
- `pnpm typecheck`: `@kasa/shared`, `@kasa/api`, `@kasa/web` — **Başarılı (0 hata)**
- `pnpm build`: `@kasa/shared`, `@kasa/api`, `@kasa/web` (`vite build`) — **Başarılı**
- `@kasa/shared` (Vitest): **2/2 test geçti** (`formatters.test.ts`)
- `@kasa/api` (Vitest + Supertest + Gerçek PostgreSQL `kasa_mutabakat_test`): **13/13 test geçti**
  - `calculator.test.ts` (4/4): kuruş kesinliği, kredi kartı/havale nakit izolasyonu, onaylı/mükerrer dekont filtresi, çoklu kasiyer mağaza toplamı
  - `stage3-core-modules.test.ts` (3/3): dinamik mağaza adı düzenleme & RBAC, personel oluşturma & pasifleştirmede anlık oturum iptali, aynı mağazada aynı gün 2 bağımsız kasiyer oturumu + hareket iptali + teslim beyanı + açık/fazla + düzeltme iadesi + merkeze gönderim + çapraz mağaza 403
  - `auth-rbac-isolation.test.ts` (4/4) ve `password.test.ts` (2/2) regresyon testleri yeşil
- `@kasa/web` (Vitest + Testing Library): **3/3 test geçti** (`LoginPage.test.tsx`, `StatusBadges.test.tsx`)

### Aşama 4 Doğrulaması (24.11.2026)
- Kurulu sistem OCR araçları: `tesseract 5.3.4` (`tur`, `eng`, `osd`) + `poppler-utils 24.02.0` (`pdftotext`, `pdftoppm`)
- `pnpm typecheck`: `@kasa/shared`, `@kasa/api`, `@kasa/web` — **Başarılı (0 hata)**
- `pnpm build`: `@kasa/shared`, `@kasa/api`, `@kasa/web` (`vite build`) — **Başarılı**
- `@kasa/shared` (Vitest): **2/2 test geçti**
- `@kasa/api` (Vitest + Supertest + Gerçek PostgreSQL + Gerçek Poppler/Tesseract OCR): **20/20 test geçti (6 dosya)**
  - `receipt-parser.test.ts` (6/6): Türkçe para ayrıştırma, IBAN MOD-97 doğrulama, hesap bakiyesi & masraf dışlama, yalnızca bakiyeli dekont reddi, çoklu tutar şüphesi, magic-bytes zararlı dosya engeli
  - `stage4-receipts-ocr.test.ts` (1/1 – 11 adımlı uçtan uca akış): sahte `.jpg` reddi, gerçek PDF `pdftotext` ayrıştırma & bakiye dışlama, Katman 1 (SHA-256) ve Katman 2 (Referans No) otomatik `DUPLICATE` tespiti, Katman 4 bileşik alan şüpheli mükerrer uyarısı, gerçek PNG `sharp` + `tesseract -l tur+eng` OCR, çapraz mağaza dosya indirme 403 engeli, `nosniff`/`sandbox` önizleme başlıkları, kasiyer teyidi, merkez onayı sonrası oturum `bankTransferTotal` atomik artışı, ayrı banka hesabı teyidi ve reddedilen dekontun orijinal dosyasının diskte korunması
  - Aşama 2 ve Aşama 3 regresyon testleri (13/13) tamamen yeşil
- `@kasa/web` (Vitest + Testing Library): **3/3 test geçti**

### Aşama 5 Doğrulaması (24.11.2026)
- `pnpm typecheck`: `@kasa/shared`, `@kasa/api`, `@kasa/web` — **Başarılı (0 hata)**
- `pnpm build`: `@kasa/shared`, `@kasa/api`, `@kasa/web` (`vite build`) — **Başarılı**
- `@kasa/shared` (Vitest): **2/2 test geçti**
- `@kasa/api` (Vitest + Supertest + Gerçek PostgreSQL `kasa_mutabakat_test`): **21/21 test geçti (7 dosya)**
  - `stage5-central-reconciliation.test.ts` (1/1): merkez paneli RBAC (mağaza yöneticisi & kasiyer 403), açık oturum varken onay engeli (409), beyan vs merkez nakit fark hesaplaması (`cashVariance`, `declaredVsCentralDiff`), `reconciliation_items` kırılımı, onayda hem mutabakat hem kasiyer oturumu kilitleme (`CENTRAL_APPROVED`, `isLocked = true`), kilitli mutabakatta doğrudan değişiklik engeli (409), gerekçeli `financial_adjustments` delta kaydı + audit log ve mağaza bazlı mutabakat izolasyonu
  - Aşama 2, 3 ve 4 regresyon testleri (20/20) tamamen yeşil
- `@kasa/web` (Vitest + Testing Library): **3/3 test geçti**

### Aşama 6 Doğrulaması (24.11.2026)
- `pnpm typecheck`: `@kasa/shared`, `@kasa/api`, `@kasa/web` — **Başarılı (0 hata)**
- `pnpm build`: `@kasa/shared`, `@kasa/api`, `@kasa/web` (`vite build`, Recharts dahil) — **Başarılı**
- `@kasa/shared` (Vitest): **2/2 test geçti**
- `@kasa/api` (Vitest + Supertest + Gerçek PostgreSQL `kasa_mutabakat_test`): **25/25 test geçti (9 dosya)**
  - `report-export.test.ts` (3/3): OWASP CSV/Excel formül enjeksiyonu (`=`, `+`, `-`, `@`) nötralizasyonu, UTF-8 BOM + Türkçe karakter bütünlüğü, `exceljs` ile gerçek `.xlsx` üretim ve geri okuma doğrulaması
  - `stage6-reports.test.ts` (1/1): tüm 9 finansal raporun gerçek veriden üretilmesi, açık/fazla toplam doğrulaması, mağaza yöneticisi çapraz mağaza 403 izolasyonu, gerçek `.xlsx` ve `.csv` HTTP indirme ve `REPORT_EXPORTED` audit kaydı
  - Aşama 2, 3, 4 ve 5 regresyon testleri (21/21) tamamen yeşil
- `@kasa/web` (Vitest + Testing Library): **3/3 test geçti**

### Aşama 7 Doğrulaması (24.11.2026)
- `pnpm typecheck`: `@kasa/shared`, `@kasa/api`, `@kasa/web` — **Başarılı (0 hata)**
- `pnpm build`: `@kasa/shared`, `@kasa/api`, `@kasa/web` (`vite build` + `manualChunks`: `index` 211 kB, `vendor-react` 262 kB, `vendor-charts` 423 kB, `vendor-ui` 48 kB — **0 boyut uyarısı**) — **Başarılı**
- `@kasa/shared` (Vitest): **2/2 test geçti** (`formatters.test.ts`)
- `@kasa/api` (Vitest + Supertest + Gerçek PostgreSQL `kasa_mutabakat_test` + Gerçek OCR): **34/34 test geçti (11 dosya)**
  - `file-security.test.ts` (4/4): magic-bytes (JPG/PNG/PDF), SVG/HTML/EXE/bozuk PNG reddi, path traversal / null byte / `.` engeli, dosya adı temizliği, dHash Hamming mesafesi
  - `stage7-security-audit.test.ts` (5/5): HTTP güvenlik başlıkları + 36 endpoint `401`, 19 mutasyon CSRF `403`, 4 rol RBAC matrisi, çapraz mağaza ve kasiyerler arası IDOR `403`, kilitli kayıt `409`, SQLi/XSS/CSV formül enjeksiyonu ve zararlı dosya reddi `400`
  - Aşama 2–6 tüm regresyon testleri (25/25) yeşil
- `@kasa/web` (Vitest + Testing Library): **4/4 test geçti (3 dosya)** (`LoginPage.test.tsx`, `StatusBadges.test.tsx`, `ModalDialog.test.tsx` regresyon testi)
- **Playwright E2E (`pnpm test:e2e`, Google Chrome + `vite preview` + Gerçek API + Gerçek PostgreSQL `kasa_mutabakat_test`):** **2/2 test geçti**
  - Senaryo 1: Kasiyer girişi -> kasa oturumu (`500,00 ₺`) -> nakit (`1.200,00 ₺`) & kredi kartı (`850,00 ₺`) nakit izolasyonu -> gerçek PDF IBAN dekont yükleme & Poppler OCR (`950,00 ₺`) + hesap bakiyesi dışlama (`62.400,00 ₺`) -> kasiyer teyidi -> gün sonu teslim (`1.680,00 ₺`, `-20,00 ₺` açık) -> Mağaza Yöneticisi onayı -> Merkez Muhasebe dekont onayı + ayrı banka hesabı teyidi -> Merkez Mutabakat Paneli onay & kilitleme -> kilitli mutabakatta gerekçeli finansal düzeltme (`1.690,00 ₺`) -> Raporlar (Recharts grafikleri, sekmeler, gerçek `.xlsx` ve `.csv` tarayıcı indirmeleri)
  - Senaryo 2: Mobil responsive (`390x844`), mobil menü aç/kapa, yatay taşma yok, kasiyer için `/merkez` ve `/ayarlar` rota koruması
- **Yedekleme & Geri Yükleme Doğrulaması:** `scripts/db-backup.sh` -> SHA-256 doğrulama -> `--confirm-overwrite` olmadan reddi -> `scripts/db-restore.sh` ile geçici `kasa_mutabakat_restore_test` veritabanına geri yükleme -> 15 tablo ve satır sayıları birebir doğrulandı.
- **Test DB İzolasyon Doğrulaması:** Tüm Vitest ve Playwright E2E çalıştırmaları sonrasında geliştirme veritabanı `kasa_mutabakat` tamamen dokunulmamış temiz durumda doğrulandı (`8` başlangıç hesabı, `0` oturum, `0` hareket, `0` dekont).
