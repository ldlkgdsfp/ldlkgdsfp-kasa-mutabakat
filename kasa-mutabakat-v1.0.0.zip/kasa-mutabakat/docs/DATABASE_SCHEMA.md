# Veritabanı Şeması (`DATABASE_SCHEMA`)

**Motor:** PostgreSQL 16 (Docker Compose `postgres:16-alpine`)  
**ORM:** Prisma (`apps/api/prisma/schema.prisma`)  
**Parasal Kesinlik:** Tüm parasal alanlar `DECIMAL(14, 2)`  
**Silme Koruması:** Finansal, mağaza ve kullanıcı kayıtlarında `ON DELETE RESTRICT`

## Tablolar (15 Adet)

1. **`roles`**: `SYSTEM_ADMIN`, `STORE_MANAGER`, `CASHIER`, `CENTRAL_ACCOUNTING`
2. **`stores`**: Mağaza ve merkez ofis tanımları (`code` benzersiz, `name` dinamik düzenlenebilir, `type`: `STORE` | `HEADQUARTERS`, `is_active`)
3. **`users`**: Personel hesapları (`email`, `username`, `full_name`, `password_hash`, `role_id`, `store_id`, kilitleme sayaçları, `is_active`)
4. **`user_sessions`**: Sunucu taraflı güvenli oturumlar (`token_hash`, `csrf_token`, `user_id`, `expires_at`, `revoked_at`, `ip_address`, `user_agent`)
5. **`payment_methods`**: Yalnızca 3 ana kategori (`CASH`, `CREDIT_CARD`, `BANK_TRANSFER`)
6. **`cash_sessions`**: Kasiyer bazlı günlük kasa oturumları (`UNIQUE(store_id, cashier_id, business_date, shift_no)`), backend hesaplı toplamlar, `expected_cash`, `declared_cash`, `cash_difference`, `status`, `is_locked`, `version`
7. **`cash_transactions`**: Gün içi satış, iade, nakit giriş/çıkış hareketleri (`amount > 0`, `is_voided`, `void_reason`)
8. **`transfer_receipts`**: IBAN/Havale dekontları, 9 durumlu yaşam döngüsü, `file_sha256`, `perceptual_hash`, `is_duplicate`, `duplicate_of_receipt_id`, `bank_account_verified`, `included_in_reconciliation`
9. **`receipt_ocr_results`**: Versiyonlu OCR ham metin, tespit edilen tutarlar, dışlanan bakiye tutarları, alan çıkarımları, `confidence_score`, `warnings_json`
10. **`receipt_verifications`**: Dekont doğrulama ve onay/ret geçmişi
11. **`central_reconciliations`**: Mağaza + iş günü bazlı merkez mutabakatı (`UNIQUE(store_id, business_date)`)
12. **`reconciliation_items`**: Kasiyer/ödeme yöntemi bazlı mutabakat satır kırılımı
13. **`financial_adjustments`**: Onaylı/kilitli finansal kayıtlarda gerekçeli düzeltme (delta) kayıtları
14. **`audit_logs`**: Değiştirilemez (append-only) denetim kayıtları
15. **`system_settings`**: Sistem eşik ve yapılandırma değerleri

## Özel PostgreSQL Kısıtları ve Kısmi Benzersizlik İndeksleri (SQL Migration)
- `cash_transactions_amount_positive`: `CHECK (amount > 0)`
- `transfer_receipts_approved_sha256_unique`: `CREATE UNIQUE INDEX ... ON transfer_receipts (file_sha256) WHERE status = 'APPROVED' AND is_duplicate = false`
- `transfer_receipts_approved_ref_unique`: `CREATE UNIQUE INDEX ... ON transfer_receipts (LOWER(TRIM(reference_number))) WHERE status = 'APPROVED' AND is_duplicate = false AND reference_number IS NOT NULL AND TRIM(reference_number) <> ''`
