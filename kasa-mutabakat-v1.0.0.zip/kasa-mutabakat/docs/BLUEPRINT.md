# BLUEPRINT – Mağaza ve Merkez Günlük Kasa Takip ve Mutabakat Sistemi

**Sürüm:** 1.0.0 (Tüm 8 Aşama Tamamlandı)  
**Son Güncelleme:** 24.11.2026

## 1. Proje Özeti
Üç mağaza ve bir merkez ofisin günlük kasa kapanışlarını, 3 ana ödeme yöntemini (`Nakit`, `Kredi Kartı`, `Havale / EFT`), kasiyer bazlı tahsilat ve açık/fazla hesaplarını, IBAN transfer dekontu yükleme/OCR/mükerrer kontrolünü ve merkez muhasebe mutabakat onayını tek çatı altında yöneten web uygulamasıdır.

## 2. Temel Finansal İlkeler
- Tüm parasal alanlar PostgreSQL'de `DECIMAL(14,2)`, backend'de `Decimal.js` ile işlenir.
- Tüm finansal hesaplamalar yalnızca backend'de yapılır; frontend yalnızca gösterir (`₺`, `GG.AA.YYYY`).
- Ödeme yöntemleri kesin olarak izoledir: Kredi kartı ve Havale/EFT hiçbir zaman beklenen nakit hesabına girmez.
- Beklenen Nakit = `Açılış Kasası + Nakit Satış + Diğer Nakit Girişi − Nakit İade − Diğer Nakit Çıkışı`.
- Kasa Farkı = `Teslim Edilen Gerçek Nakit − Beklenen Nakit` (`<0` açık, `>0` fazla, `=0` eşit).
- IBAN dekontlarında hesap bakiyesi asla transfer tutarı kabul edilmez; OCR kesin doğrulama sayılmaz; mükerrer dekont toplama eklenmez; orijinal dosya silinmez; banka hesabı teyidi ayrı izlenir.
- Onaylı/kilitli kayıtlar doğrudan düzenlenmez; tüm düzeltmeler gerekçe ve `audit_logs` ile kayıt altına alınır.

## 3. Aşama Durum Tablosu

| Aşama | Başlık | Durum |
| :--- | :--- | :--- |
| Aşama 1 | Mimari, Veritabanı ve Planlama | Tamamlandı (Onaylandı) |
| Aşama 2 | Temel Altyapı, DB, Kimlik Doğrulama ve RBAC | Tamamlandı (Test Edildi) |
| Aşama 3 | Mağaza, Personel, Kasiyer Kasa İşlemleri ve Günlük Kapanış | Tamamlandı (Test Edildi) |
| Aşama 4 | IBAN Dekont Yükleme, OCR, Ayrıştırma ve Mükerrer Kontrol | Tamamlandı (Test Edildi) |
| Aşama 5 | Merkez Kontrol Paneli ve Mutabakat Onay/Düzeltme | Tamamlandı (Test Edildi) |
| Aşama 6 | 9 Rapor, Grafikler ve Excel/CSV Dışa Aktarma | Tamamlandı (Test Edildi) |
| Aşama 7 | Kapsamlı Unit, Integration, E2E Testleri ve Güvenlik Denetimi | Tamamlandı (Test Edildi) |
| Aşama 8 | Son Dokümantasyon Eşitleme, README ve Yerel Git Commit Hazırlığı | Tamamlandı (Push Onayı Bekliyor) |

## 4. Gelecekteki Değişiklik Protokolü
Her değişiklikten önce: `BLUEPRINT.md` -> ilgili `.agents/skills/<ad>/SKILL.md` -> etki analizi -> gerekiyorsa Prisma migration -> testler -> dokümantasyon güncellemesi.
