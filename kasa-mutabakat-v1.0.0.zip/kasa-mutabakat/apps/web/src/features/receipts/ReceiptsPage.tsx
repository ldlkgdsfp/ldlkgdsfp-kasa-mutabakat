import { useState, type FormEvent } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  formatCurrencyTRY,
  formatDateTimeTR,
  formatDateTR,
  RECEIPT_STATUS_LABELS_TR,
  RECEIPT_STATUSES,
  type CashSessionSummaryDTO,
  type ReceiptStatus,
  type StoreSummary,
  type TransferReceiptDetailDTO,
  type TransferReceiptSummaryDTO,
} from '@kasa/shared';
import { ArrowRight, CopyX, FileUp, ReceiptText } from 'lucide-react';
import { DataTable, type DataTableColumn } from '../../components/DataTable';
import { ModalDialog } from '../../components/ModalDialog';
import { BankVerifiedBadge, ReceiptStatusBadge } from '../../components/StatusBadges';
import { ApiClientError, apiRequest } from '../../lib/api';
import { useAuth } from '../auth/AuthContext';

interface ReceiptListResponse {
  items: TransferReceiptSummaryDTO[];
  summary: {
    totalCount: number;
    pendingApprovalCount: number;
    manualReviewCount: number;
    duplicateOrFailedCount: number;
    approvedTotal: string;
    bankVerifiedTotal: string;
  };
}

export function ReceiptsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchParams] = useSearchParams();

  const initialSessionFilter = searchParams.get('sessionId') ?? '';
  const [storeFilter, setStoreFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<ReceiptStatus | ''>('');
  const [bankFilter, setBankFilter] = useState<'' | 'true' | 'false'>('');
  const [sessionFilter, setSessionFilter] = useState(initialSessionFilter);

  const [uploadOpen, setUploadOpen] = useState(false);
  const [selectedSessionId, setSelectedSessionId] = useState(initialSessionFilter);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const canUpload = user?.role !== 'CENTRAL_ACCOUNTING';
  const isGlobal = user?.role === 'SYSTEM_ADMIN' || user?.role === 'CENTRAL_ACCOUNTING';

  const storesQuery = useQuery({
    queryKey: ['stores'],
    queryFn: () => apiRequest<{ items: StoreSummary[] }>('/stores'),
  });

  const openSessionsQuery = useQuery({
    queryKey: ['cash-sessions', 'open-for-upload'],
    queryFn: () => apiRequest<{ items: CashSessionSummaryDTO[] }>('/cash-sessions'),
    enabled: canUpload,
  });

  const receiptsQuery = useQuery({
    queryKey: ['receipts', storeFilter, statusFilter, bankFilter, sessionFilter],
    queryFn: () => {
      const qs = new URLSearchParams();
      if (storeFilter) qs.set('storeId', storeFilter);
      if (statusFilter) qs.set('status', statusFilter);
      if (bankFilter) qs.set('bankAccountVerified', bankFilter);
      if (sessionFilter) qs.set('cashSessionId', sessionFilter);
      return apiRequest<ReceiptListResponse>(`/receipts?${qs.toString()}`);
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!selectedFile) throw new Error('Lütfen bir dekont dosyası seçin.');
      if (!selectedSessionId) throw new Error('Lütfen açık bir kasa oturumu seçin.');
      const formData = new FormData();
      formData.append('cashSessionId', selectedSessionId);
      formData.append('file', selectedFile);
      return apiRequest<TransferReceiptDetailDTO>('/receipts/upload', {
        method: 'POST',
        body: formData,
      });
    },
    onSuccess: (created) => {
      void queryClient.invalidateQueries({ queryKey: ['receipts'] });
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setUploadOpen(false);
      setSelectedFile(null);
      setUploadError(null);
      navigate(`/dekontlar/${created.id}`);
    },
    onError: (err) => {
      setUploadError(
        err instanceof ApiClientError
          ? err.message
          : err instanceof Error
            ? err.message
            : 'Dekont yüklenemedi.',
      );
    },
  });

  const editableSessions = (openSessionsQuery.data?.items ?? []).filter(
    (s) => !s.isLocked && (s.status === 'OPEN' || s.status === 'RETURNED_FOR_CORRECTION'),
  );
  const stores = (storesQuery.data?.items ?? []).filter((s) => s.type === 'STORE');
  const summary = receiptsQuery.data?.summary;

  function openUploadModal() {
    setUploadError(null);
    setSelectedFile(null);
    if (!selectedSessionId && editableSessions.length > 0) {
      setSelectedSessionId(editableSessions[0]!.id);
    }
    setUploadOpen(true);
  }

  const columns: Array<DataTableColumn<TransferReceiptSummaryDTO>> = [
    {
      key: 'createdAt',
      header: 'Yüklenme / İş Günü',
      render: (r) => (
        <div>
          <p className="text-xs font-medium text-slate-900 tabular-nums">
            {formatDateTimeTR(r.createdAt)}
          </p>
          <p className="text-[11px] text-slate-500 tabular-nums">
            Kasa Günü: {formatDateTR(r.sessionBusinessDate)}
          </p>
        </div>
      ),
    },
    {
      key: 'storeCashier',
      header: 'Mağaza / Kasiyer',
      render: (r) => (
        <div>
          <p className="font-medium text-slate-900">{r.store.name}</p>
          <p className="text-xs text-slate-500">{r.cashier.fullName}</p>
        </div>
      ),
    },
    {
      key: 'sender',
      header: 'Gönderen / Referans',
      render: (r) => (
        <div className="max-w-52">
          <p className="font-medium text-slate-800 truncate">{r.senderName ?? 'Okunamadı'}</p>
          <p className="text-xs text-slate-500 font-mono truncate">
            {r.referenceNumber ?? r.originalFilename}
          </p>
        </div>
      ),
    },
    {
      key: 'amount',
      header: 'Transfer Tutarı',
      align: 'right',
      render: (r) => (
        <div>
          <p className="font-semibold text-slate-900 tabular-nums">
            {r.verifiedAmount ? formatCurrencyTRY(r.verifiedAmount) : 'Belirsiz'}
          </p>
          {r.latestConfidenceScore ? (
            <p className="text-[11px] text-slate-500 tabular-nums">
              OCR Güven: %{r.latestConfidenceScore}
            </p>
          ) : null}
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Dekont Durumu',
      render: (r) => (
        <div className="space-y-1">
          <ReceiptStatusBadge status={r.status} />
          {r.isDuplicate ? (
            <p className="text-[11px] font-medium text-rose-700 flex items-center gap-1">
              <CopyX className="h-3 w-3" aria-hidden="true" />
              Mükerrer ({r.duplicateReason})
            </p>
          ) : null}
        </div>
      ),
    },
    {
      key: 'bank',
      header: 'Banka Teyidi',
      render: (r) => <BankVerifiedBadge verified={r.bankAccountVerified} />,
    },
    {
      key: 'action',
      header: 'İncele',
      align: 'right',
      render: (r) => (
        <Link
          to={`/dekontlar/${r.id}`}
          className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-blue-700 hover:bg-blue-50"
        >
          <span>İncele</span>
          <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
        </Link>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            IBAN / Havale Dekontları ve OCR Doğrulama
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Yüklenen JPG, PNG ve PDF dekontlar otomatik OCR ve 4 katmanlı mükerrer kontrolünden
            geçer. Yalnızca merkez tarafından onaylanan ve mükerrer olmayan dekontlar mutabakata
            dahil edilir.
          </p>
        </div>
        {canUpload ? (
          <button
            id="upload-receipt-btn"
            type="button"
            onClick={openUploadModal}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 transition-colors shrink-0"
          >
            <FileUp className="h-4 w-4" aria-hidden="true" />
            Yeni Dekont Yükle
          </button>
        ) : null}
      </header>

      {/* Özet Kartları */}
      <section aria-label="Dekont özeti" className="grid grid-cols-2 lg:grid-cols-6 gap-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Toplam Dekont</p>
          <p className="mt-1 text-xl font-semibold text-slate-900 tabular-nums">
            {summary?.totalCount ?? 0}
          </p>
        </div>
        <div className="rounded-xl border border-amber-200 bg-amber-50/40 p-4">
          <p className="text-xs text-amber-800">Manuel / Kasiyer Kontrol</p>
          <p className="mt-1 text-xl font-semibold text-amber-900 tabular-nums">
            {summary?.manualReviewCount ?? 0}
          </p>
        </div>
        <div className="rounded-xl border border-blue-200 bg-blue-50/40 p-4">
          <p className="text-xs text-blue-800">Merkez Onayı Bekleyen</p>
          <p className="mt-1 text-xl font-semibold text-blue-900 tabular-nums">
            {summary?.pendingApprovalCount ?? 0}
          </p>
        </div>
        <div className="rounded-xl border border-rose-200 bg-rose-50/40 p-4">
          <p className="text-xs text-rose-800">Mükerrer / Hatalı</p>
          <p className="mt-1 text-xl font-semibold text-rose-900 tabular-nums">
            {summary?.duplicateOrFailedCount ?? 0}
          </p>
        </div>
        <div className="rounded-xl border border-emerald-200 bg-emerald-50/40 p-4">
          <p className="text-xs text-emerald-800">Onaylı Havale / EFT</p>
          <p className="mt-1 text-lg font-semibold text-emerald-900 tabular-nums">
            {formatCurrencyTRY(summary?.approvedTotal)}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Bankada Teyitli Toplam</p>
          <p className="mt-1 text-lg font-semibold text-slate-900 tabular-nums">
            {formatCurrencyTRY(summary?.bankVerifiedTotal)}
          </p>
        </div>
      </section>

      {/* Filtreler */}
      <section className="rounded-xl border border-slate-200 bg-white p-4 flex flex-wrap items-end gap-4">
        {isGlobal ? (
          <div>
            <label htmlFor="rcpt-store" className="block text-xs font-medium text-slate-600 mb-1">
              Mağaza
            </label>
            <select
              id="rcpt-store"
              value={storeFilter}
              onChange={(e) => setStoreFilter(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm min-w-44"
            >
              <option value="">Tüm Mağazalar</option>
              {stores.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>
        ) : null}

        <div>
          <label htmlFor="rcpt-status" className="block text-xs font-medium text-slate-600 mb-1">
            Dekont Durumu
          </label>
          <select
            id="rcpt-status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as ReceiptStatus | '')}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm min-w-52"
          >
            <option value="">Tüm Durumlar</option>
            {RECEIPT_STATUSES.map((st) => (
              <option key={st} value={st}>
                {RECEIPT_STATUS_LABELS_TR[st]}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="rcpt-bank" className="block text-xs font-medium text-slate-600 mb-1">
            Banka Hesabı Teyidi
          </label>
          <select
            id="rcpt-bank"
            value={bankFilter}
            onChange={(e) => setBankFilter(e.target.value as '' | 'true' | 'false')}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm min-w-44"
          >
            <option value="">Tümü</option>
            <option value="true">Bankada Teyitli</option>
            <option value="false">Banka Teyidi Bekliyor</option>
          </select>
        </div>

        {sessionFilter ? (
          <button
            type="button"
            onClick={() => setSessionFilter('')}
            className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50"
          >
            Oturum Filtresini Temizle
          </button>
        ) : null}
      </section>

      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <ReceiptText className="h-4 w-4 text-slate-700" aria-hidden="true" />
          <h2 className="text-base font-semibold text-slate-900">Yüklenen Dekontlar</h2>
        </div>
        {receiptsQuery.isLoading ? (
          <p className="text-sm text-slate-500">Dekontlar yükleniyor...</p>
        ) : (
          <DataTable
            caption="IBAN transfer dekontları listesi"
            columns={columns}
            rows={receiptsQuery.data?.items ?? []}
            rowKey={(r) => r.id}
            emptyMessage="Kriterlere uygun yüklenmiş dekont bulunmamaktadır."
          />
        )}
      </section>

      {/* Dekont Yükleme Modalı */}
      <ModalDialog
        open={uploadOpen}
        title="IBAN / Havale Dekontu Yükle"
        description="Desteklenen biçimler: JPG, JPEG, PNG, PDF (en fazla 10 MB). Yükleme sonrası OCR ve mükerrer kontrolü otomatik çalışır."
        onClose={() => setUploadOpen(false)}
      >
        <form
          onSubmit={(e: FormEvent) => {
            e.preventDefault();
            setUploadError(null);
            uploadMutation.mutate();
          }}
          className="space-y-4"
        >
          {uploadError ? (
            <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
              {uploadError}
            </div>
          ) : null}

          {editableSessions.length === 0 ? (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900">
              Dekont yükleyebilmek için önce <strong>Günlük Kasa</strong> ekranından açık bir kasa
              oturumu başlatmalısınız.
            </div>
          ) : (
            <>
              <div>
                <label htmlFor="up-session" className="block text-xs font-medium text-slate-700 mb-1">
                  Bağlanacak Açık Kasa Oturumu
                </label>
                <select
                  id="up-session"
                  required
                  value={selectedSessionId}
                  onChange={(e) => setSelectedSessionId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
                >
                  <option value="">Kasa oturumu seçin...</option>
                  {editableSessions.map((s) => (
                    <option key={s.id} value={s.id}>
                      {formatDateTR(s.businessDate)} · {s.store.name} · {s.cashier.fullName} (Vardiya #{s.shiftNo})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="up-file" className="block text-xs font-medium text-slate-700 mb-1">
                  Dekont Dosyası (JPG, JPEG, PNG veya PDF)
                </label>
                <input
                  id="up-file"
                  type="file"
                  required
                  accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] ?? null)}
                  className="block w-full text-sm text-slate-700 file:mr-3 file:rounded-lg file:border-0 file:bg-slate-900 file:px-3.5 file:py-2 file:text-xs file:font-semibold file:text-white hover:file:bg-slate-800"
                />
              </div>
            </>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setUploadOpen(false)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={uploadMutation.isPending || editableSessions.length === 0}
              className="rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
            >
              {uploadMutation.isPending ? 'OCR İşleniyor...' : 'Yükle ve OCR ile Oku'}
            </button>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
}
