import { useEffect, useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  formatCurrencyTRY,
  formatDateTimeTR,
  formatDateTR,
  type ReceiptCentralAction,
  type TransferReceiptDetailDTO,
} from '@kasa/shared';
import {
  AlertTriangle,
  ArrowLeft,
  BadgeCheck,
  CopyX,
  ExternalLink,
  Landmark,
  RefreshCw,
  Send,
  ShieldAlert,
  XCircle,
} from 'lucide-react';
import { ModalDialog } from '../../components/ModalDialog';
import { BankVerifiedBadge, ReceiptStatusBadge } from '../../components/StatusBadges';
import { ApiClientError, apiRequest } from '../../lib/api';
import { useAuth } from '../auth/AuthContext';

export function ReceiptDetailPage() {
  const { receiptId } = useParams<{ receiptId: string }>();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Düzenlenebilir doğrulama alanları
  const [verifiedAmount, setVerifiedAmount] = useState('');
  const [transactionDate, setTransactionDate] = useState('');
  const [transactionTime, setTransactionTime] = useState('');
  const [senderName, setSenderName] = useState('');
  const [receiverName, setReceiverName] = useState('');
  const [senderBank, setSenderBank] = useState('');
  const [receiverBank, setReceiverBank] = useState('');
  const [iban, setIban] = useState('');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [description, setDescription] = useState('');
  const [note, setNote] = useState('');
  const [approveWithBankCheck, setApproveWithBankCheck] = useState(false);

  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Merkez Ret / Mükerrer / Manuel Kontrol Modalı
  const [centralActionModal, setCentralActionModal] = useState<ReceiptCentralAction | null>(null);
  const [centralReason, setCentralReason] = useState('');

  const detailQuery = useQuery({
    queryKey: ['receipt', receiptId],
    queryFn: () => apiRequest<TransferReceiptDetailDTO>(`/receipts/${receiptId}`),
    enabled: Boolean(receiptId),
  });

  const receipt = detailQuery.data;

  useEffect(() => {
    if (!receipt) return;
    setVerifiedAmount(receipt.verifiedAmount ?? '');
    setTransactionDate(receipt.transactionDate ?? '');
    setTransactionTime(receipt.transactionTime ?? '');
    setSenderName(receipt.senderName ?? '');
    setReceiverName(receipt.receiverName ?? '');
    setSenderBank(receipt.senderBank ?? '');
    setReceiverBank(receipt.receiverBank ?? '');
    setIban(receipt.iban ?? '');
    setReferenceNumber(receipt.referenceNumber ?? '');
    setDescription(receipt.description ?? '');
  }, [receipt]);

  const confirmMutation = useMutation({
    mutationFn: () =>
      apiRequest<TransferReceiptDetailDTO>(`/receipts/${receiptId}/confirm`, {
        method: 'POST',
        body: JSON.stringify({
          verifiedAmount: verifiedAmount.trim().replace(',', '.'),
          transactionDate: transactionDate || null,
          transactionTime: transactionTime.trim() || null,
          senderName: senderName.trim() || null,
          receiverName: receiverName.trim() || null,
          senderBank: senderBank.trim() || null,
          receiverBank: receiverBank.trim() || null,
          iban: iban.trim() || null,
          referenceNumber: referenceNumber.trim() || null,
          description: description.trim() || null,
          note: note.trim() || null,
        }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['receipt', receiptId] });
      void queryClient.invalidateQueries({ queryKey: ['receipts'] });
      setActionError(null);
      setActionSuccess('Dekont bilgileri teyit edildi ve Merkez Onayına gönderildi.');
    },
    onError: (err) => {
      setActionSuccess(null);
      setActionError(err instanceof ApiClientError ? err.message : 'Doğrulama kaydedilemedi.');
    },
  });

  const centralReviewMutation = useMutation({
    mutationFn: (payload: { action: ReceiptCentralAction; reason?: string }) =>
      apiRequest<TransferReceiptDetailDTO>(`/receipts/${receiptId}/central-review`, {
        method: 'POST',
        body: JSON.stringify({
          action: payload.action,
          ...(payload.action === 'APPROVE'
            ? {
                verifiedAmount: verifiedAmount.trim().replace(',', '.') || undefined,
                transactionDate: transactionDate || null,
                transactionTime: transactionTime.trim() || null,
                senderName: senderName.trim() || null,
                receiverName: receiverName.trim() || null,
                senderBank: senderBank.trim() || null,
                receiverBank: receiverBank.trim() || null,
                iban: iban.trim() || null,
                referenceNumber: referenceNumber.trim() || null,
                description: description.trim() || null,
                bankAccountVerified: approveWithBankCheck,
              }
            : {}),
          reason: payload.reason ?? (note.trim() || null),
        }),
      }),
    onSuccess: (_data, vars) => {
      void queryClient.invalidateQueries({ queryKey: ['receipt', receiptId] });
      void queryClient.invalidateQueries({ queryKey: ['receipts'] });
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setCentralActionModal(null);
      setCentralReason('');
      setActionError(null);
      setActionSuccess(
        vars.action === 'APPROVE'
          ? 'Dekont merkez tarafından onaylandı ve günlük Havale/EFT mutabakatına dahil edildi.'
          : 'Dekont durumu güncellendi.',
      );
    },
    onError: (err) => {
      setActionSuccess(null);
      setActionError(err instanceof ApiClientError ? err.message : 'Merkez işlemi başarısız.');
    },
  });

  const bankVerifyMutation = useMutation({
    mutationFn: (nextState: boolean) =>
      apiRequest<TransferReceiptDetailDTO>(`/receipts/${receiptId}/bank-verify`, {
        method: 'POST',
        body: JSON.stringify({
          bankAccountVerified: nextState,
          reason: nextState
            ? 'Banka ekstresinde tutarın hesaba geçtiği merkez tarafından teyit edildi.'
            : 'Banka hesabı teyidi geri alındı.',
        }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['receipt', receiptId] });
      void queryClient.invalidateQueries({ queryKey: ['receipts'] });
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setActionError(null);
      setActionSuccess('Banka hesabı teyit durumu güncellendi.');
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'Banka teyidi güncellenemedi.');
    },
  });

  const reprocessMutation = useMutation({
    mutationFn: () =>
      apiRequest<TransferReceiptDetailDTO>(`/receipts/${receiptId}/reprocess-ocr`, {
        method: 'POST',
        body: JSON.stringify({}),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['receipt', receiptId] });
      setActionSuccess('Orijinal dosya üzerinden OCR yeniden çalıştırıldı.');
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'OCR yeniden çalıştırılamadı.');
    },
  });

  if (detailQuery.isLoading) {
    return <p className="text-sm text-slate-500">Dekont detayı yükleniyor...</p>;
  }

  if (detailQuery.isError || !receipt) {
    return (
      <div className="space-y-4">
        <Link to="/dekontlar" className="inline-flex items-center gap-1.5 text-sm text-blue-700 hover:underline">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          Dekont Listesine Dön
        </Link>
        <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800">
          Dekont kaydı bulunamadı veya erişim yetkiniz yok.
        </div>
      </div>
    );
  }

  const latestOcr = receipt.ocrResults[0];
  const fileUrl = `/api/v1/receipts/${receipt.id}/file`;
  const isCentral = user?.role === 'CENTRAL_ACCOUNTING' || user?.role === 'SYSTEM_ADMIN';
  const canStoreConfirm =
    !isCentral &&
    (receipt.status === 'EXTRACTED' ||
      receipt.status === 'MANUAL_REVIEW_REQUIRED' ||
      receipt.status === 'FAILED_OCR');
  const canCentralAct =
    isCentral && !receipt.isDuplicate && receipt.status !== 'DUPLICATE' && receipt.status !== 'APPROVED';
  const fieldsEditable = canStoreConfirm || canCentralAct;

  return (
    <div className="space-y-6">
      <div>
        <Link
          to="/dekontlar"
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 mb-3"
        >
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
          IBAN Dekontlarına Dön
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
              Dekont İnceleme – {receipt.originalFilename}
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              {receipt.store.name} · Kasiyer: <strong>{receipt.cashier.fullName}</strong> · Kasa
              Günü: <span className="tabular-nums">{formatDateTR(receipt.sessionBusinessDate)}</span>
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <ReceiptStatusBadge status={receipt.status} />
            <BankVerifiedBadge verified={receipt.bankAccountVerified} />
          </div>
        </div>
      </div>

      {/* Mükerrer veya OCR Uyarıları */}
      {receipt.isDuplicate || receipt.duplicateOfReceiptId ? (
        <div
          role="alert"
          className="rounded-xl border border-rose-300 bg-rose-50 p-4 flex items-start gap-3 text-sm text-rose-900"
        >
          <CopyX className="h-5 w-5 text-rose-700 shrink-0 mt-0.5" aria-hidden="true" />
          <div>
            <p className="font-semibold">
              {receipt.isDuplicate
                ? `Mükerrer Dekont Tespit Edildi (${receipt.duplicateReason ?? ''})`
                : `Şüpheli Mükerrer Uyarısı (${receipt.duplicateReason ?? ''})`}
            </p>
            <p className="text-xs mt-1">
              Aynı transfer günlük toplama iki kez eklenemez. Orijinal dekont denetim amacıyla
              silinmeden saklanır.{' '}
              {receipt.duplicateOfReceiptId ? (
                <Link
                  to={`/dekontlar/${receipt.duplicateOfReceiptId}`}
                  className="underline font-semibold"
                >
                  Eşleşen dekontu aç →
                </Link>
              ) : null}
            </p>
          </div>
        </div>
      ) : null}

      {latestOcr && latestOcr.warnings.length > 0 ? (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 space-y-1.5">
          <p className="text-xs font-semibold text-amber-900 flex items-center gap-1.5">
            <AlertTriangle className="h-4 w-4 text-amber-700" aria-hidden="true" />
            OCR ve Finansal Kontrol Uyarıları (Güven Skoru: %{latestOcr.confidenceScore})
          </p>
          <ul className="list-disc pl-5 text-xs text-amber-900 space-y-0.5">
            {latestOcr.warnings.map((w, i) => (
              <li key={i}>{w}</li>
            ))}
          </ul>
        </div>
      ) : null}

      {latestOcr && latestOcr.excludedBalanceAmounts.length > 0 ? (
        <div className="rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-xs text-sky-900">
          <strong>Hesap Bakiyesi Dışlama Kuralı Uygulandı:</strong> Dekont üzerinde tespit edilen{' '}
          {latestOcr.excludedBalanceAmounts.map((b) => formatCurrencyTRY(b.amount)).join(', ')} hesap
          bakiyesi tutarları transfer tutarı olarak kabul edilmedi.
        </div>
      ) : null}

      {actionError ? (
        <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
          {actionError}
        </div>
      ) : null}
      {actionSuccess ? (
        <div role="status" className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          {actionSuccess}
        </div>
      ) : null}

      {/* Çift Sütun: Sol = Orijinal Dekont Önizleme, Sağ = Çıkarılan Alanlar & Onay */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Orijinal Dekont Önizleme */}
        <section className="lg:col-span-5 rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <h2 className="text-sm font-semibold text-slate-900">Orijinal Dekont Önizleme</h2>
            <a
              href={fileUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 hover:underline"
            >
              <span>Yeni Sekmede Aç</span>
              <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
            </a>
          </div>
          <div className="p-4 bg-slate-100/70 flex items-center justify-center min-h-80">
            {receipt.mimeType === 'application/pdf' ? (
              <iframe
                title={`Dekont PDF Önizleme: ${receipt.originalFilename}`}
                src={fileUrl}
                className="w-full h-[520px] rounded border border-slate-200 bg-white"
              />
            ) : (
              <img
                src={fileUrl}
                alt={`Yüklenen dekont: ${receipt.originalFilename}`}
                className="max-h-[540px] w-auto rounded border border-slate-200 bg-white object-contain"
              />
            )}
          </div>
          {latestOcr ? (
            <div className="p-4 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
              <span>
                Motor: <strong className="font-mono">{latestOcr.provider}</strong> · Güven:{' '}
                <strong className="tabular-nums">%{latestOcr.confidenceScore}</strong>
              </span>
              {receipt.status !== 'APPROVED' ? (
                <button
                  type="button"
                  onClick={() => reprocessMutation.mutate()}
                  disabled={reprocessMutation.isPending}
                  className="inline-flex items-center gap-1 rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  <RefreshCw className="h-3 w-3" aria-hidden="true" />
                  OCR Tekrarla
                </button>
              ) : null}
            </div>
          ) : null}
        </section>

        {/* Çıkarılan Alanlar ve Doğrulama Formu */}
        <section className="lg:col-span-7 space-y-5">
          <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                Tespit Edilen ve Doğrulanacak Dekont Bilgileri
              </h2>
              <p className="text-xs text-slate-600 mt-0.5">
                OCR sonucu kesin doğrulama sayılmaz; alanları orijinal dekontla karşılaştırıp
                onaylayın.
              </p>
            </div>

            <form
              onSubmit={(e: FormEvent) => {
                e.preventDefault();
                if (canStoreConfirm) {
                  confirmMutation.mutate();
                } else if (canCentralAct) {
                  centralReviewMutation.mutate({ action: 'APPROVE' });
                }
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="r-amount" className="block text-xs font-medium text-slate-700 mb-1">
                    Transfer Tutarı (₺) *
                  </label>
                  <input
                    id="r-amount"
                    type="text"
                    inputMode="decimal"
                    required
                    disabled={!fieldsEditable}
                    value={verifiedAmount}
                    onChange={(e) => setVerifiedAmount(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold tabular-nums disabled:bg-slate-50"
                  />
                </div>
                <div>
                  <label htmlFor="r-date" className="block text-xs font-medium text-slate-700 mb-1">
                    İşlem Tarihi
                  </label>
                  <input
                    id="r-date"
                    type="date"
                    disabled={!fieldsEditable}
                    value={transactionDate}
                    onChange={(e) => setTransactionDate(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums disabled:bg-slate-50"
                  />
                </div>
                <div>
                  <label htmlFor="r-time" className="block text-xs font-medium text-slate-700 mb-1">
                    İşlem Saati
                  </label>
                  <input
                    id="r-time"
                    type="text"
                    disabled={!fieldsEditable}
                    value={transactionTime}
                    onChange={(e) => setTransactionTime(e.target.value)}
                    placeholder="14:30"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums disabled:bg-slate-50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="r-sender" className="block text-xs font-medium text-slate-700 mb-1">
                    Gönderen Adı
                  </label>
                  <input
                    id="r-sender"
                    type="text"
                    disabled={!fieldsEditable}
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:bg-slate-50"
                  />
                </div>
                <div>
                  <label htmlFor="r-receiver" className="block text-xs font-medium text-slate-700 mb-1">
                    Alıcı Adı
                  </label>
                  <input
                    id="r-receiver"
                    type="text"
                    disabled={!fieldsEditable}
                    value={receiverName}
                    onChange={(e) => setReceiverName(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:bg-slate-50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="r-sbank" className="block text-xs font-medium text-slate-700 mb-1">
                    Gönderen Banka
                  </label>
                  <input
                    id="r-sbank"
                    type="text"
                    disabled={!fieldsEditable}
                    value={senderBank}
                    onChange={(e) => setSenderBank(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:bg-slate-50"
                  />
                </div>
                <div>
                  <label htmlFor="r-rbank" className="block text-xs font-medium text-slate-700 mb-1">
                    Alıcı Banka
                  </label>
                  <input
                    id="r-rbank"
                    type="text"
                    disabled={!fieldsEditable}
                    value={receiverBank}
                    onChange={(e) => setReceiverBank(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:bg-slate-50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="r-iban" className="block text-xs font-medium text-slate-700 mb-1">
                    IBAN
                  </label>
                  <input
                    id="r-iban"
                    type="text"
                    disabled={!fieldsEditable}
                    value={iban}
                    onChange={(e) => setIban(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono disabled:bg-slate-50"
                  />
                </div>
                <div>
                  <label htmlFor="r-ref" className="block text-xs font-medium text-slate-700 mb-1">
                    İşlem / Referans Numarası
                  </label>
                  <input
                    id="r-ref"
                    type="text"
                    disabled={!fieldsEditable}
                    value={referenceNumber}
                    onChange={(e) => setReferenceNumber(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs font-mono disabled:bg-slate-50"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="r-desc" className="block text-xs font-medium text-slate-700 mb-1">
                  Dekont Açıklaması
                </label>
                <input
                  id="r-desc"
                  type="text"
                  disabled={!fieldsEditable}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:bg-slate-50"
                />
              </div>

              {fieldsEditable ? (
                <div>
                  <label htmlFor="r-note" className="block text-xs font-medium text-slate-700 mb-1">
                    Kontrol / Doğrulama Notu (Opsiyonel)
                  </label>
                  <input
                    id="r-note"
                    type="text"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="Düzeltme veya inceleme açıklaması..."
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
              ) : null}

              {canStoreConfirm ? (
                <div className="pt-2">
                  <button
                    id="confirm-receipt-btn"
                    type="submit"
                    disabled={confirmMutation.isPending}
                    className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
                  >
                    <Send className="h-4 w-4" aria-hidden="true" />
                    {confirmMutation.isPending
                      ? 'Gönderiliyor...'
                      : 'Bilgileri Teyit Et ve Merkez Onayına Gönder'}
                  </button>
                </div>
              ) : null}

              {canCentralAct ? (
                <div className="pt-3 border-t border-slate-200 space-y-3">
                  <label className="flex items-center gap-2 text-xs text-slate-700">
                    <input
                      type="checkbox"
                      checked={approveWithBankCheck}
                      onChange={(e) => setApproveWithBankCheck(e.target.checked)}
                      className="h-4 w-4 rounded border-slate-300"
                    />
                    <span>Paranın banka hesabına geçtiği ekstrede de doğrulandı</span>
                  </label>

                  <div className="flex flex-wrap gap-2">
                    <button
                      id="central-approve-receipt-btn"
                      type="submit"
                      disabled={centralReviewMutation.isPending}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-800 disabled:opacity-60"
                    >
                      <BadgeCheck className="h-4 w-4" aria-hidden="true" />
                      Onayla ve Mutabakata Dahil Et
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCentralReason('');
                        setCentralActionModal('SEND_TO_MANUAL_REVIEW');
                      }}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-amber-300 bg-amber-50 px-3.5 py-2 text-xs font-semibold text-amber-900 hover:bg-amber-100"
                    >
                      <ShieldAlert className="h-3.5 w-3.5" aria-hidden="true" />
                      Manuel Kontrole İade
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCentralReason('');
                        setCentralActionModal('MARK_DUPLICATE');
                      }}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-rose-300 bg-white px-3.5 py-2 text-xs font-semibold text-rose-800 hover:bg-rose-50"
                    >
                      <CopyX className="h-3.5 w-3.5" aria-hidden="true" />
                      Mükerrer İşaretle
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setCentralReason('');
                        setCentralActionModal('REJECT');
                      }}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-rose-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-rose-800"
                    >
                      <XCircle className="h-3.5 w-3.5" aria-hidden="true" />
                      Reddet
                    </button>
                  </div>
                </div>
              ) : null}
            </form>
          </div>

          {/* Ayrı Banka Hesabı Teyidi Kontrolü (Merkez Muhasebe) */}
          {isCentral && !receipt.isDuplicate && receipt.status !== 'REJECTED' ? (
            <div className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-1.5">
                  <Landmark className="h-4 w-4 text-slate-700" aria-hidden="true" />
                  Banka Hesabı Ekstre Kontrolü (Ayrı Aşama)
                </h2>
                <p className="text-xs text-slate-600 mt-1">
                  Dekontun okunması veya onaylanması paranın banka hesabına geçtiğini otomatik
                  kanıtlamaz. Banka hareketlerinden teyit ettiğinizde işaretleyin.
                </p>
              </div>
              <button
                type="button"
                disabled={bankVerifyMutation.isPending}
                onClick={() => bankVerifyMutation.mutate(!receipt.bankAccountVerified)}
                className={`shrink-0 rounded-lg px-4 py-2 text-xs font-semibold transition-colors ${
                  receipt.bankAccountVerified
                    ? 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                    : 'bg-slate-900 text-white hover:bg-slate-800'
                }`}
              >
                {receipt.bankAccountVerified
                  ? 'Banka Teyidini Kaldır'
                  : 'Bankada Hesaba Geçtiğini Teyit Et'}
              </button>
            </div>
          ) : null}

          {/* Doğrulama Geçmişi ve Ham OCR Metni */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-3">
            <h2 className="text-sm font-semibold text-slate-900">
              Doğrulama ve İnceleme Geçmişi ({receipt.verifications.length})
            </h2>
            {receipt.verifications.length === 0 ? (
              <p className="text-xs text-slate-500">Henüz manuel doğrulama kaydı bulunmuyor.</p>
            ) : (
              <ul className="divide-y divide-slate-100 text-xs">
                {receipt.verifications.map((v) => (
                  <li key={v.id} className="py-2.5 flex items-start justify-between gap-3">
                    <div>
                      <p className="font-medium text-slate-900">
                        {v.verifiedBy.fullName} · <span className="font-mono">{v.stage}</span> ·{' '}
                        <span className="font-mono text-blue-700">{v.action}</span>
                      </p>
                      {v.reason ? <p className="text-slate-600 mt-0.5">{v.reason}</p> : null}
                    </div>
                    <span className="text-slate-500 tabular-nums shrink-0">
                      {formatDateTimeTR(v.verifiedAt)}
                    </span>
                  </li>
                ))}
              </ul>
            )}

            {latestOcr ? (
              <details className="pt-2 border-t border-slate-100">
                <summary className="cursor-pointer text-xs font-medium text-slate-600 hover:text-slate-900">
                  Ham OCR Metnini ve Tespit Edilen Tüm Tutarları Göster
                </summary>
                <pre className="mt-2 max-h-60 overflow-auto rounded-lg bg-slate-950 p-3 text-[11px] text-slate-100 whitespace-pre-wrap">
                  {latestOcr.rawText || '(Metin çıkarılamadı)'}
                </pre>
              </details>
            ) : null}
          </div>
        </section>
      </div>

      {/* Merkez Gerekçe Modalı */}
      <ModalDialog
        open={centralActionModal !== null}
        title={
          centralActionModal === 'REJECT'
            ? 'Dekontu Reddet'
            : centralActionModal === 'MARK_DUPLICATE'
              ? 'Dekontu Mükerrer İşaretle'
              : 'Manuel Kontrole Gönder'
        }
        description="Orijinal dekont silinmez; karar gerekçesiyle denetim günlüğüne kaydedilir."
        onClose={() => setCentralActionModal(null)}
      >
        <form
          onSubmit={(e: FormEvent) => {
            e.preventDefault();
            if (!centralActionModal) return;
            centralReviewMutation.mutate({
              action: centralActionModal,
              reason: centralReason.trim(),
            });
          }}
          className="space-y-4"
        >
          <div>
            <label htmlFor="c-reason" className="block text-xs font-medium text-slate-700 mb-1">
              Gerekçe (En az 5 karakter)
            </label>
            <textarea
              id="c-reason"
              rows={3}
              required
              minLength={5}
              value={centralReason}
              onChange={(e) => setCentralReason(e.target.value)}
              placeholder="Karar gerekçesini açıkça yazın..."
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setCentralActionModal(null)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={centralReviewMutation.isPending}
              className="rounded-lg bg-rose-700 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-800 disabled:opacity-60"
            >
              Kaydet
            </button>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
}
