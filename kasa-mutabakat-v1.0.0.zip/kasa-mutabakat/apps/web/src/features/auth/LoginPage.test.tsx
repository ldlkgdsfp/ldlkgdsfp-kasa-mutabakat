import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { describe, expect, it, vi } from 'vitest';
import { AuthProvider } from './AuthContext';
import { LoginPage } from './LoginPage';

vi.stubGlobal(
  'fetch',
  vi.fn().mockResolvedValue({
    ok: false,
    status: 401,
    headers: new Headers({ 'content-type': 'application/json' }),
    json: async () => ({ error: { code: 'UNAUTHORIZED', message: 'Oturum yok' } }),
  }),
);

describe('LoginPage', () => {
  it('renders accessible Turkish sign-in form with autofill attributes and deferred errors', async () => {
    const user = userEvent.setup();

    render(
      <MemoryRouter>
        <AuthProvider>
          <LoginPage />
        </AuthProvider>
      </MemoryRouter>,
    );

    const identifierInput = screen.getByLabelText('Kullanıcı Adı veya E-posta');
    const passwordInput = screen.getByLabelText('Parola');

    expect(identifierInput).toHaveAttribute('autocomplete', 'username');
    expect(identifierInput).toHaveAttribute('aria-invalid', 'false');
    expect(passwordInput).toHaveAttribute('autocomplete', 'current-password');
    expect(passwordInput).toHaveAttribute('aria-invalid', 'false');
    expect(passwordInput).toHaveAttribute('type', 'password');

    // Parola görünürlük düğmesi çalışır
    const toggleButton = screen.getByRole('button', { name: 'Parolayı göster' });
    await user.click(toggleButton);
    expect(passwordInput).toHaveAttribute('type', 'text');
    expect(toggleButton).toHaveAttribute('aria-pressed', 'true');

    // Boş gönderimde etkileşim sonrası erişilebilir hata gösterilir
    await user.click(screen.getByRole('button', { name: 'Giriş Yap' }));
    expect(identifierInput).toHaveAttribute('aria-invalid', 'true');
    expect(identifierInput).toHaveAttribute('aria-describedby', 'login-identifier-error');
  });
});
