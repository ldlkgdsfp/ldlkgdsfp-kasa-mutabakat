import { useRef, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginRequestSchema } from '@kasa/shared';
import { Building2, Eye, EyeOff, Lock, ShieldCheck, User } from 'lucide-react';
import { ApiClientError } from '../../lib/api';
import { useAuth } from './AuthContext';

export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [touched, setTouched] = useState({ identifier: false, password: false });
  const [submitted, setSubmitted] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [announcement, setAnnouncement] = useState('');

  const identifierRef = useRef<HTMLInputElement>(null);
  const passwordRef = useRef<HTMLInputElement>(null);

  const parsed = loginRequestSchema.safeParse({ identifier, password });
  const fieldErrors = parsed.success ? {} : parsed.error.flatten().fieldErrors;

  const identifierError =
    (touched.identifier || submitted) && fieldErrors.identifier?.[0]
      ? fieldErrors.identifier[0]
      : null;
  const passwordError =
    (touched.password || submitted) && fieldErrors.password?.[0]
      ? fieldErrors.password[0]
      : null;

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitted(true);
    setServerError(null);

    if (!parsed.success) {
      const errs = parsed.error.flatten().fieldErrors;
      if (errs.identifier?.[0]) {
        setAnnouncement(`Kullanıcı adı veya e-posta: ${errs.identifier[0]}`);
        identifierRef.current?.focus();
      } else if (errs.password?.[0]) {
        setAnnouncement(`Parola: ${errs.password[0]}`);
        passwordRef.current?.focus();
      }
      return;
    }

    setIsSubmitting(true);
    try {
      await login(parsed.data);
      navigate('/', { replace: true });
    } catch (err) {
      const message =
        err instanceof ApiClientError
          ? err.message
          : 'Giriş sırasında bir bağlantı hatası oluştu.';
      setServerError(message);
      setAnnouncement(message);
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="min-h-dvh bg-slate-100 flex flex-col lg:flex-row">
      {/* Sol kurumsal bilgi paneli */}
      <aside className="hidden lg:flex lg:w-[44%] bg-slate-900 text-slate-100 p-12 flex-col justify-between">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-blue-600 flex items-center justify-center text-white">
            <Building2 className="h-5 w-5" aria-hidden="true" />
          </div>
          <div>
            <p className="text-sm font-semibold tracking-wide text-white">KASA MUTABAKAT</p>
            <p className="text-xs text-slate-400">Mağaza ve Merkez Finans Kontrolü</p>
          </div>
        </div>

        <div className="space-y-6 max-w-md">
          <h2 className="text-3xl font-semibold tracking-tight leading-snug text-white">
            Günlük kasa kapanışı, IBAN dekont doğrulama ve merkez mutabakatı tek sistemde.
          </h2>
          <p className="text-sm leading-relaxed text-slate-300">
            Üç mağaza ve merkez ofis arasında kasiyer bazlı tahsilat takibi, kesin ondalık kasa
            farkı hesaplaması, mükerrer dekont engelleme ve tam denetim izi.
          </p>
          <dl className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-800">
            <div>
              <dt className="text-xs text-slate-400">Ödeme Kategorileri</dt>
              <dd className="text-sm font-medium text-slate-100 mt-1">
                Nakit · Kredi Kartı · Havale/EFT
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-400">Erişim Politikası</dt>
              <dd className="text-sm font-medium text-slate-100 mt-1">
                Rol ve Mağaza İzolasyonlu
              </dd>
            </div>
          </dl>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" aria-hidden="true" />
          <span>Sunucu taraflı güvenli oturum, CSRF koruması ve değiştirilemez denetim kaydı</span>
        </div>
      </aside>

      {/* Sağ giriş alanı */}
      <main className="flex-1 flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-md">
          <div className="lg:hidden flex items-center gap-2.5 mb-8">
            <div className="h-9 w-9 rounded-lg bg-slate-900 flex items-center justify-center text-white">
              <Building2 className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-900">Kasa Mutabakat</p>
              <p className="text-xs text-slate-500">Mağaza &amp; Merkez Finans Kontrolü</p>
            </div>
          </div>

          <section className="bg-white rounded-xl border border-slate-200 shadow-sm p-7 sm:p-8">
            <header className="mb-6">
              <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
                Sisteme Giriş Yapın
              </h1>
              <p className="text-sm text-slate-600 mt-1.5">
                Yetkili personel hesabınızla devam edin.
              </p>
            </header>

            <div aria-live="polite" className="visually-hidden">
              {announcement}
            </div>

            {serverError ? (
              <div
                role="alert"
                className="mb-5 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800"
              >
                {serverError}
              </div>
            ) : null}

            <form onSubmit={handleSubmit} noValidate className="space-y-5">
              <div>
                <label
                  htmlFor="login-identifier"
                  className="block text-sm font-medium text-slate-700 mb-1.5"
                >
                  Kullanıcı Adı veya E-posta
                </label>
                <div className="relative">
                  <User
                    className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    ref={identifierRef}
                    id="login-identifier"
                    name="username"
                    type="text"
                    required
                    autoComplete="username"
                    spellCheck={false}
                    autoCapitalize="none"
                    autoCorrect="off"
                    enterKeyHint="next"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    onBlur={() => setTouched((prev) => ({ ...prev, identifier: true }))}
                    aria-invalid={identifierError ? 'true' : 'false'}
                    aria-describedby={identifierError ? 'login-identifier-error' : undefined}
                    placeholder="ornek.kullanici"
                    className="w-full rounded-lg border border-slate-300 bg-white pl-10 pr-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                  />
                </div>
                {identifierError ? (
                  <p id="login-identifier-error" className="mt-1.5 text-xs font-medium text-rose-700">
                    {identifierError}
                  </p>
                ) : null}
              </div>

              <div>
                <label
                  htmlFor="login-password"
                  className="block text-sm font-medium text-slate-700 mb-1.5"
                >
                  Parola
                </label>
                <div className="relative">
                  <Lock
                    className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    ref={passwordRef}
                    id="login-password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    autoComplete="current-password"
                    enterKeyHint="done"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onBlur={() => setTouched((prev) => ({ ...prev, password: true }))}
                    aria-invalid={passwordError ? 'true' : 'false'}
                    aria-describedby={passwordError ? 'login-password-error' : undefined}
                    placeholder="••••••••"
                    className="w-full rounded-lg border border-slate-300 bg-white pl-10 pr-11 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((prev) => !prev)}
                    aria-label={showPassword ? 'Parolayı gizle' : 'Parolayı göster'}
                    aria-pressed={showPassword}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-slate-500 hover:text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600/30"
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" aria-hidden="true" />
                    ) : (
                      <Eye className="h-4 w-4" aria-hidden="true" />
                    )}
                  </button>
                </div>
                {passwordError ? (
                  <p id="login-password-error" className="mt-1.5 text-xs font-medium text-rose-700">
                    {passwordError}
                  </p>
                ) : null}
              </div>

              <button
                id="login-submit-button"
                type="submit"
                disabled={isSubmitting}
                className="w-full rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-xs hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:ring-offset-2 disabled:opacity-60 disabled:cursor-not-allowed transition-colors"
              >
                {isSubmitting ? 'Giriş Yapılıyor...' : 'Giriş Yap'}
              </button>
            </form>

            <footer className="mt-6 pt-5 border-t border-slate-100 text-xs text-slate-500">
              Parolanızı unuttuysanız sistem yöneticinizle iletişime geçin. Ardışık 5 hatalı
              denemede hesap güvenlik amacıyla geçici olarak kilitlenir.
            </footer>
          </section>
        </div>
      </main>
    </div>
  );
}
