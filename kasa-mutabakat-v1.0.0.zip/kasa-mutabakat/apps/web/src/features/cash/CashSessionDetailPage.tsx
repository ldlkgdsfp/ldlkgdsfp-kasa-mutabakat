import { useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  formatCurrencyTRY,
  formatDateTimeTR,
  formatDateTR,
  type CashSessionDetailDTO,
  type CashTransactionDTO,
  type CashTransactionType,
  type PaymentMethodCode,
} from '@kasa/shared';
import {
  ArrowLeft,
  Ban,
  CheckCircle2,
  PlusCircle,
  RotateCcw,
  Send,
} from 'lucide-react';
import { DataTable, type DataTableColumn } from '../../components/DataTable';
import { ModalDialog } from '../../components/ModalDialog';
import { CashDifferenceBadge, SessionStatusBadge } from '../../components/StatusBadges';
import { ApiClientError, apiRequest } from '../../lib/api';
import { useAuth } from '../auth/AuthContext';

export function CashSessionDetailPage() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Yeni hareket formu
  const [paymentMethodCode, setPaymentMethodCode] = useState<PaymentMethodCode>('CASH');
  const [transactionType, setTransactionType] = useState<CashTransactionType>('SALE');
  const [amount, setAmount] = useState('');
  const [referenceNo, setReferenceNo] = useState('');
  const [description, setDescription] = useState('');
  const [txError, setTxError] = useState<string | null>(null);

  // Kapanış beyanı
  const [declaredCash, setDeclaredCash] = useState('');
  const [submitNotes, setSubmitNotes] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);

  // İptal ve iade modalları
  const [voidTarget, setVoidTarget] = useState<CashTransactionDTO | null>(null);
  const [voidReason, setVoidReason] = useState('');
  const [returnModalOpen, setReturnModalOpen] = useState(false);
  const [returnReason, setReturnReason] = useState('');

  const detailQuery = useQuery({
    queryKey: ['cash-session', sessionId],
    queryFn: () => apiRequest<CashSessionDetailDTO>(`/cash-sessions/${sessionId}`),
    enabled: Boolean(sessionId),
  });

  const addTxMutation = useMutation({
    mutationFn: () =>
      apiRequest(`/cash-sessions/${sessionId}/transactions`, {
        method: 'POST',
        body: JSON.stringify({
          paymentMethodCode,
          transactionType,
          amount: amount.trim().replace(',', '.'),
          referenceNo: referenceNo.trim() || null,
          description: description.trim() || null,
        }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['cash-session', sessionId] });
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setAmount('');
      setReferenceNo('');
      setDescription('');
      setTxError(null);
    },
    onError: (err) => {
      setTxError(err instanceof ApiClientError ? err.message : 'Hareket kaydedilemedi.');
    },
  });

  const voidMutation = useMutation({
    mutationFn: (txId: string) =>
      apiRequest(`/cash-sessions/${sessionId}/transactions/${txId}/void`, {
        method: 'POST',
        body: JSON.stringify({ reason: voidReason.trim() }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['cash-session', sessionId] });
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setVoidTarget(null);
      setVoidReason('');
      setActionError(null);
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'İşlem iptal edilemedi.');
    },
  });

  const submitMutation = useMutation({
    mutationFn: () =>
      apiRequest(`/cash-sessions/${sessionId}/submit`, {
        method: 'POST',
        body: JSON.stringify({
          declaredCash: declaredCash.trim().replace(',', '.'),
          notes: submitNotes.trim() || null,
        }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['cash-session', sessionId] });
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setActionError(null);
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'Teslim beyanı kaydedilemedi.');
    },
  });

  const storeApproveMutation = useMutation({
    mutationFn: () =>
      apiRequest(`/cash-sessions/${sessionId}/store-approve`, {
        method: 'POST',
        body: JSON.stringify({}),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['cash-session', sessionId] });
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setActionError(null);
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'Merkeze gönderim başarısız.');
    },
  });

  const returnMutation = useMutation({
    mutationFn: () =>
      apiRequest(`/cash-sessions/${sessionId}/return`, {
        method: 'POST',
        body: JSON.stringify({ reason: returnReason.trim() }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['cash-session', sessionId] });
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setReturnModalOpen(false);
      setReturnReason('');
      setActionError(null);
    },
    onError: (err) => {
      setActionError(err instanceof ApiClientError ? err.message : 'İade işlemi başarısız.');
    },
  });

  if (detailQuery.isLoading) {
    return <p className="text-sm text-slate-500">Kasa oturumu yükleniyor...</p>;
  }

  if (detailQuery.isError || !detailQuery.data) {
    return (
      <div className="space-y-4">
        <Link to="/kasa" className="inline-flex items-center gap-1.5 text-sm text-blue-700 hover:underline">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          Günlük Kasaya Dön
        </Link>
        <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800">
          Kasa oturumu yüklenemedi veya görüntüleme yetkiniz bulunmuyor.
        </div>
      </div>
    );
  }

  const session = detailQuery.data;
  const isEditableStatus =
    !session.isLocked &&
    (session.status === 'OPEN' || session.status === 'RETURNED_FOR_CORRECTION');

  const canModify =
    isEditableStatus &&
    user?.role !== 'CENTRAL_ACCOUNTING' &&
    (user?.role !== 'CASHIER' || session.cashierId === user.id);

  const canStoreApprove =
    !session.isLocked &&
    session.status === 'CASHIER_SUBMITTED' &&
    (user?.role === 'STORE_MANAGER' || user?.role === 'SYSTEM_ADMIN');

  const canReturn =
    !session.isLocked &&
    ((user?.role === 'STORE_MANAGER' && session.status === 'CASHIER_SUBMITTED') ||
      ((user?.role === 'CENTRAL_ACCOUNTING' || user?.role === 'SYSTEM_ADMIN') &&
        (session.status === 'CASHIER_SUBMITTED' || session.status === 'STORE_MANAGER_APPROVED')));

  const availableTxTypes: Array<{ value: CashTransactionType; label: string }> =
    paymentMethodCode === 'CASH'
      ? [
          { value: 'SALE', label: 'Nakit Satış' },
          { value: 'REFUND', label: 'Nakit İade' },
          { value: 'CASH_IN', label: 'Diğer Nakit Girişi' },
          { value: 'CASH_OUT', label: 'Diğer Nakit Çıkışı (Masraf vb.)' },
        ]
      : paymentMethodCode === 'CREDIT_CARD'
        ? [
            { value: 'SALE', label: 'Kredi Kartı Satış' },
            { value: 'REFUND', label: 'Kredi Kartı İade' },
          ]
        : [{ value: 'REFUND', label: 'Havale / EFT İade' }];

  const txColumns: Array<DataTableColumn<CashTransactionDTO>> = [
    {
      key: 'occurredAt',
      header: 'Saat',
      render: (t) => <span className="text-xs tabular-nums">{formatDateTimeTR(t.occurredAt)}</span>,
    },
    {
      key: 'method',
      header: 'Ödeme Yöntemi',
      render: (t) => (
        <span className="inline-flex rounded-md bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-700">
          {t.paymentMethodName}
        </span>
      ),
    },
    {
      key: 'type',
      header: 'Hareket Türü',
      render: (t) => (
        <span className={t.isVoided ? 'line-through text-slate-400' : 'font-medium text-slate-900'}>
          {t.transactionTypeLabel}
        </span>
      ),
    },
    {
      key: 'amount',
      header: 'Tutar',
      align: 'right',
      render: (t) => (
        <span
          className={
            t.isVoided
              ? 'line-through text-slate-400 tabular-nums'
              : t.transactionType === 'REFUND' || t.transactionType === 'CASH_OUT'
                ? 'font-semibold text-rose-700 tabular-nums'
                : 'font-semibold text-slate-900 tabular-nums'
          }
        >
          {t.transactionType === 'REFUND' || t.transactionType === 'CASH_OUT' ? '-' : ''}
          {formatCurrencyTRY(t.amount)}
        </span>
      ),
    },
    {
      key: 'desc',
      header: 'Açıklama / Referans',
      render: (t) => (
        <div className="text-xs">
          <p className={t.isVoided ? 'line-through text-slate-400' : 'text-slate-700'}>
            {t.description || t.referenceNo || '-'}
          </p>
          {t.isVoided ? (
            <p className="text-rose-700 font-medium mt-0.5">İptal: {t.voidReason}</p>
          ) : null}
        </div>
      ),
    },
    ...(canModify
      ? [
          {
            key: 'void',
            header: 'İşlem',
            align: 'right' as const,
            render: (t: CashTransactionDTO) =>
              t.isVoided || t.transferReceiptId ? (
                <span className="text-xs text-slate-400">-</span>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setVoidReason('');
                    setVoidTarget(t);
                  }}
                  className="inline-flex items-center gap-1 rounded-md border border-rose-200 px-2 py-1 text-xs font-medium text-rose-700 hover:bg-rose-50"
                >
                  <Ban className="h-3 w-3" aria-hidden="true" />
                  İptal
                </button>
              ),
          },
        ]
      : []),
  ];

  return (
    <div className="space-y-6">
      <div>
        <Link
          to="/kasa"
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 mb-3"
        >
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
          Günlük Kasa Listesine Dön
        </Link>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
              {session.store.name} – {session.cashier.fullName}
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              İş Günü: <strong className="tabular-nums">{formatDateTR(session.businessDate)}</strong>{' '}
              · Vardiya #{session.shiftNo} · Kasiyer Hesabı:{' '}
              <span className="font-mono text-xs">{session.cashier.username}</span>
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <CashDifferenceBadge
              status={session.cashDifferenceStatus}
              difference={session.cashDifference}
            />
            <SessionStatusBadge status={session.status} />
          </div>
        </div>
      </div>

      {session.status === 'RETURNED_FOR_CORRECTION' && session.notes ? (
        <div
          role="alert"
          className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-900"
        >
          <strong>Düzeltme İçin İade Gerekçesi:</strong> {session.notes}
        </div>
      ) : null}

      {actionError ? (
        <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
          {actionError}
        </div>
      ) : null}

      {/* Backend Hesaplı Finansal Özet Kartları */}
      <section aria-label="Oturum finansal özeti" className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Açılış Kasası</p>
          <p className="mt-1 text-lg font-semibold text-slate-900 tabular-nums">
            {formatCurrencyTRY(session.openingCash)}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Nakit Satış</p>
          <p className="mt-1 text-lg font-semibold text-slate-900 tabular-nums">
            {formatCurrencyTRY(session.cashSalesTotal)}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Kredi Kartı Satış</p>
          <p className="mt-1 text-lg font-semibold text-slate-900 tabular-nums">
            {formatCurrencyTRY(session.creditCardSalesTotal)}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Nakit hesabına dahil edilmez</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Onaylı Havale / EFT</p>
          <p className="mt-1 text-lg font-semibold text-slate-900 tabular-nums">
            {formatCurrencyTRY(session.bankTransferTotal)}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Yalnızca onaylı dekontlardan</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Toplam İade / Nakit Çıkış</p>
          <p className="mt-1 text-lg font-semibold text-rose-700 tabular-nums">
            {formatCurrencyTRY(session.totalRefunds)} / {formatCurrencyTRY(session.otherCashOutTotal)}
          </p>
        </div>
        <div className="rounded-xl border border-blue-200 bg-blue-50/40 p-4">
          <p className="text-xs font-medium text-blue-800">Beklenen Nakit (Backend)</p>
          <p className="mt-1 text-xl font-bold text-blue-900 tabular-nums">
            {formatCurrencyTRY(session.expectedCash)}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Teslim Edilen Gerçek Nakit</p>
          <p className="mt-1 text-xl font-bold text-slate-900 tabular-nums">
            {session.declaredCash !== null ? formatCurrencyTRY(session.declaredCash) : 'Girilmedi'}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Net Satış Toplamı</p>
          <p className="mt-1 text-xl font-bold text-emerald-800 tabular-nums">
            {formatCurrencyTRY(session.netSalesTotal)}
          </p>
        </div>
      </section>

      {/* Gün İçi Tahsilat / Hareket Ekleme Formu */}
      {canModify ? (
        <section className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
          <div className="flex items-center gap-2">
            <PlusCircle className="h-4 w-4 text-blue-700" aria-hidden="true" />
            <h2 className="text-base font-semibold text-slate-900">Yeni Kasa Hareketi Kaydet</h2>
          </div>

          {txError ? (
            <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
              {txError}
            </div>
          ) : null}

          <form
            onSubmit={(e: FormEvent) => {
              e.preventDefault();
              setTxError(null);
              addTxMutation.mutate();
            }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end"
          >
            <div>
              <label htmlFor="tx-method" className="block text-xs font-medium text-slate-700 mb-1">
                Ödeme Yöntemi
              </label>
              <select
                id="tx-method"
                value={paymentMethodCode}
                onChange={(e) => {
                  const next = e.target.value as PaymentMethodCode;
                  setPaymentMethodCode(next);
                  setTransactionType(next === 'BANK_TRANSFER' ? 'REFUND' : 'SALE');
                }}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
              >
                <option value="CASH">Nakit</option>
                <option value="CREDIT_CARD">Kredi Kartı</option>
                <option value="BANK_TRANSFER">Havale / EFT (Sadece İade)</option>
              </select>
            </div>

            <div>
              <label htmlFor="tx-type" className="block text-xs font-medium text-slate-700 mb-1">
                Hareket Türü
              </label>
              <select
                id="tx-type"
                value={transactionType}
                onChange={(e) => setTransactionType(e.target.value as CashTransactionType)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
              >
                {availableTxTypes.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="tx-amount" className="block text-xs font-medium text-slate-700 mb-1">
                Tutar (₺)
              </label>
              <input
                id="tx-amount"
                type="text"
                inputMode="decimal"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="250.00"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
              />
            </div>

            <div>
              <label htmlFor="tx-ref" className="block text-xs font-medium text-slate-700 mb-1">
                Fiş / Ref No
              </label>
              <input
                id="tx-ref"
                type="text"
                value={referenceNo}
                onChange={(e) => setReferenceNo(e.target.value)}
                placeholder="Opsiyonel"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>

            <div>
              <label htmlFor="tx-desc" className="block text-xs font-medium text-slate-700 mb-1">
                Açıklama
              </label>
              <input
                id="tx-desc"
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Hareket notu"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={addTxMutation.isPending}
              className="rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
            >
              {addTxMutation.isPending ? 'Kaydediliyor...' : 'Ekle'}
            </button>
          </form>
          <p className="text-xs text-slate-500 flex flex-wrap items-center justify-between gap-2">
            <span>
              Not: Havale / EFT tahsilatları mükerrer kontrol ve merkez doğrulaması zorunluluğu
              gereği yalnızca <strong>IBAN Dekontları</strong> modülü üzerinden mutabakata dahil
              edilir.
            </span>
            <Link
              to={`/dekontlar?sessionId=${session.id}`}
              className="font-semibold text-blue-700 hover:underline"
            >
              Bu Oturumun IBAN Dekontlarını Yönet →
            </Link>
          </p>
        </section>
      ) : null}

      {/* Kasa Hareketleri Tablosu */}
      <section className="space-y-3">
        <h2 className="text-base font-semibold text-slate-900">
          Kasa Hareketleri ({session.transactions.length})
        </h2>
        <DataTable
          caption="Kasa hareketleri listesi"
          columns={txColumns}
          rows={session.transactions}
          rowKey={(t) => t.id}
          emptyMessage="Bu oturumda henüz hareket kaydedilmedi."
        />
      </section>

      {/* Kasiyer Gün Sonu Teslim Beyanı */}
      {canModify ? (
        <section className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Gün Sonu Nakit Teslim Beyanı
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Kasada sayılan gerçek nakit tutarını girin. Beklenen nakit (
              <strong className="tabular-nums">{formatCurrencyTRY(session.expectedCash)}</strong>)
              ile fark backend tarafından otomatik hesaplanır.
            </p>
          </div>
          <form
            onSubmit={(e: FormEvent) => {
              e.preventDefault();
              setActionError(null);
              submitMutation.mutate();
            }}
            className="grid grid-cols-1 md:grid-cols-3 gap-3 items-end"
          >
            <div>
              <label htmlFor="declared-cash" className="block text-xs font-medium text-slate-700 mb-1">
                Teslim Edilen Gerçek Nakit (₺)
              </label>
              <input
                id="declared-cash"
                type="text"
                inputMode="decimal"
                required
                value={declaredCash}
                onChange={(e) => setDeclaredCash(e.target.value)}
                placeholder={session.expectedCash}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label htmlFor="submit-notes" className="block text-xs font-medium text-slate-700 mb-1">
                Kapanış Açıklaması (Varsa açık/fazla nedeni)
              </label>
              <input
                id="submit-notes"
                type="text"
                value={submitNotes}
                onChange={(e) => setSubmitNotes(e.target.value)}
                placeholder="Gün sonu sayım notu"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <button
              id="submit-cash-session-btn"
              type="submit"
              disabled={submitMutation.isPending}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-700 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-800 disabled:opacity-60"
            >
              <Send className="h-4 w-4" aria-hidden="true" />
              {submitMutation.isPending ? 'Gönderiliyor...' : 'Kasayı Teslim Et'}
            </button>
          </form>
        </section>
      ) : null}

      {/* Mağaza Yöneticisi Onay / Düzeltmeye İade Aksiyonları */}
      {canStoreApprove || canReturn ? (
        <section className="rounded-xl border border-blue-200 bg-blue-50/40 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Yönetici Kontrol ve Onay</h2>
            <p className="text-xs text-slate-600 mt-0.5">
              Teslim edilen tutarı ve hareketleri kontrol edip merkeze gönderebilir veya gerekçeyle
              düzeltme için kasiyere iade edebilirsiniz.
            </p>
          </div>
          <div className="flex flex-wrap gap-2 shrink-0">
            {canReturn ? (
              <button
                type="button"
                onClick={() => {
                  setReturnReason('');
                  setReturnModalOpen(true);
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-rose-300 bg-white px-4 py-2 text-sm font-medium text-rose-700 hover:bg-rose-50"
              >
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
                Düzeltme İçin İade Et
              </button>
            ) : null}
            {canStoreApprove ? (
              <button
                id="store-approve-btn"
                type="button"
                onClick={() => storeApproveMutation.mutate()}
                disabled={storeApproveMutation.isPending}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
              >
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                {storeApproveMutation.isPending ? 'Gönderiliyor...' : 'Onayla ve Merkeze Gönder'}
              </button>
            ) : null}
          </div>
        </section>
      ) : null}

      {/* Hareket İptal Modalı */}
      <ModalDialog
        open={voidTarget !== null}
        title="Kasa Hareketini İptal Et"
        description="Finansal kayıtlar fiziksel olarak silinmez; iptal gerekçesiyle denetim kaydına işlenir."
        onClose={() => setVoidTarget(null)}
      >
        <form
          onSubmit={(e: FormEvent) => {
            e.preventDefault();
            if (!voidTarget) return;
            voidMutation.mutate(voidTarget.id);
          }}
          className="space-y-4"
        >
          <p className="text-sm text-slate-700">
            İptal edilecek hareket:{' '}
            <strong>
              {voidTarget?.paymentMethodName} – {voidTarget?.transactionTypeLabel} (
              {formatCurrencyTRY(voidTarget?.amount)})
            </strong>
          </p>
          <div>
            <label htmlFor="void-reason" className="block text-xs font-medium text-slate-700 mb-1">
              İptal Gerekçesi (En az 5 karakter)
            </label>
            <textarea
              id="void-reason"
              rows={3}
              required
              minLength={5}
              value={voidReason}
              onChange={(e) => setVoidReason(e.target.value)}
              placeholder="Örn. Hatalı tutar girişi nedeniyle iptal edildi"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setVoidTarget(null)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={voidMutation.isPending}
              className="rounded-lg bg-rose-700 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-800 disabled:opacity-60"
            >
              {voidMutation.isPending ? 'İptal Ediliyor...' : 'Hareketi İptal Et'}
            </button>
          </div>
        </form>
      </ModalDialog>

      {/* Düzeltme İçin İade Modalı */}
      <ModalDialog
        open={returnModalOpen}
        title="Oturumu Düzeltme İçin İade Et"
        description="Oturum tekrar düzenlenebilir duruma geçer ve gerekçe kasiyere gösterilir."
        onClose={() => setReturnModalOpen(false)}
      >
        <form
          onSubmit={(e: FormEvent) => {
            e.preventDefault();
            returnMutation.mutate();
          }}
          className="space-y-4"
        >
          <div>
            <label htmlFor="return-reason" className="block text-xs font-medium text-slate-700 mb-1">
              İade Gerekçesi (En az 5 karakter)
            </label>
            <textarea
              id="return-reason"
              rows={3}
              required
              minLength={5}
              value={returnReason}
              onChange={(e) => setReturnReason(e.target.value)}
              placeholder="Örn. Gün sonu nakit sayımı tekrar doğrulanmalı"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setReturnModalOpen(false)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={returnMutation.isPending}
              className="rounded-lg bg-rose-700 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-800 disabled:opacity-60"
            >
              {returnMutation.isPending ? 'İade Ediliyor...' : 'Düzeltmeye İade Et'}
            </button>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
}
