import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  CASH_SESSION_STATUS_LABELS_TR,
  CASH_SESSION_STATUSES,
  formatCurrencyTRY,
  formatDateTR,
  type CashSessionStatus,
  type CashSessionSummaryDTO,
  type StoreSummary,
  type UserSummary,
} from '@kasa/shared';
import { ArrowRight, Calendar, Plus, Users, Wallet } from 'lucide-react';
import { DataTable, type DataTableColumn } from '../../components/DataTable';
import { ModalDialog } from '../../components/ModalDialog';
import { CashDifferenceBadge, SessionStatusBadge } from '../../components/StatusBadges';
import { ApiClientError, apiRequest } from '../../lib/api';
import { useAuth } from '../auth/AuthContext';

interface AggregateTotals {
  sessionCount: number;
  submittedCount: number;
  cashSalesTotal: string;
  creditCardSalesTotal: string;
  bankTransferTotal: string;
  totalRefunds: string;
  expectedCashTotal: string;
  declaredCashTotal: string;
  totalShortage: string;
  totalSurplus: string;
  netCashVariance: string;
  netSalesTotal: string;
}

interface CashierRollup {
  cashierId: string;
  cashierName: string;
  cashierUsername: string;
  storeId: string;
  storeName: string;
  sessionCount: number;
  cashSalesTotal: string;
  creditCardSalesTotal: string;
  bankTransferTotal: string;
  totalRefunds: string;
  expectedCashTotal: string;
  declaredCashTotal: string;
  cashShortage: string;
  cashSurplus: string;
  netCashVariance: string;
}

interface CashSessionsResponse {
  items: CashSessionSummaryDTO[];
  totals: AggregateTotals;
  byCashier: CashierRollup[];
}

function getTodayIsoTR(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Istanbul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

export function CashSessionsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const todayIso = getTodayIsoTR();
  const [businessDate, setBusinessDate] = useState(todayIso);
  const [storeFilter, setStoreFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<CashSessionStatus | ''>('');

  const [openModal, setOpenModal] = useState(false);
  const [modalDate, setModalDate] = useState(todayIso);
  const [openingCash, setOpeningCash] = useState('0.00');
  const [modalStoreId, setModalStoreId] = useState(user?.storeId ?? '');
  const [modalCashierId, setModalCashierId] = useState(user?.id ?? '');
  const [modalNotes, setModalNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const canOpenSession = user?.role !== 'CENTRAL_ACCOUNTING';
  const isGlobal = user?.role === 'SYSTEM_ADMIN' || user?.role === 'CENTRAL_ACCOUNTING';

  const storesQuery = useQuery({
    queryKey: ['stores'],
    queryFn: () => apiRequest<{ items: StoreSummary[] }>('/stores'),
  });

  const usersQuery = useQuery({
    queryKey: ['users', 'active', modalStoreId],
    queryFn: () => {
      const qs = new URLSearchParams({ onlyActive: 'true' });
      if (modalStoreId && user?.role === 'SYSTEM_ADMIN') qs.set('storeId', modalStoreId);
      return apiRequest<{ items: UserSummary[] }>(`/users?${qs.toString()}`);
    },
    enabled: user?.role === 'STORE_MANAGER' || user?.role === 'SYSTEM_ADMIN',
  });

  const sessionsQuery = useQuery({
    queryKey: ['cash-sessions', businessDate, storeFilter, statusFilter],
    queryFn: () => {
      const qs = new URLSearchParams();
      if (businessDate) qs.set('businessDate', businessDate);
      if (storeFilter) qs.set('storeId', storeFilter);
      if (statusFilter) qs.set('status', statusFilter);
      return apiRequest<CashSessionsResponse>(`/cash-sessions?${qs.toString()}`);
    },
  });

  const openMutation = useMutation({
    mutationFn: () =>
      apiRequest<CashSessionSummaryDTO>('/cash-sessions', {
        method: 'POST',
        body: JSON.stringify({
          businessDate: modalDate,
          openingCash: openingCash.trim().replace(',', '.'),
          ...(user?.role === 'SYSTEM_ADMIN' ? { storeId: modalStoreId, cashierId: modalCashierId } : {}),
          ...(user?.role === 'STORE_MANAGER' && modalCashierId ? { cashierId: modalCashierId } : {}),
          notes: modalNotes.trim() || null,
        }),
      }),
    onSuccess: (created) => {
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setOpenModal(false);
      setFormError(null);
      navigate(`/kasa/${created.id}`);
    },
    onError: (err) => {
      setFormError(err instanceof ApiClientError ? err.message : 'Kasa oturumu açılamadı.');
    },
  });

  const stores = (storesQuery.data?.items ?? []).filter((s) => s.type === 'STORE');
  const data = sessionsQuery.data;
  const totals = data?.totals;

  const sessionColumns: Array<DataTableColumn<CashSessionSummaryDTO>> = [
    {
      key: 'date',
      header: 'Tarih / Vardiya',
      render: (s) => (
        <div>
          <p className="font-medium text-slate-900 tabular-nums">{formatDateTR(s.businessDate)}</p>
          <p className="text-xs text-slate-500">Vardiya #{s.shiftNo}</p>
        </div>
      ),
    },
    {
      key: 'store',
      header: 'Mağaza',
      render: (s) => (
        <span className="font-medium text-slate-800">
          {s.store.name} <span className="text-xs text-slate-500">({s.store.code})</span>
        </span>
      ),
    },
    {
      key: 'cashier',
      header: 'Kasiyer',
      render: (s) => (
        <div>
          <p className="font-medium text-slate-900">{s.cashier.fullName}</p>
          <p className="text-xs text-slate-500 font-mono">{s.cashier.username}</p>
        </div>
      ),
    },
    {
      key: 'cashSales',
      header: 'Nakit Satış',
      align: 'right',
      render: (s) => formatCurrencyTRY(s.cashSalesTotal),
    },
    {
      key: 'cardSales',
      header: 'Kredi Kartı',
      align: 'right',
      render: (s) => formatCurrencyTRY(s.creditCardSalesTotal),
    },
    {
      key: 'transfer',
      header: 'Onaylı Havale',
      align: 'right',
      render: (s) => formatCurrencyTRY(s.bankTransferTotal),
    },
    {
      key: 'expectedCash',
      header: 'Beklenen Nakit',
      align: 'right',
      render: (s) => <span className="font-semibold text-slate-900">{formatCurrencyTRY(s.expectedCash)}</span>,
    },
    {
      key: 'diff',
      header: 'Kasa Farkı',
      render: (s) => (
        <CashDifferenceBadge status={s.cashDifferenceStatus} difference={s.cashDifference} />
      ),
    },
    {
      key: 'status',
      header: 'Durum',
      render: (s) => <SessionStatusBadge status={s.status} />,
    },
    {
      key: 'action',
      header: 'Detay',
      align: 'right',
      render: (s) => (
        <Link
          to={`/kasa/${s.id}`}
          className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-blue-700 hover:bg-blue-50"
        >
          <span>Aç</span>
          <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
        </Link>
      ),
    },
  ];

  const cashierColumns: Array<DataTableColumn<CashierRollup>> = [
    {
      key: 'cashier',
      header: 'Kasiyer',
      render: (r) => (
        <div>
          <p className="font-medium text-slate-900">{r.cashierName}</p>
          <p className="text-xs text-slate-500">{r.storeName}</p>
        </div>
      ),
    },
    {
      key: 'cash',
      header: 'Nakit Satış',
      align: 'right',
      render: (r) => formatCurrencyTRY(r.cashSalesTotal),
    },
    {
      key: 'card',
      header: 'Kredi Kartı',
      align: 'right',
      render: (r) => formatCurrencyTRY(r.creditCardSalesTotal),
    },
    {
      key: 'transfer',
      header: 'Havale / EFT',
      align: 'right',
      render: (r) => formatCurrencyTRY(r.bankTransferTotal),
    },
    {
      key: 'refunds',
      header: 'İade',
      align: 'right',
      render: (r) => formatCurrencyTRY(r.totalRefunds),
    },
    {
      key: 'expected',
      header: 'Beklenen Kasa',
      align: 'right',
      render: (r) => <span className="font-medium">{formatCurrencyTRY(r.expectedCashTotal)}</span>,
    },
    {
      key: 'declared',
      header: 'Teslim Edilen',
      align: 'right',
      render: (r) => formatCurrencyTRY(r.declaredCashTotal),
    },
    {
      key: 'shortage',
      header: 'Kasa Açığı',
      align: 'right',
      render: (r) => (
        <span className={r.cashShortage !== '0.00' ? 'font-semibold text-rose-700' : 'text-slate-500'}>
          {formatCurrencyTRY(r.cashShortage)}
        </span>
      ),
    },
    {
      key: 'surplus',
      header: 'Kasa Fazlası',
      align: 'right',
      render: (r) => (
        <span className={r.cashSurplus !== '0.00' ? 'font-semibold text-amber-700' : 'text-slate-500'}>
          {formatCurrencyTRY(r.cashSurplus)}
        </span>
      ),
    },
  ];

  function handleOpenModal() {
    setModalDate(businessDate || todayIso);
    setOpeningCash('0.00');
    setModalNotes('');
    setFormError(null);
    if (user?.role === 'SYSTEM_ADMIN') {
      setModalStoreId(stores[0]?.id ?? '');
      setModalCashierId('');
    } else {
      setModalStoreId(user?.storeId ?? '');
      setModalCashierId(user?.id ?? '');
    }
    setOpenModal(true);
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Günlük Kasa ve Kasiyer Takibi
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Aynı mağazada birden fazla kasiyerin bağımsız vardiya kapanışlarını, ödeme yöntemlerini
            ve açık/fazla durumlarını izleyin.
          </p>
        </div>
        {canOpenSession ? (
          <button
            id="open-cash-session-btn"
            type="button"
            onClick={handleOpenModal}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 transition-colors shrink-0"
          >
            <Plus className="h-4 w-4" aria-hidden="true" />
            Yeni Kasa Oturumu Aç
          </button>
        ) : null}
      </header>

      {/* Filtre Çubuğu */}
      <section
        aria-label="Kasa filtreleri"
        className="rounded-xl border border-slate-200 bg-white p-4 flex flex-wrap items-end gap-4"
      >
        <div>
          <label htmlFor="filter-date" className="block text-xs font-medium text-slate-600 mb-1">
            İş Günü
          </label>
          <div className="relative">
            <Calendar
              className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              id="filter-date"
              type="date"
              value={businessDate}
              onChange={(e) => setBusinessDate(e.target.value)}
              className="rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-sm tabular-nums"
            />
          </div>
        </div>

        {isGlobal ? (
          <div>
            <label htmlFor="filter-store" className="block text-xs font-medium text-slate-600 mb-1">
              Mağaza
            </label>
            <select
              id="filter-store"
              value={storeFilter}
              onChange={(e) => setStoreFilter(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm min-w-44"
            >
              <option value="">Tüm Mağazalar</option>
              {stores.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>
        ) : null}

        <div>
          <label htmlFor="filter-status" className="block text-xs font-medium text-slate-600 mb-1">
            Oturum Durumu
          </label>
          <select
            id="filter-status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as CashSessionStatus | '')}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm min-w-48"
          >
            <option value="">Tüm Durumlar</option>
            {CASH_SESSION_STATUSES.map((st) => (
              <option key={st} value={st}>
                {CASH_SESSION_STATUS_LABELS_TR[st]}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={() => {
            setBusinessDate('');
            setStoreFilter('');
            setStatusFilter('');
          }}
          className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50"
        >
          Tüm Tarihleri Göster
        </button>
      </section>

      {/* Özet KPI Kartları */}
      <section aria-label="Günlük kasa özeti" className="grid grid-cols-2 lg:grid-cols-6 gap-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs font-medium text-slate-500">Nakit Satış</p>
          <p className="mt-1.5 text-lg font-semibold text-slate-900 tabular-nums">
            {formatCurrencyTRY(totals?.cashSalesTotal)}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs font-medium text-slate-500">Kredi Kartı</p>
          <p className="mt-1.5 text-lg font-semibold text-slate-900 tabular-nums">
            {formatCurrencyTRY(totals?.creditCardSalesTotal)}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs font-medium text-slate-500">Onaylı Havale / EFT</p>
          <p className="mt-1.5 text-lg font-semibold text-slate-900 tabular-nums">
            {formatCurrencyTRY(totals?.bankTransferTotal)}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs font-medium text-slate-500">Beklenen Nakit</p>
          <p className="mt-1.5 text-lg font-semibold text-blue-800 tabular-nums">
            {formatCurrencyTRY(totals?.expectedCashTotal)}
          </p>
        </div>
        <div className="rounded-xl border border-rose-200 bg-rose-50/40 p-4">
          <p className="text-xs font-medium text-rose-700">Toplam Kasa Açığı</p>
          <p className="mt-1.5 text-lg font-semibold text-rose-800 tabular-nums">
            {formatCurrencyTRY(totals?.totalShortage)}
          </p>
        </div>
        <div className="rounded-xl border border-amber-200 bg-amber-50/40 p-4">
          <p className="text-xs font-medium text-amber-800">Toplam Kasa Fazlası</p>
          <p className="mt-1.5 text-lg font-semibold text-amber-900 tabular-nums">
            {formatCurrencyTRY(totals?.totalSurplus)}
          </p>
        </div>
      </section>

      {/* Günlük Kasa Oturumları Tablosu */}
      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <Wallet className="h-4 w-4 text-slate-700" aria-hidden="true" />
          <h2 className="text-base font-semibold text-slate-900">Günlük Kasa Oturumları</h2>
        </div>
        {sessionsQuery.isLoading ? (
          <p className="text-sm text-slate-500">Kasa oturumları yükleniyor...</p>
        ) : (
          <DataTable
            caption="Günlük kasa oturumları"
            columns={sessionColumns}
            rows={data?.items ?? []}
            rowKey={(s) => s.id}
            emptyMessage="Seçili kriterlere uygun kasa oturumu bulunmuyor."
          />
        )}
      </section>

      {/* Kasiyer Bazlı Özet Tablosu */}
      {(data?.byCashier.length ?? 0) > 0 ? (
        <section className="space-y-3">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-slate-700" aria-hidden="true" />
            <h2 className="text-base font-semibold text-slate-900">
              Kasiyer Bazlı Tahsilat ve Kasa Farkı Özeti
            </h2>
          </div>
          <DataTable
            caption="Kasiyer bazlı tahsilat ve kasa farkı özeti"
            columns={cashierColumns}
            rows={data?.byCashier ?? []}
            rowKey={(r) => `${r.storeId}-${r.cashierId}`}
          />
        </section>
      ) : null}

      {/* Yeni Kasa Oturumu Açma Modalı */}
      <ModalDialog
        open={openModal}
        title="Yeni Günlük Kasa Oturumu Aç"
        description="Açılış kasasını girerek gün içi tahsilatları kaydetmeye başlayın."
        onClose={() => setOpenModal(false)}
      >
        <form
          onSubmit={(e: FormEvent) => {
            e.preventDefault();
            setFormError(null);
            openMutation.mutate();
          }}
          className="space-y-4"
        >
          {formError ? (
            <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
              {formError}
            </div>
          ) : null}

          {user?.role === 'SYSTEM_ADMIN' ? (
            <div>
              <label htmlFor="open-store" className="block text-xs font-medium text-slate-700 mb-1">
                Mağaza
              </label>
              <select
                id="open-store"
                required
                value={modalStoreId}
                onChange={(e) => {
                  setModalStoreId(e.target.value);
                  setModalCashierId('');
                }}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
              >
                <option value="">Mağaza seçin...</option>
                {stores.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          ) : null}

          {user?.role === 'STORE_MANAGER' || user?.role === 'SYSTEM_ADMIN' ? (
            <div>
              <label htmlFor="open-cashier" className="block text-xs font-medium text-slate-700 mb-1">
                Kasiyer Hesabı
              </label>
              <select
                id="open-cashier"
                required
                value={modalCashierId}
                onChange={(e) => setModalCashierId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
              >
                <option value="">Kasiyer seçin...</option>
                {(usersQuery.data?.items ?? []).map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.fullName} ({u.roleLabel})
                  </option>
                ))}
              </select>
            </div>
          ) : null}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="open-date" className="block text-xs font-medium text-slate-700 mb-1">
                İş Günü
              </label>
              <input
                id="open-date"
                type="date"
                required
                value={modalDate}
                onChange={(e) => setModalDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div>
              <label htmlFor="open-cash" className="block text-xs font-medium text-slate-700 mb-1">
                Açılış Kasası (₺)
              </label>
              <input
                id="open-cash"
                type="text"
                inputMode="decimal"
                required
                value={openingCash}
                onChange={(e) => setOpeningCash(e.target.value)}
                placeholder="500.00"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
              />
            </div>
          </div>

          <div>
            <label htmlFor="open-notes" className="block text-xs font-medium text-slate-700 mb-1">
              Açıklama (Opsiyonel)
            </label>
            <textarea
              id="open-notes"
              rows={2}
              value={modalNotes}
              onChange={(e) => setModalNotes(e.target.value)}
              placeholder="Sabah vardiyası açılış notu..."
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setOpenModal(false)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={openMutation.isPending}
              className="rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
            >
              {openMutation.isPending ? 'Açılıyor...' : 'Oturumu Aç'}
            </button>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
}
