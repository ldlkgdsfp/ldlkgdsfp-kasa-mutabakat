import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  formatCurrencyTRY,
  formatDateTimeTR,
  formatDateTR,
  type AdjustableFieldName,
  type CentralDashboardResponseDTO,
  type CentralReconciliationAction,
  type CentralStoreDailyStatusDTO,
  type TransferReceiptSummaryDTO,
} from '@kasa/shared';
import {
  AlertTriangle,
  ArrowRight,
  Calendar,
  CheckCircle2,
  FileCheck2,
  Lock,
  PlusCircle,
  RefreshCw,
  RotateCcw,
  ShieldAlert,
} from 'lucide-react';
import { DataTable, type DataTableColumn } from '../../components/DataTable';
import { ModalDialog } from '../../components/ModalDialog';
import {
  BankVerifiedBadge,
  ReceiptStatusBadge,
  ReconciliationStatusBadge,
  SessionStatusBadge,
} from '../../components/StatusBadges';
import { ApiClientError, apiRequest } from '../../lib/api';

function getTodayIsoTR(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Istanbul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

const ADJUSTMENT_FIELD_LABELS: Record<AdjustableFieldName, string> = {
  central_verified_cash: 'Merkezin Doğruladığı Nakit (₺)',
  credit_card_total: 'Kredi Kartı Toplamı (₺)',
  approved_transfer_total: 'Onaylı Havale / EFT Toplamı (₺)',
};

export function CentralControlPage() {
  const queryClient = useQueryClient();
  const [businessDate, setBusinessDate] = useState(getTodayIsoTR());

  // Mağaza Mutabakat İnceleme Modalı
  const [activeStoreRow, setActiveStoreRow] = useState<CentralStoreDailyStatusDTO | null>(null);
  const [verifiedCashInput, setVerifiedCashInput] = useState('');
  const [reconNotes, setReconNotes] = useState('');
  const [modalError, setModalError] = useState<string | null>(null);

  // Kilitli Kayıtta Finansal Düzeltme Modalı
  const [adjustOpen, setAdjustOpen] = useState(false);
  const [adjustField, setAdjustField] = useState<AdjustableFieldName>('central_verified_cash');
  const [adjustValue, setAdjustValue] = useState('');
  const [adjustReason, setAdjustReason] = useState('');
  const [adjustError, setAdjustError] = useState<string | null>(null);

  const dashboardQuery = useQuery({
    queryKey: ['central-dashboard', businessDate],
    queryFn: () =>
      apiRequest<CentralDashboardResponseDTO>(
        `/reconciliations/dashboard?businessDate=${encodeURIComponent(businessDate)}`,
      ),
  });

  const verifyMutation = useMutation({
    mutationFn: (action: CentralReconciliationAction) => {
      if (!activeStoreRow) throw new Error('Mağaza seçilmedi.');
      return apiRequest('/reconciliations/verify', {
        method: 'POST',
        body: JSON.stringify({
          storeId: activeStoreRow.store.id,
          businessDate,
          centralVerifiedCash: verifiedCashInput.trim().replace(',', '.'),
          action,
          notes: reconNotes.trim() || null,
        }),
      });
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['central-dashboard'] });
      void queryClient.invalidateQueries({ queryKey: ['cash-sessions'] });
      setActiveStoreRow(null);
      setModalError(null);
    },
    onError: (err) => {
      setModalError(err instanceof ApiClientError ? err.message : 'Mutabakat işlemi başarısız.');
    },
  });

  const adjustMutation = useMutation({
    mutationFn: () => {
      const reconId = activeStoreRow?.reconciliation?.id;
      if (!reconId) throw new Error('Mutabakat kimliği bulunamadı.');
      return apiRequest(`/reconciliations/${reconId}/adjustments`, {
        method: 'POST',
        body: JSON.stringify({
          fieldName: adjustField,
          adjustedValue: adjustValue.trim().replace(',', '.'),
          reason: adjustReason.trim(),
        }),
      });
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['central-dashboard'] });
      setAdjustOpen(false);
      setActiveStoreRow(null);
      setAdjustError(null);
    },
    onError: (err) => {
      setAdjustError(err instanceof ApiClientError ? err.message : 'Düzeltme kaydı oluşturulamadı.');
    },
  });

  function openVerifyModal(row: CentralStoreDailyStatusDTO) {
    setActiveStoreRow(row);
    setVerifiedCashInput(
      row.centralVerifiedCash ?? row.declaredCashTotal ?? row.expectedCashTotal ?? '0.00',
    );
    setReconNotes(row.reconciliation?.notes ?? '');
    setModalError(null);
  }

  function openAdjustmentModal(row: CentralStoreDailyStatusDTO) {
    setAdjustField('central_verified_cash');
    setAdjustValue(row.centralVerifiedCash ?? row.declaredCashTotal ?? '0.00');
    setAdjustReason('');
    setAdjustError(null);
    setAdjustOpen(true);
  }

  const data = dashboardQuery.data;
  const overall = data?.overall;

  const storeColumns: Array<DataTableColumn<CentralStoreDailyStatusDTO>> = [
    {
      key: 'store',
      header: 'Mağaza',
      render: (r) => (
        <div>
          <p className="font-semibold text-slate-900">{r.store.name}</p>
          <p className="text-xs text-slate-500">
            {r.store.code} · {r.sessionCount} oturum ({r.submittedSessionCount} teslim)
          </p>
        </div>
      ),
    },
    {
      key: 'grandSales',
      header: 'Net Satış',
      align: 'right',
      render: (r) => <span className="font-semibold">{formatCurrencyTRY(r.grandSalesTotal)}</span>,
    },
    {
      key: 'methods',
      header: 'Nakit / Kart / Havale',
      align: 'right',
      render: (r) => (
        <div className="text-xs space-y-0.5 tabular-nums">
          <p>Nakit: {formatCurrencyTRY(r.cashSalesTotal)}</p>
          <p className="text-slate-600">Kart: {formatCurrencyTRY(r.creditCardTotal)}</p>
          <p className="text-blue-700">Havale: {formatCurrencyTRY(r.approvedTransferTotal)}</p>
        </div>
      ),
    },
    {
      key: 'expectedCash',
      header: 'Beklenen Nakit',
      align: 'right',
      render: (r) => formatCurrencyTRY(r.expectedCashTotal),
    },
    {
      key: 'declaredVsCentral',
      header: 'Beyan / Merkez Teslim',
      align: 'right',
      render: (r) => (
        <div className="text-xs space-y-0.5 tabular-nums">
          <p>Beyan: {formatCurrencyTRY(r.declaredCashTotal)}</p>
          <p className="font-semibold text-slate-900">
            Merkez: {r.centralVerifiedCash ? formatCurrencyTRY(r.centralVerifiedCash) : 'Girilmedi'}
          </p>
        </div>
      ),
    },
    {
      key: 'variance',
      header: 'Açık / Fazla',
      align: 'right',
      render: (r) => (
        <div className="text-xs space-y-0.5 tabular-nums">
          {r.shortageTotal !== '0.00' ? (
            <p className="font-semibold text-rose-700">Açık: -{formatCurrencyTRY(r.shortageTotal)}</p>
          ) : null}
          {r.surplusTotal !== '0.00' ? (
            <p className="font-semibold text-amber-800">Fazla: +{formatCurrencyTRY(r.surplusTotal)}</p>
          ) : null}
          {r.shortageTotal === '0.00' && r.surplusTotal === '0.00' ? (
            <p className="font-medium text-emerald-700">Eşit (0,00 ₺)</p>
          ) : null}
        </div>
      ),
    },
    {
      key: 'alerts',
      header: 'Dekontlar',
      render: (r) => (
        <div className="text-xs space-y-0.5">
          {r.pendingReceiptCount > 0 ? (
            <p className="text-blue-700 font-medium">{r.pendingReceiptCount} onay bekliyor</p>
          ) : null}
          {r.problematicReceiptCount > 0 ? (
            <p className="text-rose-700 font-medium">{r.problematicReceiptCount} hatalı/mükerrer</p>
          ) : null}
          {r.pendingReceiptCount === 0 && r.problematicReceiptCount === 0 ? (
            <span className="text-slate-400">Sorun yok</span>
          ) : null}
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Merkez Durumu',
      render: (r) =>
        r.reconciliation ? (
          <ReconciliationStatusBadge status={r.reconciliation.status} />
        ) : (
          <ReconciliationStatusBadge status="PENDING" />
        ),
    },
    {
      key: 'action',
      header: 'İşlem',
      align: 'right',
      render: (r) => (
        <button
          type="button"
          onClick={() => openVerifyModal(r)}
          className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
            r.reconciliation?.isLocked
              ? 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              : 'bg-blue-700 text-white hover:bg-blue-800'
          }`}
        >
          {r.reconciliation?.isLocked ? (
            <>
              <Lock className="h-3.5 w-3.5" aria-hidden="true" />
              İncele / Düzelt
            </>
          ) : (
            <>
              <FileCheck2 className="h-3.5 w-3.5" aria-hidden="true" />
              Kontrol Et
            </>
          )}
        </button>
      ),
    },
  ];

  const receiptQueueColumns: Array<DataTableColumn<TransferReceiptSummaryDTO>> = [
    {
      key: 'store',
      header: 'Mağaza / Kasiyer',
      render: (r) => (
        <div>
          <p className="font-medium text-slate-900">{r.store.name}</p>
          <p className="text-xs text-slate-500">{r.cashier.fullName}</p>
        </div>
      ),
    },
    {
      key: 'amount',
      header: 'Tutar',
      align: 'right',
      render: (r) => (
        <span className="font-semibold">
          {r.verifiedAmount ? formatCurrencyTRY(r.verifiedAmount) : 'Belirsiz'}
        </span>
      ),
    },
    {
      key: 'sender',
      header: 'Gönderen / Ref',
      render: (r) => (
        <div className="text-xs">
          <p className="font-medium text-slate-800">{r.senderName ?? '-'}</p>
          <p className="font-mono text-slate-500">{r.referenceNumber ?? r.originalFilename}</p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Durum',
      render: (r) => <ReceiptStatusBadge status={r.status} />,
    },
    {
      key: 'bank',
      header: 'Banka Teyidi',
      render: (r) => <BankVerifiedBadge verified={r.bankAccountVerified} />,
    },
    {
      key: 'link',
      header: 'İncele',
      align: 'right',
      render: (r) => (
        <Link
          to={`/dekontlar/${r.id}`}
          className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-medium text-blue-700 hover:bg-blue-50"
        >
          <span>Dekontu Aç</span>
          <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
        </Link>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Merkez Muhasebe ve Mutabakat Paneli
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Tüm mağazaların günlük satışlarını, nakit teslim farklarını ve IBAN dekontlarını tek
            ekrandan doğrulayın, onaylayıp kilitleyin veya düzeltme için geri gönderin.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="relative">
            <Calendar
              className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              id="central-date-picker"
              type="date"
              aria-label="Mutabakat iş günü"
              value={businessDate}
              onChange={(e) => setBusinessDate(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white pl-9 pr-3 py-2 text-sm tabular-nums"
            />
          </div>
          <button
            type="button"
            onClick={() => void dashboardQuery.refetch()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
            Yenile
          </button>
        </div>
      </header>

      {/* Merkez Genel KPI Kartları */}
      <section aria-label="Merkez günlük özet" className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Günlük Net Satış (Tüm Mağazalar)</p>
          <p className="mt-1.5 text-xl font-bold text-slate-900 tabular-nums">
            {formatCurrencyTRY(overall?.grandSalesTotal)}
          </p>
          <p className="text-[11px] text-slate-500 mt-1 tabular-nums">
            İadeler: {formatCurrencyTRY(overall?.refundTotal)}
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Ödeme Yöntemi Toplamları</p>
          <dl className="mt-1.5 space-y-0.5 text-xs tabular-nums">
            <div className="flex justify-between">
              <dt className="text-slate-500">Nakit:</dt>
              <dd className="font-semibold text-slate-900">{formatCurrencyTRY(overall?.cashSalesTotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Kredi Kartı:</dt>
              <dd className="font-semibold text-slate-900">{formatCurrencyTRY(overall?.creditCardTotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Onaylı Havale:</dt>
              <dd className="font-semibold text-blue-700">{formatCurrencyTRY(overall?.approvedTransferTotal)}</dd>
            </div>
          </dl>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Nakit Mutabakat (Beklenen / Teslim)</p>
          <dl className="mt-1.5 space-y-0.5 text-xs tabular-nums">
            <div className="flex justify-between">
              <dt className="text-slate-500">Beklenen Nakit:</dt>
              <dd className="font-semibold text-blue-800">{formatCurrencyTRY(overall?.expectedCashTotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Mağaza Beyanı:</dt>
              <dd className="font-semibold text-slate-900">{formatCurrencyTRY(overall?.declaredCashTotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Merkez Doğrulanan:</dt>
              <dd className="font-semibold text-emerald-800">{formatCurrencyTRY(overall?.centralVerifiedCashTotal)}</dd>
            </div>
          </dl>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Açık / Fazla ve Bekleyen Kuyruk</p>
          <dl className="mt-1.5 space-y-0.5 text-xs tabular-nums">
            <div className="flex justify-between">
              <dt className="text-rose-700">Toplam Açık:</dt>
              <dd className="font-semibold text-rose-800">{formatCurrencyTRY(overall?.totalShortage)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-amber-800">Toplam Fazla:</dt>
              <dd className="font-semibold text-amber-900">{formatCurrencyTRY(overall?.totalSurplus)}</dd>
            </div>
            <div className="flex justify-between pt-0.5 border-t border-slate-100">
              <dt className="text-slate-500">Bekleyen Kapanış / Dekont:</dt>
              <dd className="font-semibold text-slate-900">
                {overall?.pendingClosingCount ?? 0} / {overall?.pendingReceiptCount ?? 0}
              </dd>
            </div>
          </dl>
        </div>
      </section>

      {/* Mağazaların Günlük Mutabakat Durumu */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-900">
            Mağaza Bazlı Günlük Mutabakat Durumu ({formatDateTR(businessDate)})
          </h2>
          <span className="text-xs text-slate-500 tabular-nums">
            Bankada Teyitli Havale Toplamı: <strong>{formatCurrencyTRY(overall?.bankVerifiedTransferTotal)}</strong>
          </span>
        </div>
        {dashboardQuery.isLoading ? (
          <p className="text-sm text-slate-500">Merkez mutabakat verileri yükleniyor...</p>
        ) : (
          <DataTable
            caption="Mağaza bazlı günlük mutabakat tablosu"
            columns={storeColumns}
            rows={data?.stores ?? []}
            rowKey={(r) => r.store.id}
          />
        )}
      </section>

      {/* Onay Bekleyen ve Sorunlu Dekont Kuyrukları */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <section className="space-y-3">
          <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-blue-700" aria-hidden="true" />
            <span>Merkez Onayı Bekleyen Dekontlar ({data?.pendingReceiptsQueue.length ?? 0})</span>
          </h2>
          <DataTable
            caption="Merkez onayı bekleyen dekontlar"
            columns={receiptQueueColumns}
            rows={data?.pendingReceiptsQueue ?? []}
            rowKey={(r) => r.id}
            emptyMessage="Seçili gün için onay bekleyen dekont bulunmuyor."
          />
        </section>

        <section className="space-y-3">
          <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-rose-700" aria-hidden="true" />
            <span>
              Hatalı, Mükerrer ve Manuel Kontrol Dekontları ({data?.problematicReceiptsQueue.length ?? 0})
            </span>
          </h2>
          <DataTable
            caption="Hatalı ve mükerrer dekontlar"
            columns={receiptQueueColumns}
            rows={data?.problematicReceiptsQueue ?? []}
            rowKey={(r) => r.id}
            emptyMessage="Seçili gün için hatalı veya mükerrer dekont bulunmuyor."
          />
        </section>
      </div>

      {/* Merkez Mağaza Doğrulama & Onay Modalı */}
      <ModalDialog
        open={activeStoreRow !== null && !adjustOpen}
        title={
          activeStoreRow
            ? `${activeStoreRow.store.name} – Merkez Mutabakat (${formatDateTR(businessDate)})`
            : 'Merkez Mutabakat'
        }
        description="Mağazanın beyan ettiği nakit tutar ile merkezin gerçekte teslim aldığı tutarı karşılaştırın."
        onClose={() => setActiveStoreRow(null)}
      >
        {activeStoreRow ? (
          <div className="space-y-4">
            {modalError ? (
              <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
                {modalError}
              </div>
            ) : null}

            {/* Özet Rakamlar */}
            <dl className="grid grid-cols-2 gap-3 rounded-lg bg-slate-50 border border-slate-200 p-3.5 text-xs tabular-nums">
              <div>
                <dt className="text-slate-500">Beklenen Nakit (Sistem)</dt>
                <dd className="text-sm font-bold text-blue-800 mt-0.5">
                  {formatCurrencyTRY(activeStoreRow.expectedCashTotal)}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Mağazanın Beyan Ettiği Nakit</dt>
                <dd className="text-sm font-bold text-slate-900 mt-0.5">
                  {formatCurrencyTRY(activeStoreRow.declaredCashTotal)}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Kredi Kartı Toplamı</dt>
                <dd className="font-semibold text-slate-800 mt-0.5">
                  {formatCurrencyTRY(activeStoreRow.creditCardTotal)}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Onaylı Havale / EFT</dt>
                <dd className="font-semibold text-slate-800 mt-0.5">
                  {formatCurrencyTRY(activeStoreRow.approvedTransferTotal)}
                </dd>
              </div>
            </dl>

            {/* Bağlı Kasiyer Oturumları */}
            <div>
              <p className="text-xs font-semibold text-slate-700 mb-1.5">
                Kasiyer Kapanışları ({activeStoreRow.sessions.length})
              </p>
              {activeStoreRow.sessions.length === 0 ? (
                <p className="text-xs text-slate-500">Bu gün için kasa oturumu açılmamış.</p>
              ) : (
                <ul className="divide-y divide-slate-100 rounded-lg border border-slate-200 text-xs">
                  {activeStoreRow.sessions.map((s) => (
                    <li key={s.id} className="px-3 py-2 flex items-center justify-between gap-2">
                      <div>
                        <p className="font-medium text-slate-900">
                          {s.cashier.fullName} (Vardiya #{s.shiftNo})
                        </p>
                        <p className="text-slate-500 tabular-nums">
                          Beklenen: {formatCurrencyTRY(s.expectedCash)} · Beyan:{' '}
                          {s.declaredCash ? formatCurrencyTRY(s.declaredCash) : '-'}
                        </p>
                      </div>
                      <SessionStatusBadge status={s.status} />
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {activeStoreRow.reconciliation?.isLocked ? (
              <div className="space-y-3">
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3.5 text-xs text-emerald-900 space-y-1">
                  <p className="font-semibold flex items-center gap-1.5">
                    <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                    Merkez Tarafından Onaylandı ve Kilitlendi
                  </p>
                  <p>
                    Doğrulanan Nakit:{' '}
                    <strong className="tabular-nums">
                      {formatCurrencyTRY(activeStoreRow.reconciliation.centralVerifiedCash)}
                    </strong>{' '}
                    · Merkez–Beklenen Farkı:{' '}
                    <strong className="tabular-nums">
                      {formatCurrencyTRY(activeStoreRow.reconciliation.cashVariance)}
                    </strong>{' '}
                    · Merkez–Beyan Farkı:{' '}
                    <strong className="tabular-nums">
                      {formatCurrencyTRY(activeStoreRow.reconciliation.declaredVsCentralDiff)}
                    </strong>
                  </p>
                  <p className="text-[11px]">
                    Kontrol / Onay: {activeStoreRow.reconciliation.approvedBy?.fullName ?? '-'} (
                    {formatDateTimeTR(activeStoreRow.reconciliation.approvedAt)})
                  </p>
                </div>

                {/* Düzeltme Geçmişi */}
                {activeStoreRow.reconciliation.adjustments.length > 0 ? (
                  <div>
                    <p className="text-xs font-semibold text-slate-700 mb-1">
                      Gerekçeli Finansal Düzeltme Geçmişi
                    </p>
                    <ul className="divide-y divide-slate-100 rounded-lg border border-slate-200 text-xs">
                      {activeStoreRow.reconciliation.adjustments.map((a) => (
                        <li key={a.id} className="p-2.5 space-y-0.5">
                          <p className="font-medium text-slate-900 tabular-nums">
                            {a.fieldName}: {formatCurrencyTRY(a.previousValue)} →{' '}
                            {formatCurrencyTRY(a.adjustedValue)} (Fark: {formatCurrencyTRY(a.deltaAmount)})
                          </p>
                          <p className="text-slate-600">Gerekçe: {a.reason}</p>
                          <p className="text-[11px] text-slate-400">
                            {a.createdBy.fullName} · {formatDateTimeTR(a.createdAt)}
                          </p>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}

                <div className="flex justify-between items-center pt-2">
                  <button
                    type="button"
                    onClick={() => openAdjustmentModal(activeStoreRow)}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800"
                  >
                    <PlusCircle className="h-3.5 w-3.5" aria-hidden="true" />
                    Gerekçeli Düzeltme Kaydı Ekle
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveStoreRow(null)}
                    className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
                  >
                    Kapat
                  </button>
                </div>
              </div>
            ) : (
              <form
                onSubmit={(e: FormEvent) => {
                  e.preventDefault();
                  verifyMutation.mutate('APPROVE');
                }}
                className="space-y-4"
              >
                <div>
                  <label htmlFor="central-cash" className="block text-xs font-medium text-slate-700 mb-1">
                    Merkezin Gerçekte Teslim Aldığı Nakit (₺) *
                  </label>
                  <input
                    id="central-cash"
                    type="text"
                    inputMode="decimal"
                    required
                    value={verifiedCashInput}
                    onChange={(e) => setVerifiedCashInput(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold tabular-nums"
                  />
                </div>

                <div>
                  <label htmlFor="central-notes" className="block text-xs font-medium text-slate-700 mb-1">
                    Kontrol Açıklaması (İade veya uyuşmazlıkta zorunlu)
                  </label>
                  <textarea
                    id="central-notes"
                    rows={2}
                    value={reconNotes}
                    onChange={(e) => setReconNotes(e.target.value)}
                    placeholder="Sayım ve kontrol açıklaması..."
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>

                <div className="flex flex-wrap justify-between gap-2 pt-2 border-t border-slate-100">
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={verifyMutation.isPending}
                      onClick={() => verifyMutation.mutate('RETURN')}
                      className="inline-flex items-center gap-1 rounded-lg border border-rose-300 bg-white px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50"
                    >
                      <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                      Düzeltmeye İade
                    </button>
                    <button
                      type="button"
                      disabled={verifyMutation.isPending}
                      onClick={() => verifyMutation.mutate('DISPUTE')}
                      className="inline-flex items-center gap-1 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-semibold text-amber-900 hover:bg-amber-100"
                    >
                      <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />
                      Uyuşmazlık
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={verifyMutation.isPending}
                      onClick={() => verifyMutation.mutate('SAVE_REVIEW')}
                      className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
                    >
                      Taslak Kaydet
                    </button>
                    <button
                      id="central-approve-recon-btn"
                      type="submit"
                      disabled={verifyMutation.isPending}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-800 disabled:opacity-60"
                    >
                      <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                      Onayla ve Kilitle
                    </button>
                  </div>
                </div>
              </form>
            )}
          </div>
        ) : null}
      </ModalDialog>

      {/* Kilitli Kayıt İçin Gerekçeli Finansal Düzeltme Modalı */}
      <ModalDialog
        open={adjustOpen}
        title="Gerekçeli Finansal Düzeltme Kaydı"
        description="Onaylanmış finansal kayıtlar doğrudan değiştirilmez; bu işlem önceki ve yeni tutar farkını gerekçesiyle denetim günlüğüne işler."
        onClose={() => setAdjustOpen(false)}
      >
        <form
          onSubmit={(e: FormEvent) => {
            e.preventDefault();
            setAdjustError(null);
            adjustMutation.mutate();
          }}
          className="space-y-4"
        >
          {adjustError ? (
            <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
              {adjustError}
            </div>
          ) : null}

          <div>
            <label htmlFor="adj-field" className="block text-xs font-medium text-slate-700 mb-1">
              Düzeltilecek Alan
            </label>
            <select
              id="adj-field"
              value={adjustField}
              onChange={(e) => setAdjustField(e.target.value as AdjustableFieldName)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
            >
              {(Object.keys(ADJUSTMENT_FIELD_LABELS) as AdjustableFieldName[]).map((k) => (
                <option key={k} value={k}>
                  {ADJUSTMENT_FIELD_LABELS[k]}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="adj-val" className="block text-xs font-medium text-slate-700 mb-1">
              Yeni Doğrulanmış Tutar (₺)
            </label>
            <input
              id="adj-val"
              type="text"
              inputMode="decimal"
              required
              value={adjustValue}
              onChange={(e) => setAdjustValue(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold tabular-nums"
            />
          </div>

          <div>
            <label htmlFor="adj-reason" className="block text-xs font-medium text-slate-700 mb-1">
              Düzeltme Gerekçesi (En az 10 karakter)
            </label>
            <textarea
              id="adj-reason"
              rows={3}
              required
              minLength={10}
              value={adjustReason}
              onChange={(e) => setAdjustReason(e.target.value)}
              placeholder="Örn. Merkez kasa yeniden sayımında 20,00 TL eksik tespit edildi."
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setAdjustOpen(false)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={adjustMutation.isPending}
              className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-60"
            >
              {adjustMutation.isPending ? 'Kaydediliyor...' : 'Düzeltme Kaydını Onayla'}
            </button>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
}
