import { useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  STORE_TYPE_LABELS_TR,
  type StoreSummary,
  type StoreType,
} from '@kasa/shared';
import { CheckCircle2, Pencil, Plus, XCircle } from 'lucide-react';
import { DataTable, type DataTableColumn } from '../../components/DataTable';
import { ModalDialog } from '../../components/ModalDialog';
import { ApiClientError, apiRequest } from '../../lib/api';
import { useAuth } from '../auth/AuthContext';

export function StoresPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const isAdmin = user?.role === 'SYSTEM_ADMIN';

  const [createOpen, setCreateOpen] = useState(false);
  const [editingStore, setEditingStore] = useState<StoreSummary | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Form alanları
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [type, setType] = useState<StoreType>('STORE');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [isActive, setIsActive] = useState(true);

  const storesQuery = useQuery({
    queryKey: ['stores'],
    queryFn: () => apiRequest<{ items: StoreSummary[] }>('/stores'),
  });

  const createMutation = useMutation({
    mutationFn: () =>
      apiRequest<StoreSummary>('/stores', {
        method: 'POST',
        body: JSON.stringify({
          code: code.trim().toUpperCase(),
          name: name.trim(),
          type,
          address: address.trim() || null,
          phone: phone.trim() || null,
        }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['stores'] });
      setCreateOpen(false);
      setFormError(null);
    },
    onError: (err) => {
      setFormError(err instanceof ApiClientError ? err.message : 'Mağaza oluşturulamadı.');
    },
  });

  const updateMutation = useMutation({
    mutationFn: (storeId: string) =>
      apiRequest<StoreSummary>(`/stores/${storeId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          name: name.trim(),
          address: address.trim() || null,
          phone: phone.trim() || null,
          isActive,
        }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['stores'] });
      setEditingStore(null);
      setFormError(null);
    },
    onError: (err) => {
      setFormError(err instanceof ApiClientError ? err.message : 'Mağaza güncellenemedi.');
    },
  });

  function openCreateModal() {
    setCode('');
    setName('');
    setType('STORE');
    setAddress('');
    setPhone('');
    setFormError(null);
    setCreateOpen(true);
  }

  function openEditModal(store: StoreSummary) {
    setName(store.name);
    setAddress(store.address ?? '');
    setPhone(store.phone ?? '');
    setIsActive(store.isActive);
    setFormError(null);
    setEditingStore(store);
  }

  function handleCreateSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    createMutation.mutate();
  }

  function handleUpdateSubmit(e: FormEvent) {
    e.preventDefault();
    if (!editingStore) return;
    setFormError(null);
    updateMutation.mutate(editingStore.id);
  }

  const columns: Array<DataTableColumn<StoreSummary>> = [
    {
      key: 'code',
      header: 'Kod',
      render: (s) => <span className="font-mono text-xs font-semibold text-slate-700">{s.code}</span>,
    },
    {
      key: 'name',
      header: 'Mağaza / Birim Adı',
      render: (s) => <span className="font-medium text-slate-900">{s.name}</span>,
    },
    {
      key: 'type',
      header: 'Tür',
      render: (s) => (
        <span className="inline-flex items-center rounded-md bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-700">
          {STORE_TYPE_LABELS_TR[s.type]}
        </span>
      ),
    },
    {
      key: 'phone',
      header: 'Telefon',
      render: (s) => s.phone ?? '-',
    },
    {
      key: 'isActive',
      header: 'Durum',
      render: (s) =>
        s.isActive ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 text-xs font-medium text-emerald-800">
            <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
            Aktif
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 border border-slate-200 px-2.5 py-0.5 text-xs font-medium text-slate-600">
            <XCircle className="h-3.5 w-3.5" aria-hidden="true" />
            Pasif
          </span>
        ),
    },
    ...(isAdmin
      ? [
          {
            key: 'actions',
            header: 'İşlem',
            align: 'right' as const,
            render: (s: StoreSummary) => (
              <button
                type="button"
                onClick={() => openEditModal(s)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                <Pencil className="h-3.5 w-3.5" aria-hidden="true" />
                Düzenle
              </button>
            ),
          },
        ]
      : []),
  ];

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Mağaza ve Merkez Ofis Yönetimi
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Mağaza isimleri ve iletişim bilgileri geçmiş finansal kayıtları bozmadan dinamik olarak
            güncellenebilir.
          </p>
        </div>
        {isAdmin ? (
          <button
            id="new-store-button"
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 transition-colors shrink-0"
          >
            <Plus className="h-4 w-4" aria-hidden="true" />
            Yeni Mağaza Ekle
          </button>
        ) : null}
      </header>

      {storesQuery.isLoading ? (
        <p className="text-sm text-slate-500">Mağaza listesi yükleniyor...</p>
      ) : (
        <DataTable
          caption="Mağaza ve merkez ofis listesi"
          columns={columns}
          rows={storesQuery.data?.items ?? []}
          rowKey={(s) => s.id}
        />
      )}

      {/* Yeni Mağaza Modalı */}
      <ModalDialog
        open={createOpen}
        title="Yeni Mağaza / Birim Oluştur"
        description="Mağaza kodu benzersiz olmalıdır; mağaza adı daha sonra değiştirilebilir."
        onClose={() => setCreateOpen(false)}
      >
        <form onSubmit={handleCreateSubmit} className="space-y-4">
          {formError ? (
            <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
              {formError}
            </div>
          ) : null}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="store-code" className="block text-xs font-medium text-slate-700 mb-1">
                Mağaza Kodu
              </label>
              <input
                id="store-code"
                type="text"
                required
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="MAG-04"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm uppercase"
              />
            </div>
            <div>
              <label htmlFor="store-type" className="block text-xs font-medium text-slate-700 mb-1">
                Birim Türü
              </label>
              <select
                id="store-type"
                value={type}
                onChange={(e) => setType(e.target.value as StoreType)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                <option value="STORE">Mağaza</option>
                <option value="HEADQUARTERS">Merkez Ofis</option>
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="store-name" className="block text-xs font-medium text-slate-700 mb-1">
              Mağaza Adı
            </label>
            <input
              id="store-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Örn. Beşiktaş Şubesi"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div>
            <label htmlFor="store-phone" className="block text-xs font-medium text-slate-700 mb-1">
              Telefon (Opsiyonel)
            </label>
            <input
              id="store-phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="0212 000 00 00"
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div>
            <label htmlFor="store-address" className="block text-xs font-medium text-slate-700 mb-1">
              Adres (Opsiyonel)
            </label>
            <textarea
              id="store-address"
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={createMutation.isPending}
              className="rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
            >
              {createMutation.isPending ? 'Kaydediliyor...' : 'Mağazayı Oluştur'}
            </button>
          </div>
        </form>
      </ModalDialog>

      {/* Mağaza Düzenleme Modalı */}
      <ModalDialog
        open={editingStore !== null}
        title={`Mağaza Düzenle (${editingStore?.code ?? ''})`}
        description="Mağaza adını değiştirdiğinizde geçmiş tüm kasa ve mutabakat kayıtları yeni adla izlenir."
        onClose={() => setEditingStore(null)}
      >
        <form onSubmit={handleUpdateSubmit} className="space-y-4">
          {formError ? (
            <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
              {formError}
            </div>
          ) : null}

          <div>
            <label htmlFor="edit-store-name" className="block text-xs font-medium text-slate-700 mb-1">
              Mağaza Adı
            </label>
            <input
              id="edit-store-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div>
            <label htmlFor="edit-store-phone" className="block text-xs font-medium text-slate-700 mb-1">
              Telefon
            </label>
            <input
              id="edit-store-phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <div>
            <label htmlFor="edit-store-address" className="block text-xs font-medium text-slate-700 mb-1">
              Adres
            </label>
            <textarea
              id="edit-store-address"
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300"
            />
            <span>Mağaza aktif durumda</span>
          </label>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setEditingStore(null)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={updateMutation.isPending}
              className="rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
            >
              {updateMutation.isPending ? 'Güncelleniyor...' : 'Değişiklikleri Kaydet'}
            </button>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
}
