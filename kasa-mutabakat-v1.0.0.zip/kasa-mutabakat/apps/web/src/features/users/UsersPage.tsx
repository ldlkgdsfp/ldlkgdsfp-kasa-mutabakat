import { useState, type FormEvent } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  formatDateTimeTR,
  ROLE_CODES,
  ROLE_LABELS_TR,
  type RoleCode,
  type StoreSummary,
  type UserSummary,
} from '@kasa/shared';
import { CheckCircle2, Pencil, UserPlus, XCircle } from 'lucide-react';
import { DataTable, type DataTableColumn } from '../../components/DataTable';
import { ModalDialog } from '../../components/ModalDialog';
import { ApiClientError, apiRequest } from '../../lib/api';
import { useAuth } from '../auth/AuthContext';

export function UsersPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const isAdmin = user?.role === 'SYSTEM_ADMIN';

  const [createOpen, setCreateOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserSummary | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [roleCode, setRoleCode] = useState<RoleCode>('CASHIER');
  const [storeId, setStoreId] = useState('');
  const [isActive, setIsActive] = useState(true);

  const usersQuery = useQuery({
    queryKey: ['users'],
    queryFn: () => apiRequest<{ items: UserSummary[] }>('/users'),
  });

  const storesQuery = useQuery({
    queryKey: ['stores'],
    queryFn: () => apiRequest<{ items: StoreSummary[] }>('/stores'),
  });

  const createMutation = useMutation({
    mutationFn: () =>
      apiRequest<UserSummary>('/users', {
        method: 'POST',
        body: JSON.stringify({
          username: username.trim(),
          email: email.trim(),
          fullName: fullName.trim(),
          password,
          roleCode,
          storeId: storeId || null,
        }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['users'] });
      setCreateOpen(false);
      setFormError(null);
    },
    onError: (err) => {
      setFormError(err instanceof ApiClientError ? err.message : 'Personel oluşturulamadı.');
    },
  });

  const updateMutation = useMutation({
    mutationFn: (userId: string) =>
      apiRequest<UserSummary>(`/users/${userId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          email: email.trim(),
          fullName: fullName.trim(),
          roleCode,
          storeId: storeId || null,
          isActive,
          ...(password.trim() ? { newPassword: password } : {}),
        }),
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['users'] });
      setEditingUser(null);
      setFormError(null);
    },
    onError: (err) => {
      setFormError(err instanceof ApiClientError ? err.message : 'Personel güncellenemedi.');
    },
  });

  const stores = storesQuery.data?.items ?? [];
  const filteredStores =
    roleCode === 'CASHIER' || roleCode === 'STORE_MANAGER'
      ? stores.filter((s) => s.type === 'STORE' && s.isActive)
      : stores;

  function openCreateModal() {
    setUsername('');
    setEmail('');
    setFullName('');
    setPassword('');
    setRoleCode('CASHIER');
    const firstStore = stores.find((s) => s.type === 'STORE' && s.isActive);
    setStoreId(firstStore?.id ?? '');
    setFormError(null);
    setCreateOpen(true);
  }

  function openEditModal(u: UserSummary) {
    setEmail(u.email);
    setFullName(u.fullName);
    setRoleCode(u.role);
    setStoreId(u.storeId ?? '');
    setIsActive(u.isActive);
    setPassword('');
    setFormError(null);
    setEditingUser(u);
  }

  const columns: Array<DataTableColumn<UserSummary>> = [
    {
      key: 'fullName',
      header: 'Ad Soyad',
      render: (u) => (
        <div>
          <p className="font-medium text-slate-900">{u.fullName}</p>
          <p className="text-xs text-slate-500 font-mono">{u.username}</p>
        </div>
      ),
    },
    {
      key: 'role',
      header: 'Rol',
      render: (u) => (
        <span className="inline-flex items-center rounded-md bg-slate-100 px-2.5 py-0.5 text-xs font-medium text-slate-800">
          {u.roleLabel}
        </span>
      ),
    },
    {
      key: 'store',
      header: 'Bağlı Birim',
      render: (u) => (u.store ? `${u.store.name} (${u.store.code})` : 'Merkez / Tümü'),
    },
    {
      key: 'lastLoginAt',
      header: 'Son Giriş',
      render: (u) => (
        <span className="text-xs tabular-nums text-slate-600">
          {u.lastLoginAt ? formatDateTimeTR(u.lastLoginAt) : 'Henüz giriş yok'}
        </span>
      ),
    },
    {
      key: 'isActive',
      header: 'Durum',
      render: (u) =>
        u.isActive ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 text-xs font-medium text-emerald-800">
            <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
            Aktif
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 rounded-full bg-slate-100 border border-slate-200 px-2.5 py-0.5 text-xs font-medium text-slate-600">
            <XCircle className="h-3.5 w-3.5" aria-hidden="true" />
            Pasif
          </span>
        ),
    },
    ...(isAdmin
      ? [
          {
            key: 'actions',
            header: 'İşlem',
            align: 'right' as const,
            render: (u: UserSummary) => (
              <button
                type="button"
                onClick={() => openEditModal(u)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                <Pencil className="h-3.5 w-3.5" aria-hidden="true" />
                Düzenle
              </button>
            ),
          },
        ]
      : []),
  ];

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Personel ve Rol Yönetimi
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Her kasa hareketi yalnızca sisteme kayıtlı bir personel hesabıyla ilişkilendirilir;
            serbest metin kasiyer girişi yapılmaz.
          </p>
        </div>
        {isAdmin ? (
          <button
            id="new-user-button"
            type="button"
            onClick={openCreateModal}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 transition-colors shrink-0"
          >
            <UserPlus className="h-4 w-4" aria-hidden="true" />
            Yeni Personel Ekle
          </button>
        ) : null}
      </header>

      {usersQuery.isLoading ? (
        <p className="text-sm text-slate-500">Personel listesi yükleniyor...</p>
      ) : (
        <DataTable
          caption="Personel ve roller tablosu"
          columns={columns}
          rows={usersQuery.data?.items ?? []}
          rowKey={(u) => u.id}
        />
      )}

      {/* Yeni Personel Modalı */}
      <ModalDialog
        open={createOpen}
        title="Yeni Personel Hesabı Oluştur"
        description="Mağaza yöneticisi ve kasiyer rolleri mutlaka aktif bir mağazaya bağlanmalıdır."
        onClose={() => setCreateOpen(false)}
      >
        <form
          onSubmit={(e: FormEvent) => {
            e.preventDefault();
            setFormError(null);
            createMutation.mutate();
          }}
          className="space-y-4"
        >
          {formError ? (
            <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
              {formError}
            </div>
          ) : null}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="u-username" className="block text-xs font-medium text-slate-700 mb-1">
                Kullanıcı Adı
              </label>
              <input
                id="u-username"
                type="text"
                required
                spellCheck={false}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="magaza1.kasiyer2"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label htmlFor="u-fullname" className="block text-xs font-medium text-slate-700 mb-1">
                Ad Soyad
              </label>
              <input
                id="u-fullname"
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Zeynep Demir"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="u-email" className="block text-xs font-medium text-slate-700 mb-1">
                E-posta
              </label>
              <input
                id="u-email"
                type="email"
                required
                spellCheck={false}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="zeynep@firma.com"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label htmlFor="u-password" className="block text-xs font-medium text-slate-700 mb-1">
                Başlangıç Parolası (En az 8 karakter)
              </label>
              <input
                id="u-password"
                type="password"
                required
                minLength={8}
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="u-role" className="block text-xs font-medium text-slate-700 mb-1">
                Rol
              </label>
              <select
                id="u-role"
                value={roleCode}
                onChange={(e) => setRoleCode(e.target.value as RoleCode)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                {ROLE_CODES.map((rc) => (
                  <option key={rc} value={rc}>
                    {ROLE_LABELS_TR[rc]}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="u-store" className="block text-xs font-medium text-slate-700 mb-1">
                Bağlı Mağaza / Birim
              </label>
              <select
                id="u-store"
                required={roleCode === 'CASHIER' || roleCode === 'STORE_MANAGER'}
                value={storeId}
                onChange={(e) => setStoreId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                <option value="">Birim seçin...</option>
                {filteredStores.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={createMutation.isPending}
              className="rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
            >
              {createMutation.isPending ? 'Kaydediliyor...' : 'Personeli Oluştur'}
            </button>
          </div>
        </form>
      </ModalDialog>

      {/* Personel Düzenleme Modalı */}
      <ModalDialog
        open={editingUser !== null}
        title={`Personel Düzenle (${editingUser?.username ?? ''})`}
        description="Hesap pasifleştirildiğinde veya parola sıfırlandığında aktif oturumlar anında sonlandırılır."
        onClose={() => setEditingUser(null)}
      >
        <form
          onSubmit={(e: FormEvent) => {
            e.preventDefault();
            if (!editingUser) return;
            setFormError(null);
            updateMutation.mutate(editingUser.id);
          }}
          className="space-y-4"
        >
          {formError ? (
            <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
              {formError}
            </div>
          ) : null}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="eu-fullname" className="block text-xs font-medium text-slate-700 mb-1">
                Ad Soyad
              </label>
              <input
                id="eu-fullname"
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label htmlFor="eu-email" className="block text-xs font-medium text-slate-700 mb-1">
                E-posta
              </label>
              <input
                id="eu-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="eu-role" className="block text-xs font-medium text-slate-700 mb-1">
                Rol
              </label>
              <select
                id="eu-role"
                value={roleCode}
                onChange={(e) => setRoleCode(e.target.value as RoleCode)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                {ROLE_CODES.map((rc) => (
                  <option key={rc} value={rc}>
                    {ROLE_LABELS_TR[rc]}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="eu-store" className="block text-xs font-medium text-slate-700 mb-1">
                Bağlı Mağaza / Birim
              </label>
              <select
                id="eu-store"
                required={roleCode === 'CASHIER' || roleCode === 'STORE_MANAGER'}
                value={storeId}
                onChange={(e) => setStoreId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
              >
                <option value="">Birim seçin...</option>
                {filteredStores.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="eu-password" className="block text-xs font-medium text-slate-700 mb-1">
              Yeni Parola (Değiştirmek istemiyorsanız boş bırakın)
            </label>
            <input
              id="eu-password"
              type="password"
              minLength={8}
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            />
          </div>

          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300"
            />
            <span>Kullanıcı hesabı aktif</span>
          </label>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setEditingUser(null)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              disabled={updateMutation.isPending}
              className="rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
            >
              {updateMutation.isPending ? 'Güncelleniyor...' : 'Kaydet'}
            </button>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
}
