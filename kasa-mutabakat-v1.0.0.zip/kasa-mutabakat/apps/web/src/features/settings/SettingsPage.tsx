import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { formatDateTimeTR, type SystemSettingDTO } from '@kasa/shared';
import { Check, Save } from 'lucide-react';
import { ApiClientError, apiRequest } from '../../lib/api';

export function SettingsPage() {
  const queryClient = useQueryClient();
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [savedKey, setSavedKey] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const settingsQuery = useQuery({
    queryKey: ['settings'],
    queryFn: () => apiRequest<{ items: SystemSettingDTO[] }>('/settings'),
  });

  const updateMutation = useMutation({
    mutationFn: ({ key, valueJson }: { key: string; valueJson: unknown }) =>
      apiRequest<SystemSettingDTO>(`/settings/${encodeURIComponent(key)}`, {
        method: 'PATCH',
        body: JSON.stringify({ valueJson }),
      }),
    onSuccess: (_data, vars) => {
      void queryClient.invalidateQueries({ queryKey: ['settings'] });
      setSavedKey(vars.key);
      setErrorMsg(null);
      setTimeout(() => setSavedKey((k) => (k === vars.key ? null : k)), 2000);
    },
    onError: (err) => {
      setErrorMsg(err instanceof ApiClientError ? err.message : 'Ayar güncellenemedi.');
    },
  });

  function handleSave(item: SystemSettingDTO) {
    const raw = drafts[item.key] ?? String(item.valueJson);
    let parsedValue: unknown = raw;
    if (typeof item.valueJson === 'boolean') {
      parsedValue = raw === 'true';
    } else if (typeof item.valueJson === 'number') {
      const n = Number(raw);
      if (Number.isNaN(n)) {
        setErrorMsg(`'${item.key}' için geçerli bir sayı girin.`);
        return;
      }
      parsedValue = n;
    }
    updateMutation.mutate({ key: item.key, valueJson: parsedValue });
  }

  const items = settingsQuery.data?.items ?? [];

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">Sistem Ayarları</h1>
        <p className="text-sm text-slate-600 mt-1">
          Finansal eşikler, OCR güven skoru ve güvenlik kuralları denetim kayıtlı olarak yönetilir.
        </p>
      </header>

      {errorMsg ? (
        <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
          {errorMsg}
        </div>
      ) : null}

      <div className="bg-white rounded-xl border border-slate-200 divide-y divide-slate-100">
        {settingsQuery.isLoading ? (
          <p className="p-6 text-sm text-slate-500">Ayarlar yükleniyor...</p>
        ) : (
          items.map((item) => {
            const currentVal = drafts[item.key] ?? String(item.valueJson);
            const isBool = typeof item.valueJson === 'boolean';
            return (
              <div
                key={item.key}
                className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-semibold text-slate-900">
                      {item.key}
                    </span>
                    <span className="rounded bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-600">
                      {item.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{item.description}</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Son güncelleme: {formatDateTimeTR(item.updatedAt)}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {isBool ? (
                    <select
                      aria-label={item.key}
                      value={currentVal}
                      onChange={(e) =>
                        setDrafts((prev) => ({ ...prev, [item.key]: e.target.value }))
                      }
                      className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"
                    >
                      <option value="true">Aktif (Evet)</option>
                      <option value="false">Pasif (Hayır)</option>
                    </select>
                  ) : (
                    <input
                      aria-label={item.key}
                      type="text"
                      value={currentVal}
                      onChange={(e) =>
                        setDrafts((prev) => ({ ...prev, [item.key]: e.target.value }))
                      }
                      className="w-52 rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                  )}
                  <button
                    type="button"
                    onClick={() => handleSave(item)}
                    disabled={updateMutation.isPending}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:opacity-60"
                  >
                    {savedKey === item.key ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-emerald-400" aria-hidden="true" />
                        Kaydedildi
                      </>
                    ) : (
                      <>
                        <Save className="h-3.5 w-3.5" aria-hidden="true" />
                        Kaydet
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
