import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  formatCurrencyTRY,
  formatDateTimeTR,
  formatDateTR,
  type CashSessionSummaryDTO,
  type StoreSummary,
  type TransferReceiptSummaryDTO,
} from '@kasa/shared';
import {
  ArrowRight,
  BarChart3,
  FileCheck2,
  ReceiptText,
  Wallet,
} from 'lucide-react';
import { DataTable, type DataTableColumn } from '../../components/DataTable';
import { CashDifferenceBadge, SessionStatusBadge } from '../../components/StatusBadges';
import { apiRequest } from '../../lib/api';
import { useAuth } from '../auth/AuthContext';

interface AuditLogRow {
  id: string;
  action: string;
  entityType: string;
  actorRole: string | null;
  actor: { id: string; username: string; fullName: string } | null;
  store: { id: string; code: string; name: string } | null;
  ipAddress: string | null;
  createdAt: string;
}

interface CashSessionsOverview {
  items: CashSessionSummaryDTO[];
  totals: {
    sessionCount: number;
    cashSalesTotal: string;
    creditCardSalesTotal: string;
    bankTransferTotal: string;
    expectedCashTotal: string;
    totalShortage: string;
    totalSurplus: string;
    netSalesTotal: string;
  };
}

interface ReceiptsOverview {
  items: TransferReceiptSummaryDTO[];
  summary: {
    totalCount: number;
    pendingApprovalCount: number;
    manualReviewCount: number;
    duplicateOrFailedCount: number;
    approvedTotal: string;
    bankVerifiedTotal: string;
  };
}

function getTodayIsoTR(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Istanbul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

export function OverviewPage({ mode }: { mode: 'overview' | 'audit' | 'planned' }) {
  const { user } = useAuth();
  const todayIso = getTodayIsoTR();

  const canReadAudit =
    user?.role === 'SYSTEM_ADMIN' ||
    user?.role === 'CENTRAL_ACCOUNTING' ||
    user?.role === 'STORE_MANAGER';

  const isCentral = user?.role === 'SYSTEM_ADMIN' || user?.role === 'CENTRAL_ACCOUNTING';

  const storesQuery = useQuery({
    queryKey: ['stores'],
    queryFn: () => apiRequest<{ items: StoreSummary[] }>('/stores'),
    enabled: mode === 'overview',
  });

  const todaySessionsQuery = useQuery({
    queryKey: ['cash-sessions', 'overview', todayIso],
    queryFn: () => apiRequest<CashSessionsOverview>(`/cash-sessions?businessDate=${todayIso}`),
    enabled: mode === 'overview',
  });

  const todayReceiptsQuery = useQuery({
    queryKey: ['receipts', 'overview', todayIso],
    queryFn: () =>
      apiRequest<ReceiptsOverview>(`/receipts?startDate=${todayIso}&endDate=${todayIso}`),
    enabled: mode === 'overview',
  });

  const auditQuery = useQuery({
    queryKey: ['audit-logs', mode],
    queryFn: () => apiRequest<{ items: AuditLogRow[] }>(`/audit-logs?limit=${mode === 'audit' ? 100 : 10}`),
    enabled: canReadAudit && (mode === 'overview' || mode === 'audit'),
  });

  const auditColumns: Array<DataTableColumn<AuditLogRow>> = [
    {
      key: 'createdAt',
      header: 'Tarih / Saat',
      render: (r) => <span className="tabular-nums text-xs">{formatDateTimeTR(r.createdAt)}</span>,
    },
    {
      key: 'action',
      header: 'İşlem',
      render: (r) => (
        <span className="font-mono text-xs font-medium text-slate-800">{r.action}</span>
      ),
    },
    {
      key: 'actor',
      header: 'Kullanıcı',
      render: (r) => r.actor?.fullName ?? 'Sistem',
    },
    {
      key: 'store',
      header: 'Mağaza',
      render: (r) => (r.store ? `${r.store.name} (${r.store.code})` : 'Genel'),
    },
  ];

  const sessionColumns: Array<DataTableColumn<CashSessionSummaryDTO>> = [
    {
      key: 'store',
      header: 'Mağaza / Kasiyer',
      render: (s) => (
        <div>
          <p className="font-medium text-slate-900">{s.store.name}</p>
          <p className="text-xs text-slate-500">{s.cashier.fullName}</p>
        </div>
      ),
    },
    {
      key: 'netSales',
      header: 'Net Satış',
      align: 'right',
      render: (s) => formatCurrencyTRY(s.netSalesTotal),
    },
    {
      key: 'expected',
      header: 'Beklenen Nakit',
      align: 'right',
      render: (s) => formatCurrencyTRY(s.expectedCash),
    },
    {
      key: 'diff',
      header: 'Fark',
      render: (s) => (
        <CashDifferenceBadge status={s.cashDifferenceStatus} difference={s.cashDifference} />
      ),
    },
    {
      key: 'status',
      header: 'Durum',
      render: (s) => <SessionStatusBadge status={s.status} />,
    },
    {
      key: 'link',
      header: 'Detay',
      align: 'right',
      render: (s) => (
        <Link to={`/kasa/${s.id}`} className="text-xs font-semibold text-blue-700 hover:underline">
          Aç →
        </Link>
      ),
    },
  ];

  if (mode === 'planned') {
    return (
      <section className="bg-white rounded-xl border border-slate-200 p-8 max-w-2xl">
        <h1 className="text-xl font-semibold text-slate-900">Sayfa Bulunamadı</h1>
        <p className="mt-2 text-sm text-slate-600">
          Aradığınız sayfa bulunamadı. Sol menüden yetkili olduğunuz modüllere geçiş yapabilirsiniz.
        </p>
      </section>
    );
  }

  if (mode === 'audit') {
    return (
      <div className="space-y-6">
        <header>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Güvenlik ve İşlem Denetim Kayıtları
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Tüm giriş, kasa hareketi, dekont onayı, mutabakat kilidi ve finansal düzeltme olayları
            değiştirilemez denetim günlüğünde saklanır.
          </p>
        </header>
        {auditQuery.isLoading ? (
          <p className="text-sm text-slate-500">Denetim kayıtları yükleniyor...</p>
        ) : (
          <DataTable
            caption="Güvenlik ve finansal denetim kayıtları"
            columns={auditColumns}
            rows={auditQuery.data?.items ?? []}
            rowKey={(r) => r.id}
            emptyMessage="Henüz denetim kaydı bulunmamaktadır."
          />
        )}
      </div>
    );
  }

  const totals = todaySessionsQuery.data?.totals;
  const rcptSummary = todayReceiptsQuery.data?.summary;
  const activeStoresCount = (storesQuery.data?.items ?? []).filter(
    (s) => s.type === 'STORE' && s.isActive,
  ).length;

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Genel Bakış – {formatDateTR(todayIso)}
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Hoş geldiniz, <strong>{user?.fullName}</strong> ({user?.roleLabel}). Yetki kapsamınızdaki
            bugünkü canlı kasa ve IBAN dekont durumu aşağıdadır.
          </p>
        </div>
        <span className="text-xs font-medium text-slate-500">
          Kapsamdaki aktif mağaza: <strong>{activeStoresCount}</strong>
        </span>
      </header>

      {/* Bugünkü Canlı KPI Kartları */}
      <section aria-label="Günlük özet" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Bugünkü Net Satış</p>
          <p className="mt-2 text-2xl font-bold text-slate-900 tabular-nums">
            {formatCurrencyTRY(totals?.netSalesTotal)}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            {totals?.sessionCount ?? 0} kasa oturumu
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Ödeme Yöntemleri</p>
          <dl className="mt-2 space-y-1 text-xs tabular-nums">
            <div className="flex justify-between">
              <dt className="text-slate-500">Nakit:</dt>
              <dd className="font-semibold text-slate-900">{formatCurrencyTRY(totals?.cashSalesTotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Kredi Kartı:</dt>
              <dd className="font-semibold text-slate-900">{formatCurrencyTRY(totals?.creditCardSalesTotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-slate-500">Onaylı Havale:</dt>
              <dd className="font-semibold text-blue-700">{formatCurrencyTRY(totals?.bankTransferTotal)}</dd>
            </div>
          </dl>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Beklenen Nakit ve Farklar</p>
          <p className="mt-2 text-xl font-bold text-blue-800 tabular-nums">
            {formatCurrencyTRY(totals?.expectedCashTotal)}
          </p>
          <p className="mt-1 text-xs tabular-nums">
            <span className="text-rose-700 font-medium">
              Açık: {formatCurrencyTRY(totals?.totalShortage)}
            </span>{' '}
            ·{' '}
            <span className="text-amber-800 font-medium">
              Fazla: {formatCurrencyTRY(totals?.totalSurplus)}
            </span>
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">Bugünkü IBAN Dekontları</p>
          <p className="mt-2 text-2xl font-bold text-slate-900 tabular-nums">
            {rcptSummary?.totalCount ?? 0}
          </p>
          <p className="mt-1 text-xs text-slate-600 tabular-nums">
            Onay bekleyen: <strong>{rcptSummary?.pendingApprovalCount ?? 0}</strong> · Sorunlu:{' '}
            <strong className="text-rose-700">{rcptSummary?.duplicateOrFailedCount ?? 0}</strong>
          </p>
        </div>
      </section>

      {/* Hızlı Geçiş Kartları */}
      <section aria-label="Hızlı işlemler" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <Link
          to="/kasa"
          className="rounded-xl border border-slate-200 bg-white p-4 hover:border-blue-300 hover:bg-blue-50/30 transition-colors flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <Wallet className="h-5 w-5 text-blue-700" aria-hidden="true" />
            <div>
              <p className="text-sm font-semibold text-slate-900">Günlük Kasa</p>
              <p className="text-xs text-slate-500">Oturum, tahsilat ve kapanış</p>
            </div>
          </div>
          <ArrowRight className="h-4 w-4 text-slate-400" aria-hidden="true" />
        </Link>

        <Link
          to="/dekontlar"
          className="rounded-xl border border-slate-200 bg-white p-4 hover:border-blue-300 hover:bg-blue-50/30 transition-colors flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <ReceiptText className="h-5 w-5 text-emerald-700" aria-hidden="true" />
            <div>
              <p className="text-sm font-semibold text-slate-900">IBAN Dekontları</p>
              <p className="text-xs text-slate-500">Yükleme, OCR ve doğrulama</p>
            </div>
          </div>
          <ArrowRight className="h-4 w-4 text-slate-400" aria-hidden="true" />
        </Link>

        {isCentral ? (
          <Link
            to="/merkez"
            className="rounded-xl border border-slate-200 bg-white p-4 hover:border-blue-300 hover:bg-blue-50/30 transition-colors flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <FileCheck2 className="h-5 w-5 text-slate-900" aria-hidden="true" />
              <div>
                <p className="text-sm font-semibold text-slate-900">Merkez Mutabakat</p>
                <p className="text-xs text-slate-500">Mağaza kontrol ve onay</p>
              </div>
            </div>
            <ArrowRight className="h-4 w-4 text-slate-400" aria-hidden="true" />
          </Link>
        ) : null}

        <Link
          to="/raporlar"
          className="rounded-xl border border-slate-200 bg-white p-4 hover:border-blue-300 hover:bg-blue-50/30 transition-colors flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <BarChart3 className="h-5 w-5 text-amber-700" aria-hidden="true" />
            <div>
              <p className="text-sm font-semibold text-slate-900">Raporlar ve Analiz</p>
              <p className="text-xs text-slate-500">9 rapor, grafik, Excel / CSV</p>
            </div>
          </div>
          <ArrowRight className="h-4 w-4 text-slate-400" aria-hidden="true" />
        </Link>
      </section>

      {/* Bugünkü Kasa Oturumları */}
      <section className="space-y-3">
        <h2 className="text-base font-semibold text-slate-900">Bugünkü Kasa Oturumları</h2>
        <DataTable
          caption="Bugünkü kasa oturumları"
          columns={sessionColumns}
          rows={todaySessionsQuery.data?.items ?? []}
          rowKey={(s) => s.id}
          emptyMessage="Bugün için henüz kasa oturumu açılmamıştır."
        />
      </section>

      {/* Son Denetim Kayıtları */}
      {canReadAudit ? (
        <section className="space-y-3">
          <h2 className="text-base font-semibold text-slate-900">Son Denetim Kayıtları</h2>
          <DataTable
            caption="Son denetim kayıtları"
            columns={auditColumns}
            rows={auditQuery.data?.items ?? []}
            rowKey={(r) => r.id}
            emptyMessage="Henüz denetim kaydı bulunmamaktadır."
          />
        </section>
      ) : null}
    </div>
  );
}
