import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  formatCurrencyTRY,
  formatDateTR,
  REPORT_LABELS_TR,
  REPORT_TYPES,
  type ReportColumnDefinition,
  type ReportPayloadDTO,
  type ReportType,
  type StoreSummary,
  type UserSummary,
} from '@kasa/shared';
import {
  ArrowDownUp,
  BarChart3,
  FileSpreadsheet,
  FileText,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { DataTable, type DataTableColumn } from '../../components/DataTable';
import { apiRequest } from '../../lib/api';
import { useAuth } from '../auth/AuthContext';

function getTodayIsoTR(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Istanbul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

function getMonthStartIsoTR(): string {
  return `${getTodayIsoTR().slice(0, 7)}-01`;
}

const PIE_COLORS = ['#0f172a', '#1d4ed8', '#047857'];

const SUMMARY_LABELS_TR: Record<string, string> = {
  rowCount: 'Kayıt Sayısı',
  storeCount: 'Mağaza Sayısı',
  cashierCount: 'Kasiyer Sayısı',
  dayCount: 'Gün Sayısı',
  monthCount: 'Dönem Sayısı',
  totalCount: 'Toplam Dekont',
  totalPending: 'Bekleyen İşlem',
  pendingClosings: 'Bekleyen Kapanış',
  pendingReceipts: 'Bekleyen Dekont',
  varianceCount: 'Farklı Oturum Sayısı',
  duplicateOrFailedCount: 'Mükerrer / Hatalı',
  netSalesTotal: 'Net Satış Toplamı',
  cashSalesTotal: 'Nakit Satış Toplamı',
  creditCardSalesTotal: 'Kredi Kartı Toplamı',
  bankTransferTotal: 'Onaylı Havale / EFT',
  approvedTotal: 'Onaylı Havale / EFT',
  bankVerifiedTotal: 'Bankada Teyitli',
  grossTotal: 'Brüt Tahsilat',
  totalShortage: 'Toplam Kasa Açığı',
  totalSurplus: 'Toplam Kasa Fazlası',
  netCashVariance: 'Net Nakit Farkı',
};

const CURRENCY_SUMMARY_KEYS = new Set([
  'netSalesTotal',
  'cashSalesTotal',
  'creditCardSalesTotal',
  'bankTransferTotal',
  'approvedTotal',
  'bankVerifiedTotal',
  'grossTotal',
  'totalShortage',
  'totalSurplus',
  'netCashVariance',
]);

export function ReportsPage() {
  const { user } = useAuth();
  const isGlobal = user?.role === 'SYSTEM_ADMIN' || user?.role === 'CENTRAL_ACCOUNTING';
  const canFilterCashier = user?.role !== 'CASHIER';

  const [reportType, setReportType] = useState<ReportType>('daily-store');
  const [startDate, setStartDate] = useState(getMonthStartIsoTR());
  const [endDate, setEndDate] = useState(getTodayIsoTR());
  const [storeId, setStoreId] = useState('');
  const [cashierId, setCashierId] = useState('');
  const [sortBy, setSortBy] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const storesQuery = useQuery({
    queryKey: ['stores'],
    queryFn: () => apiRequest<{ items: StoreSummary[] }>('/stores'),
    enabled: isGlobal,
  });

  const usersQuery = useQuery({
    queryKey: ['users', 'report-filter'],
    queryFn: () => apiRequest<{ items: UserSummary[] }>('/users'),
    enabled: canFilterCashier,
  });

  const queryParamsString = useMemo(() => {
    const qs = new URLSearchParams();
    if (startDate) qs.set('startDate', startDate);
    if (endDate) qs.set('endDate', endDate);
    if (storeId && isGlobal) qs.set('storeId', storeId);
    if (cashierId && canFilterCashier) qs.set('cashierId', cashierId);
    if (sortBy) qs.set('sortBy', sortBy);
    qs.set('sortDir', sortDir);
    return qs.toString();
  }, [startDate, endDate, storeId, cashierId, sortBy, sortDir, isGlobal, canFilterCashier]);

  const reportQuery = useQuery({
    queryKey: ['report', reportType, queryParamsString],
    queryFn: () => apiRequest<ReportPayloadDTO>(`/reports/${reportType}?${queryParamsString}`),
  });

  const report = reportQuery.data;
  const stores = (storesQuery.data?.items ?? []).filter((s) => s.type === 'STORE');
  const users = usersQuery.data?.items ?? [];

  function handleExport(format: 'xlsx' | 'csv') {
    const url = `/api/v1/reports/${reportType}/export?${queryParamsString}&format=${format}`;
    window.location.assign(url);
  }

  function renderCell(col: ReportColumnDefinition, value: string | number | boolean | null | undefined) {
    if (value === null || value === undefined || value === '') return '-';
    if (col.type === 'currency') {
      const str = String(value);
      const isNegative = str.startsWith('-');
      return (
        <span className={isNegative ? 'font-semibold text-rose-700' : undefined}>
          {formatCurrencyTRY(str)}
        </span>
      );
    }
    if (col.type === 'percent') {
      return <span className="tabular-nums">%{value}</span>;
    }
    if (col.type === 'date') {
      return <span className="tabular-nums">{formatDateTR(String(value))}</span>;
    }
    return String(value);
  }

  const tableColumns: Array<DataTableColumn<Record<string, string | number | boolean | null>>> =
    (report?.columns ?? []).map((col) => ({
      key: col.key,
      header: col.label,
      align:
        col.type === 'currency' || col.type === 'number' || col.type === 'percent'
          ? 'right'
          : 'left',
      render: (row) => renderCell(col, row[col.key]),
    }));

  const chartData = report?.chartData ?? [];

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900 tracking-tight">
            Raporlama ve Finansal Analiz
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Tüm raporlar gerçek PostgreSQL kayıtlarından backend Decimal.js motoruyla hesaplanır;
            filtrelenebilir, sıralanabilir ve Excel / CSV olarak dışa aktarılabilir.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 shrink-0">
          <button
            id="export-xlsx-btn"
            type="button"
            onClick={() => handleExport('xlsx')}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-800 transition-colors"
          >
            <FileSpreadsheet className="h-4 w-4" aria-hidden="true" />
            Excel (.xlsx) İndir
          </button>
          <button
            id="export-csv-btn"
            type="button"
            onClick={() => handleExport('csv')}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 transition-colors"
          >
            <FileText className="h-4 w-4" aria-hidden="true" />
            CSV (.csv) İndir
          </button>
        </div>
      </header>

      {/* 9 Rapor Seçici */}
      <nav aria-label="Rapor türleri" className="flex flex-wrap gap-2">
        {REPORT_TYPES.map((rt) => {
          const active = reportType === rt;
          return (
            <button
              key={rt}
              type="button"
              onClick={() => {
                setReportType(rt);
                setSortBy('');
              }}
              aria-pressed={active}
              className={`rounded-lg px-3 py-2 text-xs font-medium transition-colors border ${
                active
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              {REPORT_LABELS_TR[rt]}
            </button>
          );
        })}
      </nav>

      {/* Filtre ve Sıralama Çubuğu */}
      <section className="rounded-xl border border-slate-200 bg-white p-4 flex flex-wrap items-end gap-3">
        <div>
          <label htmlFor="rep-start" className="block text-xs font-medium text-slate-600 mb-1">
            Başlangıç Tarihi
          </label>
          <input
            id="rep-start"
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
          />
        </div>
        <div>
          <label htmlFor="rep-end" className="block text-xs font-medium text-slate-600 mb-1">
            Bitiş Tarihi
          </label>
          <input
            id="rep-end"
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
          />
        </div>

        {isGlobal ? (
          <div>
            <label htmlFor="rep-store" className="block text-xs font-medium text-slate-600 mb-1">
              Mağaza
            </label>
            <select
              id="rep-store"
              value={storeId}
              onChange={(e) => setStoreId(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm min-w-40"
            >
              <option value="">Tüm Mağazalar</option>
              {stores.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>
        ) : null}

        {canFilterCashier ? (
          <div>
            <label htmlFor="rep-cashier" className="block text-xs font-medium text-slate-600 mb-1">
              Kasiyer / Personel
            </label>
            <select
              id="rep-cashier"
              value={cashierId}
              onChange={(e) => setCashierId(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm min-w-44"
            >
              <option value="">Tüm Personel</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.fullName}
                </option>
              ))}
            </select>
          </div>
        ) : null}

        <div>
          <label htmlFor="rep-sort" className="block text-xs font-medium text-slate-600 mb-1">
            Sıralama Ölçütü
          </label>
          <select
            id="rep-sort"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm min-w-40"
          >
            <option value="">Varsayılan</option>
            {(report?.columns ?? []).map((c) => (
              <option key={c.key} value={c.key}>
                {c.label}
              </option>
            ))}
          </select>
        </div>

        <button
          type="button"
          onClick={() => setSortDir((d) => (d === 'desc' ? 'asc' : 'desc'))}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50"
        >
          <ArrowDownUp className="h-3.5 w-3.5" aria-hidden="true" />
          <span>{sortDir === 'desc' ? 'Azalan' : 'Artan'}</span>
        </button>
      </section>

      {/* Rapor Özet Kartları */}
      {report && Object.keys(report.summary).length > 0 ? (
        <section aria-label="Rapor özeti" className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {Object.entries(report.summary).map(([key, val]) => (
            <div key={key} className="rounded-xl border border-slate-200 bg-white p-4">
              <p className="text-xs text-slate-500">{SUMMARY_LABELS_TR[key] ?? key}</p>
              <p className="mt-1 text-lg font-semibold text-slate-900 tabular-nums">
                {CURRENCY_SUMMARY_KEYS.has(key) ? formatCurrencyTRY(String(val)) : String(val)}
              </p>
            </div>
          ))}
        </section>
      ) : null}

      {/* Grafik Alanı */}
      {chartData.length > 0 ? (
        <section className="rounded-xl border border-slate-200 bg-white p-5 space-y-3">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-blue-700" aria-hidden="true" />
            <h2 className="text-sm font-semibold text-slate-900">
              {report?.title} – Görsel Analiz
            </h2>
          </div>

          <div className="h-72 w-full">
            {reportType === 'payment-distribution' ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={105}
                    paddingAngle={3}
                  >
                    {chartData.map((_entry, idx) => (
                      <Cell key={idx} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val: number) => formatCurrencyTRY(val)}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : reportType === 'cashier-variance' ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip formatter={(val: number) => formatCurrencyTRY(val)} />
                  <Legend />
                  <Bar dataKey="Kasa Açığı" fill="#be123c" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Kasa Fazlası" fill="#b45309" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : reportType === 'iban-transfers' || reportType === 'pending-approvals' ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="Adet" fill="#1d4ed8" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : reportType === 'shortage-surplus' ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip formatter={(val: number) => formatCurrencyTRY(val)} />
                  <Bar dataKey="Fark" fill="#be123c" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip formatter={(val: number) => formatCurrencyTRY(val)} />
                  <Legend />
                  <Bar dataKey="Nakit" stackId="a" fill="#0f172a" />
                  <Bar dataKey="Kredi Kartı" stackId="a" fill="#1d4ed8" />
                  <Bar dataKey="Havale / EFT" stackId="a" fill="#047857" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </section>
      ) : null}

      {/* Rapor Tablosu */}
      <section className="space-y-3">
        <h2 className="text-base font-semibold text-slate-900">
          {report?.title ?? REPORT_LABELS_TR[reportType]} ({report?.rows.length ?? 0} kayıt)
        </h2>
        {reportQuery.isLoading ? (
          <p className="text-sm text-slate-500">Rapor verileri hesaplanıyor...</p>
        ) : (
          <DataTable
            caption={report?.title ?? 'Finansal rapor tablosu'}
            columns={tableColumns}
            rows={report?.rows ?? []}
            rowKey={(_row, idx) => `${reportType}-${idx}`}
            emptyMessage="Seçili tarih aralığı ve filtrelerde raporlanacak kayıt bulunmamaktadır."
          />
        )}
      </section>
    </div>
  );
}
