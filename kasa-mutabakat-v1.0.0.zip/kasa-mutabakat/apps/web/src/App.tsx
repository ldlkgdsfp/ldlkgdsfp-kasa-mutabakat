import type { ReactNode } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import type { RoleCode } from '@kasa/shared';
import { AppLayout } from './app/AppLayout';
import { AuthProvider, useAuth } from './features/auth/AuthContext';
import { LoginPage } from './features/auth/LoginPage';
import { CashSessionDetailPage } from './features/cash/CashSessionDetailPage';
import { CashSessionsPage } from './features/cash/CashSessionsPage';
import { CentralControlPage } from './features/central/CentralControlPage';
import { OverviewPage } from './features/dashboard/OverviewPage';
import { ReceiptDetailPage } from './features/receipts/ReceiptDetailPage';
import { ReceiptsPage } from './features/receipts/ReceiptsPage';
import { ReportsPage } from './features/reports/ReportsPage';
import { SettingsPage } from './features/settings/SettingsPage';
import { StoresPage } from './features/stores/StoresPage';
import { UsersPage } from './features/users/UsersPage';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function RequireAuthRoute({
  children,
  allowedRoles,
}: {
  children: ReactNode;
  allowedRoles?: RoleCode[];
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-slate-50 text-sm text-slate-600">
        Oturum doğrulanıyor...
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/giris" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return (
      <AppLayout>
        <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 p-6 text-sm text-rose-800">
          Bu sayfaya erişim yetkiniz bulunmamaktadır.
        </div>
      </AppLayout>
    );
  }

  return <AppLayout>{children}</AppLayout>;
}

function PublicOnlyRoute({ children }: { children: ReactNode }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-slate-50 text-sm text-slate-600">
        Yükleniyor...
      </div>
    );
  }

  if (user) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route
              path="/giris"
              element={
                <PublicOnlyRoute>
                  <LoginPage />
                </PublicOnlyRoute>
              }
            />
            <Route
              path="/"
              element={
                <RequireAuthRoute>
                  <OverviewPage mode="overview" />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/kasa"
              element={
                <RequireAuthRoute>
                  <CashSessionsPage />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/kasa/:sessionId"
              element={
                <RequireAuthRoute>
                  <CashSessionDetailPage />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/dekontlar"
              element={
                <RequireAuthRoute>
                  <ReceiptsPage />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/dekontlar/:receiptId"
              element={
                <RequireAuthRoute>
                  <ReceiptDetailPage />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/merkez"
              element={
                <RequireAuthRoute allowedRoles={['SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING']}>
                  <CentralControlPage />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/raporlar"
              element={
                <RequireAuthRoute>
                  <ReportsPage />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/magazalar"
              element={
                <RequireAuthRoute allowedRoles={['SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING', 'STORE_MANAGER']}>
                  <StoresPage />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/personel"
              element={
                <RequireAuthRoute allowedRoles={['SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING', 'STORE_MANAGER']}>
                  <UsersPage />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/ayarlar"
              element={
                <RequireAuthRoute allowedRoles={['SYSTEM_ADMIN']}>
                  <SettingsPage />
                </RequireAuthRoute>
              }
            />
            <Route
              path="/denetim"
              element={
                <RequireAuthRoute allowedRoles={['SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING', 'STORE_MANAGER']}>
                  <OverviewPage mode="audit" />
                </RequireAuthRoute>
              }
            />
            <Route
              path="*"
              element={
                <RequireAuthRoute>
                  <OverviewPage mode="planned" />
                </RequireAuthRoute>
              }
            />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </QueryClientProvider>
  );
}
