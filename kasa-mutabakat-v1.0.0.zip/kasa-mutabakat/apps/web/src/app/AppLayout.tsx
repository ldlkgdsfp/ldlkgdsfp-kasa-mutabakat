import { useState, type ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { formatDateTR, type RoleCode } from '@kasa/shared';
import {
  BarChart3,
  Building2,
  FileCheck2,
  LayoutDashboard,
  LogOut,
  Menu,
  ReceiptText,
  Settings,
  ShieldAlert,
  Store,
  Users,
  Wallet,
  X,
} from 'lucide-react';
import { useAuth } from '../features/auth/AuthContext';

interface NavItem {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  roles: RoleCode[];
  stageTag?: string;
}

const NAV_ITEMS: NavItem[] = [
  {
    to: '/',
    label: 'Genel Bakış',
    icon: LayoutDashboard,
    roles: ['SYSTEM_ADMIN', 'STORE_MANAGER', 'CASHIER', 'CENTRAL_ACCOUNTING'],
  },
  {
    to: '/kasa',
    label: 'Günlük Kasa',
    icon: Wallet,
    roles: ['SYSTEM_ADMIN', 'STORE_MANAGER', 'CASHIER', 'CENTRAL_ACCOUNTING'],
  },
  {
    to: '/dekontlar',
    label: 'IBAN Dekontları',
    icon: ReceiptText,
    roles: ['SYSTEM_ADMIN', 'STORE_MANAGER', 'CASHIER', 'CENTRAL_ACCOUNTING'],
  },
  {
    to: '/merkez',
    label: 'Merkez Mutabakat',
    icon: FileCheck2,
    roles: ['SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING'],
  },
  {
    to: '/raporlar',
    label: 'Raporlar',
    icon: BarChart3,
    roles: ['SYSTEM_ADMIN', 'STORE_MANAGER', 'CASHIER', 'CENTRAL_ACCOUNTING'],
  },
  {
    to: '/magazalar',
    label: 'Mağazalar',
    icon: Store,
    roles: ['SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING', 'STORE_MANAGER'],
  },
  {
    to: '/personel',
    label: 'Personel ve Roller',
    icon: Users,
    roles: ['SYSTEM_ADMIN', 'STORE_MANAGER', 'CENTRAL_ACCOUNTING'],
  },
  {
    to: '/denetim',
    label: 'Denetim Kayıtları',
    icon: ShieldAlert,
    roles: ['SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING', 'STORE_MANAGER'],
  },
  {
    to: '/ayarlar',
    label: 'Sistem Ayarları',
    icon: Settings,
    roles: ['SYSTEM_ADMIN'],
  },
];

export function AppLayout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (!user) return null;

  const visibleItems = NAV_ITEMS.filter((item) => item.roles.includes(user.role));
  const todayLabel = formatDateTR(new Date());

  return (
    <div className="min-h-dvh flex bg-slate-50 text-slate-900">
      {/* Mobil arka plan katmanı */}
      {mobileMenuOpen ? (
        <div
          className="fixed inset-0 z-30 bg-slate-950/50 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
          aria-hidden="true"
        />
      ) : null}

      {/* Sol navigasyon menüsü */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 text-slate-200 flex flex-col transition-transform duration-200 lg:static lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800">
          <Link to="/" className="flex items-center gap-2.5 text-white">
            <div className="h-8 w-8 rounded-md bg-blue-600 flex items-center justify-center shrink-0">
              <Building2 className="h-4 w-4 text-white" aria-hidden="true" />
            </div>
            <div className="leading-tight">
              <span className="block text-sm font-semibold tracking-wide">KASA MUTABAKAT</span>
              <span className="block text-[11px] text-slate-400">Finans Kontrol</span>
            </div>
          </Link>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(false)}
            aria-label="Menüyü kapat"
            className="lg:hidden p-1.5 rounded-md text-slate-400 hover:text-white"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <nav aria-label="Ana menü" className="flex-1 overflow-y-auto px-3 py-4">
          <ul className="space-y-1">
            {visibleItems.map((item) => {
              const Icon = item.icon;
              const isCurrent =
                item.to === '/'
                  ? location.pathname === '/'
                  : location.pathname === item.to || location.pathname.startsWith(`${item.to}/`);
              return (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    onClick={() => setMobileMenuOpen(false)}
                    aria-current={isCurrent ? 'page' : undefined}
                    className="kasa-nav-link flex items-center justify-between gap-2.5 rounded-lg px-3 py-2.5 text-sm text-slate-300 hover:bg-slate-800/80 hover:text-white transition-colors"
                  >
                    <span className="flex items-center gap-2.5 min-w-0">
                      <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                      <span className="truncate">{item.label}</span>
                    </span>
                    {item.stageTag ? (
                      <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 shrink-0">
                        {item.stageTag}
                      </span>
                    ) : null}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className="rounded-lg bg-slate-800/70 p-3 text-xs">
            <p className="font-medium text-white truncate">{user.fullName}</p>
            <p className="text-slate-400 mt-0.5 truncate">{user.roleLabel}</p>
            {user.store ? (
              <p className="text-sky-300 mt-1 font-medium truncate">
                {user.store.name} ({user.store.code})
              </p>
            ) : null}
          </div>
          <button
            id="logout-button"
            type="button"
            onClick={() => void logout()}
            className="mt-3 w-full flex items-center justify-center gap-2 rounded-lg border border-slate-700 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Güvenli Çıkış</span>
          </button>
        </div>
      </aside>

      {/* Ana içerik alanı */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-20">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Ana menüyü aç"
              aria-expanded={mobileMenuOpen}
              className="lg:hidden p-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              <Menu className="h-5 w-5" aria-hidden="true" />
            </button>
            <div className="min-w-0">
              <p className="text-xs text-slate-500">Aktif Kapsam</p>
              <p className="text-sm font-semibold text-slate-900 truncate">
                {user.role === 'SYSTEM_ADMIN' || user.role === 'CENTRAL_ACCOUNTING'
                  ? 'Tüm Mağazalar ve Merkez Ofis'
                  : user.store
                    ? `${user.store.name} (${user.store.code})`
                    : 'Atanmamış'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="hidden sm:block text-right">
              <p className="text-xs text-slate-500">İş Günü</p>
              <p className="text-sm font-medium text-slate-800 tabular-nums">{todayLabel}</p>
            </div>
            <span className="inline-flex items-center rounded-full bg-slate-100 border border-slate-200 px-3 py-1 text-xs font-medium text-slate-700">
              {user.roleLabel}
            </span>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">{children}</main>
      </div>
    </div>
  );
}
