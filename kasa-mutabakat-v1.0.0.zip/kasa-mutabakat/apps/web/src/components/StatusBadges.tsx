import {
  CASH_SESSION_STATUS_LABELS_TR,
  formatCurrencyTRY,
  type CashDifferenceStatus,
  type CashSessionStatus,
} from '@kasa/shared';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Lock,
  MinusCircle,
  RotateCcw,
  Send,
  TrendingUp,
} from 'lucide-react';

export function SessionStatusBadge({ status }: { status: CashSessionStatus }) {
  const styles: Record<CashSessionStatus, { cls: string; Icon: typeof Clock }> = {
    OPEN: {
      cls: 'bg-sky-50 text-sky-800 border-sky-200',
      Icon: Clock,
    },
    CASHIER_SUBMITTED: {
      cls: 'bg-amber-50 text-amber-800 border-amber-200',
      Icon: Send,
    },
    STORE_MANAGER_APPROVED: {
      cls: 'bg-blue-50 text-blue-800 border-blue-200',
      Icon: CheckCircle2,
    },
    RETURNED_FOR_CORRECTION: {
      cls: 'bg-rose-50 text-rose-800 border-rose-200',
      Icon: RotateCcw,
    },
    CENTRAL_APPROVED: {
      cls: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      Icon: CheckCircle2,
    },
    LOCKED: {
      cls: 'bg-slate-100 text-slate-800 border-slate-300',
      Icon: Lock,
    },
  };

  const { cls, Icon } = styles[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium ${cls}`}
    >
      <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
      <span>{CASH_SESSION_STATUS_LABELS_TR[status]}</span>
    </span>
  );
}

export function CashDifferenceBadge({
  status,
  difference,
}: {
  status: CashDifferenceStatus;
  difference: string | null;
}) {
  if (status === 'PENDING' || difference === null) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-xs font-medium text-slate-600">
        <MinusCircle className="h-3.5 w-3.5" aria-hidden="true" />
        <span>Beyan Bekliyor</span>
      </span>
    );
  }

  if (status === 'SHORTAGE') {
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-rose-200 bg-rose-50 px-2.5 py-0.5 text-xs font-semibold text-rose-800 tabular-nums">
        <AlertTriangle className="h-3.5 w-3.5" aria-hidden="true" />
        <span>Açık: {formatCurrencyTRY(difference)}</span>
      </span>
    );
  }

  if (status === 'SURPLUS') {
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-amber-200 bg-amber-50 px-2.5 py-0.5 text-xs font-semibold text-amber-800 tabular-nums">
        <TrendingUp className="h-3.5 w-3.5" aria-hidden="true" />
        <span>Fazla: +{formatCurrencyTRY(difference)}</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 text-xs font-semibold text-emerald-800 tabular-nums">
      <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
      <span>Eşit (0,00 ₺)</span>
    </span>
  );
}

import { RECEIPT_STATUS_LABELS_TR, type ReceiptStatus } from '@kasa/shared';
import {
  BadgeCheck,
  CopyX,
  FileSearch,
  FileWarning,
  Landmark,
  ShieldAlert,
  Upload,
  XCircle,
} from 'lucide-react';

export function ReceiptStatusBadge({ status }: { status: ReceiptStatus }) {
  const styles: Record<ReceiptStatus, { cls: string; Icon: typeof Clock }> = {
    UPLOADED: { cls: 'bg-slate-100 text-slate-700 border-slate-200', Icon: Upload },
    OCR_PROCESSING: { cls: 'bg-sky-50 text-sky-800 border-sky-200', Icon: FileSearch },
    EXTRACTED: { cls: 'bg-indigo-50 text-indigo-800 border-indigo-200', Icon: FileSearch },
    MANUAL_REVIEW_REQUIRED: {
      cls: 'bg-amber-50 text-amber-900 border-amber-300',
      Icon: ShieldAlert,
    },
    PENDING_CENTRAL_APPROVAL: {
      cls: 'bg-blue-50 text-blue-800 border-blue-200',
      Icon: Send,
    },
    APPROVED: { cls: 'bg-emerald-50 text-emerald-800 border-emerald-200', Icon: BadgeCheck },
    REJECTED: { cls: 'bg-rose-50 text-rose-800 border-rose-200', Icon: XCircle },
    DUPLICATE: { cls: 'bg-rose-100 text-rose-900 border-rose-300', Icon: CopyX },
    FAILED_OCR: { cls: 'bg-orange-50 text-orange-900 border-orange-300', Icon: FileWarning },
  };

  const { cls, Icon } = styles[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium ${cls}`}
    >
      <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
      <span>{RECEIPT_STATUS_LABELS_TR[status]}</span>
    </span>
  );
}

export function BankVerifiedBadge({ verified }: { verified: boolean }) {
  if (verified) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 text-xs font-medium text-emerald-800">
        <Landmark className="h-3.5 w-3.5" aria-hidden="true" />
        <span>Banka Teyitli</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-xs font-medium text-slate-600">
      <Landmark className="h-3.5 w-3.5" aria-hidden="true" />
      <span>Banka Teyidi Yok</span>
    </span>
  );
}

import { RECONCILIATION_STATUS_LABELS_TR, type ReconciliationStatus } from '@kasa/shared';

export function ReconciliationStatusBadge({ status }: { status: ReconciliationStatus }) {
  const styles: Record<ReconciliationStatus, { cls: string; Icon: typeof Clock }> = {
    PENDING: { cls: 'bg-slate-100 text-slate-700 border-slate-200', Icon: Clock },
    IN_REVIEW: { cls: 'bg-blue-50 text-blue-800 border-blue-200', Icon: FileSearch },
    APPROVED: { cls: 'bg-emerald-50 text-emerald-800 border-emerald-200', Icon: Lock },
    RETURNED: { cls: 'bg-rose-50 text-rose-800 border-rose-200', Icon: RotateCcw },
    DISPUTED: { cls: 'bg-amber-50 text-amber-900 border-amber-300', Icon: AlertTriangle },
  };

  const { cls, Icon } = styles[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium ${cls}`}
    >
      <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
      <span>{RECONCILIATION_STATUS_LABELS_TR[status]}</span>
    </span>
  );
}
