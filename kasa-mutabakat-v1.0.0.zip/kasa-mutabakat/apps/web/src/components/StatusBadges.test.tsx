import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { CashDifferenceBadge, SessionStatusBadge } from './StatusBadges';

describe('StatusBadges', () => {
  it('renders clear Turkish labels for shortage, surplus, equal, and pending differences', () => {
    const { rerender } = render(<CashDifferenceBadge status="SHORTAGE" difference="-125.50" />);
    expect(screen.getByText('Açık: -125,50 ₺')).toBeInTheDocument();

    rerender(<CashDifferenceBadge status="SURPLUS" difference="40.00" />);
    expect(screen.getByText('Fazla: +40,00 ₺')).toBeInTheDocument();

    rerender(<CashDifferenceBadge status="EQUAL" difference="0.00" />);
    expect(screen.getByText('Eşit (0,00 ₺)')).toBeInTheDocument();

    rerender(<CashDifferenceBadge status="PENDING" difference={null} />);
    expect(screen.getByText('Beyan Bekliyor')).toBeInTheDocument();
  });

  it('renders Turkish session status badge', () => {
    render(<SessionStatusBadge status="STORE_MANAGER_APPROVED" />);
    expect(screen.getByText('Merkeze Gönderildi')).toBeInTheDocument();
  });
});
