import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { ModalDialog } from './ModalDialog';

describe('ModalDialog', () => {
  beforeEach(() => {
    // jsdom ortamında native dialog showModal / close davranışı
    HTMLDialogElement.prototype.showModal = vi.fn(function (this: HTMLDialogElement) {
      this.setAttribute('open', '');
    });
    HTMLDialogElement.prototype.close = vi.fn(function (this: HTMLDialogElement) {
      this.removeAttribute('open');
      this.dispatchEvent(new Event('close'));
    });
  });

  afterEach(() => {
    cleanup();
  });

  it('programatik open=false geçişinde onClose tetiklemez; yalnızca kullanıcı kapattığında tetikler', () => {
    const onClose = vi.fn();

    const { rerender } = render(
      <ModalDialog open={true} title="Test Modal" onClose={onClose}>
        <p>İçerik</p>
      </ModalDialog>,
    );

    // Programatik kapatma (ör. başka bir modala geçişte) onClose çağırmamalı
    rerender(
      <ModalDialog open={false} title="Test Modal" onClose={onClose}>
        <p>İçerik</p>
      </ModalDialog>,
    );
    expect(onClose).not.toHaveBeenCalled();

    // Tekrar aç ve kullanıcı X düğmesiyle kapatsın -> onClose çağrılmalı
    rerender(
      <ModalDialog open={true} title="Test Modal" onClose={onClose}>
        <p>İçerik</p>
      </ModalDialog>,
    );
    fireEvent.click(screen.getByRole('button', { name: 'Pencereyi kapat' }));
    expect(onClose).toHaveBeenCalledTimes(1);
  });
});
