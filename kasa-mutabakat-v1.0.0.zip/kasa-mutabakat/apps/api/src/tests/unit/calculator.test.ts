import { describe, expect, it } from 'vitest';
import {
  aggregateSessionTotals,
  calculateSessionTotals,
} from '../../modules/reconciliation/calculator.js';

describe('Decimal.js Finansal Hesaplama Motoru', () => {
  it('kayan noktalı sayı sapması olmadan kuruş kesinliğiyle beklenen nakit ve fark hesaplar', () => {
    const result = calculateSessionTotals({
      openingCash: '500.00',
      declaredCash: '600.30',
      transactions: [
        { paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '0.10', isVoided: false },
        { paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '0.20', isVoided: false },
        { paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '150.00', isVoided: false },
        { paymentMethodCode: 'CASH', transactionType: 'CASH_IN', amount: '25.00', isVoided: false },
        { paymentMethodCode: 'CASH', transactionType: 'REFUND', amount: '50.00', isVoided: false },
        { paymentMethodCode: 'CASH', transactionType: 'CASH_OUT', amount: '25.00', isVoided: false },
        // İptal edilmiş hareket hesaba GİRMEMELİDİR
        { paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '9999.99', isVoided: true },
      ],
      receipts: [],
    });

    // 500.00 + 150.30 + 25.00 - 50.00 - 25.00 = 600.30
    expect(result.cashSalesTotal).toBe('150.30');
    expect(result.expectedCash).toBe('600.30');
    expect(result.cashDifference).toBe('0.00');
    expect(result.cashDifferenceStatus).toBe('EQUAL');
    expect(result.cashShortage).toBe('0.00');
    expect(result.cashSurplus).toBe('0.00');
  });

  it('kredi kartı ve Havale/EFT tahsilatlarını beklenen nakit hesabına kesinlikle karıştırmaz', () => {
    const result = calculateSessionTotals({
      openingCash: '1000.00',
      declaredCash: '1450.00',
      transactions: [
        { paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '500.00', isVoided: false },
        { paymentMethodCode: 'CREDIT_CARD', transactionType: 'SALE', amount: '4200.75', isVoided: false },
        { paymentMethodCode: 'CREDIT_CARD', transactionType: 'REFUND', amount: '200.75', isVoided: false },
        // Manuel BANK_TRANSFER satış olsa bile dekontsuz sayılmaz
        { paymentMethodCode: 'BANK_TRANSFER', transactionType: 'SALE', amount: '999.00', isVoided: false },
      ],
      receipts: [
        // Yalnızca APPROVED + !isDuplicate dekont sayılır
        { verifiedAmount: '1250.50', status: 'APPROVED', isDuplicate: false, bankAccountVerified: true },
        { verifiedAmount: '300.00', status: 'APPROVED', isDuplicate: false, bankAccountVerified: false },
        // Aşağıdakiler ASLA sayılmamalı
        { verifiedAmount: '1250.50', status: 'APPROVED', isDuplicate: true, bankAccountVerified: true },
        { verifiedAmount: '500.00', status: 'PENDING_CENTRAL_APPROVAL', isDuplicate: false, bankAccountVerified: false },
        { verifiedAmount: '500.00', status: 'EXTRACTED', isDuplicate: false, bankAccountVerified: false },
        { verifiedAmount: '500.00', status: 'DUPLICATE', isDuplicate: true, bankAccountVerified: false },
        { verifiedAmount: '500.00', status: 'REJECTED', isDuplicate: false, bankAccountVerified: false },
      ],
    });

    // Beklenen nakit = 1000 + 500 = 1500 (kart ve havale dahil değil!)
    expect(result.expectedCash).toBe('1500.00');
    // Fark = 1450 - 1500 = -50.00 (Kasa Açığı)
    expect(result.cashDifference).toBe('-50.00');
    expect(result.cashDifferenceStatus).toBe('SHORTAGE');
    expect(result.cashShortage).toBe('50.00');
    expect(result.cashSurplus).toBe('0.00');

    expect(result.creditCardSalesTotal).toBe('4200.75');
    expect(result.cardRefundTotal).toBe('200.75');
    expect(result.bankTransferTotal).toBe('1550.50');
    expect(result.bankVerifiedTransferTotal).toBe('1250.50');
    // Net satış = (500 + 4200.75 + 1550.50) - 200.75 = 6050.50
    expect(result.netSalesTotal).toBe('6050.50');
  });

  it('requireBankVerification aktif olduğunda yalnızca banka hesabı teyitli onaylı dekontları toplar', () => {
    const result = calculateSessionTotals({
      openingCash: '0.00',
      declaredCash: '10.00',
      transactions: [],
      requireBankVerification: true,
      receipts: [
        { verifiedAmount: '1000.00', status: 'APPROVED', isDuplicate: false, bankAccountVerified: true },
        { verifiedAmount: '750.00', status: 'APPROVED', isDuplicate: false, bankAccountVerified: false },
      ],
    });

    expect(result.bankTransferTotal).toBe('1000.00');
    expect(result.bankVerifiedTransferTotal).toBe('1000.00');
    expect(result.cashDifference).toBe('10.00');
    expect(result.cashDifferenceStatus).toBe('SURPLUS');
    expect(result.cashSurplus).toBe('10.00');
  });

  it('birden fazla kasiyer oturumunu mağaza toplamında kesin olarak birleştirir', () => {
    const s1 = calculateSessionTotals({
      openingCash: '500.00',
      declaredCash: '1480.00',
      transactions: [
        { paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '1000.00', isVoided: false },
        { paymentMethodCode: 'CREDIT_CARD', transactionType: 'SALE', amount: '500.00', isVoided: false },
      ],
      receipts: [],
    });
    const s2 = calculateSessionTotals({
      openingCash: '300.00',
      declaredCash: '835.50',
      transactions: [
        { paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '500.00', isVoided: false },
      ],
      receipts: [],
    });

    const agg = aggregateSessionTotals([s1, s2]);
    expect(agg.sessionCount).toBe(2);
    expect(agg.submittedCount).toBe(2);
    expect(agg.cashSalesTotal).toBe('1500.00');
    expect(agg.creditCardSalesTotal).toBe('500.00');
    expect(agg.expectedCashTotal).toBe('2300.00');
    expect(agg.declaredCashTotal).toBe('2315.50');
    expect(agg.totalShortage).toBe('20.00');
    expect(agg.totalSurplus).toBe('35.50');
    expect(agg.netCashVariance).toBe('15.50');
  });
});
