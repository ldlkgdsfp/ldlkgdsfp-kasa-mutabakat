import path from 'node:path';
import { describe, expect, it } from 'vitest';
import {
  computeHammingDistance,
  detectMagicFileType,
  resolveStoredReceiptPath,
  sanitizeOriginalFilename,
  verifyUploadedReceiptFile,
} from '../../modules/receipts/file-security.js';
import { ValidationError } from '../../utils/errors.js';

describe('Dekont Dosya Güvenliği (Magic Bytes, Path Traversal, Sanitization)', () => {
  it('gerçek JPG, PNG ve PDF imzalarını tanır; sahte veya zararlı içerikleri reddeder', () => {
    expect(detectMagicFileType(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0]))?.mimeType).toBe(
      'image/jpeg',
    );
    expect(
      detectMagicFileType(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))?.mimeType,
    ).toBe('image/png');
    expect(detectMagicFileType(Buffer.from('%PDF-1.7\n...'))?.mimeType).toBe('application/pdf');

    // Zararlı içerikler
    expect(detectMagicFileType(Buffer.from('<svg onload="alert(1)"></svg>'))).toBeNull();
    expect(detectMagicFileType(Buffer.from('<html><script>alert(1)</script></html>'))).toBeNull();
    expect(detectMagicFileType(Buffer.from('MZ\x90\x00\x03\x00\x00\x00'))).toBeNull();
    expect(detectMagicFileType(Buffer.from('kisa'))).toBeNull();
  });

  it('bozuk görsel, boş dosya, boyut aşımı ve uzantı-içerik uyumsuzluğunu reddeder', async () => {
    await expect(verifyUploadedReceiptFile(Buffer.alloc(0), 'bos.pdf', 10)).rejects.toThrow(
      ValidationError,
    );

    const oversized = Buffer.alloc(2 * 1024 * 1024 + 10, 0x20);
    await expect(verifyUploadedReceiptFile(oversized, 'buyuk.pdf', 2)).rejects.toThrow(
      ValidationError,
    );

    // İzin verilmeyen uzantı
    await expect(
      verifyUploadedReceiptFile(Buffer.from('%PDF-1.4\n123456'), 'script.svg', 10),
    ).rejects.toThrow(ValidationError);

    // Uzantı .png ama içerik %PDF-
    await expect(
      verifyUploadedReceiptFile(Buffer.from('%PDF-1.4\n123456'), 'sahte.png', 10),
    ).rejects.toThrow(ValidationError);

    // Geçerli PNG imzası ama bozuk gövde (sharp doğrulamasından geçemez)
    const corruptPng = Buffer.from([
      0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x01, 0x02, 0x03,
    ]);
    await expect(verifyUploadedReceiptFile(corruptPng, 'bozuk.png', 10)).rejects.toThrow(
      ValidationError,
    );
  });

  it('path traversal, mutlak yol, boş yol ve null byte saldırılarını engeller', () => {
    const valid = resolveStoredReceiptPath('2026/11/abc-123.pdf');
    expect(valid.endsWith(path.join('2026', '11', 'abc-123.pdf'))).toBe(true);

    const dangerousPaths = [
      '',
      '.',
      '..',
      '../.env',
      '2026/../../.env',
      '2026/11/../../../etc/passwd',
      '/etc/passwd',
      '2026/11/test.pdf\0.png',
    ];
    for (const bad of dangerousPaths) {
      expect(() => resolveStoredReceiptPath(bad)).toThrow(ValidationError);
    }
  });

  it('dosya adlarını güvenli biçimde temizler ve dHash mesafesini doğru hesaplar', () => {
    expect(sanitizeOriginalFilename('../../etc/passwd')).toBe('passwd');
    expect(sanitizeOriginalFilename('dekont\r\nSet-Cookie: x=1.pdf')).toBe(
      'dekontSet-Cookie: x=1.pdf',
    );
    expect(sanitizeOriginalFilename('   ')).toBe('dekont');
    expect(sanitizeOriginalFilename('a'.repeat(400)).length).toBe(255);

    expect(computeHammingDistance('0000000000000000', '0000000000000000')).toBe(0);
    expect(computeHammingDistance('0000000000000000', '000000000000000f')).toBe(4);
    expect(computeHammingDistance('abc', 'abcd')).toBe(Number.POSITIVE_INFINITY);
  });
});
