import ExcelJS from 'exceljs';
import type { ReportPayloadDTO } from '@kasa/shared';
import { describe, expect, it } from 'vitest';
import {
  buildReportCsv,
  buildReportXlsx,
  sanitizeSpreadsheetText,
} from '../../modules/reports/export.js';

const sampleReport: ReportPayloadDTO = {
  reportType: 'daily-store',
  title: 'Günlük Mağaza Raporu',
  generatedAt: '2026-11-24T12:00:00.000Z',
  filters: {
    startDate: '2026-11-01',
    endDate: '2026-11-24',
    storeId: null,
    cashierId: null,
  },
  columns: [
    { key: 'businessDate', label: 'Tarih', type: 'date' },
    { key: 'storeName', label: 'Mağaza', type: 'text' },
    { key: 'notes', label: 'Açıklama', type: 'text' },
    { key: 'netSales', label: 'Net Satış', type: 'currency' },
    { key: 'variance', label: 'Kasa Farkı', type: 'currency' },
  ],
  rows: [
    {
      businessDate: '2026-11-24',
      storeName: 'Şişli Şubesi (ğüşiöç)',
      notes: '=HYPERLINK("http://evil.example","Tıkla")',
      netSales: '2450.75',
      variance: '-15.50',
    },
    {
      businessDate: '2026-11-23',
      storeName: 'Kadıköy Şubesi',
      notes: '+CMD|calc',
      netSales: '1800.00',
      variance: '0.00',
    },
  ],
  summary: { netSalesTotal: '4250.75' },
  chartData: [],
};

describe('Rapor Excel (.xlsx) ve CSV (.csv) Dışa Aktarma Güvenliği', () => {
  it('OWASP formül enjeksiyonu tetikleyicilerini metin hücrelerinde nötralize eder', () => {
    expect(sanitizeSpreadsheetText('=SUM(A1:A5)')).toBe("'=SUM(A1:A5)");
    expect(sanitizeSpreadsheetText('+1+1')).toBe("'+1+1");
    expect(sanitizeSpreadsheetText('-2+3')).toBe("'-2+3");
    expect(sanitizeSpreadsheetText('@SUM(1,2)')).toBe("'@SUM(1,2)");
    expect(sanitizeSpreadsheetText('Normal Mağaza Adı')).toBe('Normal Mağaza Adı');
  });

  it('UTF-8 BOM, Türkçe karakter koruması ve formül sanitizasyonu ile CSV üretir', () => {
    const csvBuf = buildReportCsv(sampleReport);
    // UTF-8 BOM (EF BB BF)
    expect(csvBuf[0]).toBe(0xef);
    expect(csvBuf[1]).toBe(0xbb);
    expect(csvBuf[2]).toBe(0xbf);

    const text = csvBuf.toString('utf8');
    expect(text).toContain('Şişli Şubesi (ğüşiöç)');
    expect(text).toContain('24.11.2026');
    expect(text).toContain('"\'=HYPERLINK(""http://evil.example"",""Tıkla"")"');
    expect(text).toContain("'+CMD|calc");
    expect(text).toContain('-15.50');
  });

  it('exceljs ile geçerli ve okunabilir .xlsx dosyası üretir ve formülleri nötralize eder', async () => {
    const xlsxBuf = await buildReportXlsx(sampleReport);
    // XLSX (ZIP) magic bytes: PK\x03\x04
    expect(xlsxBuf[0]).toBe(0x50);
    expect(xlsxBuf[1]).toBe(0x4b);

    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(xlsxBuf as unknown as ArrayBuffer);
    const sheet = wb.worksheets[0]!;
    expect(sheet.name).toBe('Günlük Mağaza Raporu');
    expect(sheet.getRow(5).getCell(2).value).toBe('Şişli Şubesi (ğüşiöç)');
    expect(sheet.getRow(5).getCell(3).value).toBe('\'=HYPERLINK("http://evil.example","Tıkla")');
    expect(sheet.getRow(5).getCell(4).value).toBe(2450.75);
    expect(sheet.getRow(5).getCell(5).value).toBe(-15.5);
  });
});
