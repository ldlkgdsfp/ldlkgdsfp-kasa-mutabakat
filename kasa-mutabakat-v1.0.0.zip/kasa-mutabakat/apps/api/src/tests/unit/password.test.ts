import { describe, expect, it } from 'vitest';
import {
  generateSecureToken,
  hashPassword,
  sha256Hex,
  timingSafeStringEqual,
  verifyPassword,
} from '../../utils/password.js';

describe('password & token security utilities', () => {
  it('hashes password with unique random salt and verifies accurately', async () => {
    const hash1 = await hashPassword('GucluParola2026!');
    const hash2 = await hashPassword('GucluParola2026!');

    expect(hash1).not.toBe(hash2);
    expect(hash1.startsWith('scrypt$')).toBe(true);
    expect(await verifyPassword('GucluParola2026!', hash1)).toBe(true);
    expect(await verifyPassword('GucluParola2026!', hash2)).toBe(true);
    expect(await verifyPassword('YanlisParola!', hash1)).toBe(false);
    expect(await verifyPassword('GucluParola2026!', 'invalid-hash-format')).toBe(false);
  });

  it('generates cryptographically random tokens and compares strings safely', () => {
    const t1 = generateSecureToken(32);
    const t2 = generateSecureToken(32);

    expect(t1).toHaveLength(64);
    expect(t1).not.toBe(t2);
    expect(sha256Hex(t1)).toHaveLength(64);
    expect(timingSafeStringEqual(t1, t1)).toBe(true);
    expect(timingSafeStringEqual(t1, t2)).toBe(false);
    expect(timingSafeStringEqual('short', 'much-longer')).toBe(false);
  });
});
