import { describe, expect, it } from 'vitest';
import {
  computeHammingDistance,
  detectMagicFileType,
} from '../../modules/receipts/file-security.js';
import {
  parseTurkishBankReceipt,
  parseTurkishMoney,
  validateTurkishIban,
} from '../../modules/receipts/parser.js';

describe('Türk Banka Dekont Ayrıştırıcısı ve Dosya Güvenliği', () => {
  it('Türkçe ve uluslararası para formatlarını Decimal kesinliğiyle ayrıştırır', () => {
    expect(parseTurkishMoney('1.250,50 TL')).toBe('1250.50');
    expect(parseTurkishMoney('₺ 45.900,00')).toBe('45900.00');
    expect(parseTurkishMoney('1250.75 TRY')).toBe('1250.75');
    expect(parseTurkishMoney('850,00')).toBe('850.00');
    expect(parseTurkishMoney('0,00 TL')).toBeNull();
  });

  it('Türk IBAN MOD-97 sağlama toplamını doğru kontrol eder', () => {
    expect(validateTurkishIban('TR33 0006 1005 1978 6457 8413 26')).toBe(true);
    expect(validateTurkishIban('TR330006100519786457841327')).toBe(false);
    expect(validateTurkishIban('DE89370400440532013000')).toBe(false);
  });

  it('hesap bakiyesini ve işlem masrafını dışlayıp doğru transfer tutarını çıkarır', () => {
    const sampleText = `
      T.C. ZİRAAT BANKASI A.Ş.
      FAST PARA TRANSFERİ DEKONTU
      İşlem Tarihi: 24.11.2026
      İşlem Saati: 14:25
      Gönderen: AHMET YILMAZ
      Alıcı: KASA MUTABAKAT TİC. LTD. ŞTİ.
      Alıcı Banka: Garanti BBVA
      Alıcı IBAN: TR33 0006 1005 1978 6457 8413 26
      FAST Sorgu No: FST2026112400891
      Transfer Tutarı: 2.350,75 TL
      İşlem Masrafı: 4,49 TL
      Kullanılabilir Bakiye: 85.400,00 TL
      İşlem Sonrası Bakiye: 83.044,76 TL
      Açıklama: Mağaza 1 sipariş ödemesi
    `;

    const parsed = parseTurkishBankReceipt(sampleText, 95, 80);

    expect(parsed.extractedAmount).toBe('2350.75');
    expect(parsed.excludedBalanceAmounts.map((x) => x.amount)).toEqual(['85400.00', '83044.76']);
    expect(parsed.transactionDate).toBe('2026-11-24');
    expect(parsed.transactionTime).toBe('14:25');
    expect(parsed.senderName).toBe('AHMET YILMAZ');
    expect(parsed.receiverName).toBe('KASA MUTABAKAT TİC. LTD. ŞTİ.');
    expect(parsed.senderBank).toBe('T.C. Ziraat Bankası');
    expect(parsed.receiverBank).toBe('Garanti BBVA');
    expect(parsed.iban).toBe('TR330006100519786457841326');
    expect(parsed.referenceNumber).toBe('FST2026112400891');
    expect(parsed.description).toBe('Mağaza 1 sipariş ödemesi');
    expect(parsed.requiresManualReview).toBe(false);
    expect(Number(parsed.confidenceScore)).toBeGreaterThanOrEqual(85);
  });

  it('yalnızca hesap bakiyesi içeren dekontta bakiyeyi transfer tutarı olarak ASLA kabul etmez', () => {
    const balanceOnlyText = `
      AKBANK HESAP ÖZETİ
      İşlem Tarihi: 24.11.2026
      Güncel Bakiye: 42.750,00 TL
      Son Bakiye: 42.750,00 TL
    `;

    const parsed = parseTurkishBankReceipt(balanceOnlyText, 95, 80);
    expect(parsed.extractedAmount).toBeNull();
    expect(parsed.excludedBalanceAmounts).toHaveLength(2);
    expect(parsed.requiresManualReview).toBe(true);
    expect(parsed.warnings.some((w) => w.includes('hesap bakiyesi'))).toBe(true);
  });

  it('belirsiz çoklu tutar içeren dekontu zorunlu manuel doğrulamaya yönlendirir', () => {
    const ambiguousText = `
      İşlem Tarihi: 24.11.2026
      Tutar: 1.500,00 TL
      Tutar: 2.750,00 TL
      Referans No: REF991122
    `;

    const parsed = parseTurkishBankReceipt(ambiguousText, 92, 80);
    expect(parsed.requiresManualReview).toBe(true);
    expect(parsed.warnings.some((w) => w.includes('birden fazla'))).toBe(true);
  });

  it('magic-bytes kontrolü zararlı/sahte dosyaları reddeder, gerçek JPG/PNG/PDF kabul eder', () => {
    expect(detectMagicFileType(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0]))?.mimeType).toBe(
      'image/jpeg',
    );
    expect(
      detectMagicFileType(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))?.mimeType,
    ).toBe('image/png');
    expect(detectMagicFileType(Buffer.from('%PDF-1.4\n...'))?.mimeType).toBe('application/pdf');
    expect(detectMagicFileType(Buffer.from('<script>alert(1)</script>'))).toBeNull();
    expect(detectMagicFileType(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>'))).toBeNull();
    expect(computeHammingDistance('0000000000000000', '000000000000000f')).toBe(4);
  });
});
