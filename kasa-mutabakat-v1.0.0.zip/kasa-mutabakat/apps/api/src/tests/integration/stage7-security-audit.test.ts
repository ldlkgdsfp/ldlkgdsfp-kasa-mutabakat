import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '../../../../../.env') });

if (process.env.TEST_DATABASE_URL) {
  process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
}
process.env.NODE_ENV = 'test';
process.env.UPLOAD_STORAGE_DIR = './storage/receipts-test';

import request from 'supertest';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../app.js';
import { prisma } from '../../config/prisma.js';
import { hashPassword } from '../../utils/password.js';

const app = createApp();
const TEST_PASSWORD = 'Stage7AuditPassword2026!';

function buildMinimalPdf(lines: string[]): Buffer {
  let y = 760;
  const textCommands = lines
    .map((line) => {
      const safe = line.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
      const cmd = `BT /F1 12 Tf 50 ${y} Td (${safe}) Tj ET`;
      y -= 20;
      return cmd;
    })
    .join('\n');

  const objects = [
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj',
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj',
    '3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj',
    `4 0 obj << /Length ${Buffer.byteLength(textCommands, 'utf8')} >> stream\n${textCommands}\nendstream endobj`,
    '5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj',
  ];

  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [0];
  for (const obj of objects) {
    offsets.push(Buffer.byteLength(pdf, 'utf8'));
    pdf += `${obj}\n`;
  }
  const xrefPos = Buffer.byteLength(pdf, 'utf8');
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i < offsets.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`;
  return Buffer.from(pdf, 'utf8');
}

describe('Aşama 7 – Kapsamlı Güvenlik Denetimi ve Negatif Test Paketi', () => {
  let hqId: string;
  let mag1Id: string;
  let mag2Id: string;
  let cashierRoleId: string;

  beforeAll(async () => {
    const roles = [
      { code: 'SYSTEM_ADMIN' as const, name: 'Sistem Yöneticisi' },
      { code: 'STORE_MANAGER' as const, name: 'Mağaza Yöneticisi' },
      { code: 'CASHIER' as const, name: 'Kasiyer' },
      { code: 'CENTRAL_ACCOUNTING' as const, name: 'Merkez Muhasebe / Kontrol' },
    ];
    for (const r of roles) {
      await prisma.role.upsert({ where: { code: r.code }, update: {}, create: r });
    }

    const methods = [
      { code: 'CASH' as const, name: 'Nakit', sortOrder: 1 },
      { code: 'CREDIT_CARD' as const, name: 'Kredi Kartı', sortOrder: 2 },
      { code: 'BANK_TRANSFER' as const, name: 'Havale / EFT', sortOrder: 3 },
    ];
    for (const m of methods) {
      await prisma.paymentMethod.upsert({ where: { code: m.code }, update: {}, create: m });
    }

    const stores = [
      { code: 'MERKEZ', name: 'Merkez Ofis', type: 'HEADQUARTERS' as const },
      { code: 'MAG-01', name: 'Mağaza 1', type: 'STORE' as const },
      { code: 'MAG-02', name: 'Mağaza 2', type: 'STORE' as const },
    ];
    for (const s of stores) {
      await prisma.store.upsert({ where: { code: s.code }, update: {}, create: s });
    }

    await prisma.systemSetting.upsert({
      where: { key: 'require_bank_verification_for_reconciliation' },
      update: { valueJson: false },
      create: {
        key: 'require_bank_verification_for_reconciliation',
        valueJson: false,
        category: 'reconciliation',
        description: 'Banka teyidi zorunluluğu',
      },
    });

    const roleMap = new Map((await prisma.role.findMany()).map((r) => [r.code, r.id]));
    const storeMap = new Map((await prisma.store.findMany()).map((s) => [s.code, s.id]));
    hqId = storeMap.get('MERKEZ')!;
    mag1Id = storeMap.get('MAG-01')!;
    mag2Id = storeMap.get('MAG-02')!;
    cashierRoleId = roleMap.get('CASHIER')!;

    const passwordHash = await hashPassword(TEST_PASSWORD);
    const seedUsers = [
      {
        username: 's7.admin',
        email: 's7.admin@local.test',
        fullName: 'S7 Admin',
        roleId: roleMap.get('SYSTEM_ADMIN')!,
        storeId: hqId,
      },
      {
        username: 's7.merkez',
        email: 's7.merkez@local.test',
        fullName: 'S7 Merkez Muhasebe',
        roleId: roleMap.get('CENTRAL_ACCOUNTING')!,
        storeId: hqId,
      },
      {
        username: 's7.m1.mgr',
        email: 's7.m1.mgr@local.test',
        fullName: 'S7 Mağaza 1 Yönetici',
        roleId: roleMap.get('STORE_MANAGER')!,
        storeId: mag1Id,
      },
      {
        username: 's7.m1.cashier1',
        email: 's7.m1.cashier1@local.test',
        fullName: 'S7 Mağaza 1 Kasiyer 1',
        roleId: cashierRoleId,
        storeId: mag1Id,
      },
      {
        username: 's7.m1.cashier2',
        email: 's7.m1.cashier2@local.test',
        fullName: 'S7 Mağaza 1 Kasiyer 2',
        roleId: cashierRoleId,
        storeId: mag1Id,
      },
      {
        username: 's7.m2.mgr',
        email: 's7.m2.mgr@local.test',
        fullName: 'S7 Mağaza 2 Yönetici',
        roleId: roleMap.get('STORE_MANAGER')!,
        storeId: mag2Id,
      },
      {
        username: 's7.m2.cashier',
        email: 's7.m2.cashier@local.test',
        fullName: 'S7 Mağaza 2 Kasiyer',
        roleId: cashierRoleId,
        storeId: mag2Id,
      },
    ];

    for (const u of seedUsers) {
      await prisma.user.upsert({
        where: { username: u.username },
        update: { passwordHash, isActive: true, failedLoginAttempts: 0, lockedUntil: null },
        create: { ...u, passwordHash },
      });
    }
  });

  beforeEach(async () => {
    await prisma.financialAdjustment.deleteMany({});
    await prisma.reconciliationItem.deleteMany({});
    await prisma.centralReconciliation.deleteMany({});
    await prisma.receiptVerification.deleteMany({});
    await prisma.receiptOcrResult.deleteMany({});
    await prisma.cashTransaction.deleteMany({});
    await prisma.transferReceipt.deleteMany({});
    await prisma.cashSession.deleteMany({});
    await prisma.userSession.deleteMany({});
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  async function loginAs(username: string) {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: username, password: TEST_PASSWORD });
    expect(res.status).toBe(200);
    const setCookieHeader = res.headers['set-cookie'];
    const cookie = Array.isArray(setCookieHeader) ? setCookieHeader[0]! : setCookieHeader!;
    return { cookie, csrf: res.body.csrfToken as string, user: res.body.user };
  }

  it('HTTP güvenlik başlıklarını uygular ve kimlik doğrulamasız tüm uç noktaları 401 ile engeller', async () => {
    const health = await request(app).get('/api/v1/health').expect(200);
    expect(health.headers['x-powered-by']).toBeUndefined();
    expect(health.headers['x-content-type-options']).toBe('nosniff');
    expect(health.headers['cross-origin-resource-policy']).toBe('same-site');
    expect(health.headers['x-request-id']).toBeTruthy();

    const dummyUuid = '11111111-1111-4111-8111-111111111111';
    const unauthEndpoints: Array<{ method: 'get' | 'post' | 'patch'; path: string }> = [
      { method: 'get', path: '/api/v1/auth/me' },
      { method: 'post', path: '/api/v1/auth/logout' },
      { method: 'post', path: '/api/v1/auth/logout-all' },
      { method: 'get', path: '/api/v1/stores' },
      { method: 'post', path: '/api/v1/stores' },
      { method: 'get', path: `/api/v1/stores/${dummyUuid}` },
      { method: 'patch', path: `/api/v1/stores/${dummyUuid}` },
      { method: 'get', path: '/api/v1/users' },
      { method: 'get', path: '/api/v1/users/roles' },
      { method: 'post', path: '/api/v1/users' },
      { method: 'patch', path: `/api/v1/users/${dummyUuid}` },
      { method: 'get', path: '/api/v1/settings' },
      { method: 'patch', path: '/api/v1/settings/require_bank_verification_for_reconciliation' },
      { method: 'get', path: '/api/v1/cash-sessions' },
      { method: 'post', path: '/api/v1/cash-sessions' },
      { method: 'get', path: `/api/v1/cash-sessions/${dummyUuid}` },
      { method: 'post', path: `/api/v1/cash-sessions/${dummyUuid}/transactions` },
      { method: 'post', path: `/api/v1/cash-sessions/${dummyUuid}/submit` },
      { method: 'post', path: `/api/v1/cash-sessions/${dummyUuid}/store-approve` },
      { method: 'post', path: `/api/v1/cash-sessions/${dummyUuid}/return` },
      { method: 'get', path: '/api/v1/receipts' },
      { method: 'post', path: '/api/v1/receipts/upload' },
      { method: 'get', path: `/api/v1/receipts/${dummyUuid}` },
      { method: 'get', path: `/api/v1/receipts/${dummyUuid}/file` },
      { method: 'post', path: `/api/v1/receipts/${dummyUuid}/confirm` },
      { method: 'post', path: `/api/v1/receipts/${dummyUuid}/central-review` },
      { method: 'post', path: `/api/v1/receipts/${dummyUuid}/bank-verify` },
      { method: 'post', path: `/api/v1/receipts/${dummyUuid}/reprocess-ocr` },
      { method: 'get', path: '/api/v1/reconciliations/dashboard' },
      { method: 'get', path: '/api/v1/reconciliations' },
      { method: 'get', path: `/api/v1/reconciliations/${dummyUuid}` },
      { method: 'post', path: '/api/v1/reconciliations/verify' },
      { method: 'post', path: `/api/v1/reconciliations/${dummyUuid}/adjustments` },
      { method: 'get', path: '/api/v1/reports/daily-store' },
      { method: 'get', path: '/api/v1/reports/daily-store/export?format=xlsx' },
      { method: 'get', path: '/api/v1/audit-logs' },
    ];

    for (const ep of unauthEndpoints) {
      const res = await request(app)[ep.method](ep.path);
      expect(res.status, `${ep.method.toUpperCase()} ${ep.path} 401 dönmeli`).toBe(401);
    }
  });

  it('tüm durum değiştiren uç noktalarda CSRF korumasını zorunlu kılar (403)', async () => {
    const admin = await loginAs('s7.admin');
    const dummyUuid = '11111111-1111-4111-8111-111111111111';

    const mutatingEndpoints: Array<{ method: 'post' | 'patch'; path: string }> = [
      { method: 'post', path: '/api/v1/auth/logout' },
      { method: 'post', path: '/api/v1/auth/logout-all' },
      { method: 'post', path: '/api/v1/stores' },
      { method: 'patch', path: `/api/v1/stores/${mag1Id}` },
      { method: 'post', path: '/api/v1/users' },
      { method: 'patch', path: `/api/v1/users/${admin.user.id}` },
      { method: 'patch', path: '/api/v1/settings/require_bank_verification_for_reconciliation' },
      { method: 'post', path: '/api/v1/cash-sessions' },
      { method: 'post', path: `/api/v1/cash-sessions/${dummyUuid}/transactions` },
      { method: 'post', path: `/api/v1/cash-sessions/${dummyUuid}/submit` },
      { method: 'post', path: `/api/v1/cash-sessions/${dummyUuid}/store-approve` },
      { method: 'post', path: `/api/v1/cash-sessions/${dummyUuid}/return` },
      { method: 'post', path: '/api/v1/receipts/upload' },
      { method: 'post', path: `/api/v1/receipts/${dummyUuid}/confirm` },
      { method: 'post', path: `/api/v1/receipts/${dummyUuid}/central-review` },
      { method: 'post', path: `/api/v1/receipts/${dummyUuid}/bank-verify` },
      { method: 'post', path: `/api/v1/receipts/${dummyUuid}/reprocess-ocr` },
      { method: 'post', path: '/api/v1/reconciliations/verify' },
      { method: 'post', path: `/api/v1/reconciliations/${dummyUuid}/adjustments` },
    ];

    for (const ep of mutatingEndpoints) {
      // CSRF başlığı eksik
      const noToken = await request(app)[ep.method](ep.path).set('Cookie', admin.cookie).send({});
      expect(noToken.status, `CSRF eksik: ${ep.method.toUpperCase()} ${ep.path}`).toBe(403);

      // Geçersiz CSRF başlığı
      const badToken = await request(app)[ep.method](ep.path)
        .set('Cookie', admin.cookie)
        .set('X-CSRF-Token', 'gecersiz-csrf-token')
        .send({});
      expect(badToken.status, `CSRF yanlış: ${ep.method.toUpperCase()} ${ep.path}`).toBe(403);
    }
  });

  it('rol bazlı yetkilendirme (RBAC) matrisini tüm rollerde kesin uygular', async () => {
    const central = await loginAs('s7.merkez');
    const mgr1 = await loginAs('s7.m1.mgr');
    const cashier1 = await loginAs('s7.m1.cashier1');
    const dummyUuid = '11111111-1111-4111-8111-111111111111';

    // CASHIER kısıtlamaları
    await request(app)
      .post('/api/v1/stores')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ code: 'MAG-99', name: 'Yetkisiz', type: 'STORE' })
      .expect(403);
    await request(app)
      .post('/api/v1/users')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({})
      .expect(403);
    await request(app).get('/api/v1/settings').set('Cookie', cashier1.cookie).expect(403);
    await request(app).get('/api/v1/audit-logs').set('Cookie', cashier1.cookie).expect(403);
    await request(app)
      .get('/api/v1/reconciliations/dashboard')
      .set('Cookie', cashier1.cookie)
      .expect(403);
    await request(app).get('/api/v1/reconciliations').set('Cookie', cashier1.cookie).expect(403);
    await request(app)
      .post(`/api/v1/receipts/${dummyUuid}/central-review`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ action: 'APPROVE' })
      .expect(403);
    await request(app)
      .post(`/api/v1/receipts/${dummyUuid}/bank-verify`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ bankAccountVerified: true })
      .expect(403);

    // STORE_MANAGER kısıtlamaları
    await request(app)
      .patch(`/api/v1/stores/${mag1Id}`)
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({ name: 'Yetkisiz İsim' })
      .expect(403);
    await request(app)
      .post('/api/v1/users')
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({})
      .expect(403);
    await request(app).get('/api/v1/settings').set('Cookie', mgr1.cookie).expect(403);
    await request(app)
      .get('/api/v1/reconciliations/dashboard')
      .set('Cookie', mgr1.cookie)
      .expect(403);
    await request(app)
      .post('/api/v1/reconciliations/verify')
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({})
      .expect(403);
    await request(app)
      .post(`/api/v1/reconciliations/${dummyUuid}/adjustments`)
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({})
      .expect(403);
    await request(app)
      .post(`/api/v1/receipts/${dummyUuid}/central-review`)
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({ action: 'APPROVE' })
      .expect(403);

    // CENTRAL_ACCOUNTING kısıtlamaları (sistem yönetimi sadece SYSTEM_ADMIN)
    await request(app)
      .post('/api/v1/stores')
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({ code: 'MAG-98', name: 'Yetkisiz', type: 'STORE' })
      .expect(403);
    await request(app)
      .post('/api/v1/users')
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({
        username: 'yetkisiz',
        email: 'yetkisiz@local.test',
        fullName: 'Yetkisiz Kullanıcı',
        password: 'Password2026!',
        roleCode: 'CASHIER',
        storeId: mag1Id,
      })
      .expect(403);
    await request(app)
      .patch('/api/v1/settings/require_bank_verification_for_reconciliation')
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({ valueJson: true })
      .expect(403);
  });

  it('çapraz mağaza IDOR ve kasiyerler arası yetkisiz müdahale denemelerini 403 ile engeller', async () => {
    const cashier1 = await loginAs('s7.m1.cashier1');
    const cashier1B = await loginAs('s7.m1.cashier2');
    const mgr1 = await loginAs('s7.m1.mgr');
    const cashier2 = await loginAs('s7.m2.cashier');
    const mgr2 = await loginAs('s7.m2.mgr');
    const central = await loginAs('s7.merkez');

    // Mağaza 1 Kasiyer 1 oturum açar, satış girer, PDF dekont yükler
    const s1 = await request(app)
      .post('/api/v1/cash-sessions')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ businessDate: '2026-11-24', openingCash: '400.00' })
      .expect(201);
    const s1Id = s1.body.id as string;

    const txRes = await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/transactions`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({
        paymentMethodCode: 'CASH',
        transactionType: 'SALE',
        amount: '300.00',
        description: 'Normal satış',
      })
      .expect(201);
    const txId = txRes.body.transaction.id as string;

    const pdf = buildMinimalPdf([
      'GARANTI BBVA',
      'Islem Tarihi: 24.11.2026',
      'Islem Saati: 12:15',
      'Gonderen: AHMET DEMIR',
      'Referans No: GRT202611240701',
      'Transfer Tutari: 750,00 TL',
    ]);
    const recRes = await request(app)
      .post('/api/v1/receipts/upload')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .field('cashSessionId', s1Id)
      .attach('file', pdf, { filename: 'garanti-s7.pdf', contentType: 'application/pdf' })
      .expect(201);
    const recId = recRes.body.id as string;

    // 1. Mağaza 2 yöneticisi ve kasiyeri Mağaza 1'in oturum, hareket, dekont, dosya, rapor ve loglarına erişemez
    await request(app).get(`/api/v1/cash-sessions/${s1Id}`).set('Cookie', mgr2.cookie).expect(403);
    await request(app)
      .get(`/api/v1/cash-sessions/${s1Id}`)
      .set('Cookie', cashier2.cookie)
      .expect(403);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/transactions`)
      .set('Cookie', mgr2.cookie)
      .set('X-CSRF-Token', mgr2.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '50.00' })
      .expect(403);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/transactions/${txId}/void`)
      .set('Cookie', mgr2.cookie)
      .set('X-CSRF-Token', mgr2.csrf)
      .send({ reason: 'Çapraz mağaza iptal denemesi' })
      .expect(403);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/store-approve`)
      .set('Cookie', mgr2.cookie)
      .set('X-CSRF-Token', mgr2.csrf)
      .send({})
      .expect(403);
    await request(app).get(`/api/v1/receipts/${recId}`).set('Cookie', mgr2.cookie).expect(403);
    await request(app).get(`/api/v1/receipts/${recId}/file`).set('Cookie', mgr2.cookie).expect(403);
    await request(app)
      .post(`/api/v1/receipts/${recId}/confirm`)
      .set('Cookie', mgr2.cookie)
      .set('X-CSRF-Token', mgr2.csrf)
      .send({ verifiedAmount: '750.00' })
      .expect(403);
    await request(app)
      .post(`/api/v1/receipts/${recId}/reprocess-ocr`)
      .set('Cookie', mgr2.cookie)
      .set('X-CSRF-Token', mgr2.csrf)
      .send({})
      .expect(403);
    await request(app)
      .get(`/api/v1/reports/daily-store?storeId=${mag1Id}`)
      .set('Cookie', mgr2.cookie)
      .expect(403);
    await request(app)
      .get(`/api/v1/reports/daily-store/export?format=csv&storeId=${mag1Id}`)
      .set('Cookie', mgr2.cookie)
      .expect(403);
    await request(app)
      .get(`/api/v1/audit-logs?storeId=${mag1Id}`)
      .set('Cookie', mgr2.cookie)
      .expect(403);

    // 2. Aynı mağazadaki başka bir kasiyer (Kasiyer 2), Kasiyer 1'in oturumuna ve dekontuna müdahale edemez
    await request(app)
      .get(`/api/v1/cash-sessions/${s1Id}`)
      .set('Cookie', cashier1B.cookie)
      .expect(403);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/transactions`)
      .set('Cookie', cashier1B.cookie)
      .set('X-CSRF-Token', cashier1B.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '10.00' })
      .expect(403);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/submit`)
      .set('Cookie', cashier1B.cookie)
      .set('X-CSRF-Token', cashier1B.csrf)
      .send({ declaredCash: '700.00' })
      .expect(403);
    await request(app)
      .get(`/api/v1/receipts/${recId}/file`)
      .set('Cookie', cashier1B.cookie)
      .expect(403);

    // 3. Kasiyer kendi oturumuna store-approve yapamaz (403)
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/submit`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ declaredCash: '700.00' })
      .expect(200);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/store-approve`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({})
      .expect(403);

    // 4. Mağaza 1 yöneticisi onaylar -> Merkez kilitler -> Mağaza 2 mutabakat detayını göremez (403)
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/store-approve`)
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({})
      .expect(200);

    // Dekontu merkez onayından geçir ki mutabakat kilitlenebilsin
    await request(app)
      .post(`/api/v1/receipts/${recId}/central-review`)
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({ action: 'APPROVE', bankAccountVerified: true, reason: 'Güvenlik testi onayı' })
      .expect(200);

    const verified = await request(app)
      .post('/api/v1/reconciliations/verify')
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({
        storeId: mag1Id,
        businessDate: '2026-11-24',
        action: 'APPROVE',
        centralVerifiedCash: '700.00',
        notes: 'Güvenlik testi kilitleme',
      })
      .expect(200);
    const reconId = verified.body.id as string;

    await request(app)
      .get(`/api/v1/reconciliations/${reconId}`)
      .set('Cookie', mgr2.cookie)
      .expect(403);

    // Kilitli oturuma yeni işlem, iptal veya yeniden submit yapılamaz (409)
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/transactions`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '10.00' })
      .expect(409);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1Id}/submit`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ declaredCash: '700.00' })
      .expect(409);
  });

  it('SQLi/XSS payloadları, zararlı dosya yüklemeleri ve CSV formül enjeksiyonunu güvenli yönetir', async () => {
    const cashier1 = await loginAs('s7.m1.cashier1');
    const central = await loginAs('s7.merkez');

    // Geçersiz UUID üzerinden SQLi denemesi Zod ile 400 döner
    await request(app)
      .get("/api/v1/cash-sessions/' OR 1=1 --")
      .set('Cookie', central.cookie)
      .expect(400);
    await request(app)
      .get("/api/v1/reports/daily-store?storeId='; DROP TABLE stores; --")
      .set('Cookie', central.cookie)
      .expect(400);

    const open = await request(app)
      .post('/api/v1/cash-sessions')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({
        businessDate: '2026-11-24',
        openingCash: '100.00',
        notes: '=CMD|\' /C calc\'!A0 <script>alert(1)</script>',
      })
      .expect(201);
    const sessionId = open.body.id as string;

    // Zararlı SVG, HTML ve bozuk PNG yükleme reddi (400)
    await request(app)
      .post('/api/v1/receipts/upload')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .field('cashSessionId', sessionId)
      .attach('file', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"/>'), {
        filename: 'evil.svg',
        contentType: 'image/svg+xml',
      })
      .expect(400);

    await request(app)
      .post('/api/v1/receipts/upload')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .field('cashSessionId', sessionId)
      .attach('file', Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0xff, 0xff]), {
        filename: 'corrupt.png',
        contentType: 'image/png',
      })
      .expect(400);

    // Kasiyer notu/açıklamasında formül içeren satış girip CSV export güvenliğini kontrol et
    await request(app)
      .post(`/api/v1/cash-sessions/${sessionId}/transactions`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({
        paymentMethodCode: 'CASH',
        transactionType: 'SALE',
        amount: '250.00',
        description: '=SUM(A1:A5)',
      })
      .expect(201);

    // CSV dışa aktarma güvenli başlıklar ve UTF-8 BOM ile döner
    const csvRes = await request(app)
      .get('/api/v1/reports/daily-store/export?format=csv&startDate=2026-11-24&endDate=2026-11-24')
      .set('Cookie', central.cookie)
      .expect(200);
    expect(csvRes.headers['x-content-type-options']).toBe('nosniff');
    expect(csvRes.headers['cache-control']).toBe('private, no-store');
    expect(csvRes.headers['content-type']).toContain('text/csv');
    expect(csvRes.text.startsWith('\uFEFF')).toBe(true);
  });
});
