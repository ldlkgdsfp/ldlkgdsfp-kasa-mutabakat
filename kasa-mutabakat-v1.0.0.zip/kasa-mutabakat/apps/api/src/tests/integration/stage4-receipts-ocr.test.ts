import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '../../../../../.env') });

if (process.env.TEST_DATABASE_URL) {
  process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
}
process.env.NODE_ENV = 'test';

import sharp from 'sharp';
import request from 'supertest';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../app.js';
import { prisma } from '../../config/prisma.js';
import { resolveStoredReceiptPath } from '../../modules/receipts/file-security.js';
import { hashPassword } from '../../utils/password.js';

const app = createApp();
const TEST_PASSWORD = 'Stage4Password2026!';

/**
 * Gerçek pdftotext ile okunabilir minimal geçerli PDF dosyası üretir.
 */
function buildRealPdfBuffer(lines: string[]): Buffer {
  const escapedLines = lines.map((l) =>
    l
      .replace(/\\/g, '\\\\')
      .replace(/\(/g, '\\(')
      .replace(/\)/g, '\\)')
      // Standart PDF Type1 Helvetica ASCII güvenli metin
      .replace(/İ/g, 'I')
      .replace(/ı/g, 'i')
      .replace(/Ş/g, 'S')
      .replace(/ş/g, 's')
      .replace(/Ğ/g, 'G')
      .replace(/ğ/g, 'g')
      .replace(/Ü/g, 'U')
      .replace(/ü/g, 'u')
      .replace(/Ö/g, 'O')
      .replace(/ö/g, 'o')
      .replace(/Ç/g, 'C')
      .replace(/ç/g, 'c'),
  );

  let y = 760;
  const textCommands = escapedLines
    .map((line) => {
      const cmd = `BT /F1 12 Tf 50 ${y} Td (${line}) Tj ET`;
      y -= 20;
      return cmd;
    })
    .join('\n');

  const objects: string[] = [
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj',
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj',
    '3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj',
    `4 0 obj << /Length ${Buffer.byteLength(textCommands, 'utf8')} >> stream\n${textCommands}\nendstream endobj`,
    '5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj',
  ];

  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [0];
  for (const obj of objects) {
    offsets.push(Buffer.byteLength(pdf, 'utf8'));
    pdf += `${obj}\n`;
  }
  const xrefPos = Buffer.byteLength(pdf, 'utf8');
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i < offsets.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`;

  return Buffer.from(pdf, 'utf8');
}

/**
 * Gerçek sharp + Tesseract OCR ile okunabilir PNG dekont görseli üretir.
 */
async function buildRealReceiptPngBuffer(lines: string[]): Promise<Buffer> {
  const tspans = lines
    .map(
      (line, idx) =>
        `<text x="40" y="${65 + idx * 42}" font-family="DejaVu Sans, Arial, sans-serif" font-size="24" fill="#111111">${line
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')}</text>`,
    )
    .join('');

  const svg = `<svg width="1100" height="${120 + lines.length * 42}" xmlns="http://www.w3.org/2000/svg">
    <rect width="100%" height="100%" fill="#ffffff"/>
    ${tspans}
  </svg>`;

  return sharp(Buffer.from(svg)).png().toBuffer();
}

describe('Aşama 4 – IBAN Dekont Yükleme, Gerçek OCR, 4 Katmanlı Mükerrer Kontrolü ve Merkez Onayı', () => {
  let mag1Id: string;
  let mag2Id: string;
  let hqId: string;

  beforeAll(async () => {
    const roles = [
      { code: 'SYSTEM_ADMIN' as const, name: 'Sistem Yöneticisi' },
      { code: 'STORE_MANAGER' as const, name: 'Mağaza Yöneticisi' },
      { code: 'CASHIER' as const, name: 'Kasiyer' },
      { code: 'CENTRAL_ACCOUNTING' as const, name: 'Merkez Muhasebe / Kontrol' },
    ];
    for (const r of roles) {
      await prisma.role.upsert({ where: { code: r.code }, update: {}, create: r });
    }

    const methods = [
      { code: 'CASH' as const, name: 'Nakit', sortOrder: 1 },
      { code: 'CREDIT_CARD' as const, name: 'Kredi Kartı', sortOrder: 2 },
      { code: 'BANK_TRANSFER' as const, name: 'Havale / EFT', sortOrder: 3 },
    ];
    for (const m of methods) {
      await prisma.paymentMethod.upsert({ where: { code: m.code }, update: {}, create: m });
    }

    const stores = [
      { code: 'MERKEZ', name: 'Merkez Ofis', type: 'HEADQUARTERS' as const },
      { code: 'MAG-01', name: 'Mağaza 1', type: 'STORE' as const },
      { code: 'MAG-02', name: 'Mağaza 2', type: 'STORE' as const },
    ];
    for (const s of stores) {
      await prisma.store.upsert({ where: { code: s.code }, update: {}, create: s });
    }

    const roleMap = new Map((await prisma.role.findMany()).map((r) => [r.code, r.id]));
    const storeMap = new Map((await prisma.store.findMany()).map((s) => [s.code, s.id]));
    hqId = storeMap.get('MERKEZ')!;
    mag1Id = storeMap.get('MAG-01')!;
    mag2Id = storeMap.get('MAG-02')!;

    const passwordHash = await hashPassword(TEST_PASSWORD);
    const seedUsers = [
      {
        username: 's4.merkez',
        email: 's4.merkez@local.test',
        fullName: 'Merkez Kontrol',
        roleId: roleMap.get('CENTRAL_ACCOUNTING')!,
        storeId: hqId,
      },
      {
        username: 's4.m1.cashier',
        email: 's4.m1.cashier@local.test',
        fullName: 'Mağaza 1 Kasiyer',
        roleId: roleMap.get('CASHIER')!,
        storeId: mag1Id,
      },
      {
        username: 's4.m2.mgr',
        email: 's4.m2.mgr@local.test',
        fullName: 'Mağaza 2 Yöneticisi',
        roleId: roleMap.get('STORE_MANAGER')!,
        storeId: mag2Id,
      },
    ];
    for (const u of seedUsers) {
      await prisma.user.upsert({
        where: { username: u.username },
        update: { passwordHash, isActive: true, failedLoginAttempts: 0, lockedUntil: null },
        create: { ...u, passwordHash },
      });
    }
  });

  beforeEach(async () => {
    await prisma.financialAdjustment.deleteMany({});
    await prisma.reconciliationItem.deleteMany({});
    await prisma.centralReconciliation.deleteMany({});
    await prisma.receiptVerification.deleteMany({});
    await prisma.receiptOcrResult.deleteMany({});
    await prisma.cashTransaction.deleteMany({});
    await prisma.transferReceipt.deleteMany({});
    await prisma.cashSession.deleteMany({});
    await prisma.userSession.deleteMany({});
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  async function loginAs(username: string) {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: username, password: TEST_PASSWORD });
    expect(res.status).toBe(200);
    const setCookieHeader = res.headers['set-cookie'];
    const cookie = Array.isArray(setCookieHeader) ? setCookieHeader[0]! : setCookieHeader!;
    return { cookie, csrf: res.body.csrfToken as string, user: res.body.user };
  }

  it('sahte uzantılı zararlı dosyayı magic-bytes ile reddeder; gerçek PDF ve PNG dekontları OCR ile okuyup mükerrer ve onay akışlarını yürütür', async () => {
    const cashier1 = await loginAs('s4.m1.cashier');
    const mgr2 = await loginAs('s4.m2.mgr');
    const central = await loginAs('s4.merkez');

    // Kasa oturumu aç (500.00 TL açılış nakdi)
    const openRes = await request(app)
      .post('/api/v1/cash-sessions')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ businessDate: '2026-11-24', openingCash: '500.00' })
      .expect(201);
    const sessionId = openRes.body.id as string;

    // 1. Sahte .jpg uzantılı zararlı dosya reddedilmelidir (400)
    const fakeRes = await request(app)
      .post('/api/v1/receipts/upload')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .field('cashSessionId', sessionId)
      .attach('file', Buffer.from('<script>alert("xss")</script>'), {
        filename: 'sahte-dekont.jpg',
        contentType: 'image/jpeg',
      });
    expect(fakeRes.status).toBe(400);

    // 2. Gerçek PDF banka dekontu yükle (bakiye + masraf + gerçek transfer tutarı içerir)
    const pdf1 = buildRealPdfBuffer([
      'T.C. ZIRAAT BANKASI A.S.',
      'FAST PARA TRANSFERI DEKONTU',
      'Islem Tarihi: 24.11.2026',
      'Islem Saati: 11:30',
      'Gonderen: MEHMET KAYA',
      'Alici: KASA MUTABAKAT A.S.',
      'Alici Banka: Garanti BBVA',
      'Alici IBAN: TR330006100519786457841326',
      'FAST Sorgu No: FST2026112499812',
      'Transfer Tutari: 1.850,50 TL',
      'Islem Masrafi: 4,49 TL',
      'Kullanilabilir Bakiye: 48.200,00 TL',
      'Aciklama: Magaza 1 siparis',
    ]);

    const upload1 = await request(app)
      .post('/api/v1/receipts/upload')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .field('cashSessionId', sessionId)
      .attach('file', pdf1, {
        filename: 'ziraat-dekont.pdf',
        contentType: 'application/pdf',
      })
      .expect(201);

    const receipt1Id = upload1.body.id as string;
    expect(upload1.body.verifiedAmount).toBe('1850.50');
    expect(upload1.body.referenceNumber).toBe('FST2026112499812');
    expect(upload1.body.iban).toBe('TR330006100519786457841326');
    expect(upload1.body.ocrResults[0].excludedBalanceAmounts).toHaveLength(1);
    expect(upload1.body.ocrResults[0].excludedBalanceAmounts[0].amount).toBe('48200.00');
    expect(upload1.body.includedInReconciliation).toBe(false);
    expect(upload1.body.status).toBe('EXTRACTED');

    // OCR tek başına mutabakat toplamına EKLEMEMELİDİR
    const sessionBeforeApprove = await request(app)
      .get(`/api/v1/cash-sessions/${sessionId}`)
      .set('Cookie', cashier1.cookie)
      .expect(200);
    expect(sessionBeforeApprove.body.bankTransferTotal).toBe('0.00');
    expect(sessionBeforeApprove.body.expectedCash).toBe('500.00');

    // 3. Katman 1 Mükerrer: Birebir aynı PDF tekrar yüklendiğinde otomatik DUPLICATE olur
    const dupFileUpload = await request(app)
      .post('/api/v1/receipts/upload')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .field('cashSessionId', sessionId)
      .attach('file', pdf1, {
        filename: 'ziraat-dekont-kopya.pdf',
        contentType: 'application/pdf',
      })
      .expect(201);

    expect(dupFileUpload.body.status).toBe('DUPLICATE');
    expect(dupFileUpload.body.isDuplicate).toBe(true);
    expect(dupFileUpload.body.duplicateReason).toBe('FILE_HASH_MATCH');
    expect(dupFileUpload.body.duplicateOfReceiptId).toBe(receipt1Id);

    // Mükerrer dekont merkez tarafından dahi onaylanamaz (409)
    await request(app)
      .post(`/api/v1/receipts/${dupFileUpload.body.id}/central-review`)
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({ action: 'APPROVE' })
      .expect(409);

    // 4. Katman 2 Mükerrer: Farklı PDF dosyası ama AYNI referans numarası -> DUPLICATE
    const pdfSameRef = buildRealPdfBuffer([
      'T.C. ZIRAAT BANKASI A.S.',
      'Islem Tarihi: 24.11.2026',
      'Islem Saati: 11:30',
      'Gonderen: MEHMET KAYA',
      'FAST Sorgu No: FST2026112499812',
      'Transfer Tutari: 1.850,50 TL',
      'Aciklama: Farkli dosya ayni referans',
    ]);
    const dupRefUpload = await request(app)
      .post('/api/v1/receipts/upload')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .field('cashSessionId', sessionId)
      .attach('file', pdfSameRef, {
        filename: 'farkli-dosya-ayni-ref.pdf',
        contentType: 'application/pdf',
      })
      .expect(201);
    expect(dupRefUpload.body.status).toBe('DUPLICATE');
    expect(dupRefUpload.body.duplicateReason).toBe('REFERENCE_NO_MATCH');

    // 5. Katman 4 Şüpheli Mükerrer: Farklı PDF, referans yok, aynı tutar+tarih+saat+gönderen -> MANUAL_REVIEW_REQUIRED
    const pdfCompositeDup = buildRealPdfBuffer([
      'GARANTI BBVA',
      'Islem Tarihi: 24.11.2026',
      'Islem Saati: 11:34',
      'Gonderen: MEHMET KAYA',
      'Transfer Tutari: 1.850,50 TL',
    ]);
    const compositeDupUpload = await request(app)
      .post('/api/v1/receipts/upload')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .field('cashSessionId', sessionId)
      .attach('file', pdfCompositeDup, {
        filename: 'supheli-mukerrer.pdf',
        contentType: 'application/pdf',
      })
      .expect(201);
    expect(compositeDupUpload.body.status).toBe('MANUAL_REVIEW_REQUIRED');
    expect(compositeDupUpload.body.duplicateReason).toBe('COMPOSITE_FIELD_MATCH');

    // 6. Gerçek PNG görseli + gerçek Tesseract (tur+eng) OCR testi
    const pngReceipt = await buildRealReceiptPngBuffer([
      'AKBANK HAVALE DEKONTU',
      'Islem Tarihi: 24.11.2026',
      'Islem Saati: 15:10',
      'Gonderen: SELMA ARSLAN',
      'Referans No: AKB202611240055',
      'Transfer Tutari: 640,00 TL',
      'Guncel Bakiye: 19.500,00 TL',
    ]);
    const pngUpload = await request(app)
      .post('/api/v1/receipts/upload')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .field('cashSessionId', sessionId)
      .attach('file', pngReceipt, {
        filename: 'akbank-dekont.png',
        contentType: 'image/png',
      })
      .expect(201);

    expect(pngUpload.body.ocrResults[0].provider).toBe('LOCAL_TESSERACT');
    expect(pngUpload.body.verifiedAmount).toBe('640.00');
    // Bakiye 19.500,00 TL dışlanmış olmalıdır
    expect(pngUpload.body.ocrResults[0].excludedBalanceAmounts.some((b: { amount: string }) => b.amount === '19500.00')).toBe(true);

    // 7. Çapraz mağaza dosya önizleme engeli (Mağaza 2 yöneticisi Mağaza 1 dekontunu indiremez)
    await request(app)
      .get(`/api/v1/receipts/${receipt1Id}/file`)
      .set('Cookie', mgr2.cookie)
      .expect(403);

    // Yetkili kasiyer kendi dekontunu güvenli başlıklarla önizleyebilir
    const filePreview = await request(app)
      .get(`/api/v1/receipts/${receipt1Id}/file`)
      .set('Cookie', cashier1.cookie)
      .expect(200);
    expect(filePreview.headers['x-content-type-options']).toBe('nosniff');
    expect(filePreview.headers['content-security-policy']).toBe('sandbox');

    // 8. Kasiyer teyidi -> PENDING_CENTRAL_APPROVAL (hâlâ toplamda 0.00!)
    const confirmed = await request(app)
      .post(`/api/v1/receipts/${receipt1Id}/confirm`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({
        verifiedAmount: '1850.50',
        transactionDate: '2026-11-24',
        transactionTime: '11:30',
        senderName: 'MEHMET KAYA',
        receiverName: 'KASA MUTABAKAT A.S.',
        senderBank: 'T.C. Ziraat Bankası',
        receiverBank: 'Garanti BBVA',
        iban: 'TR330006100519786457841326',
        referenceNumber: 'FST2026112499812',
      })
      .expect(200);
    expect(confirmed.body.status).toBe('PENDING_CENTRAL_APPROVAL');

    // 9. Merkez Muhasebe Onayı -> APPROVED + Oturum bankTransferTotal = 1850.50 (expectedCash 500.00 değişmez!)
    const approved = await request(app)
      .post(`/api/v1/receipts/${receipt1Id}/central-review`)
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({
        action: 'APPROVE',
        bankAccountVerified: false,
        reason: 'Dekont incelendi ve onaylandı; banka ekstresi ayrıca kontrol edilecek',
      })
      .expect(200);

    expect(approved.body.status).toBe('APPROVED');
    expect(approved.body.includedInReconciliation).toBe(true);
    expect(approved.body.bankAccountVerified).toBe(false);

    const sessionAfterApprove = await request(app)
      .get(`/api/v1/cash-sessions/${sessionId}`)
      .set('Cookie', central.cookie)
      .expect(200);
    expect(sessionAfterApprove.body.bankTransferTotal).toBe('1850.50');
    expect(sessionAfterApprove.body.expectedCash).toBe('500.00');

    // 10. Ayrı Banka Hesabı Teyidi
    const bankVerified = await request(app)
      .post(`/api/v1/receipts/${receipt1Id}/bank-verify`)
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({
        bankAccountVerified: true,
        reason: 'Garanti BBVA hesap ekstresinde 1.850,50 TL doğrulandı',
      })
      .expect(200);
    expect(bankVerified.body.bankAccountVerified).toBe(true);
    expect(bankVerified.body.bankVerifiedAt).not.toBeNull();

    // 11. Orijinal dekont dosyası diskte korunmaya devam ediyor (reddedilen dekont dahil asla silinmez)
    const rejected = await request(app)
      .post(`/api/v1/receipts/${compositeDupUpload.body.id}/central-review`)
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({ action: 'REJECT', reason: 'Şüpheli mükerrer olduğu için reddedildi' })
      .expect(200);
    expect(rejected.body.status).toBe('REJECTED');

    const rejectedDb = await prisma.transferReceipt.findUniqueOrThrow({
      where: { id: compositeDupUpload.body.id },
    });
    const absPath = resolveStoredReceiptPath(rejectedDb.storedPath);
    const stat = await fs.stat(absPath);
    expect(stat.size).toBeGreaterThan(0);
  });
});
