import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '../../../../../.env') });

if (process.env.TEST_DATABASE_URL) {
  process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
}
process.env.NODE_ENV = 'test';

import { REPORT_TYPES } from '@kasa/shared';
import request from 'supertest';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../app.js';
import { prisma } from '../../config/prisma.js';
import { hashPassword } from '../../utils/password.js';

const app = createApp();
const TEST_PASSWORD = 'Stage6Password2026!';

describe('Aşama 6 – 9 Finansal Rapor, Mağaza İzolasyonu ve Excel/CSV Dışa Aktarma', () => {
  let mag1Id: string;
  let mag2Id: string;
  let hqId: string;

  beforeAll(async () => {
    const roles = [
      { code: 'SYSTEM_ADMIN' as const, name: 'Sistem Yöneticisi' },
      { code: 'STORE_MANAGER' as const, name: 'Mağaza Yöneticisi' },
      { code: 'CASHIER' as const, name: 'Kasiyer' },
      { code: 'CENTRAL_ACCOUNTING' as const, name: 'Merkez Muhasebe / Kontrol' },
    ];
    for (const r of roles) {
      await prisma.role.upsert({ where: { code: r.code }, update: {}, create: r });
    }

    const methods = [
      { code: 'CASH' as const, name: 'Nakit', sortOrder: 1 },
      { code: 'CREDIT_CARD' as const, name: 'Kredi Kartı', sortOrder: 2 },
      { code: 'BANK_TRANSFER' as const, name: 'Havale / EFT', sortOrder: 3 },
    ];
    for (const m of methods) {
      await prisma.paymentMethod.upsert({ where: { code: m.code }, update: {}, create: m });
    }

    const stores = [
      { code: 'MERKEZ', name: 'Merkez Ofis', type: 'HEADQUARTERS' as const },
      { code: 'MAG-01', name: 'Mağaza 1', type: 'STORE' as const },
      { code: 'MAG-02', name: 'Mağaza 2', type: 'STORE' as const },
      { code: 'MAG-03', name: 'Mağaza 3', type: 'STORE' as const },
    ];
    for (const s of stores) {
      await prisma.store.upsert({ where: { code: s.code }, update: {}, create: s });
    }

    const roleMap = new Map((await prisma.role.findMany()).map((r) => [r.code, r.id]));
    const storeMap = new Map((await prisma.store.findMany()).map((s) => [s.code, s.id]));
    hqId = storeMap.get('MERKEZ')!;
    mag1Id = storeMap.get('MAG-01')!;
    mag2Id = storeMap.get('MAG-02')!;

    const passwordHash = await hashPassword(TEST_PASSWORD);
    const seedUsers = [
      {
        username: 's6.merkez',
        email: 's6.merkez@local.test',
        fullName: 'Aşama 6 Merkez',
        roleId: roleMap.get('CENTRAL_ACCOUNTING')!,
        storeId: hqId,
      },
      {
        username: 's6.m1.mgr',
        email: 's6.m1.mgr@local.test',
        fullName: 'Mağaza 1 Yöneticisi',
        roleId: roleMap.get('STORE_MANAGER')!,
        storeId: mag1Id,
      },
      {
        username: 's6.m1.cashier',
        email: 's6.m1.cashier@local.test',
        fullName: 'Mağaza 1 Kasiyer',
        roleId: roleMap.get('CASHIER')!,
        storeId: mag1Id,
      },
      {
        username: 's6.m2.cashier',
        email: 's6.m2.cashier@local.test',
        fullName: 'Mağaza 2 Kasiyer',
        roleId: roleMap.get('CASHIER')!,
        storeId: mag2Id,
      },
    ];
    for (const u of seedUsers) {
      await prisma.user.upsert({
        where: { username: u.username },
        update: { passwordHash, isActive: true, failedLoginAttempts: 0, lockedUntil: null },
        create: { ...u, passwordHash },
      });
    }
  });

  beforeEach(async () => {
    await prisma.financialAdjustment.deleteMany({});
    await prisma.reconciliationItem.deleteMany({});
    await prisma.centralReconciliation.deleteMany({});
    await prisma.receiptVerification.deleteMany({});
    await prisma.receiptOcrResult.deleteMany({});
    await prisma.cashTransaction.deleteMany({});
    await prisma.transferReceipt.deleteMany({});
    await prisma.cashSession.deleteMany({});
    await prisma.userSession.deleteMany({});
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  async function loginAs(username: string) {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: username, password: TEST_PASSWORD });
    expect(res.status).toBe(200);
    const setCookieHeader = res.headers['set-cookie'];
    const cookie = Array.isArray(setCookieHeader) ? setCookieHeader[0]! : setCookieHeader!;
    return { cookie, csrf: res.body.csrfToken as string };
  }

  it('9 raporun tamamını gerçek veriden hesaplar, mağaza izolasyonunu korur ve XLSX/CSV dışa aktarır', async () => {
    const central = await loginAs('s6.merkez');
    const mgr1 = await loginAs('s6.m1.mgr');
    const c1 = await loginAs('s6.m1.cashier');
    const c2 = await loginAs('s6.m2.cashier');

    // Mağaza 1 oturumu: 200 açılış + 1000 nakit + 500 kart; teslim 1180 (-20 açık)
    const s1 = await request(app)
      .post('/api/v1/cash-sessions')
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ businessDate: '2026-11-24', openingCash: '200.00' })
      .expect(201);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1.body.id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '1000.00' })
      .expect(201);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1.body.id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'CREDIT_CARD', transactionType: 'SALE', amount: '500.00' })
      .expect(201);
    await request(app)
      .post(`/api/v1/cash-sessions/${s1.body.id}/submit`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ declaredCash: '1180.00' })
      .expect(200);

    // Mağaza 2 oturumu: 100 açılış + 600 nakit; teslim 710 (+10 fazla)
    const s2 = await request(app)
      .post('/api/v1/cash-sessions')
      .set('Cookie', c2.cookie)
      .set('X-CSRF-Token', c2.csrf)
      .send({ businessDate: '2026-11-24', openingCash: '100.00' })
      .expect(201);
    await request(app)
      .post(`/api/v1/cash-sessions/${s2.body.id}/transactions`)
      .set('Cookie', c2.cookie)
      .set('X-CSRF-Token', c2.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '600.00' })
      .expect(201);
    await request(app)
      .post(`/api/v1/cash-sessions/${s2.body.id}/submit`)
      .set('Cookie', c2.cookie)
      .set('X-CSRF-Token', c2.csrf)
      .send({ declaredCash: '710.00' })
      .expect(200);

    // Tüm 9 rapor türü merkez için 200 döner
    for (const reportType of REPORT_TYPES) {
      const res = await request(app)
        .get(`/api/v1/reports/${reportType}?startDate=2026-11-01&endDate=2026-11-30`)
        .set('Cookie', central.cookie)
        .expect(200);
      expect(res.body.reportType).toBe(reportType);
      expect(Array.isArray(res.body.columns)).toBe(true);
      expect(Array.isArray(res.body.rows)).toBe(true);
    }

    // Açık ve Fazla Raporu her iki farklı oturumu da yakalar (-20 ve +10)
    const ssRes = await request(app)
      .get('/api/v1/reports/shortage-surplus?startDate=2026-11-01&endDate=2026-11-30')
      .set('Cookie', central.cookie)
      .expect(200);
    expect(ssRes.body.rows).toHaveLength(2);
    expect(ssRes.body.summary.totalShortage).toBe('20.00');
    expect(ssRes.body.summary.totalSurplus).toBe('10.00');

    // Mağaza izolasyonu: Mağaza 1 yöneticisi Mağaza 2 raporunu isteyemez (403)
    await request(app)
      .get(`/api/v1/reports/daily-store?startDate=2026-11-01&endDate=2026-11-30&storeId=${mag2Id}`)
      .set('Cookie', mgr1.cookie)
      .expect(403);

    // Mağaza 1 yöneticisi yalnızca Mağaza 1 verilerini görür
    const mgr1Report = await request(app)
      .get('/api/v1/reports/daily-store?startDate=2026-11-01&endDate=2026-11-30')
      .set('Cookie', mgr1.cookie)
      .expect(200);
    expect(mgr1Report.body.rows).toHaveLength(1);
    expect(mgr1Report.body.summary.netSalesTotal).toBe('1500.00');

    // Excel (.xlsx) dışa aktarma testi
    const xlsxRes = await request(app)
      .get('/api/v1/reports/store-comparison/export?startDate=2026-11-01&endDate=2026-11-30&format=xlsx')
      .set('Cookie', central.cookie)
      .buffer(true)
      .parse((res, cb) => {
        const chunks: Buffer[] = [];
        res.on('data', (c: Buffer) => chunks.push(c));
        res.on('end', () => cb(null, Buffer.concat(chunks)));
      })
      .expect(200);
    expect(xlsxRes.headers['content-type']).toContain(
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    expect(xlsxRes.headers['content-disposition']).toContain('.xlsx');
    expect((xlsxRes.body as Buffer)[0]).toBe(0x50); // PK
    expect((xlsxRes.body as Buffer)[1]).toBe(0x4b);

    // CSV (.csv) dışa aktarma testi
    const csvRes = await request(app)
      .get('/api/v1/reports/cashier-variance/export?startDate=2026-11-01&endDate=2026-11-30&format=csv')
      .set('Cookie', central.cookie)
      .expect(200);
    expect(csvRes.headers['content-type']).toContain('text/csv');
    expect(csvRes.headers['content-disposition']).toContain('.csv');
    expect(csvRes.text).toContain('Mağaza 1 Kasiyer');
    expect(csvRes.text).toContain('20.00');

    // Dışa aktarma audit log'a yazılmış olmalıdır
    const exportLogs = await prisma.auditLog.findMany({
      where: { action: 'REPORT_EXPORTED' },
    });
    expect(exportLogs.length).toBeGreaterThanOrEqual(2);
  });
});
