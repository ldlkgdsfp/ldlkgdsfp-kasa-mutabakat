import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '../../../../../.env') });

if (process.env.TEST_DATABASE_URL) {
  process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
}
process.env.NODE_ENV = 'test';

import request from 'supertest';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../app.js';
import { prisma } from '../../config/prisma.js';
import { hashPassword } from '../../utils/password.js';

const app = createApp();
const TEST_PASSWORD = 'Stage5Password2026!';

describe('Aşama 5 – Merkez Kontrol Paneli, Mutabakat Onay/Kilitleme ve Gerekçeli Finansal Düzeltme', () => {
  let mag1Id: string;
  let mag2Id: string;
  let hqId: string;

  beforeAll(async () => {
    const roles = [
      { code: 'SYSTEM_ADMIN' as const, name: 'Sistem Yöneticisi' },
      { code: 'STORE_MANAGER' as const, name: 'Mağaza Yöneticisi' },
      { code: 'CASHIER' as const, name: 'Kasiyer' },
      { code: 'CENTRAL_ACCOUNTING' as const, name: 'Merkez Muhasebe / Kontrol' },
    ];
    for (const r of roles) {
      await prisma.role.upsert({ where: { code: r.code }, update: {}, create: r });
    }

    const methods = [
      { code: 'CASH' as const, name: 'Nakit', sortOrder: 1 },
      { code: 'CREDIT_CARD' as const, name: 'Kredi Kartı', sortOrder: 2 },
      { code: 'BANK_TRANSFER' as const, name: 'Havale / EFT', sortOrder: 3 },
    ];
    for (const m of methods) {
      await prisma.paymentMethod.upsert({ where: { code: m.code }, update: {}, create: m });
    }

    const stores = [
      { code: 'MERKEZ', name: 'Merkez Ofis', type: 'HEADQUARTERS' as const },
      { code: 'MAG-01', name: 'Mağaza 1', type: 'STORE' as const },
      { code: 'MAG-02', name: 'Mağaza 2', type: 'STORE' as const },
      { code: 'MAG-03', name: 'Mağaza 3', type: 'STORE' as const },
    ];
    for (const s of stores) {
      await prisma.store.upsert({ where: { code: s.code }, update: {}, create: s });
    }

    const roleMap = new Map((await prisma.role.findMany()).map((r) => [r.code, r.id]));
    const storeMap = new Map((await prisma.store.findMany()).map((s) => [s.code, s.id]));
    hqId = storeMap.get('MERKEZ')!;
    mag1Id = storeMap.get('MAG-01')!;
    mag2Id = storeMap.get('MAG-02')!;

    const passwordHash = await hashPassword(TEST_PASSWORD);
    const seedUsers = [
      {
        username: 's5.merkez',
        email: 's5.merkez@local.test',
        fullName: 'Merkez Kontrol Uzmanı',
        roleId: roleMap.get('CENTRAL_ACCOUNTING')!,
        storeId: hqId,
      },
      {
        username: 's5.m1.mgr',
        email: 's5.m1.mgr@local.test',
        fullName: 'Mağaza 1 Yöneticisi',
        roleId: roleMap.get('STORE_MANAGER')!,
        storeId: mag1Id,
      },
      {
        username: 's5.m2.mgr',
        email: 's5.m2.mgr@local.test',
        fullName: 'Mağaza 2 Yöneticisi',
        roleId: roleMap.get('STORE_MANAGER')!,
        storeId: mag2Id,
      },
      {
        username: 's5.m1.cashier',
        email: 's5.m1.cashier@local.test',
        fullName: 'Mağaza 1 Kasiyer',
        roleId: roleMap.get('CASHIER')!,
        storeId: mag1Id,
      },
    ];
    for (const u of seedUsers) {
      await prisma.user.upsert({
        where: { username: u.username },
        update: { passwordHash, isActive: true, failedLoginAttempts: 0, lockedUntil: null },
        create: { ...u, passwordHash },
      });
    }
  });

  beforeEach(async () => {
    await prisma.financialAdjustment.deleteMany({});
    await prisma.reconciliationItem.deleteMany({});
    await prisma.centralReconciliation.deleteMany({});
    await prisma.receiptVerification.deleteMany({});
    await prisma.receiptOcrResult.deleteMany({});
    await prisma.cashTransaction.deleteMany({});
    await prisma.transferReceipt.deleteMany({});
    await prisma.cashSession.deleteMany({});
    await prisma.userSession.deleteMany({});
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  async function loginAs(username: string) {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: username, password: TEST_PASSWORD });
    expect(res.status).toBe(200);
    const setCookieHeader = res.headers['set-cookie'];
    const cookie = Array.isArray(setCookieHeader) ? setCookieHeader[0]! : setCookieHeader!;
    return { cookie, csrf: res.body.csrfToken as string, user: res.body.user };
  }

  it('merkez kontrol paneli yetkisini, beyan vs merkez fark hesabını, onay kilidini ve gerekçeli düzeltme kaydını doğrular', async () => {
    const central = await loginAs('s5.merkez');
    const mgr1 = await loginAs('s5.m1.mgr');
    const mgr2 = await loginAs('s5.m2.mgr');
    const cashier1 = await loginAs('s5.m1.cashier');

    // RBAC: Mağaza yöneticisi ve kasiyer merkez paneline erişemez (403)
    await request(app)
      .get('/api/v1/reconciliations/dashboard?businessDate=2026-11-24')
      .set('Cookie', mgr1.cookie)
      .expect(403);
    await request(app)
      .get('/api/v1/reconciliations/dashboard?businessDate=2026-11-24')
      .set('Cookie', cashier1.cookie)
      .expect(403);

    // Mağaza 1 kasiyeri oturum açar: 500 açılış + 1000 nakit + 750 kart = beklenen nakit 1500.00
    const s1 = await request(app)
      .post('/api/v1/cash-sessions')
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ businessDate: '2026-11-24', openingCash: '500.00' })
      .expect(201);
    const sessionId = s1.body.id as string;

    await request(app)
      .post(`/api/v1/cash-sessions/${sessionId}/transactions`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '1000.00' })
      .expect(201);

    await request(app)
      .post(`/api/v1/cash-sessions/${sessionId}/transactions`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ paymentMethodCode: 'CREDIT_CARD', transactionType: 'SALE', amount: '750.00' })
      .expect(201);

    // Oturum henüz açıkken (teslim edilmemişken) merkez onay veremez (409)
    await request(app)
      .post('/api/v1/reconciliations/verify')
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({
        storeId: mag1Id,
        businessDate: '2026-11-24',
        centralVerifiedCash: '1500.00',
        action: 'APPROVE',
      })
      .expect(409);

    // Kasiyer 1500.00 teslim beyan eder, mağaza yöneticisi merkeze gönderir
    await request(app)
      .post(`/api/v1/cash-sessions/${sessionId}/submit`)
      .set('Cookie', cashier1.cookie)
      .set('X-CSRF-Token', cashier1.csrf)
      .send({ declaredCash: '1500.00' })
      .expect(200);

    await request(app)
      .post(`/api/v1/cash-sessions/${sessionId}/store-approve`)
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({})
      .expect(200);

    // Merkez paneli tüm mağazaları ve onay bekleyen kapanışı gösterir
    const dashBefore = await request(app)
      .get('/api/v1/reconciliations/dashboard?businessDate=2026-11-24')
      .set('Cookie', central.cookie)
      .expect(200);
    expect(dashBefore.body.stores.length).toBeGreaterThanOrEqual(3);
    expect(dashBefore.body.overall.pendingClosingCount).toBe(1);
    expect(dashBefore.body.overall.expectedCashTotal).toBe('1500.00');
    expect(dashBefore.body.overall.creditCardTotal).toBe('750.00');

    // Merkez sayımında 1480.00 teslim aldı -> beyan 1500.00, fark -20.00 (kasa açığı) -> Onayla ve Kilitle
    const approved = await request(app)
      .post('/api/v1/reconciliations/verify')
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({
        storeId: mag1Id,
        businessDate: '2026-11-24',
        centralVerifiedCash: '1480.00',
        action: 'APPROVE',
        notes: 'Merkez fiziksel sayımında 20 TL eksik teslim alındı',
      })
      .expect(200);

    const reconId = approved.body.id as string;
    expect(approved.body.status).toBe('APPROVED');
    expect(approved.body.isLocked).toBe(true);
    expect(approved.body.expectedCashTotal).toBe('1500.00');
    expect(approved.body.declaredCashTotal).toBe('1500.00');
    expect(approved.body.centralVerifiedCash).toBe('1480.00');
    expect(approved.body.cashVariance).toBe('-20.00');
    expect(approved.body.declaredVsCentralDiff).toBe('-20.00');
    expect(approved.body.items).toHaveLength(3); // CASH, CREDIT_CARD, BANK_TRANSFER

    // Kilitli mutabakat doğrudan değiştirilemez (409)
    await request(app)
      .post('/api/v1/reconciliations/verify')
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({
        storeId: mag1Id,
        businessDate: '2026-11-24',
        centralVerifiedCash: '1500.00',
        action: 'APPROVE',
      })
      .expect(409);

    // Bağlı kasa oturumu da kilitlendi (CENTRAL_APPROVED) ve yeni işlem eklenemez (409)
    const lockedSession = await request(app)
      .get(`/api/v1/cash-sessions/${sessionId}`)
      .set('Cookie', central.cookie)
      .expect(200);
    expect(lockedSession.body.status).toBe('CENTRAL_APPROVED');
    expect(lockedSession.body.isLocked).toBe(true);

    // Kilitli kayıtta gerekçeli Finansal Düzeltme Kaydı oluşturulabilir (1480 -> 1500, delta +20.00)
    const adjusted = await request(app)
      .post(`/api/v1/reconciliations/${reconId}/adjustments`)
      .set('Cookie', central.cookie)
      .set('X-CSRF-Token', central.csrf)
      .send({
        fieldName: 'central_verified_cash',
        adjustedValue: '1500.00',
        reason: 'Kasa zarfı ikinci kontrolde 20 TL daha bulundu ve doğrulandı',
      })
      .expect(201);

    expect(adjusted.body.centralVerifiedCash).toBe('1500.00');
    expect(adjusted.body.cashVariance).toBe('0.00');
    expect(adjusted.body.declaredVsCentralDiff).toBe('0.00');
    expect(adjusted.body.adjustments).toHaveLength(1);
    expect(adjusted.body.adjustments[0].deltaAmount).toBe('20.00');

    // Mağaza izolasyonu: Mağaza 1 yöneticisi kendi mutabakatını görür, Mağaza 2 yöneticisi 403 alır
    await request(app)
      .get(`/api/v1/reconciliations/${reconId}`)
      .set('Cookie', mgr1.cookie)
      .expect(200);
    await request(app)
      .get(`/api/v1/reconciliations/${reconId}`)
      .set('Cookie', mgr2.cookie)
      .expect(403);
  });
});
