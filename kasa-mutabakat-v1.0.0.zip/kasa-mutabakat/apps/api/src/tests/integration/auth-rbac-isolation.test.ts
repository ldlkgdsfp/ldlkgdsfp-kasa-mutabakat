import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '../../../../../.env') });

// Integration testleri kesinlikle izole kasa_mutabakat_test veritabanında çalışır
if (process.env.TEST_DATABASE_URL) {
  process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
}
process.env.NODE_ENV = 'test';

import request from 'supertest';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../app.js';
import { prisma } from '../../config/prisma.js';
import { hashPassword } from '../../utils/password.js';

const app = createApp();
const TEST_PASSWORD = 'TestPassword2026!';

describe('Auth, CSRF, RBAC ve Mağaza İzolasyonu (Gerçek PostgreSQL Test DB)', () => {
  let mag1Id: string;
  let mag2Id: string;

  beforeAll(async () => {
    const roles = [
      { code: 'SYSTEM_ADMIN' as const, name: 'Sistem Yöneticisi' },
      { code: 'STORE_MANAGER' as const, name: 'Mağaza Yöneticisi' },
      { code: 'CASHIER' as const, name: 'Kasiyer' },
      { code: 'CENTRAL_ACCOUNTING' as const, name: 'Merkez Muhasebe / Kontrol' },
    ];
    for (const r of roles) {
      await prisma.role.upsert({
        where: { code: r.code },
        update: {},
        create: r,
      });
    }

    const stores = [
      { code: 'MERKEZ', name: 'Merkez Ofis', type: 'HEADQUARTERS' as const },
      { code: 'MAG-01', name: 'Mağaza 1', type: 'STORE' as const },
      { code: 'MAG-02', name: 'Mağaza 2', type: 'STORE' as const },
      { code: 'MAG-03', name: 'Mağaza 3', type: 'STORE' as const },
    ];
    for (const s of stores) {
      await prisma.store.upsert({
        where: { code: s.code },
        update: {},
        create: s,
      });
    }

    const allRoles = await prisma.role.findMany();
    const roleMap = new Map(allRoles.map((r) => [r.code, r.id]));
    const allStores = await prisma.store.findMany();
    const storeMap = new Map(allStores.map((s) => [s.code, s.id]));

    mag1Id = storeMap.get('MAG-01')!;
    mag2Id = storeMap.get('MAG-02')!;

    const passwordHash = await hashPassword(TEST_PASSWORD);
    const users = [
      {
        username: 'test.admin',
        email: 'test.admin@local.test',
        fullName: 'Test Admin',
        roleId: roleMap.get('SYSTEM_ADMIN')!,
        storeId: storeMap.get('MERKEZ')!,
      },
      {
        username: 'test.merkez',
        email: 'test.merkez@local.test',
        fullName: 'Test Merkez Muhasebe',
        roleId: roleMap.get('CENTRAL_ACCOUNTING')!,
        storeId: storeMap.get('MERKEZ')!,
      },
      {
        username: 'test.m1.mgr',
        email: 'test.m1.mgr@local.test',
        fullName: 'Mağaza 1 Yöneticisi',
        roleId: roleMap.get('STORE_MANAGER')!,
        storeId: mag1Id,
      },
      {
        username: 'test.m1.cashier',
        email: 'test.m1.cashier@local.test',
        fullName: 'Mağaza 1 Kasiyer',
        roleId: roleMap.get('CASHIER')!,
        storeId: mag1Id,
      },
    ];

    for (const u of users) {
      await prisma.user.upsert({
        where: { username: u.username },
        update: {
          passwordHash,
          isActive: true,
          failedLoginAttempts: 0,
          lockedUntil: null,
        },
        create: {
          ...u,
          passwordHash,
        },
      });
    }
  });

  beforeEach(async () => {
    await prisma.userSession.deleteMany({});
    await prisma.user.updateMany({
      data: { failedLoginAttempts: 0, lockedUntil: null },
    });
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  async function loginAs(identifier: string) {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier, password: TEST_PASSWORD });

    expect(res.status).toBe(200);
    const cookies = res.headers['set-cookie'] as string[] | undefined;
    expect(cookies).toBeDefined();
    expect(cookies![0]).toContain('HttpOnly');

    return {
      cookie: cookies![0]!,
      csrfToken: res.body.csrfToken as string,
      user: res.body.user,
    };
  }

  it('sağlık kontrolü veritabanı bağlantısını doğrular', async () => {
    const res = await request(app).get('/api/v1/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.database).toBe('connected');
  });

  it('kullanıcı adı veya e-posta ile giriş yapar, oturum doğrular, CSRF kontrolü uygular ve çıkışta oturumu iptal eder', async () => {
    const unauth = await request(app).get('/api/v1/auth/me');
    expect(unauth.status).toBe(401);

    const session = await loginAs('test.m1.cashier@local.test');

    const meRes = await request(app)
      .get('/api/v1/auth/me')
      .set('Cookie', session.cookie);
    expect(meRes.status).toBe(200);
    expect(meRes.body.user.username).toBe('test.m1.cashier');
    expect(meRes.body.user.role).toBe('CASHIER');

    // CSRF olmadan çıkış reddedilmelidir
    const noCsrfLogout = await request(app)
      .post('/api/v1/auth/logout')
      .set('Cookie', session.cookie);
    expect(noCsrfLogout.status).toBe(403);

    // Yanlış CSRF ile çıkış reddedilmelidir
    const wrongCsrfLogout = await request(app)
      .post('/api/v1/auth/logout')
      .set('Cookie', session.cookie)
      .set('X-CSRF-Token', 'wrong-token');
    expect(wrongCsrfLogout.status).toBe(403);

    // Geçerli CSRF ile çıkış başarılı olur
    const validLogout = await request(app)
      .post('/api/v1/auth/logout')
      .set('Cookie', session.cookie)
      .set('X-CSRF-Token', session.csrfToken);
    expect(validLogout.status).toBe(200);

    // İptal edilen oturum artık kabul edilmemelidir
    const afterLogout = await request(app)
      .get('/api/v1/auth/me')
      .set('Cookie', session.cookie);
    expect(afterLogout.status).toBe(401);
  });

  it('ardışık 5 hatalı girişte hesabı kilitler ve doğru parola girilse bile erişimi engeller', async () => {
    for (let i = 1; i <= 4; i++) {
      const res = await request(app)
        .post('/api/v1/auth/login')
        .send({ identifier: 'test.m1.cashier', password: 'WrongPassword123!' });
      expect(res.status).toBe(401);
    }

    const fifth = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: 'test.m1.cashier', password: 'WrongPassword123!' });
    expect(fifth.status).toBe(429);

    const blockedEvenValid = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: 'test.m1.cashier', password: TEST_PASSWORD });
    expect(blockedEvenValid.status).toBe(429);
  });

  it('rol ve mağaza bazlı veri izolasyonunu kesin biçimde uygular', async () => {
    const admin = await loginAs('test.admin');
    const central = await loginAs('test.merkez');
    const mgr1 = await loginAs('test.m1.mgr');
    const cashier1 = await loginAs('test.m1.cashier');

    // Admin ve Merkez tüm 4 birimi görür
    const adminStores = await request(app).get('/api/v1/stores').set('Cookie', admin.cookie);
    expect(adminStores.status).toBe(200);
    expect(adminStores.body.items.length).toBeGreaterThanOrEqual(4);

    const centralStores = await request(app).get('/api/v1/stores').set('Cookie', central.cookie);
    expect(centralStores.status).toBe(200);
    expect(centralStores.body.items.length).toBeGreaterThanOrEqual(4);

    // Mağaza 1 yöneticisi ve kasiyeri yalnızca kendi mağazasını görür
    const mgrStores = await request(app).get('/api/v1/stores').set('Cookie', mgr1.cookie);
    expect(mgrStores.status).toBe(200);
    expect(mgrStores.body.items).toHaveLength(1);
    expect(mgrStores.body.items[0].id).toBe(mag1Id);

    const cashierStores = await request(app).get('/api/v1/stores').set('Cookie', cashier1.cookie);
    expect(cashierStores.status).toBe(200);
    expect(cashierStores.body.items).toHaveLength(1);
    expect(cashierStores.body.items[0].id).toBe(mag1Id);

    // Mağaza 1 personeli Mağaza 2 detayına erişemez (403)
    const crossStoreMgr = await request(app)
      .get(`/api/v1/stores/${mag2Id}`)
      .set('Cookie', mgr1.cookie);
    expect(crossStoreMgr.status).toBe(403);

    const crossStoreCashier = await request(app)
      .get(`/api/v1/stores/${mag2Id}`)
      .set('Cookie', cashier1.cookie);
    expect(crossStoreCashier.status).toBe(403);

    // Kendi mağazasına erişim serbest (200)
    const ownStoreMgr = await request(app)
      .get(`/api/v1/stores/${mag1Id}`)
      .set('Cookie', mgr1.cookie);
    expect(ownStoreMgr.status).toBe(200);
    expect(ownStoreMgr.body.code).toBe('MAG-01');

    // RBAC: Kasiyer denetim kayıtlarına erişemez (403)
    const cashierAudit = await request(app)
      .get('/api/v1/audit-logs')
      .set('Cookie', cashier1.cookie);
    expect(cashierAudit.status).toBe(403);

    // Mağaza 1 yöneticisi Mağaza 2 denetim kayıtlarını sorgulayamaz (403)
    const mgrCrossAudit = await request(app)
      .get(`/api/v1/audit-logs?storeId=${mag2Id}`)
      .set('Cookie', mgr1.cookie);
    expect(mgrCrossAudit.status).toBe(403);

    // Mağaza 1 yöneticisi kendi mağazasının denetim kayıtlarını görebilir (200)
    const mgrOwnAudit = await request(app)
      .get('/api/v1/audit-logs')
      .set('Cookie', mgr1.cookie);
    expect(mgrOwnAudit.status).toBe(200);
    expect(Array.isArray(mgrOwnAudit.body.items)).toBe(true);
    expect(mgrOwnAudit.body.items.length).toBeGreaterThan(0);
    for (const item of mgrOwnAudit.body.items) {
      expect(item.store?.id).toBe(mag1Id);
    }
  });
});
