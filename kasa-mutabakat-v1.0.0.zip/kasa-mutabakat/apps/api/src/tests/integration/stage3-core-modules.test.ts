import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '../../../../../.env') });

if (process.env.TEST_DATABASE_URL) {
  process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
}
process.env.NODE_ENV = 'test';

import request from 'supertest';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { createApp } from '../../app.js';
import { prisma } from '../../config/prisma.js';
import { hashPassword } from '../../utils/password.js';

const app = createApp();
const TEST_PASSWORD = 'Stage3Password2026!';

describe('Aşama 3 – Mağaza, Personel, Kasiyer Kasa İşlemleri ve Günlük Kapanış', () => {
  let mag1Id: string;
  let mag2Id: string;
  let hqId: string;
  let cashier1Id: string;
  let cashier2Id: string;

  beforeAll(async () => {
    const roles = [
      { code: 'SYSTEM_ADMIN' as const, name: 'Sistem Yöneticisi' },
      { code: 'STORE_MANAGER' as const, name: 'Mağaza Yöneticisi' },
      { code: 'CASHIER' as const, name: 'Kasiyer' },
      { code: 'CENTRAL_ACCOUNTING' as const, name: 'Merkez Muhasebe / Kontrol' },
    ];
    for (const r of roles) {
      await prisma.role.upsert({ where: { code: r.code }, update: {}, create: r });
    }

    const methods = [
      { code: 'CASH' as const, name: 'Nakit', sortOrder: 1 },
      { code: 'CREDIT_CARD' as const, name: 'Kredi Kartı', sortOrder: 2 },
      { code: 'BANK_TRANSFER' as const, name: 'Havale / EFT', sortOrder: 3 },
    ];
    for (const m of methods) {
      await prisma.paymentMethod.upsert({ where: { code: m.code }, update: {}, create: m });
    }

    const stores = [
      { code: 'MERKEZ', name: 'Merkez Ofis', type: 'HEADQUARTERS' as const },
      { code: 'MAG-01', name: 'Mağaza 1', type: 'STORE' as const },
      { code: 'MAG-02', name: 'Mağaza 2', type: 'STORE' as const },
      { code: 'MAG-03', name: 'Mağaza 3', type: 'STORE' as const },
    ];
    for (const s of stores) {
      await prisma.store.upsert({ where: { code: s.code }, update: {}, create: s });
    }

    const allRoles = await prisma.role.findMany();
    const roleMap = new Map(allRoles.map((r) => [r.code, r.id]));
    const allStores = await prisma.store.findMany();
    const storeMap = new Map(allStores.map((s) => [s.code, s.id]));

    hqId = storeMap.get('MERKEZ')!;
    mag1Id = storeMap.get('MAG-01')!;
    mag2Id = storeMap.get('MAG-02')!;

    const passwordHash = await hashPassword(TEST_PASSWORD);
    const seedUsers = [
      {
        username: 's3.admin',
        email: 's3.admin@local.test',
        fullName: 'Aşama 3 Admin',
        roleId: roleMap.get('SYSTEM_ADMIN')!,
        storeId: hqId,
      },
      {
        username: 's3.merkez',
        email: 's3.merkez@local.test',
        fullName: 'Aşama 3 Merkez',
        roleId: roleMap.get('CENTRAL_ACCOUNTING')!,
        storeId: hqId,
      },
      {
        username: 's3.m1.mgr',
        email: 's3.m1.mgr@local.test',
        fullName: 'Mağaza 1 Yöneticisi',
        roleId: roleMap.get('STORE_MANAGER')!,
        storeId: mag1Id,
      },
      {
        username: 's3.m2.mgr',
        email: 's3.m2.mgr@local.test',
        fullName: 'Mağaza 2 Yöneticisi',
        roleId: roleMap.get('STORE_MANAGER')!,
        storeId: mag2Id,
      },
      {
        username: 's3.m1.cashier1',
        email: 's3.m1.cashier1@local.test',
        fullName: 'Ayşe Kasiyer',
        roleId: roleMap.get('CASHIER')!,
        storeId: mag1Id,
      },
      {
        username: 's3.m1.cashier2',
        email: 's3.m1.cashier2@local.test',
        fullName: 'Mehmet Kasiyer',
        roleId: roleMap.get('CASHIER')!,
        storeId: mag1Id,
      },
    ];

    for (const u of seedUsers) {
      await prisma.user.upsert({
        where: { username: u.username },
        update: { passwordHash, isActive: true, failedLoginAttempts: 0, lockedUntil: null },
        create: { ...u, passwordHash },
      });
    }

    const c1 = await prisma.user.findUniqueOrThrow({ where: { username: 's3.m1.cashier1' } });
    const c2 = await prisma.user.findUniqueOrThrow({ where: { username: 's3.m1.cashier2' } });
    cashier1Id = c1.id;
    cashier2Id = c2.id;
  });

  beforeEach(async () => {
    await prisma.financialAdjustment.deleteMany({});
    await prisma.reconciliationItem.deleteMany({});
    await prisma.centralReconciliation.deleteMany({});
    await prisma.receiptVerification.deleteMany({});
    await prisma.receiptOcrResult.deleteMany({});
    await prisma.cashTransaction.deleteMany({});
    await prisma.transferReceipt.deleteMany({});
    await prisma.cashSession.deleteMany({});
    await prisma.userSession.deleteMany({});
    await prisma.user.updateMany({
      data: { failedLoginAttempts: 0, lockedUntil: null },
    });
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  async function loginAs(username: string) {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: username, password: TEST_PASSWORD });
    expect(res.status).toBe(200);
    const setCookieHeader = res.headers['set-cookie'];
    const cookie = Array.isArray(setCookieHeader) ? setCookieHeader[0]! : setCookieHeader!;
    return {
      cookie,
      csrf: res.body.csrfToken as string,
      user: res.body.user,
    };
  }

  it('sistem yöneticisi mağaza adını dinamik güncelleyebilir; yetkisiz roller 403 alır', async () => {
    const admin = await loginAs('s3.admin');
    const mgr1 = await loginAs('s3.m1.mgr');

    // Mağaza yöneticisi mağaza adını değiştiremez
    const forbidden = await request(app)
      .patch(`/api/v1/stores/${mag1Id}`)
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({ name: 'Yetkisiz İsim' });
    expect(forbidden.status).toBe(403);

    // Sistem yöneticisi mağaza adını değiştirebilir
    const renamed = await request(app)
      .patch(`/api/v1/stores/${mag1Id}`)
      .set('Cookie', admin.cookie)
      .set('X-CSRF-Token', admin.csrf)
      .send({ name: 'Kadıköy Şubesi' });
    expect(renamed.status).toBe(200);
    expect(renamed.body.name).toBe('Kadıköy Şubesi');

    // Eski isme geri al
    await request(app)
      .patch(`/api/v1/stores/${mag1Id}`)
      .set('Cookie', admin.cookie)
      .set('X-CSRF-Token', admin.csrf)
      .send({ name: 'Mağaza 1' });
  });

  it('sistem yöneticisi personel oluşturup pasifleştirdiğinde aktif oturumu anında iptal olur', async () => {
    const admin = await loginAs('s3.admin');
    const uniqueSuffix = Date.now().toString().slice(-6);
    const username = `s3.temp.${uniqueSuffix}`;

    // Mağazasız kasiyer oluşturulamaz (400)
    const missingStore = await request(app)
      .post('/api/v1/users')
      .set('Cookie', admin.cookie)
      .set('X-CSRF-Token', admin.csrf)
      .send({
        username: `${username}.bad`,
        email: `${username}.bad@local.test`,
        fullName: 'Hatalı Kasiyer',
        password: TEST_PASSWORD,
        roleCode: 'CASHIER',
        storeId: null,
      });
    expect(missingStore.status).toBe(400);

    // Merkez ofise kasiyer atanamaz (400)
    const hqCashier = await request(app)
      .post('/api/v1/users')
      .set('Cookie', admin.cookie)
      .set('X-CSRF-Token', admin.csrf)
      .send({
        username: `${username}.hq`,
        email: `${username}.hq@local.test`,
        fullName: 'HQ Kasiyer',
        password: TEST_PASSWORD,
        roleCode: 'CASHIER',
        storeId: hqId,
      });
    expect(hqCashier.status).toBe(400);

    // Geçerli kasiyer oluştur
    const created = await request(app)
      .post('/api/v1/users')
      .set('Cookie', admin.cookie)
      .set('X-CSRF-Token', admin.csrf)
      .send({
        username,
        email: `${username}@local.test`,
        fullName: 'Yeni Kasiyer',
        password: TEST_PASSWORD,
        roleCode: 'CASHIER',
        storeId: mag1Id,
      });
    expect(created.status).toBe(201);

    // Yeni kasiyer giriş yapar
    const tempSession = await loginAs(username);
    const meBefore = await request(app).get('/api/v1/auth/me').set('Cookie', tempSession.cookie);
    expect(meBefore.status).toBe(200);

    // Admin kullanıcıyı pasifleştirir
    const deactivated = await request(app)
      .patch(`/api/v1/users/${created.body.id}`)
      .set('Cookie', admin.cookie)
      .set('X-CSRF-Token', admin.csrf)
      .send({ isActive: false });
    expect(deactivated.status).toBe(200);
    expect(deactivated.body.isActive).toBe(false);

    // Pasifleştirilen kullanıcının oturumu anında düşmelidir
    const meAfter = await request(app).get('/api/v1/auth/me').set('Cookie', tempSession.cookie);
    expect(meAfter.status).toBe(401);
  });

  it('aynı mağazada aynı gün iki farklı kasiyerin bağımsız oturumlarını, hesaplamalarını, iptalini ve kapanış onayını doğrular', async () => {
    const c1 = await loginAs('s3.m1.cashier1');
    const c2 = await loginAs('s3.m1.cashier2');
    const mgr1 = await loginAs('s3.m1.mgr');
    const mgr2 = await loginAs('s3.m2.mgr');

    // Kasiyer 1 oturum açar (açılış 500.00)
    const open1 = await request(app)
      .post('/api/v1/cash-sessions')
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ businessDate: '2026-11-24', openingCash: '500.00' });
    expect(open1.status).toBe(201);
    const session1Id = open1.body.id as string;
    expect(open1.body.cashierId).toBe(cashier1Id);
    expect(open1.body.expectedCash).toBe('500.00');

    // Aynı gün Kasiyer 2 de aynı mağazada bağımsız oturum açar (açılış 300.00)
    const open2 = await request(app)
      .post('/api/v1/cash-sessions')
      .set('Cookie', c2.cookie)
      .set('X-CSRF-Token', c2.csrf)
      .send({ businessDate: '2026-11-24', openingCash: '300.00' });
    expect(open2.status).toBe(201);
    const session2Id = open2.body.id as string;
    expect(open2.body.cashierId).toBe(cashier2Id);

    // Kasiyer 1 hareketleri: +1250.50 nakit, +840.25 kredi kartı, -50.50 nakit iade, -100.00 nakit çıkış
    await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '1250.50' })
      .expect(201);

    await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'CREDIT_CARD', transactionType: 'SALE', amount: '840.25' })
      .expect(201);

    await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'REFUND', amount: '50.50' })
      .expect(201);

    await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'CASH_OUT', amount: '100.00', description: 'Kurye ödemesi' })
      .expect(201);

    // Hatalı bir hareket eklenip gerekçeyle iptal edilir -> toplama girmemelidir
    const wrongTx = await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '999.00' })
      .expect(201);

    const afterVoid = await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/transactions/${wrongTx.body.transaction.id}/void`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ reason: 'Mükerrer fiş girişi iptali' })
      .expect(200);

    // Beklenen nakit = 500 + 1250.50 - 50.50 - 100.00 = 1600.00 (840.25 kart dahil değil!)
    expect(afterVoid.body.expectedCash).toBe('1600.00');
    expect(afterVoid.body.creditCardSalesTotal).toBe('840.25');

    // Manuel Havale/EFT satışı dekont olmadan reddedilmelidir
    const manualBankSale = await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'BANK_TRANSFER', transactionType: 'SALE', amount: '500.00' });
    expect(manualBankSale.status).toBe(400);

    // Kredi kartında CASH_OUT reddedilmelidir
    const invalidCardOut = await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'CREDIT_CARD', transactionType: 'CASH_OUT', amount: '50.00' });
    expect(invalidCardOut.status).toBe(400);

    // Kasiyer 1, Kasiyer 2'nin oturumuna erişemez (403)
    const crossCashier = await request(app)
      .get(`/api/v1/cash-sessions/${session2Id}`)
      .set('Cookie', c1.cookie);
    expect(crossCashier.status).toBe(403);

    // Kasiyer 1 teslim eder: 1585.00 (15.00 ₺ açık)
    const submit1 = await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/submit`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ declaredCash: '1585.00', notes: 'Gün sonu teslim' })
      .expect(200);

    expect(submit1.body.status).toBe('CASHIER_SUBMITTED');
    expect(submit1.body.cashDifference).toBe('-15.00');
    expect(submit1.body.cashDifferenceStatus).toBe('SHORTAGE');
    expect(submit1.body.cashShortage).toBe('15.00');

    // Teslim edilmiş oturuma yeni işlem eklenemez (409)
    await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/transactions`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '10.00' })
      .expect(409);

    // Kasiyer 2 satış yapar ve fazla ile teslim eder: 300 + 200 = 500 beklenen, 520.00 teslim (+20.00 fazla)
    await request(app)
      .post(`/api/v1/cash-sessions/${session2Id}/transactions`)
      .set('Cookie', c2.cookie)
      .set('X-CSRF-Token', c2.csrf)
      .send({ paymentMethodCode: 'CASH', transactionType: 'SALE', amount: '200.00' })
      .expect(201);

    const submit2 = await request(app)
      .post(`/api/v1/cash-sessions/${session2Id}/submit`)
      .set('Cookie', c2.cookie)
      .set('X-CSRF-Token', c2.csrf)
      .send({ declaredCash: '520.00' })
      .expect(200);
    expect(submit2.body.cashDifference).toBe('20.00');
    expect(submit2.body.cashDifferenceStatus).toBe('SURPLUS');

    // Mağaza 2 yöneticisi Mağaza 1'in oturumunu göremez (403)
    await request(app)
      .get(`/api/v1/cash-sessions/${session1Id}`)
      .set('Cookie', mgr2.cookie)
      .expect(403);

    // Mağaza 1 yöneticisi her iki kasiyerin oturumlarını ve mağaza/kasiyer özetlerini görür
    const mgrList = await request(app)
      .get('/api/v1/cash-sessions?businessDate=2026-11-24')
      .set('Cookie', mgr1.cookie)
      .expect(200);
    expect(mgrList.body.items).toHaveLength(2);
    expect(mgrList.body.byCashier).toHaveLength(2);
    expect(mgrList.body.totals.expectedCashTotal).toBe('2100.00');
    expect(mgrList.body.totals.declaredCashTotal).toBe('2105.00');
    expect(mgrList.body.totals.totalShortage).toBe('15.00');
    expect(mgrList.body.totals.totalSurplus).toBe('20.00');

    // Mağaza yöneticisi Kasiyer 1 oturumunu düzeltmeye iade eder -> Kasiyer 1 yeniden teslim eder -> Mağaza yöneticisi merkeze gönderir
    const returned = await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/return`)
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({ reason: 'Kurye makbuzu tekrar sayılsın' })
      .expect(200);
    expect(returned.body.status).toBe('RETURNED_FOR_CORRECTION');

    const resubmit = await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/submit`)
      .set('Cookie', c1.cookie)
      .set('X-CSRF-Token', c1.csrf)
      .send({ declaredCash: '1600.00', notes: 'Tekrar sayıldı, eşit' })
      .expect(200);
    expect(resubmit.body.cashDifferenceStatus).toBe('EQUAL');

    const approved = await request(app)
      .post(`/api/v1/cash-sessions/${session1Id}/store-approve`)
      .set('Cookie', mgr1.cookie)
      .set('X-CSRF-Token', mgr1.csrf)
      .send({ notes: 'Kontrol edildi, merkeze gönderildi' })
      .expect(200);
    expect(approved.body.status).toBe('STORE_MANAGER_APPROVED');
  });
});
