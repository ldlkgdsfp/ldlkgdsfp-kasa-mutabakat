import type { NextFunction, Request, Response } from 'express';
import type { RoleCode } from '@kasa/shared';
import { ForbiddenError, UnauthorizedError } from '../utils/errors.js';

const GLOBAL_ROLES = new Set<RoleCode>(['SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING']);

export function hasGlobalStoreAccess(role: RoleCode): boolean {
  return GLOBAL_ROLES.has(role);
}

/**
 * Kullanıcının belirli bir storeId'ye erişim yetkisini doğrular.
 * STORE_MANAGER ve CASHIER yalnızca kendi bağlı oldukları mağazaya erişebilir.
 */
export function assertStoreAccess(
  user: { role: RoleCode; storeId: string | null },
  targetStoreId: string,
): void {
  if (hasGlobalStoreAccess(user.role)) {
    return;
  }

  if (!user.storeId || user.storeId !== targetStoreId) {
    throw new ForbiddenError('Yalnızca yetkili olduğunuz mağazanın verilerine erişebilirsiniz.');
  }
}

/**
 * Sorgu filtresi için kullanıcının erişebileceği mağaza ID'sini çözer.
 * Mağaza rolleri farklı bir storeId istese bile kesinlikle engellenir.
 */
export function resolveScopedStoreId(
  user: { role: RoleCode; storeId: string | null },
  requestedStoreId?: string,
): string | undefined {
  if (hasGlobalStoreAccess(user.role)) {
    return requestedStoreId;
  }

  if (!user.storeId) {
    throw new ForbiddenError('Hesabınıza tanımlı bir mağaza bulunmamaktadır.');
  }

  if (requestedStoreId && requestedStoreId !== user.storeId) {
    throw new ForbiddenError('Başka bir mağazanın verilerine erişim yetkiniz yoktur.');
  }

  return user.storeId;
}

/**
 * Route parametresindeki storeId alanını (varsayılan :storeId) mağaza kapsamına karşı doğrular.
 */
export function enforceStoreScopeParam(paramName = 'storeId') {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.auth) {
      next(new UnauthorizedError());
      return;
    }

    const rawParam = req.params[paramName];
    const targetStoreId = Array.isArray(rawParam) ? rawParam[0] : rawParam;
    if (!targetStoreId) {
      next();
      return;
    }

    try {
      assertStoreAccess(req.auth.user, targetStoreId);
      next();
    } catch (err) {
      next(err);
    }
  };
}
