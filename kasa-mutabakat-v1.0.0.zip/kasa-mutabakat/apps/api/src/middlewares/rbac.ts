import type { NextFunction, Request, Response } from 'express';
import type { RoleCode } from '@kasa/shared';
import { ForbiddenError, UnauthorizedError } from '../utils/errors.js';

export function requireRole(...allowedRoles: RoleCode[]) {
  const allowedSet = new Set<RoleCode>(allowedRoles);

  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.auth) {
      next(new UnauthorizedError());
      return;
    }

    if (!allowedSet.has(req.auth.user.role)) {
      next(new ForbiddenError('Bu kaynak veya işlem için rol yetkiniz bulunmamaktadır.'));
      return;
    }

    next();
  };
}
