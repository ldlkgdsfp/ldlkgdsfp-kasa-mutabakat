import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';

declare global {
  namespace Express {
    interface Request {
      requestId: string;
      clientIp: string;
    }
  }
}

export function requestContextMiddleware(req: Request, res: Response, next: NextFunction): void {
  const incomingId = req.header('x-request-id');
  req.requestId = incomingId && incomingId.length <= 64 ? incomingId : crypto.randomUUID();
  req.clientIp = req.ip ?? req.socket.remoteAddress ?? 'unknown';
  res.setHeader('X-Request-Id', req.requestId);
  next();
}
