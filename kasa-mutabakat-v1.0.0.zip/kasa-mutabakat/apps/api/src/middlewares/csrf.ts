import type { NextFunction, Request, Response } from 'express';
import { ForbiddenError, UnauthorizedError } from '../utils/errors.js';
import { timingSafeStringEqual } from '../utils/password.js';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

/**
 * Durum değiştiren (POST/PUT/PATCH/DELETE) oturumlu isteklerde
 * X-CSRF-Token başlığını sunucu taraflı oturum CSRF anahtarıyla zaman-sabit karşılaştırır.
 */
export function csrfProtection(req: Request, _res: Response, next: NextFunction): void {
  if (SAFE_METHODS.has(req.method.toUpperCase())) {
    next();
    return;
  }

  if (!req.auth) {
    next(new UnauthorizedError('Oturum doğrulaması gereklidir.'));
    return;
  }

  const headerToken = req.header('x-csrf-token');
  if (!headerToken || !timingSafeStringEqual(headerToken, req.auth.csrfToken)) {
    next(new ForbiddenError('CSRF doğrulama anahtarı eksik veya geçersiz.'));
    return;
  }

  next();
}
