import type { NextFunction, Request, Response } from 'express';
import { ROLE_LABELS_TR, type AuthUser, type RoleCode, type StoreType } from '@kasa/shared';
import { env } from '../config/env.js';
import { prisma } from '../config/prisma.js';
import { UnauthorizedError } from '../utils/errors.js';
import { sha256Hex } from '../utils/password.js';

export interface AuthContext {
  sessionId: string;
  csrfToken: string;
  expiresAt: Date;
  user: AuthUser;
}

declare global {
  namespace Express {
    interface Request {
      auth?: AuthContext;
    }
  }
}

export async function requireAuth(
  req: Request,
  _res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const rawToken = req.cookies?.[env.SESSION_COOKIE_NAME] as string | undefined;
    if (!rawToken || typeof rawToken !== 'string' || rawToken.length < 32) {
      throw new UnauthorizedError('Geçerli bir oturum bulunamadı. Lütfen giriş yapın.');
    }

    const tokenHash = sha256Hex(rawToken);
    const session = await prisma.userSession.findUnique({
      where: { tokenHash },
      include: {
        user: {
          include: {
            role: true,
            store: true,
          },
        },
      },
    });

    if (!session || session.revokedAt !== null || session.expiresAt <= new Date()) {
      throw new UnauthorizedError('Oturumunuzun süresi dolmuş veya sonlandırılmış. Lütfen tekrar giriş yapın.');
    }

    if (!session.user.isActive) {
      throw new UnauthorizedError('Kullanıcı hesabınız pasif durumdadır.');
    }

    if (session.user.store && !session.user.store.isActive) {
      throw new UnauthorizedError('Bağlı olduğunuz mağaza pasif durumdadır.');
    }

    const roleCode = session.user.role.code as RoleCode;

    req.auth = {
      sessionId: session.id,
      csrfToken: session.csrfToken,
      expiresAt: session.expiresAt,
      user: {
        id: session.user.id,
        username: session.user.username,
        email: session.user.email,
        fullName: session.user.fullName,
        role: roleCode,
        roleLabel: ROLE_LABELS_TR[roleCode],
        storeId: session.user.storeId,
        store: session.user.store
          ? {
              id: session.user.store.id,
              code: session.user.store.code,
              name: session.user.store.name,
              type: session.user.store.type as StoreType,
            }
          : null,
        isActive: session.user.isActive,
      },
    };

    next();
  } catch (err) {
    next(err);
  }
}
