import { createApp } from './app.js';
import { env } from './config/env.js';
import { logger } from './config/logger.js';
import { prisma } from './config/prisma.js';

const app = createApp();

const server = app.listen(env.PORT, '0.0.0.0', () => {
  logger.info(
    { port: env.PORT, env: env.NODE_ENV, timezone: env.APP_TIMEZONE },
    'Kasa Mutabakat API başlatıldı',
  );
});

async function shutdown(signal: string): Promise<void> {
  logger.info({ signal }, 'Sunucu güvenli kapatılıyor...');
  server.close(async () => {
    await prisma.$disconnect();
    process.exit(0);
  });
}

process.on('SIGINT', () => void shutdown('SIGINT'));
process.on('SIGTERM', () => void shutdown('SIGTERM'));
