import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { z } from 'zod';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, '../../../..');

dotenv.config({ path: path.join(repoRoot, '.env') });

// Test ortamında (Vitest / E2E) geliştirme veritabanına yazılmasını önlemek için
// TEST_DATABASE_URL tanımlıysa her zaman ona yönlendirilir.
if (process.env.NODE_ENV === 'test' && process.env.TEST_DATABASE_URL) {
  process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
}

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().min(1).max(65535).default(4000),
  APP_TIMEZONE: z.string().default('Europe/Istanbul'),
  CORS_ORIGIN: z.string().default('http://localhost:5173'),
  DATABASE_URL: z.string().min(1, 'DATABASE_URL zorunludur.'),
  SESSION_COOKIE_NAME: z.string().min(1).default('kasa_session'),
  SESSION_TTL_HOURS: z.coerce.number().int().min(1).max(168).default(12),
  COOKIE_SECURE: z
    .enum(['true', 'false'])
    .default('false')
    .transform((v) => v === 'true'),
  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().min(1000).default(900000),
  RATE_LIMIT_MAX_REQUESTS: z.coerce.number().int().min(10).default(300),
  LOGIN_RATE_LIMIT_MAX: z.coerce.number().int().min(3).default(10),
  ACCOUNT_LOCKOUT_THRESHOLD: z.coerce.number().int().min(3).default(5),
  ACCOUNT_LOCKOUT_MINUTES: z.coerce.number().int().min(1).default(15),
  UPLOAD_STORAGE_DIR: z.string().default('./storage/receipts'),
  MAX_UPLOAD_FILE_SIZE_MB: z.coerce.number().int().min(1).max(50).default(10),
  OCR_PROVIDER: z.enum(['local', 'ai_vision']).default('local'),
  OCR_MIN_CONFIDENCE_SCORE: z.coerce.number().min(0).max(100).default(80),
  OCR_AI_PROVIDER: z.string().optional().default(''),
  OCR_AI_API_KEY: z.string().optional().default(''),
  OCR_AI_MODEL: z.string().optional().default(''),
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
  console.error('Geçersiz ortam değişkenleri:', parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const env = parsed.data;
export const REPO_ROOT = repoRoot;
