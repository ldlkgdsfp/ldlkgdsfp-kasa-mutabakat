import { Router } from 'express';
import { z } from 'zod';
import type { Prisma } from '@prisma/client';
import { updateSystemSettingSchema } from '@kasa/shared';
import { prisma } from '../../config/prisma.js';
import { requireAuth } from '../../middlewares/auth.js';
import { csrfProtection } from '../../middlewares/csrf.js';
import { requireRole } from '../../middlewares/rbac.js';
import { recordAuditLog } from '../audit/audit.service.js';
import { asyncHandler } from '../../utils/async-handler.js';
import { NotFoundError, ValidationError } from '../../utils/errors.js';

const settingKeyParamSchema = z.object({
  key: z.string().trim().min(1).max(100),
});

export const settingsRouter = Router();

settingsRouter.get(
  '/',
  requireAuth,
  requireRole('SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING'),
  asyncHandler(async (_req, res) => {
    const items = await prisma.systemSetting.findMany({
      orderBy: [{ category: 'asc' }, { key: 'asc' }],
    });
    res.json({
      items: items.map((s) => ({
        key: s.key,
        valueJson: s.valueJson,
        description: s.description,
        category: s.category,
        updatedAt: s.updatedAt.toISOString(),
      })),
    });
  }),
);

settingsRouter.patch(
  '/:key',
  requireAuth,
  csrfProtection,
  requireRole('SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const { key } = settingKeyParamSchema.parse(req.params);
    const input = updateSystemSettingSchema.parse(req.body);

    const existing = await prisma.systemSetting.findUnique({ where: { key } });
    if (!existing) {
      throw new NotFoundError(`'${key}' sistem ayarı bulunamadı.`);
    }

    if (input.valueJson === undefined) {
      throw new ValidationError('Yeni ayar değeri belirtilmelidir.');
    }

    const updated = await prisma.$transaction(async (tx) => {
      const setting = await tx.systemSetting.update({
        where: { key },
        data: {
          valueJson: input.valueJson as Prisma.InputJsonValue,
          ...(input.description !== undefined ? { description: input.description } : {}),
          updatedById: req.auth!.user.id,
        },
      });

      await recordAuditLog(
        {
          actorUserId: req.auth!.user.id,
          actorRole: req.auth!.user.role,
          storeId: req.auth!.user.storeId,
          action: 'SYSTEM_SETTING_UPDATED',
          entityType: 'system_setting',
          entityId: key,
          beforeJson: { valueJson: existing.valueJson },
          afterJson: { valueJson: setting.valueJson },
          ipAddress: req.clientIp,
          userAgent: req.header('user-agent') ?? null,
          requestId: req.requestId,
        },
        tx,
      );

      return setting;
    });

    res.json({
      key: updated.key,
      valueJson: updated.valueJson,
      description: updated.description,
      category: updated.category,
      updatedAt: updated.updatedAt.toISOString(),
    });
  }),
);
