import type { Prisma } from '@prisma/client';
import { prisma } from '../../config/prisma.js';
import { computeHammingDistance } from './file-security.js';

export type DuplicateMatchReason =
  | 'FILE_HASH_MATCH'
  | 'REFERENCE_NO_MATCH'
  | 'PERCEPTUAL_HASH_MATCH'
  | 'COMPOSITE_FIELD_MATCH';

export interface DuplicateCheckResult {
  isExactDuplicate: boolean;
  isSuspectedDuplicate: boolean;
  matchedReceiptId: string | null;
  reason: DuplicateMatchReason | null;
  warningMessage: string | null;
}

export interface DuplicateCandidateInput {
  excludeReceiptId?: string;
  fileSha256: string;
  perceptualHash: string | null;
  referenceNumber: string | null;
  amount: string | null;
  transactionDate: string | null; // YYYY-MM-DD
  transactionTime: string | null; // HH:MM(:SS)
  senderName: string | null;
  iban: string | null;
  timeWindowMinutes?: number;
}

function parseMinutesOfDay(timeStr: string | null): number | null {
  if (!timeStr) return null;
  const m = /^(\d{1,2}):(\d{2})/.exec(timeStr.trim());
  if (!m) return null;
  return Number(m[1]) * 60 + Number(m[2]);
}

function normalizeName(value: string | null): string {
  if (!value) return '';
  return value
    .toLocaleLowerCase('tr-TR')
    .replace(/[^a-zçğıöşü0-9]/gi, '')
    .trim();
}

/**
 * 4 Katmanlı Mükerrer Dekont Kontrolü:
 * 1. Birebir dosya SHA-256 eşleşmesi -> KESİN MÜKERRER
 * 2. Referans / işlem numarası eşleşmesi -> KESİN MÜKERRER
 * 3. Görsel algısal özet (dHash Hamming <= 6) -> ŞÜPHELİ MÜKERRER (manuel inceleme)
 * 4. Bileşik alan eşleşmesi (aynı tutar + aynı tarih + ±N dk saat + aynı gönderen/IBAN) -> ŞÜPHELİ MÜKERRER
 */
export async function detectDuplicateReceipt(
  input: DuplicateCandidateInput,
  tx: Prisma.TransactionClient | typeof prisma = prisma,
): Promise<DuplicateCheckResult> {
  const baseWhere: Prisma.TransferReceiptWhereInput = {
    ...(input.excludeReceiptId ? { id: { not: input.excludeReceiptId } } : {}),
    status: { notIn: ['REJECTED', 'DUPLICATE'] },
    isDuplicate: false,
  };

  // Katman 1: Birebir dosya SHA-256 özeti
  const exactFileMatch = await tx.transferReceipt.findFirst({
    where: {
      ...baseWhere,
      fileSha256: input.fileSha256,
    },
    select: { id: true, originalFilename: true },
  });

  if (exactFileMatch) {
    return {
      isExactDuplicate: true,
      isSuspectedDuplicate: false,
      matchedReceiptId: exactFileMatch.id,
      reason: 'FILE_HASH_MATCH',
      warningMessage:
        'Aynı dekont dosyası (birebir SHA-256 özeti) daha önce sisteme yüklenmiştir.',
    };
  }

  // Katman 2: İşlem / Referans numarası eşleşmesi
  const normalizedRef = input.referenceNumber?.trim();
  if (normalizedRef && normalizedRef.length >= 4) {
    const exactRefMatch = await tx.transferReceipt.findFirst({
      where: {
        ...baseWhere,
        referenceNumber: { equals: normalizedRef, mode: 'insensitive' },
      },
      select: { id: true, referenceNumber: true },
    });

    if (exactRefMatch) {
      return {
        isExactDuplicate: true,
        isSuspectedDuplicate: false,
        matchedReceiptId: exactRefMatch.id,
        reason: 'REFERENCE_NO_MATCH',
        warningMessage: `Aynı işlem / referans numarasına (${normalizedRef}) sahip başka bir dekont zaten kayıtlı.`,
      };
    }
  }

  // Katman 3: Algısal görsel özet (dHash)
  if (input.perceptualHash) {
    const recentVisualReceipts = await tx.transferReceipt.findMany({
      where: {
        ...baseWhere,
        perceptualHash: { not: null },
      },
      select: { id: true, perceptualHash: true },
      orderBy: { createdAt: 'desc' },
      take: 300,
    });

    for (const candidate of recentVisualReceipts) {
      if (!candidate.perceptualHash) continue;
      const dist = computeHammingDistance(input.perceptualHash, candidate.perceptualHash);
      if (dist <= 6) {
        return {
          isExactDuplicate: false,
          isSuspectedDuplicate: true,
          matchedReceiptId: candidate.id,
          reason: 'PERCEPTUAL_HASH_MATCH',
          warningMessage:
            'Yüklenen görsel daha önce yüklenmiş bir dekontla yüksek görsel benzerlik taşıyor; manuel mükerrer kontrolü zorunludur.',
        };
      }
    }
  }

  // Katman 4: Bileşik alan eşleşmesi (Tutar + Tarih + Saat penceresi + Gönderen/IBAN)
  if (input.amount && input.transactionDate) {
    const targetDate = new Date(`${input.transactionDate}T00:00:00.000Z`);
    const sameAmountAndDate = await tx.transferReceipt.findMany({
      where: {
        ...baseWhere,
        verifiedAmount: input.amount,
        transactionDate: targetDate,
      },
      select: {
        id: true,
        transactionTime: true,
        senderName: true,
        iban: true,
      },
    });

    const timeWindow = input.timeWindowMinutes ?? 10;
    const inputMinutes = parseMinutesOfDay(input.transactionTime);
    const inputSenderNorm = normalizeName(input.senderName);
    const inputIbanNorm = input.iban?.replace(/\s+/g, '').toUpperCase() ?? '';

    for (const existing of sameAmountAndDate) {
      const existingMinutes = parseMinutesOfDay(existing.transactionTime);
      const timeMatches =
        inputMinutes === null ||
        existingMinutes === null ||
        Math.abs(inputMinutes - existingMinutes) <= timeWindow;

      if (!timeMatches) continue;

      const existingSenderNorm = normalizeName(existing.senderName);
      const existingIbanNorm = existing.iban?.replace(/\s+/g, '').toUpperCase() ?? '';

      const senderMatches =
        inputSenderNorm.length >= 3 &&
        existingSenderNorm.length >= 3 &&
        (inputSenderNorm === existingSenderNorm ||
          inputSenderNorm.includes(existingSenderNorm) ||
          existingSenderNorm.includes(inputSenderNorm));

      const ibanMatches =
        inputIbanNorm.length >= 10 &&
        existingIbanNorm.length >= 10 &&
        inputIbanNorm === existingIbanNorm;

      const bothTimesPresentAndExact =
        inputMinutes !== null &&
        existingMinutes !== null &&
        Math.abs(inputMinutes - existingMinutes) <= 2;

      if (senderMatches || ibanMatches || bothTimesPresentAndExact) {
        return {
          isExactDuplicate: false,
          isSuspectedDuplicate: true,
          matchedReceiptId: existing.id,
          reason: 'COMPOSITE_FIELD_MATCH',
          warningMessage:
            'Aynı tutar, tarih ve saat/gönderen bilgilerine sahip başka bir dekont tespit edildi; mükerrer kontrolü için manuel doğrulamaya yönlendirildi.',
        };
      }
    }
  }

  return {
    isExactDuplicate: false,
    isSuspectedDuplicate: false,
    matchedReceiptId: null,
    reason: null,
    warningMessage: null,
  };
}
