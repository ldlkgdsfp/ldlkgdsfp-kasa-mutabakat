import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import {
  bankVerifyReceiptSchema,
  centralReviewReceiptSchema,
  confirmReceiptSchema,
  receiptListQuerySchema,
} from '@kasa/shared';
import { env } from '../../config/env.js';
import { requireAuth } from '../../middlewares/auth.js';
import { csrfProtection } from '../../middlewares/csrf.js';
import { requireRole } from '../../middlewares/rbac.js';
import { asyncHandler } from '../../utils/async-handler.js';
import { ValidationError } from '../../utils/errors.js';
import {
  centralReviewReceipt,
  confirmReceiptByStore,
  getReceiptDetail,
  getReceiptFileForDownload,
  listReceipts,
  reprocessReceiptOcr,
  uploadReceipt,
  verifyReceiptBankAccount,
} from './receipts.service.js';

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: env.MAX_UPLOAD_FILE_SIZE_MB * 1024 * 1024,
    files: 1,
  },
});

const receiptIdParamSchema = z.object({
  receiptId: z.string().uuid('Geçersiz dekont kimliği.'),
});

const uploadBodySchema = z.object({
  cashSessionId: z.string().uuid('Geçerli bir kasa oturumu seçin.'),
});

export const receiptsRouter = Router();

receiptsRouter.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const query = receiptListQuerySchema.parse(req.query);
    const result = await listReceipts(req.auth!.user, query);
    res.json(result);
  }),
);

receiptsRouter.post(
  '/upload',
  requireAuth,
  csrfProtection,
  (req, res, next) => {
    upload.single('file')(req, res, (err) => {
      if (err) {
        if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') {
          next(
            new ValidationError(
              `Dosya boyutu izin verilen ${env.MAX_UPLOAD_FILE_SIZE_MB} MB sınırını aşıyor.`,
            ),
          );
          return;
        }
        next(new ValidationError(err instanceof Error ? err.message : 'Dosya yükleme hatası.'));
        return;
      }
      next();
    });
  },
  asyncHandler(async (req, res) => {
    if (!req.file) {
      throw new ValidationError('Yüklenecek dekont dosyası (JPG, JPEG, PNG veya PDF) seçilmelidir.');
    }
    const body = uploadBodySchema.parse(req.body);
    const detail = await uploadReceipt(
      {
        cashSessionId: body.cashSessionId,
        fileBuffer: req.file.buffer,
        originalFilename: req.file.originalname,
      },
      req.auth!.user,
      {
        ipAddress: req.clientIp,
        userAgent: req.header('user-agent') ?? null,
        requestId: req.requestId,
      },
    );
    res.status(201).json(detail);
  }),
);

receiptsRouter.get(
  '/:receiptId',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { receiptId } = receiptIdParamSchema.parse(req.params);
    const detail = await getReceiptDetail(receiptId, req.auth!.user);
    res.json(detail);
  }),
);

receiptsRouter.get(
  '/:receiptId/file',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { receiptId } = receiptIdParamSchema.parse(req.params);
    const fileInfo = await getReceiptFileForDownload(receiptId, req.auth!.user);

    res.setHeader('Content-Type', fileInfo.mimeType);
    res.setHeader(
      'Content-Disposition',
      `inline; filename="${encodeURIComponent(fileInfo.originalFilename)}"`,
    );
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Security-Policy', 'sandbox');
    res.setHeader('Cache-Control', 'private, no-store');

    res.sendFile(fileInfo.absolutePath);
  }),
);

receiptsRouter.post(
  '/:receiptId/confirm',
  requireAuth,
  csrfProtection,
  asyncHandler(async (req, res) => {
    const { receiptId } = receiptIdParamSchema.parse(req.params);
    const input = confirmReceiptSchema.parse(req.body);
    const updated = await confirmReceiptByStore(receiptId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);

receiptsRouter.post(
  '/:receiptId/central-review',
  requireAuth,
  csrfProtection,
  requireRole('CENTRAL_ACCOUNTING', 'SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const { receiptId } = receiptIdParamSchema.parse(req.params);
    const input = centralReviewReceiptSchema.parse(req.body);
    const updated = await centralReviewReceipt(receiptId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);

receiptsRouter.post(
  '/:receiptId/bank-verify',
  requireAuth,
  csrfProtection,
  requireRole('CENTRAL_ACCOUNTING', 'SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const { receiptId } = receiptIdParamSchema.parse(req.params);
    const input = bankVerifyReceiptSchema.parse(req.body);
    const updated = await verifyReceiptBankAccount(receiptId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);

receiptsRouter.post(
  '/:receiptId/reprocess-ocr',
  requireAuth,
  csrfProtection,
  asyncHandler(async (req, res) => {
    const { receiptId } = receiptIdParamSchema.parse(req.params);
    const updated = await reprocessReceiptOcr(receiptId, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);
