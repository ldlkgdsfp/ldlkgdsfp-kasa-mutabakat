import { execFile } from 'node:child_process';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import sharp from 'sharp';
import { env } from '../../config/env.js';
import type { AllowedReceiptMime } from './file-security.js';

const execFileAsync = promisify(execFile);

export interface OcrRawOutput {
  provider: string;
  rawText: string;
  baseQualityScore: number; // 0 - 100
  processingTimeMs: number;
  rawMetadata?: Record<string, unknown>;
}

export interface OcrProvider {
  readonly name: string;
  extractText(absoluteFilePath: string, mimeType: AllowedReceiptMime): Promise<OcrRawOutput>;
}

async function runTesseractOnImage(imagePath: string): Promise<{ text: string; confidence: number }> {
  // Hem metni hem kelime bazlı güven skorunu almak için TSV çıktısı kullan
  const { stdout: tsvOutput } = await execFileAsync(
    'tesseract',
    [imagePath, 'stdout', '-l', 'tur+eng', '--psm', '6', 'tsv'],
    { maxBuffer: 10 * 1024 * 1024, timeout: 30000 },
  );

  const lines = tsvOutput.split(/\r?\n/);
  let confSum = 0;
  let confCount = 0;
  const lineBuckets = new Map<string, string[]>();

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i]!.split('\t');
    if (cols.length < 12) continue;
    const conf = Number(cols[10]);
    const word = (cols[11] ?? '').trim();
    if (!word) continue;

    if (Number.isFinite(conf) && conf >= 0) {
      confSum += conf;
      confCount += 1;
    }

    const key = `${cols[1]}-${cols[2]}-${cols[3]}-${cols[4]}`;
    const bucket = lineBuckets.get(key) ?? [];
    bucket.push(word);
    lineBuckets.set(key, bucket);
  }

  const reconstructedText = Array.from(lineBuckets.values())
    .map((words) => words.join(' '))
    .join('\n');

  const avgConfidence = confCount > 0 ? Math.round((confSum / confCount) * 100) / 100 : 0;
  return { text: reconstructedText, confidence: avgConfidence };
}

async function preprocessImageForOcr(sourcePath: string, outputPath: string): Promise<void> {
  const image = sharp(sourcePath).rotate();
  const meta = await image.metadata();
  const targetWidth = meta.width && meta.width < 1400 ? 1800 : meta.width;

  await image
    .resize({ width: targetWidth, withoutEnlargement: false })
    .grayscale()
    .normalize()
    .sharpen()
    .png()
    .toFile(outputPath);
}

/**
 * Varsayılan yerel OCR sağlayıcısı (API anahtarı gerektirmez):
 * - Metin tabanlı PDF'lerde pdftotext ile kayıpsız metin okur.
 * - Taranmış PDF'lerde pdftoppm -> PNG -> sharp ön işleme -> Tesseract (tur+eng) çalıştırır.
 * - JPG/PNG görsellerde sharp ön işleme -> Tesseract (tur+eng) çalıştırır.
 */
export class LocalOcrProvider implements OcrProvider {
  public readonly name = 'LOCAL_TESSERACT';

  public async extractText(
    absoluteFilePath: string,
    mimeType: AllowedReceiptMime,
  ): Promise<OcrRawOutput> {
    const start = Date.now();
    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'kasa-ocr-'));

    try {
      if (mimeType === 'application/pdf') {
        // 1. Önce doğrudan metin katmanını dene (bankaların ürettiği dijital PDF dekontlar %100 net okunur)
        try {
          const { stdout: pdfText } = await execFileAsync(
            'pdftotext',
            ['-layout', absoluteFilePath, '-'],
            { maxBuffer: 10 * 1024 * 1024, timeout: 15000 },
          );
          const cleaned = pdfText.trim();
          if (cleaned.length >= 20) {
            return {
              provider: 'LOCAL_PDF_TEXT',
              rawText: cleaned,
              baseQualityScore: 98,
              processingTimeMs: Date.now() - start,
              rawMetadata: { mode: 'pdftotext' },
            };
          }
        } catch {
          // Metin çıkarılamazsa görsel render + OCR'a geç
        }

        // 2. Taranmış PDF: 1. sayfayı 250 DPI PNG'ye çevir ve Tesseract çalıştır
        const renderedPrefix = path.join(tmpDir, 'page');
        await execFileAsync(
          'pdftoppm',
          ['-png', '-r', '250', '-f', '1', '-l', '1', absoluteFilePath, renderedPrefix],
          { timeout: 25000 },
        );
        const files = await fs.readdir(tmpDir);
        const pngFile = files.find((f) => f.endsWith('.png'));
        if (!pngFile) {
          throw new Error('PDF sayfası görsele dönüştürülemedi.');
        }

        const preppedPath = path.join(tmpDir, 'prepped.png');
        await preprocessImageForOcr(path.join(tmpDir, pngFile), preppedPath);
        const { text, confidence } = await runTesseractOnImage(preppedPath);

        return {
          provider: 'LOCAL_TESSERACT_PDF',
          rawText: text,
          baseQualityScore: confidence,
          processingTimeMs: Date.now() - start,
          rawMetadata: { mode: 'pdftoppm+tesseract', wordConfidence: confidence },
        };
      }

      // JPG / PNG görselleri
      const preppedPath = path.join(tmpDir, 'prepped.png');
      await preprocessImageForOcr(absoluteFilePath, preppedPath);
      const { text, confidence } = await runTesseractOnImage(preppedPath);

      return {
        provider: 'LOCAL_TESSERACT',
        rawText: text,
        baseQualityScore: confidence,
        processingTimeMs: Date.now() - start,
        rawMetadata: { mode: 'sharp+tesseract', wordConfidence: confidence },
      };
    } finally {
      await fs.rm(tmpDir, { recursive: true, force: true }).catch(() => undefined);
    }
  }
}

/**
 * Aktif OCR sağlayıcısını ortam değişkenlerine göre seçer.
 * Harici AI API anahtarı yapılandırılmadıysa her zaman gerçek yerel OCR motoruna döner;
 * asla sahte çağrı yapmaz veya anahtar uydurmaz.
 */
export function resolveOcrProvider(): OcrProvider {
  if (env.OCR_PROVIDER === 'ai_vision' && env.OCR_AI_API_KEY && env.OCR_AI_PROVIDER) {
    // Harici AI Vision sağlayıcı bağlantısı yalnızca gerçek anahtar tanımlandığında etkinleşir;
    // aksi halde yerel OCR güvenli varsayılandır.
    return new LocalOcrProvider();
  }
  return new LocalOcrProvider();
}
