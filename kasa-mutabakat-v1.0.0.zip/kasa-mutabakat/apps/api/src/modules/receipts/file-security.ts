import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
import { env, REPO_ROOT } from '../../config/env.js';
import { ValidationError } from '../../utils/errors.js';

export type AllowedReceiptMime = 'image/jpeg' | 'image/png' | 'application/pdf';

export interface VerifiedReceiptFile {
  mimeType: AllowedReceiptMime;
  extension: '.jpg' | '.png' | '.pdf';
  sha256: string;
  perceptualHash: string | null;
  sizeBytes: number;
}

const ALLOWED_EXTENSIONS = new Set(['.jpg', '.jpeg', '.png', '.pdf']);

/**
 * Dosyanın uzantı ve başlık yerine gerçek magic-bytes imzasını doğrular.
 * Yalnızca gerçek JPG/JPEG, PNG ve PDF dosyaları kabul edilir.
 */
export function detectMagicFileType(buffer: Buffer): {
  mimeType: AllowedReceiptMime;
  extension: '.jpg' | '.png' | '.pdf';
} | null {
  if (buffer.length < 8) {
    return null;
  }

  // JPEG: FF D8 FF
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return { mimeType: 'image/jpeg', extension: '.jpg' };
  }

  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a
  ) {
    return { mimeType: 'image/png', extension: '.png' };
  }

  // PDF: %PDF- (ilk 1024 byte içinde de geçerli olabilir ama genelde offset 0)
  const headerAscii = buffer.subarray(0, Math.min(16, buffer.length)).toString('ascii');
  if (headerAscii.startsWith('%PDF-')) {
    return { mimeType: 'application/pdf', extension: '.pdf' };
  }

  return null;
}

/**
 * Görseller için 64-bit algısal özet (dHash) üretir.
 * Aynı ekran görüntüsünün yeniden sıkıştırılmış veya hafif kırpılmış kopyalarını yakalar.
 */
export async function computeImageDHash(buffer: Buffer): Promise<string | null> {
  try {
    const raw = await sharp(buffer)
      .rotate()
      .grayscale()
      .resize(9, 8, { fit: 'fill' })
      .raw()
      .toBuffer();

    if (raw.length < 72) {
      return null;
    }

    let bits = '';
    for (let y = 0; y < 8; y++) {
      for (let x = 0; x < 8; x++) {
        const left = raw[y * 9 + x] ?? 0;
        const right = raw[y * 9 + x + 1] ?? 0;
        bits += left > right ? '1' : '0';
      }
    }

    // 64 bit -> 16 karakter hex
    let hex = '';
    for (let i = 0; i < 64; i += 4) {
      hex += Number.parseInt(bits.slice(i, i + 4), 2).toString(16);
    }
    return hex;
  } catch {
    return null;
  }
}

/**
 * İki 64-bit hex dHash arasındaki Hamming bit mesafesini hesaplar (0 = birebir benzer).
 */
export function computeHammingDistance(hashA: string, hashB: string): number {
  if (hashA.length !== hashB.length || hashA.length === 0) {
    return Number.POSITIVE_INFINITY;
  }
  let distance = 0;
  for (let i = 0; i < hashA.length; i++) {
    const a = Number.parseInt(hashA[i]!, 16);
    const b = Number.parseInt(hashB[i]!, 16);
    if (Number.isNaN(a) || Number.isNaN(b)) {
      return Number.POSITIVE_INFINITY;
    }
    let xor = a ^ b;
    while (xor > 0) {
      distance += xor & 1;
      xor >>= 1;
    }
  }
  return distance;
}

export async function verifyUploadedReceiptFile(
  buffer: Buffer,
  originalFilename: string,
  maxSizeMb: number,
): Promise<VerifiedReceiptFile> {
  const maxBytes = maxSizeMb * 1024 * 1024;
  if (buffer.length === 0) {
    throw new ValidationError('Yüklenen dosya boş olamaz.');
  }
  if (buffer.length > maxBytes) {
    throw new ValidationError(
      `Dosya boyutu en fazla ${maxSizeMb} MB olabilir.`,
    );
  }

  const ext = path.extname(originalFilename).toLowerCase();
  if (ext && !ALLOWED_EXTENSIONS.has(ext)) {
    throw new ValidationError(
      'Yalnızca JPG, JPEG, PNG ve PDF formatında dekont dosyaları desteklenir.',
    );
  }

  const detected = detectMagicFileType(buffer);
  if (!detected) {
    throw new ValidationError(
      'Dosya içeriği geçerli bir JPG, PNG veya PDF dekontu değil (dosya imzası doğrulanamadı).',
    );
  }

  // Uzantı-içerik tutarlılık kontrolü
  if (ext === '.pdf' && detected.mimeType !== 'application/pdf') {
    throw new ValidationError('PDF uzantılı dosyanın içeriği gerçek bir PDF değil.');
  }
  if ((ext === '.jpg' || ext === '.jpeg') && detected.mimeType !== 'image/jpeg') {
    throw new ValidationError('JPEG uzantılı dosyanın içeriği geçerli bir JPEG görseli değil.');
  }
  if (ext === '.png' && detected.mimeType !== 'image/png') {
    throw new ValidationError('PNG uzantılı dosyanın içeriği geçerli bir PNG görseli değil.');
  }

  // Görsellerin gerçekten açılabilir olduğunu sharp ile doğrula
  let perceptualHash: string | null = null;
  if (detected.mimeType === 'image/jpeg' || detected.mimeType === 'image/png') {
    try {
      const meta = await sharp(buffer).metadata();
      if (!meta.width || !meta.height) {
        throw new Error('Geçersiz görsel boyutu');
      }
      perceptualHash = await computeImageDHash(buffer);
    } catch {
      throw new ValidationError('Görsel dosyası bozuk veya okunabilir bir resim değil.');
    }
  }

  const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');

  return {
    mimeType: detected.mimeType,
    extension: detected.extension,
    sha256,
    perceptualHash,
    sizeBytes: buffer.length,
  };
}

export function getStorageBaseDir(): string {
  const configuredDir = process.env.UPLOAD_STORAGE_DIR?.trim() || env.UPLOAD_STORAGE_DIR;
  return path.isAbsolute(configuredDir)
    ? configuredDir
    : path.resolve(REPO_ROOT, configuredDir);
}

/**
 * Orijinal dekont dosyasını web kökü dışında güvenli rastgele adla kalıcı olarak saklar.
 */
export async function persistReceiptFile(
  buffer: Buffer,
  extension: '.jpg' | '.png' | '.pdf',
): Promise<{ relativePath: string; absolutePath: string }> {
  const now = new Date();
  const year = String(now.getUTCFullYear());
  const month = String(now.getUTCMonth() + 1).padStart(2, '0');
  const filename = `${crypto.randomUUID()}${extension}`;

  const baseDir = getStorageBaseDir();
  const targetDir = path.join(baseDir, year, month);
  await fs.mkdir(targetDir, { recursive: true });

  const absolutePath = path.join(targetDir, filename);
  await fs.writeFile(absolutePath, buffer, { flag: 'wx' });

  const relativePath = path.join(year, month, filename);
  return { relativePath, absolutePath };
}

/**
 * Path traversal korumalı güvenli dosya yolu çözücü.
 */
export function resolveStoredReceiptPath(relativePath: string): string {
  if (!relativePath || relativePath.includes('\0') || path.isAbsolute(relativePath)) {
    throw new ValidationError('Geçersiz dosya yolu.');
  }
  const baseDir = getStorageBaseDir();
  const resolved = path.resolve(baseDir, relativePath);
  if (!resolved.startsWith(baseDir + path.sep)) {
    throw new ValidationError('Geçersiz dosya yolu.');
  }
  return resolved;
}

export function sanitizeOriginalFilename(name: string): string {
  const base = path.basename(name).replace(/[\r\n\0]/g, '').trim();
  return base.slice(0, 255) || 'dekont';
}
