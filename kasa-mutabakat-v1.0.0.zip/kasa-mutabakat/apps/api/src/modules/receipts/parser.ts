import { Decimal } from 'decimal.js';
import type { DetectedAmountItem } from '@kasa/shared';
import { formatFixed2 } from '../reconciliation/calculator.js';

export interface ParsedReceiptData {
  extractedAmount: string | null;
  detectedAmounts: DetectedAmountItem[];
  excludedBalanceAmounts: DetectedAmountItem[];
  transactionDate: string | null; // YYYY-MM-DD
  transactionTime: string | null; // HH:MM or HH:MM:SS
  senderName: string | null;
  receiverName: string | null;
  senderBank: string | null;
  receiverBank: string | null;
  iban: string | null;
  referenceNumber: string | null;
  description: string | null;
  confidenceScore: string;
  fieldConfidences: Record<string, number>;
  warnings: string[];
  requiresManualReview: boolean;
}

const KNOWN_TURKISH_BANKS: Array<{ pattern: RegExp; canonical: string }> = [
  { pattern: /ziraat\s*bankas[ıi]|t\.?\s*c\.?\s*ziraat/i, canonical: 'T.C. Ziraat Bankası' },
  { pattern: /t[üu]rkiye\s*[iİı]ş\s*bankas[ıi]|[iİı]ş\s*bankas[ıi]|isbank/i, canonical: 'Türkiye İş Bankası' },
  { pattern: /garanti\s*bbva|garanti\s*bankas[ıi]/i, canonical: 'Garanti BBVA' },
  { pattern: /akbank/i, canonical: 'Akbank' },
  { pattern: /yap[ıi]\s*kredi/i, canonical: 'Yapı Kredi' },
  { pattern: /vak[ıi]f\s*bank|vak[ıi]flar\s*bankas[ıi]/i, canonical: 'VakıfBank' },
  { pattern: /halk\s*bank|halkbankas[ıi]/i, canonical: 'Halkbank' },
  { pattern: /qnb\s*finansbank|qnb\s*bank|finansbank/i, canonical: 'QNB Bank' },
  { pattern: /deniz\s*bank/i, canonical: 'DenizBank' },
  { pattern: /enpara/i, canonical: 'Enpara.com' },
  { pattern: /kuveyt\s*t[üu]rk/i, canonical: 'Kuveyt Türk' },
  { pattern: /albaraka/i, canonical: 'Albaraka Türk' },
  { pattern: /t[üu]rkiye\s*finans/i, canonical: 'Türkiye Finans' },
  { pattern: /teb\b|t[üu]rk\s*ekonomi\s*bankas[ıi]/i, canonical: 'TEB' },
  { pattern: /\bing\s*bank|\bing\s*t[üu]rkiye/i, canonical: 'ING' },
  { pattern: /şeker\s*bank|seker\s*bank/i, canonical: 'Şekerbank' },
  { pattern: /fiba\s*banka/i, canonical: 'Fibabanka' },
  { pattern: /odea\s*bank/i, canonical: 'Odeabank' },
  { pattern: /papara/i, canonical: 'Papara' },
  { pattern: /emlak\s*kat[ıi]l[ıi]m/i, canonical: 'Emlak Katılım' },
  { pattern: /ziraat\s*kat[ıi]l[ıi]m/i, canonical: 'Ziraat Katılım' },
  { pattern: /vak[ıi]f\s*kat[ıi]l[ıi]m/i, canonical: 'Vakıf Katılım' },
];

const BALANCE_LINE_REGEX =
  /(bakiye|kullan[ıi]labilir\s*bakiye|g[üu]ncel\s*bakiye|son\s*bakiye|kalan\s*bakiye|i[şs]lem\s*sonras[ıi]\s*bakiye|hesap\s*bakiyesi|mevcut\s*bakiye|available\s*balance|current\s*balance|ending\s*balance|balance)/i;

const FEE_LINE_REGEX =
  /(masraf|komisyon|bsmv|i[şs]lem\s*[üu]creti|havale\s*[üu]creti|eft\s*[üu]creti|fast\s*[üu]creti|banka\s*[üu]creti|vergi|[üu]cret\s*toplam|fee|commission)/i;

const TRANSFER_AMOUNT_LABEL_REGEX =
  /(transfer\s*tutar[ıi]|i[şs]lem\s*tutar[ıi]|g[öo]nderilen\s*tutar|havale\s*tutar[ıi]|eft\s*tutar[ıi]|fast\s*tutar[ıi]|ödenen\s*tutar|odenen\s*tutar|net\s*tutar|^tutar\b|\btutar\s*[:=]|amount)/i;

const TURKISH_MONTHS: Record<string, string> = {
  ocak: '01',
  şubat: '02',
  subat: '02',
  mart: '03',
  nisan: '04',
  mayıs: '05',
  mayis: '05',
  haziran: '06',
  temmuz: '07',
  ağustos: '08',
  agustos: '08',
  eylül: '09',
  eylul: '09',
  ekim: '10',
  kasım: '11',
  kasim: '11',
  aralık: '12',
  aralik: '12',
};

/**
 * Türkçe (1.250,50) veya uluslararası (1,250.50 / 1250.50) tutar metnini Decimal stringe çevirir.
 */
export function parseTurkishMoney(raw: string): string | null {
  const cleaned = raw.replace(/\s+/g, '').replace(/[₺]/g, '').replace(/TL|TRY/gi, '');
  if (!/^\d[\d.,]*$/.test(cleaned)) {
    return null;
  }

  let normalized = cleaned;
  const hasComma = cleaned.includes(',');
  const hasDot = cleaned.includes('.');

  if (hasComma && hasDot) {
    const lastComma = cleaned.lastIndexOf(',');
    const lastDot = cleaned.lastIndexOf('.');
    if (lastComma > lastDot) {
      // TR format: 12.345,67
      normalized = cleaned.replace(/\./g, '').replace(',', '.');
    } else {
      // US format: 12,345.67
      normalized = cleaned.replace(/,/g, '');
    }
  } else if (hasComma) {
    const parts = cleaned.split(',');
    if (parts.length === 2 && parts[1]!.length <= 2) {
      normalized = `${parts[0]}.${parts[1]}`;
    } else {
      normalized = cleaned.replace(/,/g, '');
    }
  } else if (hasDot) {
    const parts = cleaned.split('.');
    if (parts.length === 2 && parts[1]!.length === 2) {
      normalized = cleaned;
    } else if (parts.length >= 2 && parts.slice(1).every((p) => p.length === 3)) {
      // Binlik ayraç: 1.250 veya 1.250.000
      normalized = cleaned.replace(/\./g, '');
    }
  }

  if (!/^\d+(\.\d{1,2})?$/.test(normalized)) {
    return null;
  }

  try {
    const dec = new Decimal(normalized);
    if (dec.lte(0) || dec.gt('999999999999.99')) {
      return null;
    }
    return formatFixed2(dec);
  } catch {
    return null;
  }
}

/**
 * Türk IBAN'ı (TR + 24 rakam = 26 karakter) MOD-97 sağlama toplamı ile doğrular.
 */
export function validateTurkishIban(iban: string): boolean {
  const clean = iban.replace(/\s+/g, '').toUpperCase();
  if (!/^TR\d{24}$/.test(clean)) {
    return false;
  }
  const rearranged = clean.slice(4) + clean.slice(0, 4);
  let numeric = '';
  for (const ch of rearranged) {
    const code = ch.charCodeAt(0);
    if (code >= 65 && code <= 90) {
      numeric += String(code - 55);
    } else {
      numeric += ch;
    }
  }
  let remainder = 0;
  for (let i = 0; i < numeric.length; i++) {
    remainder = (remainder * 10 + Number(numeric[i])) % 97;
  }
  return remainder === 1;
}

function extractLabeledValue(lines: string[], labelPatterns: RegExp[]): string | null {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;
    for (const pat of labelPatterns) {
      const m = pat.exec(line);
      if (m) {
        const inlineValue = (m[1] ?? '').trim();
        if (inlineValue.length >= 2) {
          return inlineValue;
        }
        // Değer bir sonraki satırda olabilir
        const nextLine = lines[i + 1]?.trim();
        if (nextLine && nextLine.length >= 2 && !nextLine.includes(':')) {
          return nextLine;
        }
      }
    }
  }
  return null;
}

function normalizeTurkishLower(text: string): string {
  return text.toLocaleLowerCase('tr-TR').replace(/\u0307/g, '');
}

function detectBankInText(text: string): string | null {
  const normalized = normalizeTurkishLower(text);
  for (const b of KNOWN_TURKISH_BANKS) {
    if (b.pattern.test(normalized)) {
      return b.canonical;
    }
  }
  return null;
}

function extractDateAndTime(lines: string[]): {
  date: string | null;
  time: string | null;
} {
  const fullText = lines.join('\n');

  // Öncelikle tarih etiketli satırlarda ara
  const datePriorityLines = lines.filter((l) =>
    /(tarih|i[şs]lem\s*tarihi|val[öo]r|date)/i.test(l),
  );
  const searchTargets = [...datePriorityLines, fullText];

  let date: string | null = null;
  for (const target of searchTargets) {
    // DD.MM.YYYY veya DD/MM/YYYY veya DD-MM-YYYY
    const dmy = /\b(0?[1-9]|[12]\d|3[01])[./-](0?[1-9]|1[0-2])[./-](20\d{2})\b/.exec(target);
    if (dmy) {
      date = `${dmy[3]}-${dmy[2]!.padStart(2, '0')}-${dmy[1]!.padStart(2, '0')}`;
      break;
    }

    // YYYY-MM-DD
    const ymd = /\b(20\d{2})[-./](0?[1-9]|1[0-2])[-./](0?[1-9]|[12]\d|3[01])\b/.exec(target);
    if (ymd) {
      date = `${ymd[1]}-${ymd[2]!.padStart(2, '0')}-${ymd[3]!.padStart(2, '0')}`;
      break;
    }

    // 24 Kasım 2026
    const trTextDate =
      /\b(0?[1-9]|[12]\d|3[01])\s+(ocak|şubat|subat|mart|nisan|mayıs|mayis|haziran|temmuz|ağustos|agustos|eylül|eylul|ekim|kasım|kasim|aralık|aralik)\s+(20\d{2})\b/i.exec(
        target,
      );
    if (trTextDate) {
      const month = TURKISH_MONTHS[trTextDate[2]!.toLowerCase()];
      if (month) {
        date = `${trTextDate[3]}-${month}-${trTextDate[1]!.padStart(2, '0')}`;
        break;
      }
    }
  }

  let time: string | null = null;
  const timePriorityLines = lines.filter((l) => /(saat|tarih|time)/i.test(l));
  for (const target of [...timePriorityLines, fullText]) {
    const tm = /\b([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?\b/.exec(target);
    if (tm) {
      time = tm[3]
        ? `${tm[1]!.padStart(2, '0')}:${tm[2]}:${tm[3]}`
        : `${tm[1]!.padStart(2, '0')}:${tm[2]}`;
      break;
    }
  }

  return { date, time };
}

/**
 * Türk banka havale/EFT/FAST dekontu ham metnini deterministik finansal kurallarla ayrıştırır.
 *
 * KRİTİK KURALLAR:
 * 1. Hesap bakiyesi ("Bakiye", "Kullanılabilir Bakiye" vb.) ASLA transfer tutarı kabul edilmez.
 * 2. Masraf / Komisyon / BSMV tutarları transfer tutarından ayrılır.
 * 3. Çoklu belirsiz tutar veya düşük güven skoru durumunda requiresManualReview = true döner.
 */
export function parseTurkishBankReceipt(
  rawText: string,
  ocrBaseQuality = 90,
  minConfidenceThreshold = 80,
): ParsedReceiptData {
  const warnings: string[] = [];
  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.replace(/\s+/g, ' ').trim())
    .filter((l) => l.length > 0);

  if (lines.length === 0) {
    return {
      extractedAmount: null,
      detectedAmounts: [],
      excludedBalanceAmounts: [],
      transactionDate: null,
      transactionTime: null,
      senderName: null,
      receiverName: null,
      senderBank: null,
      receiverBank: null,
      iban: null,
      referenceNumber: null,
      description: null,
      confidenceScore: '0.00',
      fieldConfidences: {},
      warnings: ['Dekont üzerinde okunabilir metin tespit edilemedi.'],
      requiresManualReview: true,
    };
  }

  const detectedAmounts: DetectedAmountItem[] = [];
  const excludedBalanceAmounts: DetectedAmountItem[] = [];

  // Para tutarı yakalama regex'i: para birimi yanında VEYA etiketli tutar satırında
  const moneyWithCurrencyRegex =
    /(?:₺|TL|TRY)\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?)|(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(?:₺|TL\b|TRY\b)/gi;
  const plainDecimalRegex = /\b(\d{1,3}(?:\.\d{3})+,\d{2}|\d+,\d{2}|\d+\.\d{2})\b/g;

  for (const line of lines) {
    // Tarih veya IBAN içindeki sayıların yanlışlıkla para sanılmasını engelle
    const sanitizedForMoney = line
      .replace(/TR\s*(?:\d\s*){24}/gi, ' ')
      .replace(/\b\d{1,2}[./-]\d{1,2}[./-]20\d{2}\b/g, ' ')
      .replace(/\b20\d{2}[./-]\d{1,2}[./-]\d{1,2}\b/g, ' ');

    const isBalance = BALANCE_LINE_REGEX.test(line);
    const isFee = !isBalance && FEE_LINE_REGEX.test(line);
    const isTransferLabeled = !isBalance && !isFee && TRANSFER_AMOUNT_LABEL_REGEX.test(line);

    const foundInLine: Array<{ raw: string; amount: string }> = [];
    for (const match of sanitizedForMoney.matchAll(moneyWithCurrencyRegex)) {
      const rawNum = match[1] ?? match[2] ?? '';
      const parsed = parseTurkishMoney(rawNum);
      if (parsed) {
        foundInLine.push({ raw: match[0].trim(), amount: parsed });
      }
    }

    // Etiketli satırda para birimi simgesi unutulmuşsa (örn. "İşlem Tutarı: 1.250,00")
    if (foundInLine.length === 0 && (isBalance || isFee || isTransferLabeled)) {
      for (const match of sanitizedForMoney.matchAll(plainDecimalRegex)) {
        const parsed = parseTurkishMoney(match[1] ?? '');
        if (parsed) {
          foundInLine.push({ raw: match[1]!, amount: parsed });
        }
      }
    }

    for (const item of foundInLine) {
      const classification: DetectedAmountItem['classification'] = isBalance
        ? 'BALANCE'
        : isFee
          ? 'FEE'
          : isTransferLabeled
            ? 'TRANSFER_CANDIDATE'
            : 'UNKNOWN';

      const entry: DetectedAmountItem = {
        raw: item.raw,
        amount: item.amount,
        line,
        classification,
      };
      detectedAmounts.push(entry);
      if (classification === 'BALANCE') {
        excludedBalanceAmounts.push(entry);
      }
    }
  }

  // Transfer tutarını belirle (hesap bakiyesi ve masraflar kesinlikle dışlanır)
  const labeledCandidates = detectedAmounts.filter((a) => a.classification === 'TRANSFER_CANDIDATE');
  const unknownCandidates = detectedAmounts.filter((a) => a.classification === 'UNKNOWN');

  let extractedAmount: string | null = null;
  let amountAmbiguous = false;

  const uniqueLabeledValues = Array.from(new Set(labeledCandidates.map((a) => a.amount)));
  const uniqueUnknownValues = Array.from(new Set(unknownCandidates.map((a) => a.amount)));

  if (uniqueLabeledValues.length === 1) {
    extractedAmount = uniqueLabeledValues[0]!;
  } else if (uniqueLabeledValues.length > 1) {
    // Öncelik: "Transfer Tutarı" / "Gönderilen Tutar" / "İşlem Tutarı" etiketi
    const strictPrimary = labeledCandidates.filter((a) =>
      /(transfer\s*tutar[ıi]|i[şs]lem\s*tutar[ıi]|g[öo]nderilen\s*tutar|havale\s*tutar[ıi]|eft\s*tutar[ıi]|fast\s*tutar[ıi])/i.test(
        a.line,
      ),
    );
    const uniqueStrict = Array.from(new Set(strictPrimary.map((a) => a.amount)));
    if (uniqueStrict.length === 1) {
      extractedAmount = uniqueStrict[0]!;
    } else {
      extractedAmount = uniqueLabeledValues[0]!;
      amountAmbiguous = true;
      warnings.push(
        `Dekontta birden fazla farklı aday tutar tespit edildi (${uniqueLabeledValues.join(', ')} ₺); manuel doğrulama zorunludur.`,
      );
    }
  } else if (uniqueUnknownValues.length === 1) {
    extractedAmount = uniqueUnknownValues[0]!;
    warnings.push('Tutar alanı açık etiket olmadan tespit edildi; tutarı kontrol edin.');
  } else if (uniqueUnknownValues.length > 1) {
    extractedAmount = uniqueUnknownValues[0]!;
    amountAmbiguous = true;
    warnings.push(
      `Dekontta etiketsiz birden fazla tutar bulundu (${uniqueUnknownValues.join(', ')} ₺); manuel doğrulama zorunludur.`,
    );
  } else if (excludedBalanceAmounts.length > 0) {
    warnings.push(
      'Dekontta yalnızca hesap bakiyesi tespit edildi; bakiye transfer tutarı olarak kabul edilmedi. Lütfen transfer tutarını manuel girin.',
    );
  } else {
    warnings.push('Transfer tutarı okunamadı; manuel doğrulama gereklidir.');
  }

  // Tarih ve saat
  const { date: transactionDate, time: transactionTime } = extractDateAndTime(lines);
  if (!transactionDate) {
    warnings.push('İşlem tarihi tespit edilemedi.');
  }

  // IBAN (TR + 24 rakam, boşluklu olabilir)
  const ibanMatch = /\b(TR(?:\s*\d){24})\b/i.exec(rawText);
  let iban: string | null = null;
  let ibanValid = false;
  if (ibanMatch) {
    iban = ibanMatch[1]!.replace(/\s+/g, '').toUpperCase();
    ibanValid = validateTurkishIban(iban);
    if (!ibanValid) {
      warnings.push(`Tespit edilen IBAN (${iban}) doğrulama sağlama toplamından geçmedi; kontrol edin.`);
    }
  }

  // Gönderen / Alıcı
  const senderName = extractLabeledValue(lines, [
    /(?:g[öo]nderen(?:\s*ad[ıi]\s*soyad[ıi]|\s*ad[ıi]|\s*[üu]nvan[ıi]?)?|g[öo]nderici|bor[çc]lu\s*hesap\s*sahibi|[öo]deyen)\s*[:=-]\s*(.+)$/i,
  ]);
  const receiverName = extractLabeledValue(lines, [
    /(?:al[ıi]c[ıi](?:\s*ad[ıi]\s*soyad[ıi]|\s*ad[ıi]|\s*[üu]nvan[ıi]?)?|lehdar|alacakl[ıi]\s*hesap\s*sahibi)\s*[:=-]\s*(.+)$/i,
  ]);

  // Bankalar
  const senderBankLabeled = extractLabeledValue(lines, [
    /(?:g[öo]nderen\s*banka|g[öo]nderici\s*banka|ç[ıi]k[ıi][şs]\s*bankas[ıi])\s*[:=-]\s*(.+)$/i,
  ]);
  const receiverBankLabeled = extractLabeledValue(lines, [
    /(?:al[ıi]c[ıi]\s*banka|kar[şs][ıi]\s*banka|hedef\s*banka)\s*[:=-]\s*(.+)$/i,
  ]);
  const headerBank = detectBankInText(lines.slice(0, 5).join(' ')) ?? detectBankInText(rawText);
  const senderBank = senderBankLabeled
    ? (detectBankInText(senderBankLabeled) ?? senderBankLabeled)
    : headerBank;
  const receiverBank = receiverBankLabeled
    ? (detectBankInText(receiverBankLabeled) ?? receiverBankLabeled)
    : null;

  // Referans / İşlem / FAST Sorgu No
  const referenceNumber = extractLabeledValue(lines, [
    /(?:fast\s*sorgu\s*no|sorgu\s*no|dekont\s*no|i[şs]lem\s*no|i[şs]lem\s*numaras[ıi]|referans\s*no|ref\.?\s*no|fi[şs]\s*no|eft\s*referans|reference(?:\s*no|\s*number)?)\s*[:=-]\s*([A-Za-z0-9/_-]{4,80})/i,
  ]);
  if (!referenceNumber) {
    warnings.push('İşlem / referans numarası tespit edilemedi.');
  }

  // Açıklama
  const description = extractLabeledValue(lines, [
    /(?:i[şs]lem\s*a[çc][ıi]klamas[ıi]|a[çc][ıi]klama|description)\s*[:=-]\s*(.+)$/i,
  ]);

  // Alan bazlı ve genel güven skoru hesabı
  const fieldConfidences: Record<string, number> = {
    amount: extractedAmount ? (amountAmbiguous ? 45 : labeledCandidates.length > 0 ? 96 : 75) : 0,
    date: transactionDate ? 95 : 0,
    time: transactionTime ? 90 : 0,
    iban: iban ? (ibanValid ? 98 : 40) : 0,
    referenceNumber: referenceNumber ? 92 : 0,
    senderName: senderName ? 88 : 0,
    receiverName: receiverName ? 88 : 0,
    bank: senderBank ? 90 : 0,
  };

  let weightedScore = 0;
  weightedScore += fieldConfidences.amount! * 0.35;
  weightedScore += fieldConfidences.date! * 0.15;
  weightedScore += fieldConfidences.referenceNumber! * 0.15;
  weightedScore += (fieldConfidences.senderName! > 0 || fieldConfidences.receiverName! > 0 ? 90 : 0) * 0.12;
  weightedScore += fieldConfidences.iban! * 0.10;
  weightedScore += Math.min(100, Math.max(0, ocrBaseQuality)) * 0.13;

  if (amountAmbiguous) {
    weightedScore = Math.min(weightedScore, 60);
  }
  if (!extractedAmount) {
    weightedScore = Math.min(weightedScore, 40);
  }

  const confidenceScore = formatFixed2(new Decimal(Math.min(100, Math.max(0, weightedScore))));
  const requiresManualReview =
    !extractedAmount ||
    amountAmbiguous ||
    new Decimal(confidenceScore).lt(minConfidenceThreshold) ||
    (iban !== null && !ibanValid);

  return {
    extractedAmount,
    detectedAmounts,
    excludedBalanceAmounts,
    transactionDate,
    transactionTime,
    senderName,
    receiverName,
    senderBank,
    receiverBank,
    iban,
    referenceNumber,
    description,
    confidenceScore,
    fieldConfidences,
    warnings,
    requiresManualReview,
  };
}
