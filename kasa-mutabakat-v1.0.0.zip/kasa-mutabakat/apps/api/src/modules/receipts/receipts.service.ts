import fs from 'node:fs/promises';
import { Prisma } from '@prisma/client';
import {
  RECEIPT_STATUS_LABELS_TR,
  type BankVerifyReceiptInput,
  type CentralReviewReceiptInput,
  type ConfirmReceiptInput,
  type DetectedAmountItem,
  type ReceiptOcrResultDTO,
  type ReceiptStatus,
  type ReceiptVerificationDTO,
  type ReceiptVerificationStage,
  type RoleCode,
  type TransferReceiptDetailDTO,
  type TransferReceiptSummaryDTO,
} from '@kasa/shared';
import { Decimal } from 'decimal.js';
import { env } from '../../config/env.js';
import { prisma } from '../../config/prisma.js';
import { assertStoreAccess, resolveScopedStoreId } from '../../middlewares/store-scope.js';
import { recordAuditLog } from '../audit/audit.service.js';
import type { RequestMeta } from '../auth/auth.service.js';
import { recalculateCashSession } from '../cash-sessions/cash-sessions.service.js';
import { formatFixed2, toDecimal } from '../reconciliation/calculator.js';
import {
  ConflictError,
  ForbiddenError,
  NotFoundError,
  ValidationError,
} from '../../utils/errors.js';
import { detectDuplicateReceipt } from './duplicate-detector.js';
import {
  persistReceiptFile,
  resolveStoredReceiptPath,
  sanitizeOriginalFilename,
  verifyUploadedReceiptFile,
  type AllowedReceiptMime,
} from './file-security.js';
import { resolveOcrProvider } from './ocr-provider.js';
import { parseTurkishBankReceipt } from './parser.js';

type Actor = { id: string; role: RoleCode; storeId: string | null };

function parseDateOnly(iso: string | null | undefined): Date | null {
  if (!iso) return null;
  return new Date(`${iso}T00:00:00.000Z`);
}

function formatDateOnly(d: Date | null): string | null {
  return d ? d.toISOString().slice(0, 10) : null;
}

function asStringArray(json: Prisma.JsonValue | null | undefined): string[] {
  if (!Array.isArray(json)) return [];
  return json.filter((item): item is string => typeof item === 'string');
}

function asDetectedAmounts(json: Prisma.JsonValue | null | undefined): DetectedAmountItem[] {
  if (!Array.isArray(json)) return [];
  return json as unknown as DetectedAmountItem[];
}

function mapOcrResult(o: {
  id: string;
  provider: string;
  rawText: string;
  extractedAmount: Prisma.Decimal | null;
  detectedAmountsJson: Prisma.JsonValue | null;
  excludedBalanceAmountsJson: Prisma.JsonValue | null;
  transactionDate: Date | null;
  transactionTime: string | null;
  senderName: string | null;
  receiverName: string | null;
  senderBank: string | null;
  receiverBank: string | null;
  iban: string | null;
  referenceNumber: string | null;
  description: string | null;
  confidenceScore: Prisma.Decimal;
  warningsJson: Prisma.JsonValue | null;
  processingTimeMs: number | null;
  createdAt: Date;
}): ReceiptOcrResultDTO {
  return {
    id: o.id,
    provider: o.provider,
    rawText: o.rawText,
    extractedAmount:
      o.extractedAmount !== null ? formatFixed2(toDecimal(o.extractedAmount.toString())) : null,
    detectedAmounts: asDetectedAmounts(o.detectedAmountsJson),
    excludedBalanceAmounts: asDetectedAmounts(o.excludedBalanceAmountsJson),
    transactionDate: formatDateOnly(o.transactionDate),
    transactionTime: o.transactionTime,
    senderName: o.senderName,
    receiverName: o.receiverName,
    senderBank: o.senderBank,
    receiverBank: o.receiverBank,
    iban: o.iban,
    referenceNumber: o.referenceNumber,
    description: o.description,
    confidenceScore: formatFixed2(toDecimal(o.confidenceScore.toString())),
    warnings: asStringArray(o.warningsJson),
    processingTimeMs: o.processingTimeMs,
    createdAt: o.createdAt.toISOString(),
  };
}

function mapReceiptSummary(
  r: {
    id: string;
    storeId: string;
    store: { id: string; code: string; name: string };
    cashierId: string;
    cashier: { id: string; username: string; fullName: string };
    cashSessionId: string;
    cashSession: { businessDate: Date };
    originalFilename: string;
    mimeType: string;
    fileSizeBytes: number;
    status: string;
    verifiedAmount: Prisma.Decimal | null;
    transactionDate: Date | null;
    transactionTime: string | null;
    senderName: string | null;
    receiverName: string | null;
    senderBank: string | null;
    receiverBank: string | null;
    iban: string | null;
    referenceNumber: string | null;
    description: string | null;
    isDuplicate: boolean;
    duplicateOfReceiptId: string | null;
    duplicateReason: string | null;
    bankAccountVerified: boolean;
    bankVerifiedAt: Date | null;
    includedInReconciliation: boolean;
    createdAt: Date;
    updatedAt: Date;
    ocrResults?: Array<{
      confidenceScore: Prisma.Decimal;
      warningsJson: Prisma.JsonValue | null;
    }>;
  },
): TransferReceiptSummaryDTO {
  const status = r.status as ReceiptStatus;
  const latestOcr = r.ocrResults?.[0];

  return {
    id: r.id,
    storeId: r.storeId,
    store: r.store,
    cashierId: r.cashierId,
    cashier: r.cashier,
    cashSessionId: r.cashSessionId,
    sessionBusinessDate: r.cashSession.businessDate.toISOString().slice(0, 10),
    originalFilename: r.originalFilename,
    mimeType: r.mimeType,
    fileSizeBytes: r.fileSizeBytes,
    status,
    statusLabel: RECEIPT_STATUS_LABELS_TR[status],
    verifiedAmount:
      r.verifiedAmount !== null ? formatFixed2(toDecimal(r.verifiedAmount.toString())) : null,
    transactionDate: formatDateOnly(r.transactionDate),
    transactionTime: r.transactionTime,
    senderName: r.senderName,
    receiverName: r.receiverName,
    senderBank: r.senderBank,
    receiverBank: r.receiverBank,
    iban: r.iban,
    referenceNumber: r.referenceNumber,
    description: r.description,
    isDuplicate: r.isDuplicate,
    duplicateOfReceiptId: r.duplicateOfReceiptId,
    duplicateReason: r.duplicateReason,
    bankAccountVerified: r.bankAccountVerified,
    bankVerifiedAt: r.bankVerifiedAt ? r.bankVerifiedAt.toISOString() : null,
    includedInReconciliation: r.includedInReconciliation,
    latestConfidenceScore: latestOcr
      ? formatFixed2(toDecimal(latestOcr.confidenceScore.toString()))
      : null,
    latestWarnings: latestOcr ? asStringArray(latestOcr.warningsJson) : [],
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  };
}

async function getNumericSetting(key: string, fallback: number): Promise<number> {
  const setting = await prisma.systemSetting.findUnique({ where: { key } });
  if (!setting) return fallback;
  const num = Number(setting.valueJson);
  return Number.isFinite(num) ? num : fallback;
}

export async function uploadReceipt(
  params: {
    cashSessionId: string;
    fileBuffer: Buffer;
    originalFilename: string;
  },
  actor: Actor,
  meta: RequestMeta,
): Promise<TransferReceiptDetailDTO> {
  if (actor.role === 'CENTRAL_ACCOUNTING') {
    throw new ForbiddenError('Merkez muhasebe personeli mağaza adına yeni dekont yükleyemez.');
  }

  const session = await prisma.cashSession.findUnique({
    where: { id: params.cashSessionId },
    include: { store: true },
  });
  if (!session) {
    throw new NotFoundError('Dekontun bağlanacağı kasa oturumu bulunamadı.');
  }

  assertStoreAccess(actor, session.storeId);
  if (actor.role === 'CASHIER' && session.cashierId !== actor.id) {
    throw new ForbiddenError('Kasiyer yalnızca kendi kasa oturumuna dekont yükleyebilir.');
  }

  if (
    session.isLocked ||
    (session.status !== 'OPEN' && session.status !== 'RETURNED_FOR_CORRECTION')
  ) {
    throw new ConflictError(
      'Teslim edilmiş, onaylanmış veya kilitli kasa oturumuna yeni dekont yüklenemez.',
    );
  }

  const [maxSizeMb, minConfidence, timeWindowMin] = await Promise.all([
    getNumericSetting('max_upload_file_size_mb', env.MAX_UPLOAD_FILE_SIZE_MB),
    getNumericSetting('ocr_min_confidence_score', env.OCR_MIN_CONFIDENCE_SCORE),
    getNumericSetting('duplicate_time_window_minutes', 10),
  ]);

  const verifiedFile = await verifyUploadedReceiptFile(
    params.fileBuffer,
    params.originalFilename,
    maxSizeMb,
  );
  const safeFilename = sanitizeOriginalFilename(params.originalFilename);
  const { relativePath, absolutePath } = await persistReceiptFile(
    params.fileBuffer,
    verifiedFile.extension,
  );

  // 1. Orijinal kaydı UPLOADED olarak oluştur (asla silinmez)
  const initialReceipt = await prisma.transferReceipt.create({
    data: {
      storeId: session.storeId,
      cashierId: session.cashierId,
      cashSessionId: session.id,
      originalFilename: safeFilename,
      storedPath: relativePath,
      mimeType: verifiedFile.mimeType,
      fileSizeBytes: verifiedFile.sizeBytes,
      fileSha256: verifiedFile.sha256,
      perceptualHash: verifiedFile.perceptualHash,
      status: 'UPLOADED',
    },
  });

  // 2. OCR işleme aşamasına geç
  await prisma.transferReceipt.update({
    where: { id: initialReceipt.id },
    data: { status: 'OCR_PROCESSING' },
  });

  let ocrFailed = false;
  let ocrFailureReason = '';
  let ocrProviderName = 'LOCAL_TESSERACT';
  let rawText = '';
  let processingTimeMs = 0;
  let rawMetadata: Record<string, unknown> | undefined;
  let parsed = parseTurkishBankReceipt('', 0, minConfidence);

  try {
    const provider = resolveOcrProvider();
    const rawOut = await provider.extractText(absolutePath, verifiedFile.mimeType);
    ocrProviderName = rawOut.provider;
    rawText = rawOut.rawText;
    processingTimeMs = rawOut.processingTimeMs;
    rawMetadata = rawOut.rawMetadata;
    parsed = parseTurkishBankReceipt(rawText, rawOut.baseQualityScore, minConfidence);
    if (rawText.trim().length < 5) {
      ocrFailed = true;
      ocrFailureReason = 'Görsel veya PDF üzerinden okunabilir metin çıkarılamadı.';
    }
  } catch (err) {
    ocrFailed = true;
    ocrFailureReason =
      err instanceof Error ? err.message : 'OCR servisi çalıştırılırken beklenmeyen hata oluştu.';
  }

  // 3. 4 katmanlı mükerrer kontrolü (OCR başarısız olsa dahi Katman 1 dosya hash + Katman 3 görsel dHash çalışır!)
  const dupResult = await detectDuplicateReceipt({
    excludeReceiptId: initialReceipt.id,
    fileSha256: verifiedFile.sha256,
    perceptualHash: verifiedFile.perceptualHash,
    referenceNumber: parsed.referenceNumber,
    amount: parsed.extractedAmount,
    transactionDate: parsed.transactionDate,
    transactionTime: parsed.transactionTime,
    senderName: parsed.senderName,
    iban: parsed.iban,
    timeWindowMinutes: timeWindowMin,
  });

  const allWarnings = [...parsed.warnings];
  if (ocrFailed && ocrFailureReason) {
    allWarnings.unshift(ocrFailureReason);
  }
  if (dupResult.warningMessage) {
    allWarnings.unshift(dupResult.warningMessage);
  }

  let nextStatus: ReceiptStatus;
  if (dupResult.isExactDuplicate) {
    nextStatus = 'DUPLICATE';
  } else if (ocrFailed) {
    nextStatus = 'FAILED_OCR';
  } else if (dupResult.isSuspectedDuplicate || parsed.requiresManualReview) {
    nextStatus = 'MANUAL_REVIEW_REQUIRED';
  } else {
    nextStatus = 'EXTRACTED';
  }

  await prisma.$transaction(async (tx) => {
    await tx.receiptOcrResult.create({
      data: {
        transferReceiptId: initialReceipt.id,
        provider: ocrProviderName,
        rawText,
        rawResponseJson: (rawMetadata ?? undefined) as Prisma.InputJsonValue | undefined,
        extractedAmount: parsed.extractedAmount,
        detectedAmountsJson: parsed.detectedAmounts as unknown as Prisma.InputJsonValue,
        excludedBalanceAmountsJson:
          parsed.excludedBalanceAmounts as unknown as Prisma.InputJsonValue,
        transactionDate: parseDateOnly(parsed.transactionDate),
        transactionTime: parsed.transactionTime,
        senderName: parsed.senderName,
        receiverName: parsed.receiverName,
        senderBank: parsed.senderBank,
        receiverBank: parsed.receiverBank,
        iban: parsed.iban,
        referenceNumber: parsed.referenceNumber,
        description: parsed.description,
        confidenceScore: parsed.confidenceScore,
        fieldConfidencesJson: parsed.fieldConfidences as unknown as Prisma.InputJsonValue,
        warningsJson: allWarnings as unknown as Prisma.InputJsonValue,
        processingTimeMs,
      },
    });

    await tx.transferReceipt.update({
      where: { id: initialReceipt.id },
      data: {
        status: nextStatus,
        verifiedAmount: parsed.extractedAmount,
        transactionDate: parseDateOnly(parsed.transactionDate),
        transactionTime: parsed.transactionTime,
        senderName: parsed.senderName,
        receiverName: parsed.receiverName,
        senderBank: parsed.senderBank,
        receiverBank: parsed.receiverBank,
        iban: parsed.iban,
        referenceNumber: parsed.referenceNumber,
        description: parsed.description,
        isDuplicate: dupResult.isExactDuplicate,
        duplicateOfReceiptId: dupResult.matchedReceiptId,
        duplicateReason: dupResult.reason,
        includedInReconciliation: false,
      },
    });

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: session.storeId,
        action: dupResult.isExactDuplicate ? 'RECEIPT_UPLOADED_DUPLICATE' : 'RECEIPT_UPLOADED',
        entityType: 'transfer_receipt',
        entityId: initialReceipt.id,
        afterJson: {
          cashSessionId: session.id,
          originalFilename: safeFilename,
          status: nextStatus,
          extractedAmount: parsed.extractedAmount,
          confidenceScore: parsed.confidenceScore,
          isDuplicate: dupResult.isExactDuplicate,
          duplicateReason: dupResult.reason,
        },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );
  });

  return getReceiptDetail(initialReceipt.id, actor);
}

export async function listReceipts(
  actor: Actor,
  filters: {
    storeId?: string;
    cashSessionId?: string;
    cashierId?: string;
    status?: ReceiptStatus;
    isDuplicate?: boolean;
    bankAccountVerified?: boolean;
    startDate?: string;
    endDate?: string;
  },
): Promise<{
  items: TransferReceiptSummaryDTO[];
  summary: {
    totalCount: number;
    pendingApprovalCount: number;
    manualReviewCount: number;
    duplicateOrFailedCount: number;
    approvedTotal: string;
    bankVerifiedTotal: string;
  };
}> {
  const scopedStoreId = resolveScopedStoreId(actor, filters.storeId);

  if (actor.role === 'CASHIER' && filters.cashierId && filters.cashierId !== actor.id) {
    throw new ForbiddenError('Yalnızca kendi yüklediğiniz dekontları görüntüleyebilirsiniz.');
  }
  const effectiveCashierId = actor.role === 'CASHIER' ? actor.id : filters.cashierId;

  const dateFilter =
    filters.startDate || filters.endDate
      ? {
          cashSession: {
            businessDate: {
              ...(filters.startDate ? { gte: parseDateOnly(filters.startDate)! } : {}),
              ...(filters.endDate ? { lte: parseDateOnly(filters.endDate)! } : {}),
            },
          },
        }
      : {};

  const receipts = await prisma.transferReceipt.findMany({
    where: {
      ...(scopedStoreId ? { storeId: scopedStoreId } : {}),
      ...(filters.cashSessionId ? { cashSessionId: filters.cashSessionId } : {}),
      ...(effectiveCashierId ? { cashierId: effectiveCashierId } : {}),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.isDuplicate !== undefined ? { isDuplicate: filters.isDuplicate } : {}),
      ...(filters.bankAccountVerified !== undefined
        ? { bankAccountVerified: filters.bankAccountVerified }
        : {}),
      ...dateFilter,
    },
    include: {
      store: { select: { id: true, code: true, name: true } },
      cashier: { select: { id: true, username: true, fullName: true } },
      cashSession: { select: { businessDate: true } },
      ocrResults: {
        select: { confidenceScore: true, warningsJson: true },
        orderBy: { createdAt: 'desc' },
        take: 1,
      },
    },
    orderBy: { createdAt: 'desc' },
  });

  const items = receipts.map(mapReceiptSummary);

  let pendingApprovalCount = 0;
  let manualReviewCount = 0;
  let duplicateOrFailedCount = 0;
  let approvedDec = new Decimal(0);
  let bankVerifiedDec = new Decimal(0);

  for (const r of items) {
    if (r.status === 'PENDING_CENTRAL_APPROVAL') pendingApprovalCount += 1;
    if (r.status === 'MANUAL_REVIEW_REQUIRED' || r.status === 'EXTRACTED') manualReviewCount += 1;
    if (r.status === 'DUPLICATE' || r.status === 'FAILED_OCR' || r.isDuplicate) {
      duplicateOrFailedCount += 1;
    }
    if (r.status === 'APPROVED' && !r.isDuplicate && r.verifiedAmount) {
      const amt = toDecimal(r.verifiedAmount);
      approvedDec = approvedDec.plus(amt);
      if (r.bankAccountVerified) {
        bankVerifiedDec = bankVerifiedDec.plus(amt);
      }
    }
  }

  return {
    items,
    summary: {
      totalCount: items.length,
      pendingApprovalCount,
      manualReviewCount,
      duplicateOrFailedCount,
      approvedTotal: formatFixed2(approvedDec),
      bankVerifiedTotal: formatFixed2(bankVerifiedDec),
    },
  };
}

export async function getReceiptDetail(
  receiptId: string,
  actor: Actor,
): Promise<TransferReceiptDetailDTO> {
  const receipt = await prisma.transferReceipt.findUnique({
    where: { id: receiptId },
    include: {
      store: { select: { id: true, code: true, name: true } },
      cashier: { select: { id: true, username: true, fullName: true } },
      cashSession: { select: { businessDate: true } },
      ocrResults: { orderBy: { createdAt: 'desc' } },
      verifications: {
        include: {
          verifiedBy: { select: { id: true, username: true, fullName: true } },
        },
        orderBy: { verifiedAt: 'desc' },
      },
    },
  });

  if (!receipt) {
    throw new NotFoundError('Dekont kaydı bulunamadı.');
  }

  assertStoreAccess(actor, receipt.storeId);
  if (actor.role === 'CASHIER' && receipt.cashierId !== actor.id) {
    throw new ForbiddenError('Başka bir kasiyere ait dekontu görüntüleyemezsiniz.');
  }

  const summary = mapReceiptSummary(receipt);
  const ocrResults = receipt.ocrResults.map(mapOcrResult);
  const verifications: ReceiptVerificationDTO[] = receipt.verifications.map((v) => ({
    id: v.id,
    stage: v.stage as ReceiptVerificationStage,
    action: v.action,
    reason: v.reason,
    verifiedBy: v.verifiedBy,
    verifiedAt: v.verifiedAt.toISOString(),
  }));

  return { ...summary, ocrResults, verifications };
}

export async function getReceiptFileForDownload(
  receiptId: string,
  actor: Actor,
): Promise<{ absolutePath: string; mimeType: string; originalFilename: string }> {
  const receipt = await prisma.transferReceipt.findUnique({
    where: { id: receiptId },
    select: {
      id: true,
      storeId: true,
      cashierId: true,
      storedPath: true,
      mimeType: true,
      originalFilename: true,
    },
  });

  if (!receipt) {
    throw new NotFoundError('Dekont dosyası bulunamadı.');
  }

  assertStoreAccess(actor, receipt.storeId);
  if (actor.role === 'CASHIER' && receipt.cashierId !== actor.id) {
    throw new ForbiddenError('Başka bir kasiyerin dekont dosyasını görüntüleyemezsiniz.');
  }

  const absolutePath = resolveStoredReceiptPath(receipt.storedPath);
  try {
    await fs.access(absolutePath);
  } catch {
    throw new NotFoundError('Dekont dosyası disk üzerinde bulunamadı.');
  }

  return {
    absolutePath,
    mimeType: receipt.mimeType,
    originalFilename: receipt.originalFilename,
  };
}

export async function confirmReceiptByStore(
  receiptId: string,
  input: ConfirmReceiptInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<TransferReceiptDetailDTO> {
  if (actor.role === 'CENTRAL_ACCOUNTING') {
    throw new ForbiddenError('Merkez personeli için merkez doğrulama uç noktasını kullanın.');
  }

  const receipt = await prisma.transferReceipt.findUnique({
    where: { id: receiptId },
    include: { cashSession: true },
  });
  if (!receipt) {
    throw new NotFoundError('Dekont bulunamadı.');
  }

  assertStoreAccess(actor, receipt.storeId);
  if (actor.role === 'CASHIER' && receipt.cashierId !== actor.id) {
    throw new ForbiddenError('Yalnızca kendi yüklediğiniz dekontu teyit edebilirsiniz.');
  }

  if (receipt.cashSession.isLocked) {
    throw new ConflictError('Kilitli kasa oturumundaki dekont değiştirilemez.');
  }

  if (
    receipt.status === 'APPROVED' ||
    receipt.status === 'REJECTED' ||
    receipt.status === 'DUPLICATE' ||
    receipt.isDuplicate
  ) {
    throw new ConflictError('Mükerrer, onaylı veya reddedilmiş dekont tekrar teyit edilemez.');
  }

  const timeWindowMin = await getNumericSetting('duplicate_time_window_minutes', 10);
  const verifiedAmountFixed = formatFixed2(new Decimal(input.verifiedAmount));

  const dupCheck = await detectDuplicateReceipt({
    excludeReceiptId: receipt.id,
    fileSha256: receipt.fileSha256,
    perceptualHash: receipt.perceptualHash,
    referenceNumber: input.referenceNumber ?? receipt.referenceNumber,
    amount: verifiedAmountFixed,
    transactionDate:
      input.transactionDate !== undefined
        ? input.transactionDate
        : formatDateOnly(receipt.transactionDate),
    transactionTime:
      input.transactionTime !== undefined ? input.transactionTime : receipt.transactionTime,
    senderName: input.senderName !== undefined ? input.senderName : receipt.senderName,
    iban: input.iban !== undefined ? input.iban : receipt.iban,
    timeWindowMinutes: timeWindowMin,
  });

  if (dupCheck.isExactDuplicate) {
    await prisma.$transaction(async (tx) => {
      await tx.transferReceipt.update({
        where: { id: receipt.id },
        data: {
          status: 'DUPLICATE',
          isDuplicate: true,
          duplicateOfReceiptId: dupCheck.matchedReceiptId,
          duplicateReason: dupCheck.reason,
          includedInReconciliation: false,
        },
      });
      await tx.receiptVerification.create({
        data: {
          transferReceiptId: receipt.id,
          stage: actor.role === 'CASHIER' ? 'CASHIER_CONFIRM' : 'STORE_MANAGER_REVIEW',
          action: 'MARKED_DUPLICATE',
          reason: dupCheck.warningMessage,
          verifiedById: actor.id,
        },
      });
    });

    throw new ConflictError(
      dupCheck.warningMessage ?? 'Girilen referans numarası mükerrer dekont olarak tespit edildi.',
    );
  }

  const prevSnapshot = {
    verifiedAmount: receipt.verifiedAmount?.toString() ?? null,
    transactionDate: formatDateOnly(receipt.transactionDate),
    transactionTime: receipt.transactionTime,
    senderName: receipt.senderName,
    receiverName: receipt.receiverName,
    senderBank: receipt.senderBank,
    receiverBank: receipt.receiverBank,
    iban: receipt.iban,
    referenceNumber: receipt.referenceNumber,
    description: receipt.description,
  };

  const nextSnapshot = {
    verifiedAmount: verifiedAmountFixed,
    transactionDate:
      input.transactionDate !== undefined
        ? input.transactionDate
        : formatDateOnly(receipt.transactionDate),
    transactionTime:
      input.transactionTime !== undefined ? input.transactionTime : receipt.transactionTime,
    senderName: input.senderName !== undefined ? input.senderName : receipt.senderName,
    receiverName: input.receiverName !== undefined ? input.receiverName : receipt.receiverName,
    senderBank: input.senderBank !== undefined ? input.senderBank : receipt.senderBank,
    receiverBank: input.receiverBank !== undefined ? input.receiverBank : receipt.receiverBank,
    iban: input.iban !== undefined ? input.iban?.replace(/\s+/g, '').toUpperCase() ?? null : receipt.iban,
    referenceNumber:
      input.referenceNumber !== undefined ? input.referenceNumber : receipt.referenceNumber,
    description: input.description !== undefined ? input.description : receipt.description,
  };

  const wasEdited = JSON.stringify(prevSnapshot) !== JSON.stringify(nextSnapshot);

  await prisma.$transaction(async (tx) => {
    await tx.transferReceipt.update({
      where: { id: receipt.id },
      data: {
        verifiedAmount: nextSnapshot.verifiedAmount,
        transactionDate: parseDateOnly(nextSnapshot.transactionDate),
        transactionTime: nextSnapshot.transactionTime,
        senderName: nextSnapshot.senderName,
        receiverName: nextSnapshot.receiverName,
        senderBank: nextSnapshot.senderBank,
        receiverBank: nextSnapshot.receiverBank,
        iban: nextSnapshot.iban,
        referenceNumber: nextSnapshot.referenceNumber,
        description: nextSnapshot.description,
        status: 'PENDING_CENTRAL_APPROVAL',
        duplicateOfReceiptId: dupCheck.isSuspectedDuplicate
          ? dupCheck.matchedReceiptId
          : receipt.duplicateOfReceiptId,
        duplicateReason: dupCheck.isSuspectedDuplicate
          ? dupCheck.reason
          : receipt.duplicateReason,
      },
    });

    await tx.receiptVerification.create({
      data: {
        transferReceiptId: receipt.id,
        stage: actor.role === 'CASHIER' ? 'CASHIER_CONFIRM' : 'STORE_MANAGER_REVIEW',
        action: wasEdited ? 'EDITED_AND_CONFIRMED' : 'CONFIRMED',
        previousValuesJson: prevSnapshot as Prisma.InputJsonValue,
        newValuesJson: nextSnapshot as Prisma.InputJsonValue,
        reason: input.note ?? null,
        verifiedById: actor.id,
      },
    });

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: receipt.storeId,
        action: 'RECEIPT_CONFIRMED_FOR_CENTRAL',
        entityType: 'transfer_receipt',
        entityId: receipt.id,
        beforeJson: prevSnapshot,
        afterJson: { ...nextSnapshot, status: 'PENDING_CENTRAL_APPROVAL' },
        reason: input.note ?? null,
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );
  });

  return getReceiptDetail(receipt.id, actor);
}

export async function centralReviewReceipt(
  receiptId: string,
  input: CentralReviewReceiptInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<TransferReceiptDetailDTO> {
  if (actor.role !== 'CENTRAL_ACCOUNTING' && actor.role !== 'SYSTEM_ADMIN') {
    throw new ForbiddenError('Dekont onayı veya reddi yalnızca merkez muhasebe tarafından yapılabilir.');
  }

  const receipt = await prisma.transferReceipt.findUnique({
    where: { id: receiptId },
    include: { cashSession: true, cashTransaction: true },
  });
  if (!receipt) {
    throw new NotFoundError('Dekont bulunamadı.');
  }

  if (receipt.cashSession.isLocked) {
    throw new ConflictError(
      'Kilitli bir günlük mutabakata bağlı dekont doğrudan değiştirilemez; finansal düzeltme kaydı kullanılmalıdır.',
    );
  }

  if (input.action !== 'APPROVE' && (!input.reason || input.reason.trim().length < 5)) {
    throw new ValidationError('Ret, mükerrer veya manuel kontrol yönlendirmesi için en az 5 karakter gerekçe zorunludur.');
  }

  if (input.action === 'APPROVE') {
    if (receipt.isDuplicate || receipt.status === 'DUPLICATE') {
      throw new ConflictError('Mükerrer olarak işaretlenmiş bir dekont onaylanamaz.');
    }

    const finalAmountStr = input.verifiedAmount
      ? formatFixed2(new Decimal(input.verifiedAmount))
      : receipt.verifiedAmount !== null
        ? formatFixed2(toDecimal(receipt.verifiedAmount.toString()))
        : null;

    if (!finalAmountStr || new Decimal(finalAmountStr).lte(0)) {
      throw new ValidationError('Onay için geçerli bir transfer tutarı belirtilmelidir.');
    }

    const finalRef =
      input.referenceNumber !== undefined ? input.referenceNumber : receipt.referenceNumber;

    // Onay anında kesin mükerrer kontrolü (Katman 1 & Katman 2)
    const dupCheck = await detectDuplicateReceipt({
      excludeReceiptId: receipt.id,
      fileSha256: receipt.fileSha256,
      perceptualHash: receipt.perceptualHash,
      referenceNumber: finalRef,
      amount: finalAmountStr,
      transactionDate:
        input.transactionDate !== undefined
          ? input.transactionDate
          : formatDateOnly(receipt.transactionDate),
      transactionTime:
        input.transactionTime !== undefined ? input.transactionTime : receipt.transactionTime,
      senderName: input.senderName !== undefined ? input.senderName : receipt.senderName,
      iban: input.iban !== undefined ? input.iban : receipt.iban,
    });

    if (dupCheck.isExactDuplicate) {
      throw new ConflictError(
        dupCheck.warningMessage ?? 'Bu dekont daha önce kayıtlı bir işlemle mükerrer olduğu için onaylanamaz.',
      );
    }

    const bankTransferMethod = await prisma.paymentMethod.findUnique({
      where: { code: 'BANK_TRANSFER' },
    });
    if (!bankTransferMethod) {
      throw new ValidationError('BANK_TRANSFER ödeme yöntemi tanımlı değil.');
    }

    const nextBankVerified =
      input.bankAccountVerified !== undefined
        ? input.bankAccountVerified
        : receipt.bankAccountVerified;

    try {
      await prisma.$transaction(async (tx) => {
        const updated = await tx.transferReceipt.update({
          where: { id: receipt.id },
          data: {
            status: 'APPROVED',
            verifiedAmount: finalAmountStr,
            ...(input.transactionDate !== undefined
              ? { transactionDate: parseDateOnly(input.transactionDate) }
              : {}),
            ...(input.transactionTime !== undefined ? { transactionTime: input.transactionTime } : {}),
            ...(input.senderName !== undefined ? { senderName: input.senderName } : {}),
            ...(input.receiverName !== undefined ? { receiverName: input.receiverName } : {}),
            ...(input.senderBank !== undefined ? { senderBank: input.senderBank } : {}),
            ...(input.receiverBank !== undefined ? { receiverBank: input.receiverBank } : {}),
            ...(input.iban !== undefined
              ? { iban: input.iban?.replace(/\s+/g, '').toUpperCase() ?? null }
              : {}),
            ...(input.referenceNumber !== undefined ? { referenceNumber: input.referenceNumber } : {}),
            ...(input.description !== undefined ? { description: input.description } : {}),
            isDuplicate: false,
            includedInReconciliation: true,
            bankAccountVerified: nextBankVerified,
            ...(nextBankVerified && !receipt.bankAccountVerified
              ? { bankVerifiedById: actor.id, bankVerifiedAt: new Date() }
              : {}),
          },
        });

        // Onaylı dekont için tekil BANK_TRANSFER satış hareketini senkronize et (çift sayım yok)
        if (receipt.cashTransaction) {
          await tx.cashTransaction.update({
            where: { id: receipt.cashTransaction.id },
            data: {
              amount: finalAmountStr,
              isVoided: false,
              voidReason: null,
              referenceNo: updated.referenceNumber,
              description: updated.description ?? `Onaylı IBAN Dekontu (${updated.originalFilename})`,
            },
          });
        } else {
          await tx.cashTransaction.create({
            data: {
              cashSessionId: receipt.cashSessionId,
              storeId: receipt.storeId,
              cashierId: receipt.cashierId,
              paymentMethodId: bankTransferMethod.id,
              transactionType: 'SALE',
              amount: finalAmountStr,
              transferReceiptId: receipt.id,
              referenceNo: updated.referenceNumber,
              description: updated.description ?? `Onaylı IBAN Dekontu (${updated.originalFilename})`,
              createdById: actor.id,
            },
          });
        }

        await tx.receiptVerification.create({
          data: {
            transferReceiptId: receipt.id,
            stage: 'CENTRAL_VERIFICATION',
            action: 'APPROVED',
            newValuesJson: {
              verifiedAmount: finalAmountStr,
              bankAccountVerified: nextBankVerified,
            } as Prisma.InputJsonValue,
            reason: input.reason ?? null,
            verifiedById: actor.id,
          },
        });

        await recalculateCashSession(receipt.cashSessionId, tx);

        await recordAuditLog(
          {
            actorUserId: actor.id,
            actorRole: actor.role,
            storeId: receipt.storeId,
            action: 'RECEIPT_APPROVED',
            entityType: 'transfer_receipt',
            entityId: receipt.id,
            beforeJson: { status: receipt.status, verifiedAmount: receipt.verifiedAmount?.toString() },
            afterJson: {
              status: 'APPROVED',
              verifiedAmount: finalAmountStr,
              bankAccountVerified: nextBankVerified,
              includedInReconciliation: true,
            },
            reason: input.reason ?? null,
            ipAddress: meta.ipAddress,
            userAgent: meta.userAgent,
            requestId: meta.requestId,
          },
          tx,
        );
      });
    } catch (err) {
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
        throw new ConflictError(
          'Aynı dosya veya aynı referans numarasına sahip başka bir dekont veritabanında zaten onaylı durumda (çift sayım engellendi).',
        );
      }
      throw err;
    }

    return getReceiptDetail(receipt.id, actor);
  }

  // REJECT | MARK_DUPLICATE | SEND_TO_MANUAL_REVIEW
  const targetStatus: ReceiptStatus =
    input.action === 'REJECT'
      ? 'REJECTED'
      : input.action === 'MARK_DUPLICATE'
        ? 'DUPLICATE'
        : 'MANUAL_REVIEW_REQUIRED';

  const verificationAction =
    input.action === 'REJECT'
      ? 'REJECTED'
      : input.action === 'MARK_DUPLICATE'
        ? 'MARKED_DUPLICATE'
        : 'SENT_TO_MANUAL_REVIEW';

  await prisma.$transaction(async (tx) => {
    await tx.transferReceipt.update({
      where: { id: receipt.id },
      data: {
        status: targetStatus,
        isDuplicate: input.action === 'MARK_DUPLICATE',
        ...(input.duplicateOfReceiptId !== undefined
          ? { duplicateOfReceiptId: input.duplicateOfReceiptId }
          : {}),
        ...(input.action === 'MARK_DUPLICATE' ? { duplicateReason: 'MANUAL_CENTRAL_MARK' } : {}),
        includedInReconciliation: false,
      },
    });

    if (receipt.cashTransaction && !receipt.cashTransaction.isVoided) {
      await tx.cashTransaction.update({
        where: { id: receipt.cashTransaction.id },
        data: {
          isVoided: true,
          voidReason: input.reason ?? 'Merkez dekont incelemesi ile iptal edildi',
          voidedById: actor.id,
          voidedAt: new Date(),
        },
      });
    }

    await tx.receiptVerification.create({
      data: {
        transferReceiptId: receipt.id,
        stage: 'CENTRAL_VERIFICATION',
        action: verificationAction,
        reason: input.reason ?? null,
        verifiedById: actor.id,
      },
    });

    await recalculateCashSession(receipt.cashSessionId, tx);

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: receipt.storeId,
        action: `RECEIPT_${input.action}`,
        entityType: 'transfer_receipt',
        entityId: receipt.id,
        beforeJson: { status: receipt.status },
        afterJson: { status: targetStatus, includedInReconciliation: false },
        reason: input.reason ?? null,
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );
  });

  return getReceiptDetail(receipt.id, actor);
}

export async function verifyReceiptBankAccount(
  receiptId: string,
  input: BankVerifyReceiptInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<TransferReceiptDetailDTO> {
  if (actor.role !== 'CENTRAL_ACCOUNTING' && actor.role !== 'SYSTEM_ADMIN') {
    throw new ForbiddenError('Banka hesabı teyidi yalnızca merkez muhasebe tarafından yapılabilir.');
  }

  const receipt = await prisma.transferReceipt.findUnique({
    where: { id: receiptId },
    include: { cashSession: true },
  });
  if (!receipt) {
    throw new NotFoundError('Dekont bulunamadı.');
  }

  if (receipt.isDuplicate || receipt.status === 'DUPLICATE' || receipt.status === 'REJECTED') {
    throw new ConflictError('Mükerrer veya reddedilmiş dekont için banka hesabı teyidi yapılamaz.');
  }

  await prisma.$transaction(async (tx) => {
    await tx.transferReceipt.update({
      where: { id: receipt.id },
      data: {
        bankAccountVerified: input.bankAccountVerified,
        bankVerifiedById: input.bankAccountVerified ? actor.id : null,
        bankVerifiedAt: input.bankAccountVerified ? new Date() : null,
      },
    });

    await tx.receiptVerification.create({
      data: {
        transferReceiptId: receipt.id,
        stage: 'BANK_STATEMENT_CHECK',
        action: input.bankAccountVerified ? 'CONFIRMED' : 'SENT_TO_MANUAL_REVIEW',
        reason:
          input.reason ??
          (input.bankAccountVerified
            ? 'Banka ekstresinde tutarın hesaba geçtiği doğrulandı.'
            : 'Banka hesabı teyidi kaldırıldı.'),
        verifiedById: actor.id,
      },
    });

    await recalculateCashSession(receipt.cashSessionId, tx);

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: receipt.storeId,
        action: 'RECEIPT_BANK_VERIFICATION_UPDATED',
        entityType: 'transfer_receipt',
        entityId: receipt.id,
        beforeJson: { bankAccountVerified: receipt.bankAccountVerified },
        afterJson: { bankAccountVerified: input.bankAccountVerified },
        reason: input.reason ?? null,
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );
  });

  return getReceiptDetail(receipt.id, actor);
}

export async function reprocessReceiptOcr(
  receiptId: string,
  actor: Actor,
  meta: RequestMeta,
): Promise<TransferReceiptDetailDTO> {
  const receipt = await prisma.transferReceipt.findUnique({
    where: { id: receiptId },
    include: { cashSession: true },
  });
  if (!receipt) {
    throw new NotFoundError('Dekont bulunamadı.');
  }

  assertStoreAccess(actor, receipt.storeId);
  if (actor.role === 'CASHIER' && receipt.cashierId !== actor.id) {
    throw new ForbiddenError('Başka bir kasiyerin dekontunu yeniden okuyamazsınız.');
  }
  if (receipt.status === 'APPROVED' || receipt.cashSession.isLocked) {
    throw new ConflictError('Onaylı veya kilitli dekont tekrar OCR işlemine sokulamaz.');
  }

  const absolutePath = resolveStoredReceiptPath(receipt.storedPath);
  const minConfidence = await getNumericSetting(
    'ocr_min_confidence_score',
    env.OCR_MIN_CONFIDENCE_SCORE,
  );
  const provider = resolveOcrProvider();
  const rawOut = await provider.extractText(absolutePath, receipt.mimeType as AllowedReceiptMime);
  const parsed = parseTurkishBankReceipt(rawOut.rawText, rawOut.baseQualityScore, minConfidence);

  await prisma.$transaction(async (tx) => {
    await tx.receiptOcrResult.create({
      data: {
        transferReceiptId: receipt.id,
        provider: rawOut.provider,
        rawText: rawOut.rawText,
        rawResponseJson: (rawOut.rawMetadata ?? undefined) as Prisma.InputJsonValue | undefined,
        extractedAmount: parsed.extractedAmount,
        detectedAmountsJson: parsed.detectedAmounts as unknown as Prisma.InputJsonValue,
        excludedBalanceAmountsJson:
          parsed.excludedBalanceAmounts as unknown as Prisma.InputJsonValue,
        transactionDate: parseDateOnly(parsed.transactionDate),
        transactionTime: parsed.transactionTime,
        senderName: parsed.senderName,
        receiverName: parsed.receiverName,
        senderBank: parsed.senderBank,
        receiverBank: parsed.receiverBank,
        iban: parsed.iban,
        referenceNumber: parsed.referenceNumber,
        description: parsed.description,
        confidenceScore: parsed.confidenceScore,
        fieldConfidencesJson: parsed.fieldConfidences as unknown as Prisma.InputJsonValue,
        warningsJson: parsed.warnings as unknown as Prisma.InputJsonValue,
        processingTimeMs: rawOut.processingTimeMs,
      },
    });

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: receipt.storeId,
        action: 'RECEIPT_OCR_REPROCESSED',
        entityType: 'transfer_receipt',
        entityId: receipt.id,
        afterJson: {
          extractedAmount: parsed.extractedAmount,
          confidenceScore: parsed.confidenceScore,
        },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );
  });

  return getReceiptDetail(receipt.id, actor);
}
