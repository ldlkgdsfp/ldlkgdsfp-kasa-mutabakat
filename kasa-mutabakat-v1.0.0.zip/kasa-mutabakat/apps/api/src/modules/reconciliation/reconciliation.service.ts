import type { Prisma } from '@prisma/client';
import {
  RECONCILIATION_STATUS_LABELS_TR,
  type CentralDashboardResponseDTO,
  type CentralReconciliationDTO,
  type CentralStoreDailyStatusDTO,
  type CreateFinancialAdjustmentInput,
  type ReconciliationStatus,
  type RoleCode,
  type VerifyCentralReconciliationInput,
} from '@kasa/shared';
import { Decimal } from 'decimal.js';
import { prisma } from '../../config/prisma.js';
import { assertStoreAccess, resolveScopedStoreId } from '../../middlewares/store-scope.js';
import { recordAuditLog } from '../audit/audit.service.js';
import type { RequestMeta } from '../auth/auth.service.js';
import { listCashSessions } from '../cash-sessions/cash-sessions.service.js';
import { listReceipts } from '../receipts/receipts.service.js';
import { formatFixed2, toDecimal } from './calculator.js';
import {
  ConflictError,
  ForbiddenError,
  NotFoundError,
  ValidationError,
} from '../../utils/errors.js';

type Actor = { id: string; role: RoleCode; storeId: string | null };

function parseDateOnly(isoDate: string): Date {
  return new Date(`${isoDate}T00:00:00.000Z`);
}

function formatDateOnly(d: Date): string {
  return d.toISOString().slice(0, 10);
}

const reconciliationInclude = {
  store: { select: { id: true, code: true, name: true } },
  checkedBy: { select: { id: true, username: true, fullName: true } },
  approvedBy: { select: { id: true, username: true, fullName: true } },
  items: {
    include: {
      cashier: { select: { id: true, fullName: true } },
      paymentMethod: { select: { code: true, name: true } },
    },
    orderBy: { createdAt: 'asc' as const },
  },
  adjustments: {
    include: {
      createdBy: { select: { id: true, username: true, fullName: true } },
      approvedBy: { select: { id: true, username: true, fullName: true } },
    },
    orderBy: { createdAt: 'desc' as const },
  },
};

type ReconciliationWithRelations = Prisma.CentralReconciliationGetPayload<{
  include: typeof reconciliationInclude;
}>;

function mapReconciliation(r: ReconciliationWithRelations): CentralReconciliationDTO {
  const status = r.status as ReconciliationStatus;
  return {
    id: r.id,
    storeId: r.storeId,
    store: r.store,
    businessDate: formatDateOnly(r.businessDate),
    expectedCashTotal: formatFixed2(toDecimal(r.expectedCashTotal.toString())),
    declaredCashTotal: formatFixed2(toDecimal(r.declaredCashTotal.toString())),
    centralVerifiedCash:
      r.centralVerifiedCash !== null
        ? formatFixed2(toDecimal(r.centralVerifiedCash.toString()))
        : null,
    cashVariance:
      r.cashVariance !== null ? formatFixed2(toDecimal(r.cashVariance.toString())) : null,
    declaredVsCentralDiff:
      r.declaredVsCentralDiff !== null
        ? formatFixed2(toDecimal(r.declaredVsCentralDiff.toString()))
        : null,
    creditCardTotal: formatFixed2(toDecimal(r.creditCardTotal.toString())),
    approvedTransferTotal: formatFixed2(toDecimal(r.approvedTransferTotal.toString())),
    bankVerifiedTransferTotal: formatFixed2(toDecimal(r.bankVerifiedTransferTotal.toString())),
    refundTotal: formatFixed2(toDecimal(r.refundTotal.toString())),
    grandSalesTotal: formatFixed2(toDecimal(r.grandSalesTotal.toString())),
    status,
    statusLabel: RECONCILIATION_STATUS_LABELS_TR[status],
    notes: r.notes,
    checkedBy: r.checkedBy,
    checkedAt: r.checkedAt ? r.checkedAt.toISOString() : null,
    approvedBy: r.approvedBy,
    approvedAt: r.approvedAt ? r.approvedAt.toISOString() : null,
    isLocked: r.isLocked,
    items: r.items.map((it) => ({
      id: it.id,
      cashSessionId: it.cashSessionId,
      cashierId: it.cashierId,
      cashierName: it.cashier?.fullName ?? null,
      paymentMethodCode: it.paymentMethod.code,
      paymentMethodName: it.paymentMethod.name,
      expectedAmount: formatFixed2(toDecimal(it.expectedAmount.toString())),
      declaredAmount: formatFixed2(toDecimal(it.declaredAmount.toString())),
      verifiedAmount: formatFixed2(toDecimal(it.verifiedAmount.toString())),
      varianceAmount: formatFixed2(toDecimal(it.varianceAmount.toString())),
      notes: it.notes,
    })),
    adjustments: r.adjustments.map((adj) => ({
      id: adj.id,
      fieldName: adj.fieldName,
      previousValue: formatFixed2(toDecimal(adj.previousValue.toString())),
      adjustedValue: formatFixed2(toDecimal(adj.adjustedValue.toString())),
      deltaAmount: formatFixed2(toDecimal(adj.deltaAmount.toString())),
      reason: adj.reason,
      createdBy: adj.createdBy,
      approvedBy: adj.approvedBy,
      createdAt: adj.createdAt.toISOString(),
    })),
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  };
}

/**
 * Merkez Kontrol Paneli: seçilen iş günü için tüm mağazaların canlı durumunu,
 * satış/ödeme dağılımlarını, açık/fazlaları, bekleyen kapanışları ve dekont kuyruklarını döndürür.
 */
export async function getCentralDashboard(
  businessDate: string,
  actor: Actor,
): Promise<CentralDashboardResponseDTO> {
  if (actor.role !== 'CENTRAL_ACCOUNTING' && actor.role !== 'SYSTEM_ADMIN') {
    throw new ForbiddenError('Merkez kontrol paneline yalnızca merkez muhasebe ve sistem yöneticisi erişebilir.');
  }

  const targetDate = parseDateOnly(businessDate);

  const [activeStores, sessionsRes, receiptsRes, reconciliations] = await Promise.all([
    prisma.store.findMany({
      where: { type: 'STORE', isActive: true },
      orderBy: { code: 'asc' },
    }),
    listCashSessions(actor, { businessDate }),
    listReceipts(actor, { startDate: businessDate, endDate: businessDate }),
    prisma.centralReconciliation.findMany({
      where: { businessDate: targetDate },
      include: reconciliationInclude,
    }),
  ]);

  const reconByStoreId = new Map<string, CentralReconciliationDTO>();
  for (const r of reconciliations) {
    reconByStoreId.set(r.storeId, mapReconciliation(r));
  }

  const zero = new Decimal(0);
  let overallGrandSales = zero;
  let overallCashSales = zero;
  let overallCreditCard = zero;
  let overallApprovedTransfer = zero;
  let overallBankVerifiedTransfer = zero;
  let overallRefunds = zero;
  let overallExpectedCash = zero;
  let overallDeclaredCash = zero;
  let overallCentralVerifiedCash = zero;
  let overallShortage = zero;
  let overallSurplus = zero;
  let pendingClosingCount = 0;

  const storeStatuses: CentralStoreDailyStatusDTO[] = activeStores.map((store) => {
    const storeSessions = sessionsRes.items.filter((s) => s.storeId === store.id);
    const storeReceipts = receiptsRes.items.filter((r) => r.storeId === store.id);
    const recon = reconByStoreId.get(store.id) ?? null;

    let cashSales = zero;
    let cardSales = zero;
    let approvedTransfer = zero;
    let bankVerifiedTransfer = zero;
    let refunds = zero;
    let expectedCash = zero;
    let declaredCash = zero;
    let sessionShortage = zero;
    let sessionSurplus = zero;
    let submittedSessionCount = 0;
    let openSessionCount = 0;

    for (const s of storeSessions) {
      cashSales = cashSales.plus(toDecimal(s.cashSalesTotal));
      cardSales = cardSales.plus(toDecimal(s.creditCardSalesTotal));
      approvedTransfer = approvedTransfer.plus(toDecimal(s.bankTransferTotal));
      refunds = refunds.plus(toDecimal(s.totalRefunds));
      expectedCash = expectedCash.plus(toDecimal(s.expectedCash));
      if (s.declaredCash !== null) {
        submittedSessionCount += 1;
        declaredCash = declaredCash.plus(toDecimal(s.declaredCash));
        sessionShortage = sessionShortage.plus(toDecimal(s.cashShortage));
        sessionSurplus = sessionSurplus.plus(toDecimal(s.cashSurplus));
      }
      if (s.status === 'OPEN' || s.status === 'RETURNED_FOR_CORRECTION') {
        openSessionCount += 1;
      }
    }

    let pendingRcptCount = 0;
    let problematicRcptCount = 0;
    for (const r of storeReceipts) {
      if (r.status === 'PENDING_CENTRAL_APPROVAL') pendingRcptCount += 1;
      if (
        r.status === 'DUPLICATE' ||
        r.status === 'FAILED_OCR' ||
        r.status === 'MANUAL_REVIEW_REQUIRED' ||
        r.isDuplicate
      ) {
        problematicRcptCount += 1;
      }
      if (r.status === 'APPROVED' && !r.isDuplicate && r.bankAccountVerified && r.verifiedAmount) {
        bankVerifiedTransfer = bankVerifiedTransfer.plus(toDecimal(r.verifiedAmount));
      }
    }

    const effectiveCard = recon ? toDecimal(recon.creditCardTotal) : cardSales;
    const effectiveApprovedTransfer = recon
      ? toDecimal(recon.approvedTransferTotal)
      : approvedTransfer;
    const effectiveGrandSales = recon
      ? toDecimal(recon.grandSalesTotal)
      : cashSales.plus(effectiveCard).plus(effectiveApprovedTransfer).minus(refunds);

    let effectiveShortage = sessionShortage;
    let effectiveSurplus = sessionSurplus;
    let centralVerifiedCashStr: string | null = null;
    let cashVarianceStr: string | null = null;
    let declaredVsCentralStr: string | null = null;

    if (recon && recon.centralVerifiedCash !== null && recon.cashVariance !== null) {
      centralVerifiedCashStr = recon.centralVerifiedCash;
      cashVarianceStr = recon.cashVariance;
      declaredVsCentralStr = recon.declaredVsCentralDiff;
      const cv = toDecimal(recon.cashVariance);
      effectiveShortage = cv.lt(0) ? cv.abs() : zero;
      effectiveSurplus = cv.gt(0) ? cv : zero;
      overallCentralVerifiedCash = overallCentralVerifiedCash.plus(
        toDecimal(recon.centralVerifiedCash),
      );
    }

    // Onay bekleyen kapanış sayısı: oturumu olan ama henüz APPROVED/LOCKED mutabakatı olmayan mağazalar
    if (storeSessions.length > 0 && (!recon || recon.status !== 'APPROVED')) {
      pendingClosingCount += 1;
    }

    overallGrandSales = overallGrandSales.plus(effectiveGrandSales);
    overallCashSales = overallCashSales.plus(cashSales);
    overallCreditCard = overallCreditCard.plus(effectiveCard);
    overallApprovedTransfer = overallApprovedTransfer.plus(effectiveApprovedTransfer);
    overallBankVerifiedTransfer = overallBankVerifiedTransfer.plus(bankVerifiedTransfer);
    overallRefunds = overallRefunds.plus(refunds);
    overallExpectedCash = overallExpectedCash.plus(expectedCash);
    overallDeclaredCash = overallDeclaredCash.plus(declaredCash);
    overallShortage = overallShortage.plus(effectiveShortage);
    overallSurplus = overallSurplus.plus(effectiveSurplus);

    return {
      store: { id: store.id, code: store.code, name: store.name },
      reconciliation: recon,
      sessionCount: storeSessions.length,
      submittedSessionCount,
      openSessionCount,
      pendingReceiptCount: pendingRcptCount,
      problematicReceiptCount: problematicRcptCount,
      cashSalesTotal: formatFixed2(cashSales),
      creditCardTotal: formatFixed2(effectiveCard),
      approvedTransferTotal: formatFixed2(effectiveApprovedTransfer),
      bankVerifiedTransferTotal: formatFixed2(bankVerifiedTransfer),
      refundTotal: formatFixed2(refunds),
      grandSalesTotal: formatFixed2(effectiveGrandSales),
      expectedCashTotal: formatFixed2(expectedCash),
      declaredCashTotal: formatFixed2(declaredCash),
      centralVerifiedCash: centralVerifiedCashStr,
      cashVariance: cashVarianceStr,
      declaredVsCentralDiff: declaredVsCentralStr,
      shortageTotal: formatFixed2(effectiveShortage),
      surplusTotal: formatFixed2(effectiveSurplus),
      sessions: storeSessions,
    };
  });

  const pendingReceiptsQueue = receiptsRes.items.filter(
    (r) => r.status === 'PENDING_CENTRAL_APPROVAL',
  );
  const problematicReceiptsQueue = receiptsRes.items.filter(
    (r) =>
      r.status === 'DUPLICATE' ||
      r.status === 'FAILED_OCR' ||
      r.status === 'MANUAL_REVIEW_REQUIRED' ||
      r.isDuplicate,
  );

  return {
    businessDate,
    overall: {
      grandSalesTotal: formatFixed2(overallGrandSales),
      cashSalesTotal: formatFixed2(overallCashSales),
      creditCardTotal: formatFixed2(overallCreditCard),
      approvedTransferTotal: formatFixed2(overallApprovedTransfer),
      bankVerifiedTransferTotal: formatFixed2(overallBankVerifiedTransfer),
      refundTotal: formatFixed2(overallRefunds),
      expectedCashTotal: formatFixed2(overallExpectedCash),
      declaredCashTotal: formatFixed2(overallDeclaredCash),
      centralVerifiedCashTotal: formatFixed2(overallCentralVerifiedCash),
      totalShortage: formatFixed2(overallShortage),
      totalSurplus: formatFixed2(overallSurplus),
      pendingClosingCount,
      pendingReceiptCount: pendingReceiptsQueue.length,
      problematicReceiptCount: problematicReceiptsQueue.length,
    },
    stores: storeStatuses,
    pendingReceiptsQueue,
    problematicReceiptsQueue,
  };
}

export async function listReconciliations(
  actor: Actor,
  filters: {
    storeId?: string;
    startDate?: string;
    endDate?: string;
    status?: ReconciliationStatus;
  },
): Promise<CentralReconciliationDTO[]> {
  if (actor.role === 'CASHIER') {
    throw new ForbiddenError('Kasiyer merkez mutabakat kayıtlarına erişemez.');
  }

  const scopedStoreId = resolveScopedStoreId(actor, filters.storeId);

  const items = await prisma.centralReconciliation.findMany({
    where: {
      ...(scopedStoreId ? { storeId: scopedStoreId } : {}),
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.startDate || filters.endDate
        ? {
            businessDate: {
              ...(filters.startDate ? { gte: parseDateOnly(filters.startDate) } : {}),
              ...(filters.endDate ? { lte: parseDateOnly(filters.endDate) } : {}),
            },
          }
        : {}),
    },
    include: reconciliationInclude,
    orderBy: [{ businessDate: 'desc' }, { store: { code: 'asc' } }],
  });

  return items.map(mapReconciliation);
}

export async function getReconciliationById(
  reconciliationId: string,
  actor: Actor,
): Promise<CentralReconciliationDTO> {
  if (actor.role === 'CASHIER') {
    throw new ForbiddenError('Kasiyer merkez mutabakat kaydına erişemez.');
  }

  const recon = await prisma.centralReconciliation.findUnique({
    where: { id: reconciliationId },
    include: reconciliationInclude,
  });

  if (!recon) {
    throw new NotFoundError('Merkez mutabakat kaydı bulunamadı.');
  }

  assertStoreAccess(actor, recon.storeId);
  return mapReconciliation(recon);
}

/**
 * Merkez muhasebe doğrulaması: beyan edilen tutar ile merkezin gerçekte teslim aldığı tutarı
 * karşılaştırır, kasiyer kırılım kalemlerini yazar, onayda kayıtları kilitler veya iade eder.
 */
export async function verifyCentralReconciliation(
  input: VerifyCentralReconciliationInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<CentralReconciliationDTO> {
  if (actor.role !== 'CENTRAL_ACCOUNTING' && actor.role !== 'SYSTEM_ADMIN') {
    throw new ForbiddenError(
      'Günlük merkez mutabakat onayı veya iadesi yalnızca merkez muhasebe tarafından yapılabilir.',
    );
  }

  if (
    (input.action === 'RETURN' || input.action === 'DISPUTE') &&
    (!input.notes || input.notes.trim().length < 5)
  ) {
    throw new ValidationError(
      'İade veya uyuşmazlık kararı için en az 5 karakter açıklama/gerekçe girilmelidir.',
    );
  }

  const store = await prisma.store.findUnique({ where: { id: input.storeId } });
  if (!store || store.type !== 'STORE') {
    throw new NotFoundError('Mutabakat yapılacak mağaza bulunamadı.');
  }

  const targetDate = parseDateOnly(input.businessDate);

  const existing = await prisma.centralReconciliation.findUnique({
    where: {
      storeId_businessDate: {
        storeId: input.storeId,
        businessDate: targetDate,
      },
    },
  });

  if (existing && (existing.isLocked || existing.status === 'APPROVED')) {
    throw new ConflictError(
      'Onaylanmış ve kilitlenmiş merkez mutabakat kaydı doğrudan değiştirilemez. Değişiklik gerekiyorsa gerekçeli Finansal Düzeltme Kaydı oluşturun.',
    );
  }

  const sessions = await prisma.cashSession.findMany({
    where: { storeId: input.storeId, businessDate: targetDate },
    include: {
      cashier: { select: { id: true, fullName: true } },
      transferReceipts: true,
    },
    orderBy: { shiftNo: 'asc' },
  });

  if (sessions.length === 0) {
    throw new ValidationError(
      'Bu mağaza ve tarih için açılmış herhangi bir kasa oturumu bulunmamaktadır.',
    );
  }

  if (input.action === 'APPROVE') {
    const unclosed = sessions.filter(
      (s) => s.status === 'OPEN' || s.status === 'RETURNED_FOR_CORRECTION' || s.declaredCash === null,
    );
    if (unclosed.length > 0) {
      throw new ConflictError(
        `Bu mağazada henüz kapanışı teslim edilmemiş ${unclosed.length} açık kasa oturumu bulunuyor. Tüm oturumlar teslim edilmeden merkez onayı verilemez.`,
      );
    }

    const unresolvedReceipts = sessions
      .flatMap((s) => s.transferReceipts)
      .filter(
        (r) =>
          r.status === 'UPLOADED' ||
          r.status === 'OCR_PROCESSING' ||
          r.status === 'EXTRACTED' ||
          r.status === 'MANUAL_REVIEW_REQUIRED' ||
          r.status === 'PENDING_CENTRAL_APPROVAL',
      );
    if (unresolvedReceipts.length > 0) {
      throw new ConflictError(
        `Bu mağaza için henüz incelenmemiş ${unresolvedReceipts.length} IBAN dekontu bulunuyor. Mutabakat onayı öncesi bekleyen dekontları sonuçlandırın.`,
      );
    }
  }

  const paymentMethods = await prisma.paymentMethod.findMany();
  const pmByCode = new Map(paymentMethods.map((m) => [m.code, m.id]));

  const zero = new Decimal(0);
  let expectedCashTotal = zero;
  let declaredCashTotal = zero;
  let cashSalesTotal = zero;
  let creditCardTotal = zero;
  let approvedTransferTotal = zero;
  let bankVerifiedTransferTotal = zero;
  let refundTotal = zero;

  for (const s of sessions) {
    expectedCashTotal = expectedCashTotal.plus(toDecimal(s.expectedCash.toString()));
    if (s.declaredCash !== null) {
      declaredCashTotal = declaredCashTotal.plus(toDecimal(s.declaredCash.toString()));
    }
    cashSalesTotal = cashSalesTotal.plus(toDecimal(s.cashSalesTotal.toString()));
    creditCardTotal = creditCardTotal.plus(toDecimal(s.creditCardSalesTotal.toString()));
    approvedTransferTotal = approvedTransferTotal.plus(toDecimal(s.bankTransferTotal.toString()));
    refundTotal = refundTotal
      .plus(toDecimal(s.cashRefundTotal.toString()))
      .plus(toDecimal(s.cardRefundTotal.toString()))
      .plus(toDecimal(s.transferRefundTotal.toString()));

    for (const r of s.transferReceipts) {
      if (r.status === 'APPROVED' && !r.isDuplicate && r.bankAccountVerified && r.verifiedAmount) {
        bankVerifiedTransferTotal = bankVerifiedTransferTotal.plus(
          toDecimal(r.verifiedAmount.toString()),
        );
      }
    }
  }

  const centralVerifiedDec = toDecimal(input.centralVerifiedCash);
  const cashVarianceDec = centralVerifiedDec.minus(expectedCashTotal);
  const declaredVsCentralDec = centralVerifiedDec.minus(declaredCashTotal);
  const grandSalesDec = cashSalesTotal
    .plus(creditCardTotal)
    .plus(approvedTransferTotal)
    .minus(refundTotal);

  const nextStatus: ReconciliationStatus =
    input.action === 'APPROVE'
      ? 'APPROVED'
      : input.action === 'RETURN'
        ? 'RETURNED'
        : input.action === 'DISPUTE'
          ? 'DISPUTED'
          : 'IN_REVIEW';

  const now = new Date();
  const shouldLock = input.action === 'APPROVE';

  const resultId = await prisma.$transaction(async (tx) => {
    const recon = await tx.centralReconciliation.upsert({
      where: {
        storeId_businessDate: {
          storeId: input.storeId,
          businessDate: targetDate,
        },
      },
      create: {
        storeId: input.storeId,
        businessDate: targetDate,
        expectedCashTotal: formatFixed2(expectedCashTotal),
        declaredCashTotal: formatFixed2(declaredCashTotal),
        centralVerifiedCash: formatFixed2(centralVerifiedDec),
        cashVariance: formatFixed2(cashVarianceDec),
        declaredVsCentralDiff: formatFixed2(declaredVsCentralDec),
        creditCardTotal: formatFixed2(creditCardTotal),
        approvedTransferTotal: formatFixed2(approvedTransferTotal),
        bankVerifiedTransferTotal: formatFixed2(bankVerifiedTransferTotal),
        refundTotal: formatFixed2(refundTotal),
        grandSalesTotal: formatFixed2(grandSalesDec),
        status: nextStatus,
        notes: input.notes ?? null,
        checkedById: actor.id,
        checkedAt: now,
        approvedById: shouldLock ? actor.id : null,
        approvedAt: shouldLock ? now : null,
        isLocked: shouldLock,
      },
      update: {
        expectedCashTotal: formatFixed2(expectedCashTotal),
        declaredCashTotal: formatFixed2(declaredCashTotal),
        centralVerifiedCash: formatFixed2(centralVerifiedDec),
        cashVariance: formatFixed2(cashVarianceDec),
        declaredVsCentralDiff: formatFixed2(declaredVsCentralDec),
        creditCardTotal: formatFixed2(creditCardTotal),
        approvedTransferTotal: formatFixed2(approvedTransferTotal),
        bankVerifiedTransferTotal: formatFixed2(bankVerifiedTransferTotal),
        refundTotal: formatFixed2(refundTotal),
        grandSalesTotal: formatFixed2(grandSalesDec),
        status: nextStatus,
        notes: input.notes ?? null,
        checkedById: actor.id,
        checkedAt: now,
        approvedById: shouldLock ? actor.id : null,
        approvedAt: shouldLock ? now : null,
        isLocked: shouldLock,
      },
    });

    // Kasiyer & ödeme yöntemi bazlı mutabakat satır kırılımlarını yenile
    await tx.reconciliationItem.deleteMany({
      where: { centralReconciliationId: recon.id },
    });

    const cashPmId = pmByCode.get('CASH')!;
    const cardPmId = pmByCode.get('CREDIT_CARD')!;
    const bankPmId = pmByCode.get('BANK_TRANSFER')!;

    for (const s of sessions) {
      const sExpected = toDecimal(s.expectedCash.toString());
      const sDeclared = s.declaredCash !== null ? toDecimal(s.declaredCash.toString()) : zero;
      const sVar = sDeclared.minus(sExpected);

      await tx.reconciliationItem.createMany({
        data: [
          {
            centralReconciliationId: recon.id,
            cashSessionId: s.id,
            cashierId: s.cashierId,
            paymentMethodId: cashPmId,
            expectedAmount: formatFixed2(sExpected),
            declaredAmount: formatFixed2(sDeclared),
            verifiedAmount: formatFixed2(sDeclared),
            varianceAmount: formatFixed2(sVar),
            notes: `Vardiya #${s.shiftNo} Nakit`,
          },
          {
            centralReconciliationId: recon.id,
            cashSessionId: s.id,
            cashierId: s.cashierId,
            paymentMethodId: cardPmId,
            expectedAmount: formatFixed2(toDecimal(s.creditCardSalesTotal.toString())),
            declaredAmount: formatFixed2(toDecimal(s.creditCardSalesTotal.toString())),
            verifiedAmount: formatFixed2(toDecimal(s.creditCardSalesTotal.toString())),
            varianceAmount: '0.00',
            notes: `Vardiya #${s.shiftNo} Kredi Kartı`,
          },
          {
            centralReconciliationId: recon.id,
            cashSessionId: s.id,
            cashierId: s.cashierId,
            paymentMethodId: bankPmId,
            expectedAmount: formatFixed2(toDecimal(s.bankTransferTotal.toString())),
            declaredAmount: formatFixed2(toDecimal(s.bankTransferTotal.toString())),
            verifiedAmount: formatFixed2(toDecimal(s.bankTransferTotal.toString())),
            varianceAmount: '0.00',
            notes: `Vardiya #${s.shiftNo} Onaylı Havale/EFT`,
          },
        ],
      });
    }

    if (shouldLock) {
      await tx.cashSession.updateMany({
        where: { storeId: input.storeId, businessDate: targetDate },
        data: {
          status: 'CENTRAL_APPROVED',
          isLocked: true,
          centralApprovedById: actor.id,
          centralApprovedAt: now,
        },
      });
    } else if (input.action === 'RETURN') {
      await tx.cashSession.updateMany({
        where: { storeId: input.storeId, businessDate: targetDate, isLocked: false },
        data: {
          status: 'RETURNED_FOR_CORRECTION',
          notes: input.notes ?? 'Merkez muhasebe tarafından düzeltme için iade edildi.',
        },
      });
    }

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: input.storeId,
        action: `CENTRAL_RECONCILIATION_${input.action}`,
        entityType: 'central_reconciliation',
        entityId: recon.id,
        beforeJson: existing
          ? {
              status: existing.status,
              centralVerifiedCash: existing.centralVerifiedCash?.toString() ?? null,
              isLocked: existing.isLocked,
            }
          : null,
        afterJson: {
          businessDate: input.businessDate,
          expectedCashTotal: formatFixed2(expectedCashTotal),
          declaredCashTotal: formatFixed2(declaredCashTotal),
          centralVerifiedCash: formatFixed2(centralVerifiedDec),
          cashVariance: formatFixed2(cashVarianceDec),
          declaredVsCentralDiff: formatFixed2(declaredVsCentralDec),
          status: nextStatus,
          isLocked: shouldLock,
        },
        reason: input.notes ?? null,
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return recon.id;
  });

  return getReconciliationById(resultId, actor);
}

/**
 * Onaylanmış ve kilitlenmiş mutabakat kaydında doğrudan düzenleme yerine
 * gerekçeli, delta hesaplı ve denetim izli Finansal Düzeltme Kaydı oluşturur.
 */
export async function createFinancialAdjustment(
  reconciliationId: string,
  input: CreateFinancialAdjustmentInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<CentralReconciliationDTO> {
  if (actor.role !== 'CENTRAL_ACCOUNTING' && actor.role !== 'SYSTEM_ADMIN') {
    throw new ForbiddenError('Finansal düzeltme kaydı yalnızca merkez muhasebe veya sistem yöneticisi tarafından oluşturulabilir.');
  }

  const recon = await prisma.centralReconciliation.findUnique({
    where: { id: reconciliationId },
  });
  if (!recon) {
    throw new NotFoundError('Düzeltme yapılacak mutabakat kaydı bulunamadı.');
  }
  if (!recon.isLocked && recon.status !== 'APPROVED') {
    throw new ConflictError(
      'Henüz onaylanıp kilitlenmemiş mutabakatı doğrudan doğrulama ekranından güncelleyebilirsiniz.',
    );
  }

  const adjustedDec = toDecimal(input.adjustedValue);
  let previousDec: Decimal;
  const updateData: Prisma.CentralReconciliationUpdateInput = {};

  if (input.fieldName === 'central_verified_cash') {
    previousDec =
      recon.centralVerifiedCash !== null
        ? toDecimal(recon.centralVerifiedCash.toString())
        : new Decimal(0);
    const expectedDec = toDecimal(recon.expectedCashTotal.toString());
    const declaredDec = toDecimal(recon.declaredCashTotal.toString());

    updateData.centralVerifiedCash = formatFixed2(adjustedDec);
    updateData.cashVariance = formatFixed2(adjustedDec.minus(expectedDec));
    updateData.declaredVsCentralDiff = formatFixed2(adjustedDec.minus(declaredDec));
  } else if (input.fieldName === 'credit_card_total') {
    previousDec = toDecimal(recon.creditCardTotal.toString());
    const delta = adjustedDec.minus(previousDec);
    updateData.creditCardTotal = formatFixed2(adjustedDec);
    updateData.grandSalesTotal = formatFixed2(
      toDecimal(recon.grandSalesTotal.toString()).plus(delta),
    );
  } else {
    // approved_transfer_total
    previousDec = toDecimal(recon.approvedTransferTotal.toString());
    const delta = adjustedDec.minus(previousDec);
    updateData.approvedTransferTotal = formatFixed2(adjustedDec);
    updateData.grandSalesTotal = formatFixed2(
      toDecimal(recon.grandSalesTotal.toString()).plus(delta),
    );
  }

  const deltaDec = adjustedDec.minus(previousDec);
  if (deltaDec.eq(0)) {
    throw new ValidationError('Yeni tutar mevcut tutarla aynı; düzeltme farkı sıfır olamaz.');
  }

  await prisma.$transaction(async (tx) => {
    const adjustment = await tx.financialAdjustment.create({
      data: {
        centralReconciliationId: recon.id,
        entityType: 'central_reconciliation',
        entityId: recon.id,
        fieldName: input.fieldName,
        previousValue: formatFixed2(previousDec),
        adjustedValue: formatFixed2(adjustedDec),
        deltaAmount: formatFixed2(deltaDec),
        reason: input.reason.trim(),
        createdById: actor.id,
        approvedById: actor.id,
      },
    });

    await tx.centralReconciliation.update({
      where: { id: recon.id },
      data: updateData,
    });

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: recon.storeId,
        action: 'FINANCIAL_ADJUSTMENT_CREATED',
        entityType: 'financial_adjustment',
        entityId: adjustment.id,
        beforeJson: {
          fieldName: input.fieldName,
          previousValue: formatFixed2(previousDec),
        },
        afterJson: {
          fieldName: input.fieldName,
          adjustedValue: formatFixed2(adjustedDec),
          deltaAmount: formatFixed2(deltaDec),
        },
        reason: input.reason.trim(),
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );
  });

  return getReconciliationById(recon.id, actor);
}
