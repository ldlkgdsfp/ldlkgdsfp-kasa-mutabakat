import { Router } from 'express';
import { z } from 'zod';
import {
  createFinancialAdjustmentSchema,
  isoDateOnlySchema,
  reconciliationListQuerySchema,
  verifyCentralReconciliationSchema,
} from '@kasa/shared';
import { requireAuth } from '../../middlewares/auth.js';
import { csrfProtection } from '../../middlewares/csrf.js';
import { requireRole } from '../../middlewares/rbac.js';
import { asyncHandler } from '../../utils/async-handler.js';
import {
  createFinancialAdjustment,
  getCentralDashboard,
  getReconciliationById,
  listReconciliations,
  verifyCentralReconciliation,
} from './reconciliation.service.js';

const dashboardQuerySchema = z.object({
  businessDate: isoDateOnlySchema.optional(),
});

const reconIdParamSchema = z.object({
  reconciliationId: z.string().uuid('Geçersiz mutabakat kimliği.'),
});

function getTodayIsoTR(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Istanbul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

export const reconciliationsRouter = Router();

reconciliationsRouter.get(
  '/dashboard',
  requireAuth,
  requireRole('CENTRAL_ACCOUNTING', 'SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const query = dashboardQuerySchema.parse(req.query);
    const businessDate = query.businessDate ?? getTodayIsoTR();
    const dashboard = await getCentralDashboard(businessDate, req.auth!.user);
    res.json(dashboard);
  }),
);

reconciliationsRouter.get(
  '/',
  requireAuth,
  requireRole('CENTRAL_ACCOUNTING', 'SYSTEM_ADMIN', 'STORE_MANAGER'),
  asyncHandler(async (req, res) => {
    const query = reconciliationListQuerySchema.parse(req.query);
    const items = await listReconciliations(req.auth!.user, query);
    res.json({ items });
  }),
);

reconciliationsRouter.get(
  '/:reconciliationId',
  requireAuth,
  requireRole('CENTRAL_ACCOUNTING', 'SYSTEM_ADMIN', 'STORE_MANAGER'),
  asyncHandler(async (req, res) => {
    const { reconciliationId } = reconIdParamSchema.parse(req.params);
    const detail = await getReconciliationById(reconciliationId, req.auth!.user);
    res.json(detail);
  }),
);

reconciliationsRouter.post(
  '/verify',
  requireAuth,
  csrfProtection,
  requireRole('CENTRAL_ACCOUNTING', 'SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const input = verifyCentralReconciliationSchema.parse(req.body);
    const updated = await verifyCentralReconciliation(input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);

reconciliationsRouter.post(
  '/:reconciliationId/adjustments',
  requireAuth,
  csrfProtection,
  requireRole('CENTRAL_ACCOUNTING', 'SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const { reconciliationId } = reconIdParamSchema.parse(req.params);
    const input = createFinancialAdjustmentSchema.parse(req.body);
    const updated = await createFinancialAdjustment(reconciliationId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(201).json(updated);
  }),
);
