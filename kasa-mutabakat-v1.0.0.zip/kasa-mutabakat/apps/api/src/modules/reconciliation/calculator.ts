import { Decimal } from 'decimal.js';
import type {
  CashDifferenceStatus,
  CashTransactionType,
  PaymentMethodCode,
} from '@kasa/shared';

Decimal.set({
  precision: 28,
  rounding: Decimal.ROUND_HALF_UP,
});

export interface CalculatorTransactionInput {
  paymentMethodCode: PaymentMethodCode;
  transactionType: CashTransactionType;
  amount: string | number | Decimal;
  isVoided: boolean;
}

export interface CalculatorReceiptInput {
  verifiedAmount: string | number | Decimal | null;
  status: string;
  isDuplicate: boolean;
  bankAccountVerified: boolean;
}

export interface SessionCalculationInput {
  openingCash: string | number | Decimal;
  declaredCash: string | number | Decimal | null;
  transactions: CalculatorTransactionInput[];
  receipts: CalculatorReceiptInput[];
  requireBankVerification?: boolean;
}

export interface SessionCalculationResult {
  openingCash: string;
  cashSalesTotal: string;
  creditCardSalesTotal: string;
  bankTransferTotal: string;
  bankVerifiedTransferTotal: string;
  cashRefundTotal: string;
  cardRefundTotal: string;
  transferRefundTotal: string;
  totalRefunds: string;
  otherCashInTotal: string;
  otherCashOutTotal: string;
  expectedCash: string;
  declaredCash: string | null;
  cashDifference: string | null;
  cashDifferenceStatus: CashDifferenceStatus;
  cashShortage: string;
  cashSurplus: string;
  netSalesTotal: string;
}

export function toDecimal(value: string | number | Decimal): Decimal {
  return new Decimal(value.toString());
}

export function formatFixed2(value: Decimal): string {
  return value.toDecimalPlaces(2, Decimal.ROUND_HALF_UP).toFixed(2);
}

/**
 * Günlük kasa oturumunun tüm parasal toplamlarını yalnızca Decimal.js ile hesaplar.
 * Kurallar:
 * - Kredi kartı satışları ve iadeleri asla beklenen nakit hesabına girmez.
 * - Havale / EFT satış toplamı yalnızca APPROVED ve mükerrer olmayan dekontlardan hesaplanır.
 * - İptal edilmiş (isVoided = true) hareketler hesaba dahil edilmez.
 * - Beklenen Nakit = Açılış Kasası + Nakit Satış + Diğer Nakit Girişi - Nakit İade - Diğer Nakit Çıkışı
 * - Kasa Farkı = Teslim Edilen Gerçek Nakit - Beklenen Nakit (<0 açık, >0 fazla, =0 eşit)
 */
export function calculateSessionTotals(
  input: SessionCalculationInput,
): SessionCalculationResult {
  const zero = new Decimal(0);
  const openingCash = toDecimal(input.openingCash);

  let cashSales = zero;
  let creditCardSales = zero;
  let cashRefunds = zero;
  let cardRefunds = zero;
  let transferRefunds = zero;
  let otherCashIn = zero;
  let otherCashOut = zero;

  for (const tx of input.transactions) {
    if (tx.isVoided) continue;
    const amount = toDecimal(tx.amount);
    if (amount.lte(0)) continue;

    if (tx.paymentMethodCode === 'CASH') {
      switch (tx.transactionType) {
        case 'SALE':
          cashSales = cashSales.plus(amount);
          break;
        case 'REFUND':
          cashRefunds = cashRefunds.plus(amount);
          break;
        case 'CASH_IN':
          otherCashIn = otherCashIn.plus(amount);
          break;
        case 'CASH_OUT':
          otherCashOut = otherCashOut.plus(amount);
          break;
      }
    } else if (tx.paymentMethodCode === 'CREDIT_CARD') {
      switch (tx.transactionType) {
        case 'SALE':
          creditCardSales = creditCardSales.plus(amount);
          break;
        case 'REFUND':
          cardRefunds = cardRefunds.plus(amount);
          break;
        default:
          // Kredi kartı ile CASH_IN / CASH_OUT yapılamaz
          break;
      }
    } else if (tx.paymentMethodCode === 'BANK_TRANSFER') {
      if (tx.transactionType === 'REFUND') {
        transferRefunds = transferRefunds.plus(amount);
      }
      // BANK_TRANSFER satışları yalnızca onaylı & mükerrer olmayan dekontlardan toplanır
    }
  }

  let approvedTransfers = zero;
  let bankVerifiedTransfers = zero;

  for (const receipt of input.receipts) {
    if (receipt.status !== 'APPROVED' || receipt.isDuplicate || receipt.verifiedAmount === null) {
      continue;
    }
    const amt = toDecimal(receipt.verifiedAmount);
    if (amt.lte(0)) continue;

    if (receipt.bankAccountVerified) {
      bankVerifiedTransfers = bankVerifiedTransfers.plus(amt);
    }

    if (input.requireBankVerification && !receipt.bankAccountVerified) {
      continue;
    }

    approvedTransfers = approvedTransfers.plus(amt);
  }

  const expectedCash = openingCash
    .plus(cashSales)
    .plus(otherCashIn)
    .minus(cashRefunds)
    .minus(otherCashOut);

  const totalRefunds = cashRefunds.plus(cardRefunds).plus(transferRefunds);
  const netSalesTotal = cashSales
    .plus(creditCardSales)
    .plus(approvedTransfers)
    .minus(totalRefunds);

  let declaredCashDec: Decimal | null = null;
  let cashDifferenceDec: Decimal | null = null;
  let cashDifferenceStatus: CashDifferenceStatus = 'PENDING';
  let cashShortage = zero;
  let cashSurplus = zero;

  if (input.declaredCash !== null && input.declaredCash !== undefined) {
    declaredCashDec = toDecimal(input.declaredCash);
    cashDifferenceDec = declaredCashDec.minus(expectedCash);

    if (cashDifferenceDec.lt(0)) {
      cashDifferenceStatus = 'SHORTAGE';
      cashShortage = cashDifferenceDec.abs();
    } else if (cashDifferenceDec.gt(0)) {
      cashDifferenceStatus = 'SURPLUS';
      cashSurplus = cashDifferenceDec;
    } else {
      cashDifferenceStatus = 'EQUAL';
    }
  }

  return {
    openingCash: formatFixed2(openingCash),
    cashSalesTotal: formatFixed2(cashSales),
    creditCardSalesTotal: formatFixed2(creditCardSales),
    bankTransferTotal: formatFixed2(approvedTransfers),
    bankVerifiedTransferTotal: formatFixed2(bankVerifiedTransfers),
    cashRefundTotal: formatFixed2(cashRefunds),
    cardRefundTotal: formatFixed2(cardRefunds),
    transferRefundTotal: formatFixed2(transferRefunds),
    totalRefunds: formatFixed2(totalRefunds),
    otherCashInTotal: formatFixed2(otherCashIn),
    otherCashOutTotal: formatFixed2(otherCashOut),
    expectedCash: formatFixed2(expectedCash),
    declaredCash: declaredCashDec !== null ? formatFixed2(declaredCashDec) : null,
    cashDifference: cashDifferenceDec !== null ? formatFixed2(cashDifferenceDec) : null,
    cashDifferenceStatus,
    cashShortage: formatFixed2(cashShortage),
    cashSurplus: formatFixed2(cashSurplus),
    netSalesTotal: formatFixed2(netSalesTotal),
  };
}

export interface AggregateTotalsInput {
  cashSalesTotal: string;
  creditCardSalesTotal: string;
  bankTransferTotal: string;
  totalRefunds: string;
  expectedCash: string;
  declaredCash: string | null;
  cashShortage: string;
  cashSurplus: string;
  netSalesTotal: string;
}

export interface AggregateTotalsResult {
  sessionCount: number;
  submittedCount: number;
  cashSalesTotal: string;
  creditCardSalesTotal: string;
  bankTransferTotal: string;
  totalRefunds: string;
  expectedCashTotal: string;
  declaredCashTotal: string;
  totalShortage: string;
  totalSurplus: string;
  netCashVariance: string;
  netSalesTotal: string;
}

/**
 * Birden fazla kasiyer oturumunu mağaza veya genel toplam olarak Decimal.js kesinliğiyle birleştirir.
 */
export function aggregateSessionTotals(
  sessions: AggregateTotalsInput[],
): AggregateTotalsResult {
  const zero = new Decimal(0);
  let cashSales = zero;
  let cardSales = zero;
  let bankTransfers = zero;
  let refunds = zero;
  let expectedCash = zero;
  let declaredCash = zero;
  let totalShortage = zero;
  let totalSurplus = zero;
  let netSales = zero;
  let submittedCount = 0;

  for (const s of sessions) {
    cashSales = cashSales.plus(toDecimal(s.cashSalesTotal));
    cardSales = cardSales.plus(toDecimal(s.creditCardSalesTotal));
    bankTransfers = bankTransfers.plus(toDecimal(s.bankTransferTotal));
    refunds = refunds.plus(toDecimal(s.totalRefunds));
    expectedCash = expectedCash.plus(toDecimal(s.expectedCash));
    netSales = netSales.plus(toDecimal(s.netSalesTotal));
    if (s.declaredCash !== null) {
      submittedCount += 1;
      declaredCash = declaredCash.plus(toDecimal(s.declaredCash));
      totalShortage = totalShortage.plus(toDecimal(s.cashShortage));
      totalSurplus = totalSurplus.plus(toDecimal(s.cashSurplus));
    }
  }

  const netCashVariance = totalSurplus.minus(totalShortage);

  return {
    sessionCount: sessions.length,
    submittedCount,
    cashSalesTotal: formatFixed2(cashSales),
    creditCardSalesTotal: formatFixed2(cardSales),
    bankTransferTotal: formatFixed2(bankTransfers),
    totalRefunds: formatFixed2(refunds),
    expectedCashTotal: formatFixed2(expectedCash),
    declaredCashTotal: formatFixed2(declaredCash),
    totalShortage: formatFixed2(totalShortage),
    totalSurplus: formatFixed2(totalSurplus),
    netCashVariance: formatFixed2(netCashVariance),
    netSalesTotal: formatFixed2(netSales),
  };
}
