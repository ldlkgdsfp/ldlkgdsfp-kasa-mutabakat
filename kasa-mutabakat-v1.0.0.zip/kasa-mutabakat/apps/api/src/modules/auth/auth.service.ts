import {
  ROLE_LABELS_TR,
  type AuthSessionResponse,
  type LoginRequest,
  type RoleCode,
  type StoreType,
} from '@kasa/shared';
import { env } from '../../config/env.js';
import { prisma } from '../../config/prisma.js';
import { recordAuditLog } from '../audit/audit.service.js';
import { TooManyRequestsError, UnauthorizedError } from '../../utils/errors.js';
import { generateSecureToken, sha256Hex, verifyPassword } from '../../utils/password.js';

export interface RequestMeta {
  ipAddress: string;
  userAgent: string | null;
  requestId: string;
}

export interface LoginResult {
  rawSessionToken: string;
  sessionResponse: AuthSessionResponse;
}

const INVALID_CREDENTIALS_MESSAGE = 'Kullanıcı adı/e-posta veya parola hatalı.';

export async function loginWithCredentials(
  input: LoginRequest,
  meta: RequestMeta,
): Promise<LoginResult> {
  const normalized = input.identifier.trim().toLowerCase();

  const user = await prisma.user.findFirst({
    where: {
      OR: [
        { username: { equals: normalized, mode: 'insensitive' } },
        { email: { equals: normalized, mode: 'insensitive' } },
      ],
    },
    include: {
      role: true,
      store: true,
    },
  });

  if (!user) {
    await recordAuditLog({
      action: 'LOGIN_FAILED',
      entityType: 'user',
      afterJson: { identifier: normalized, reason: 'USER_NOT_FOUND' },
      ipAddress: meta.ipAddress,
      userAgent: meta.userAgent,
      requestId: meta.requestId,
    });
    throw new UnauthorizedError(INVALID_CREDENTIALS_MESSAGE);
  }

  const now = new Date();
  if (user.lockedUntil && user.lockedUntil > now) {
    await recordAuditLog({
      actorUserId: user.id,
      actorRole: user.role.code,
      storeId: user.storeId,
      action: 'LOGIN_BLOCKED_LOCKED',
      entityType: 'user',
      entityId: user.id,
      ipAddress: meta.ipAddress,
      userAgent: meta.userAgent,
      requestId: meta.requestId,
    });
    throw new TooManyRequestsError(
      'Hesabınız ardışık başarısız giriş denemeleri nedeniyle geçici olarak kilitlenmiştir. Lütfen daha sonra tekrar deneyin.',
    );
  }

  if (!user.isActive) {
    await recordAuditLog({
      actorUserId: user.id,
      actorRole: user.role.code,
      storeId: user.storeId,
      action: 'LOGIN_FAILED',
      entityType: 'user',
      entityId: user.id,
      afterJson: { reason: 'USER_INACTIVE' },
      ipAddress: meta.ipAddress,
      userAgent: meta.userAgent,
      requestId: meta.requestId,
    });
    throw new UnauthorizedError('Hesabınız pasif durumdadır. Sistem yöneticisi ile iletişime geçin.');
  }

  if (user.store && !user.store.isActive) {
    throw new UnauthorizedError('Bağlı olduğunuz mağaza pasif durumdadır.');
  }

  const passwordValid = await verifyPassword(input.password, user.passwordHash);
  if (!passwordValid) {
    const nextAttempts = user.failedLoginAttempts + 1;
    const shouldLock = nextAttempts >= env.ACCOUNT_LOCKOUT_THRESHOLD;
    const lockedUntil = shouldLock
      ? new Date(now.getTime() + env.ACCOUNT_LOCKOUT_MINUTES * 60 * 1000)
      : null;

    await prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: user.id },
        data: {
          failedLoginAttempts: nextAttempts,
          lockedUntil,
        },
      });

      await recordAuditLog(
        {
          actorUserId: user.id,
          actorRole: user.role.code,
          storeId: user.storeId,
          action: shouldLock ? 'ACCOUNT_LOCKED' : 'LOGIN_FAILED',
          entityType: 'user',
          entityId: user.id,
          afterJson: { failedLoginAttempts: nextAttempts, lockedUntil },
          ipAddress: meta.ipAddress,
          userAgent: meta.userAgent,
          requestId: meta.requestId,
        },
        tx,
      );
    });

    if (shouldLock) {
      throw new TooManyRequestsError(
        `Ardışık ${env.ACCOUNT_LOCKOUT_THRESHOLD} başarısız giriş denemesi nedeniyle hesabınız ${env.ACCOUNT_LOCKOUT_MINUTES} dakika süreyle kilitlendi.`,
      );
    }

    throw new UnauthorizedError(INVALID_CREDENTIALS_MESSAGE);
  }

  const rawSessionToken = generateSecureToken(32);
  const tokenHash = sha256Hex(rawSessionToken);
  const csrfToken = generateSecureToken(32);
  const expiresAt = new Date(now.getTime() + env.SESSION_TTL_HOURS * 60 * 60 * 1000);

  await prisma.$transaction(async (tx) => {
    await tx.user.update({
      where: { id: user.id },
      data: {
        failedLoginAttempts: 0,
        lockedUntil: null,
        lastLoginAt: now,
      },
    });

    const createdSession = await tx.userSession.create({
      data: {
        userId: user.id,
        tokenHash,
        csrfToken,
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        expiresAt,
      },
    });

    await recordAuditLog(
      {
        actorUserId: user.id,
        actorRole: user.role.code,
        storeId: user.storeId,
        action: 'LOGIN_SUCCESS',
        entityType: 'user_session',
        entityId: createdSession.id,
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );
  });

  const roleCode = user.role.code as RoleCode;

  return {
    rawSessionToken,
    sessionResponse: {
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        role: roleCode,
        roleLabel: ROLE_LABELS_TR[roleCode],
        storeId: user.storeId,
        store: user.store
          ? {
              id: user.store.id,
              code: user.store.code,
              name: user.store.name,
              type: user.store.type as StoreType,
            }
          : null,
        isActive: user.isActive,
      },
      csrfToken,
      expiresAt: expiresAt.toISOString(),
    },
  };
}

export async function logoutSession(
  sessionId: string,
  user: { id: string; role: RoleCode; storeId: string | null },
  meta: RequestMeta,
): Promise<void> {
  await prisma.$transaction(async (tx) => {
    await tx.userSession.updateMany({
      where: { id: sessionId, revokedAt: null },
      data: { revokedAt: new Date() },
    });

    await recordAuditLog(
      {
        actorUserId: user.id,
        actorRole: user.role,
        storeId: user.storeId,
        action: 'LOGOUT',
        entityType: 'user_session',
        entityId: sessionId,
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );
  });
}

export async function logoutAllUserSessions(
  user: { id: string; role: RoleCode; storeId: string | null },
  meta: RequestMeta,
): Promise<number> {
  return prisma.$transaction(async (tx) => {
    const result = await tx.userSession.updateMany({
      where: { userId: user.id, revokedAt: null },
      data: { revokedAt: new Date() },
    });

    await recordAuditLog(
      {
        actorUserId: user.id,
        actorRole: user.role,
        storeId: user.storeId,
        action: 'LOGOUT_ALL_SESSIONS',
        entityType: 'user',
        entityId: user.id,
        afterJson: { revokedCount: result.count },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return result.count;
  });
}
