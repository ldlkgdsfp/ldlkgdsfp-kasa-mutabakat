import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { env } from '../../config/env.js';
import { requireAuth } from '../../middlewares/auth.js';
import { csrfProtection } from '../../middlewares/csrf.js';
import { asyncHandler } from '../../utils/async-handler.js';
import {
  loginController,
  logoutAllController,
  logoutController,
  meController,
} from './auth.controller.js';

const loginLimiter = rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  max: env.NODE_ENV === 'test' ? 1000 : env.LOGIN_RATE_LIMIT_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: {
      code: 'TOO_MANY_REQUESTS',
      message: 'Çok fazla giriş denemesi yaptınız. Lütfen daha sonra tekrar deneyin.',
    },
  },
});

export const authRouter = Router();

authRouter.post('/login', loginLimiter, asyncHandler(loginController));
authRouter.get('/me', requireAuth, asyncHandler(meController));
authRouter.post('/logout', requireAuth, csrfProtection, asyncHandler(logoutController));
authRouter.post('/logout-all', requireAuth, csrfProtection, asyncHandler(logoutAllController));
