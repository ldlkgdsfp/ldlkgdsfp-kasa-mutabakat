import type { Request, Response } from 'express';
import { loginRequestSchema } from '@kasa/shared';
import { env } from '../../config/env.js';
import {
  loginWithCredentials,
  logoutAllUserSessions,
  logoutSession,
} from './auth.service.js';

function getSessionCookieOptions(expiresAt?: Date) {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: env.COOKIE_SECURE || env.NODE_ENV === 'production',
    path: '/',
    ...(expiresAt ? { expires: expiresAt } : {}),
  };
}

export async function loginController(req: Request, res: Response): Promise<void> {
  const input = loginRequestSchema.parse(req.body);
  const { rawSessionToken, sessionResponse } = await loginWithCredentials(input, {
    ipAddress: req.clientIp,
    userAgent: req.header('user-agent') ?? null,
    requestId: req.requestId,
  });

  res.cookie(
    env.SESSION_COOKIE_NAME,
    rawSessionToken,
    getSessionCookieOptions(new Date(sessionResponse.expiresAt)),
  );
  res.status(200).json(sessionResponse);
}

export async function meController(req: Request, res: Response): Promise<void> {
  const auth = req.auth!;
  res.status(200).json({
    user: auth.user,
    csrfToken: auth.csrfToken,
    expiresAt: auth.expiresAt.toISOString(),
  });
}

export async function logoutController(req: Request, res: Response): Promise<void> {
  const auth = req.auth!;
  await logoutSession(auth.sessionId, auth.user, {
    ipAddress: req.clientIp,
    userAgent: req.header('user-agent') ?? null,
    requestId: req.requestId,
  });

  res.clearCookie(env.SESSION_COOKIE_NAME, getSessionCookieOptions());
  res.status(200).json({ message: 'Oturum güvenli şekilde sonlandırıldı.' });
}

export async function logoutAllController(req: Request, res: Response): Promise<void> {
  const auth = req.auth!;
  const revokedCount = await logoutAllUserSessions(auth.user, {
    ipAddress: req.clientIp,
    userAgent: req.header('user-agent') ?? null,
    requestId: req.requestId,
  });

  res.clearCookie(env.SESSION_COOKIE_NAME, getSessionCookieOptions());
  res.status(200).json({
    message: 'Tüm aktif oturumlar sonlandırıldı.',
    revokedCount,
  });
}
