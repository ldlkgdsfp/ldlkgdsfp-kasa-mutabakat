import { Router } from 'express';
import { z } from 'zod';
import {
  CASH_SESSION_STATUSES,
  createCashTransactionSchema,
  isoDateOnlySchema,
  openCashSessionSchema,
  returnCashSessionSchema,
  storeApproveCashSessionSchema,
  submitCashSessionSchema,
  voidCashTransactionSchema,
} from '@kasa/shared';
import { requireAuth } from '../../middlewares/auth.js';
import { csrfProtection } from '../../middlewares/csrf.js';
import { asyncHandler } from '../../utils/async-handler.js';
import {
  addCashTransaction,
  getCashSessionDetail,
  listCashSessions,
  openCashSession,
  returnCashSessionForCorrection,
  storeApproveCashSession,
  submitCashSession,
  voidCashTransaction,
} from './cash-sessions.service.js';

const sessionIdParamSchema = z.object({
  sessionId: z.string().uuid('Geçersiz kasa oturumu kimliği.'),
});

const txParamSchema = z.object({
  sessionId: z.string().uuid('Geçersiz kasa oturumu kimliği.'),
  txId: z.string().uuid('Geçersiz hareket kimliği.'),
});

const listQuerySchema = z.object({
  storeId: z.string().uuid().optional(),
  cashierId: z.string().uuid().optional(),
  businessDate: isoDateOnlySchema.optional(),
  startDate: isoDateOnlySchema.optional(),
  endDate: isoDateOnlySchema.optional(),
  status: z.enum(CASH_SESSION_STATUSES).optional(),
});

export const cashSessionsRouter = Router();

cashSessionsRouter.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const filters = listQuerySchema.parse(req.query);
    const result = await listCashSessions(req.auth!.user, filters);
    res.json(result);
  }),
);

cashSessionsRouter.post(
  '/',
  requireAuth,
  csrfProtection,
  asyncHandler(async (req, res) => {
    const input = openCashSessionSchema.parse(req.body);
    const created = await openCashSession(input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(201).json(created);
  }),
);

cashSessionsRouter.get(
  '/:sessionId',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { sessionId } = sessionIdParamSchema.parse(req.params);
    const detail = await getCashSessionDetail(sessionId, req.auth!.user);
    res.json(detail);
  }),
);

cashSessionsRouter.post(
  '/:sessionId/transactions',
  requireAuth,
  csrfProtection,
  asyncHandler(async (req, res) => {
    const { sessionId } = sessionIdParamSchema.parse(req.params);
    const input = createCashTransactionSchema.parse(req.body);
    const result = await addCashTransaction(sessionId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(201).json(result);
  }),
);

cashSessionsRouter.post(
  '/:sessionId/transactions/:txId/void',
  requireAuth,
  csrfProtection,
  asyncHandler(async (req, res) => {
    const { sessionId, txId } = txParamSchema.parse(req.params);
    const input = voidCashTransactionSchema.parse(req.body);
    const updated = await voidCashTransaction(sessionId, txId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);

cashSessionsRouter.post(
  '/:sessionId/submit',
  requireAuth,
  csrfProtection,
  asyncHandler(async (req, res) => {
    const { sessionId } = sessionIdParamSchema.parse(req.params);
    const input = submitCashSessionSchema.parse(req.body);
    const updated = await submitCashSession(sessionId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);

cashSessionsRouter.post(
  '/:sessionId/store-approve',
  requireAuth,
  csrfProtection,
  asyncHandler(async (req, res) => {
    const { sessionId } = sessionIdParamSchema.parse(req.params);
    const input = storeApproveCashSessionSchema.parse(req.body ?? {});
    const updated = await storeApproveCashSession(sessionId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);

cashSessionsRouter.post(
  '/:sessionId/return',
  requireAuth,
  csrfProtection,
  asyncHandler(async (req, res) => {
    const { sessionId } = sessionIdParamSchema.parse(req.params);
    const input = returnCashSessionSchema.parse(req.body);
    const updated = await returnCashSessionForCorrection(sessionId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);
