import type { Prisma } from '@prisma/client';
import {
  CASH_SESSION_STATUS_LABELS_TR,
  CASH_TRANSACTION_TYPE_LABELS_TR,
  type CashDifferenceStatus,
  type CashSessionDetailDTO,
  type CashSessionStatus,
  type CashSessionSummaryDTO,
  type CashTransactionDTO,
  type CashTransactionType,
  type CreateCashTransactionInput,
  type OpenCashSessionInput,
  type PaymentMethodCode,
  type ReturnCashSessionInput,
  type RoleCode,
  type StoreApproveCashSessionInput,
  type SubmitCashSessionInput,
  type VoidCashTransactionInput,
} from '@kasa/shared';
import { Decimal } from 'decimal.js';
import { prisma } from '../../config/prisma.js';
import { assertStoreAccess, resolveScopedStoreId } from '../../middlewares/store-scope.js';
import { recordAuditLog } from '../audit/audit.service.js';
import type { RequestMeta } from '../auth/auth.service.js';
import {
  aggregateSessionTotals,
  calculateSessionTotals,
  formatFixed2,
  toDecimal,
  type AggregateTotalsResult,
} from '../reconciliation/calculator.js';
import {
  ConflictError,
  ForbiddenError,
  NotFoundError,
  ValidationError,
} from '../../utils/errors.js';

type Actor = { id: string; role: RoleCode; storeId: string | null };

const EDITABLE_STATUSES = new Set<CashSessionStatus>(['OPEN', 'RETURNED_FOR_CORRECTION']);

function parseIsoDateToUtcDate(isoDate: string): Date {
  return new Date(`${isoDate}T00:00:00.000Z`);
}

function formatDateOnly(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function deriveDifferenceMeta(
  declaredCash: Prisma.Decimal | null,
  cashDifference: Prisma.Decimal | null,
): {
  status: CashDifferenceStatus;
  shortage: string;
  surplus: string;
} {
  if (declaredCash === null || cashDifference === null) {
    return { status: 'PENDING', shortage: '0.00', surplus: '0.00' };
  }
  const diff = toDecimal(cashDifference.toString());
  if (diff.lt(0)) {
    return { status: 'SHORTAGE', shortage: formatFixed2(diff.abs()), surplus: '0.00' };
  }
  if (diff.gt(0)) {
    return { status: 'SURPLUS', shortage: '0.00', surplus: formatFixed2(diff) };
  }
  return { status: 'EQUAL', shortage: '0.00', surplus: '0.00' };
}

function mapSessionSummary(
  s: {
    id: string;
    storeId: string;
    store: { id: string; code: string; name: string };
    cashierId: string;
    cashier: { id: string; username: string; fullName: string };
    businessDate: Date;
    shiftNo: number;
    openingCash: Prisma.Decimal;
    cashSalesTotal: Prisma.Decimal;
    creditCardSalesTotal: Prisma.Decimal;
    bankTransferTotal: Prisma.Decimal;
    cashRefundTotal: Prisma.Decimal;
    cardRefundTotal: Prisma.Decimal;
    transferRefundTotal: Prisma.Decimal;
    otherCashInTotal: Prisma.Decimal;
    otherCashOutTotal: Prisma.Decimal;
    expectedCash: Prisma.Decimal;
    declaredCash: Prisma.Decimal | null;
    cashDifference: Prisma.Decimal | null;
    status: string;
    notes: string | null;
    submittedAt: Date | null;
    storeApprovedAt: Date | null;
    centralApprovedAt: Date | null;
    isLocked: boolean;
    createdAt: Date;
    updatedAt: Date;
    _count?: { transactions: number };
  },
): CashSessionSummaryDTO {
  const status = s.status as CashSessionStatus;
  const totalRefundsDec = toDecimal(s.cashRefundTotal.toString())
    .plus(toDecimal(s.cardRefundTotal.toString()))
    .plus(toDecimal(s.transferRefundTotal.toString()));

  const netSalesDec = toDecimal(s.cashSalesTotal.toString())
    .plus(toDecimal(s.creditCardSalesTotal.toString()))
    .plus(toDecimal(s.bankTransferTotal.toString()))
    .minus(totalRefundsDec);

  const diffMeta = deriveDifferenceMeta(s.declaredCash, s.cashDifference);

  return {
    id: s.id,
    storeId: s.storeId,
    store: s.store,
    cashierId: s.cashierId,
    cashier: s.cashier,
    businessDate: formatDateOnly(s.businessDate),
    shiftNo: s.shiftNo,
    openingCash: formatFixed2(toDecimal(s.openingCash.toString())),
    cashSalesTotal: formatFixed2(toDecimal(s.cashSalesTotal.toString())),
    creditCardSalesTotal: formatFixed2(toDecimal(s.creditCardSalesTotal.toString())),
    bankTransferTotal: formatFixed2(toDecimal(s.bankTransferTotal.toString())),
    cashRefundTotal: formatFixed2(toDecimal(s.cashRefundTotal.toString())),
    cardRefundTotal: formatFixed2(toDecimal(s.cardRefundTotal.toString())),
    transferRefundTotal: formatFixed2(toDecimal(s.transferRefundTotal.toString())),
    totalRefunds: formatFixed2(totalRefundsDec),
    otherCashInTotal: formatFixed2(toDecimal(s.otherCashInTotal.toString())),
    otherCashOutTotal: formatFixed2(toDecimal(s.otherCashOutTotal.toString())),
    expectedCash: formatFixed2(toDecimal(s.expectedCash.toString())),
    declaredCash:
      s.declaredCash !== null ? formatFixed2(toDecimal(s.declaredCash.toString())) : null,
    cashDifference:
      s.cashDifference !== null ? formatFixed2(toDecimal(s.cashDifference.toString())) : null,
    cashDifferenceStatus: diffMeta.status,
    cashShortage: diffMeta.shortage,
    cashSurplus: diffMeta.surplus,
    netSalesTotal: formatFixed2(netSalesDec),
    status,
    statusLabel: CASH_SESSION_STATUS_LABELS_TR[status],
    notes: s.notes,
    submittedAt: s.submittedAt ? s.submittedAt.toISOString() : null,
    storeApprovedAt: s.storeApprovedAt ? s.storeApprovedAt.toISOString() : null,
    centralApprovedAt: s.centralApprovedAt ? s.centralApprovedAt.toISOString() : null,
    isLocked: s.isLocked,
    transactionCount: s._count?.transactions ?? 0,
    createdAt: s.createdAt.toISOString(),
    updatedAt: s.updatedAt.toISOString(),
  };
}

/**
 * Oturumun tüm parasal toplamlarını veritabanındaki hareketlerden ve onaylı dekontlardan
 * Decimal.js motoruyla yeniden hesaplar ve kaydeder.
 */
export async function recalculateCashSession(
  sessionId: string,
  tx: Prisma.TransactionClient | typeof prisma = prisma,
): Promise<CashSessionSummaryDTO> {
  const [session, setting] = await Promise.all([
    tx.cashSession.findUnique({
      where: { id: sessionId },
      include: {
        store: { select: { id: true, code: true, name: true } },
        cashier: { select: { id: true, username: true, fullName: true } },
        transactions: {
          include: { paymentMethod: { select: { code: true } } },
        },
        transferReceipts: {
          select: {
            verifiedAmount: true,
            status: true,
            isDuplicate: true,
            bankAccountVerified: true,
          },
        },
      },
    }),
    tx.systemSetting.findUnique({
      where: { key: 'require_bank_verification_for_reconciliation' },
    }),
  ]);

  if (!session) {
    throw new NotFoundError('Kasa oturumu bulunamadı.');
  }

  const requireBankVerification = setting?.valueJson === true;

  const calc = calculateSessionTotals({
    openingCash: session.openingCash.toString(),
    declaredCash: session.declaredCash !== null ? session.declaredCash.toString() : null,
    requireBankVerification,
    transactions: session.transactions.map((t) => ({
      paymentMethodCode: t.paymentMethod.code as PaymentMethodCode,
      transactionType: t.transactionType as CashTransactionType,
      amount: t.amount.toString(),
      isVoided: t.isVoided,
    })),
    receipts: session.transferReceipts.map((r) => ({
      verifiedAmount: r.verifiedAmount !== null ? r.verifiedAmount.toString() : null,
      status: r.status,
      isDuplicate: r.isDuplicate,
      bankAccountVerified: r.bankAccountVerified,
    })),
  });

  const updated = await tx.cashSession.update({
    where: { id: sessionId },
    data: {
      cashSalesTotal: calc.cashSalesTotal,
      creditCardSalesTotal: calc.creditCardSalesTotal,
      bankTransferTotal: calc.bankTransferTotal,
      cashRefundTotal: calc.cashRefundTotal,
      cardRefundTotal: calc.cardRefundTotal,
      transferRefundTotal: calc.transferRefundTotal,
      otherCashInTotal: calc.otherCashInTotal,
      otherCashOutTotal: calc.otherCashOutTotal,
      expectedCash: calc.expectedCash,
      cashDifference: calc.cashDifference,
      version: { increment: 1 },
    },
    include: {
      store: { select: { id: true, code: true, name: true } },
      cashier: { select: { id: true, username: true, fullName: true } },
      _count: { select: { transactions: { where: { isVoided: false } } } },
    },
  });

  return mapSessionSummary(updated);
}

export interface CashierRollupDTO {
  cashierId: string;
  cashierName: string;
  cashierUsername: string;
  storeId: string;
  storeName: string;
  sessionCount: number;
  cashSalesTotal: string;
  creditCardSalesTotal: string;
  bankTransferTotal: string;
  totalRefunds: string;
  expectedCashTotal: string;
  declaredCashTotal: string;
  cashShortage: string;
  cashSurplus: string;
  netCashVariance: string;
}

export interface StoreRollupDTO {
  storeId: string;
  storeCode: string;
  storeName: string;
  totals: AggregateTotalsResult;
}

export async function listCashSessions(
  actor: Actor,
  filters: {
    storeId?: string;
    cashierId?: string;
    businessDate?: string;
    startDate?: string;
    endDate?: string;
    status?: CashSessionStatus;
  },
): Promise<{
  items: CashSessionSummaryDTO[];
  totals: AggregateTotalsResult;
  byStore: StoreRollupDTO[];
  byCashier: CashierRollupDTO[];
}> {
  const scopedStoreId = resolveScopedStoreId(actor, filters.storeId);

  if (actor.role === 'CASHIER' && filters.cashierId && filters.cashierId !== actor.id) {
    throw new ForbiddenError('Yalnızca kendi kasa oturumlarınızı görüntüleyebilirsiniz.');
  }

  const effectiveCashierId = actor.role === 'CASHIER' ? actor.id : filters.cashierId;

  const dateWhere: Prisma.DateTimeFilter | undefined = filters.businessDate
    ? { equals: parseIsoDateToUtcDate(filters.businessDate) }
    : filters.startDate || filters.endDate
      ? {
          ...(filters.startDate ? { gte: parseIsoDateToUtcDate(filters.startDate) } : {}),
          ...(filters.endDate ? { lte: parseIsoDateToUtcDate(filters.endDate) } : {}),
        }
      : undefined;

  const sessions = await prisma.cashSession.findMany({
    where: {
      ...(scopedStoreId ? { storeId: scopedStoreId } : {}),
      ...(effectiveCashierId ? { cashierId: effectiveCashierId } : {}),
      ...(dateWhere ? { businessDate: dateWhere } : {}),
      ...(filters.status ? { status: filters.status } : {}),
    },
    include: {
      store: { select: { id: true, code: true, name: true } },
      cashier: { select: { id: true, username: true, fullName: true } },
      _count: { select: { transactions: { where: { isVoided: false } } } },
    },
    orderBy: [{ businessDate: 'desc' }, { store: { code: 'asc' } }, { shiftNo: 'desc' }],
  });

  const items = sessions.map(mapSessionSummary);
  const totals = aggregateSessionTotals(items);

  // Mağaza bazlı özet
  const storeGroups = new Map<string, { meta: { id: string; code: string; name: string }; list: CashSessionSummaryDTO[] }>();
  for (const item of items) {
    const group = storeGroups.get(item.storeId) ?? { meta: item.store, list: [] };
    group.list.push(item);
    storeGroups.set(item.storeId, group);
  }
  const byStore: StoreRollupDTO[] = Array.from(storeGroups.values()).map((g) => ({
    storeId: g.meta.id,
    storeCode: g.meta.code,
    storeName: g.meta.name,
    totals: aggregateSessionTotals(g.list),
  }));

  // Kasiyer bazlı özet
  const cashierGroups = new Map<string, { first: CashSessionSummaryDTO; list: CashSessionSummaryDTO[] }>();
  for (const item of items) {
    const key = `${item.storeId}:${item.cashierId}`;
    const group = cashierGroups.get(key) ?? { first: item, list: [] };
    group.list.push(item);
    cashierGroups.set(key, group);
  }
  const byCashier: CashierRollupDTO[] = Array.from(cashierGroups.values()).map((g) => {
    const agg = aggregateSessionTotals(g.list);
    return {
      cashierId: g.first.cashierId,
      cashierName: g.first.cashier.fullName,
      cashierUsername: g.first.cashier.username,
      storeId: g.first.storeId,
      storeName: g.first.store.name,
      sessionCount: agg.sessionCount,
      cashSalesTotal: agg.cashSalesTotal,
      creditCardSalesTotal: agg.creditCardSalesTotal,
      bankTransferTotal: agg.bankTransferTotal,
      totalRefunds: agg.totalRefunds,
      expectedCashTotal: agg.expectedCashTotal,
      declaredCashTotal: agg.declaredCashTotal,
      cashShortage: agg.totalShortage,
      cashSurplus: agg.totalSurplus,
      netCashVariance: agg.netCashVariance,
    };
  });

  return { items, totals, byStore, byCashier };
}

export async function getCashSessionDetail(
  sessionId: string,
  actor: Actor,
): Promise<CashSessionDetailDTO> {
  const session = await prisma.cashSession.findUnique({
    where: { id: sessionId },
    include: {
      store: { select: { id: true, code: true, name: true } },
      cashier: { select: { id: true, username: true, fullName: true } },
      transactions: {
        include: {
          paymentMethod: { select: { code: true, name: true } },
          createdBy: { select: { id: true, username: true, fullName: true } },
          voidedBy: { select: { id: true, username: true, fullName: true } },
        },
        orderBy: [{ occurredAt: 'desc' }, { createdAt: 'desc' }],
      },
      _count: { select: { transactions: { where: { isVoided: false } } } },
    },
  });

  if (!session) {
    throw new NotFoundError('Kasa oturumu bulunamadı.');
  }

  assertStoreAccess(actor, session.storeId);
  if (actor.role === 'CASHIER' && session.cashierId !== actor.id) {
    throw new ForbiddenError('Başka bir kasiyerin kasa oturumunu görüntüleyemezsiniz.');
  }

  const summary = mapSessionSummary(session);
  const transactions: CashTransactionDTO[] = session.transactions.map((t) => {
    const txType = t.transactionType as CashTransactionType;
    return {
      id: t.id,
      cashSessionId: t.cashSessionId,
      paymentMethodCode: t.paymentMethod.code as PaymentMethodCode,
      paymentMethodName: t.paymentMethod.name,
      transactionType: txType,
      transactionTypeLabel: CASH_TRANSACTION_TYPE_LABELS_TR[txType],
      amount: formatFixed2(toDecimal(t.amount.toString())),
      transferReceiptId: t.transferReceiptId,
      referenceNo: t.referenceNo,
      description: t.description,
      occurredAt: t.occurredAt.toISOString(),
      isVoided: t.isVoided,
      voidReason: t.voidReason,
      voidedAt: t.voidedAt ? t.voidedAt.toISOString() : null,
      createdBy: t.createdBy,
      voidedBy: t.voidedBy,
      createdAt: t.createdAt.toISOString(),
    };
  });

  return { ...summary, transactions };
}

export async function openCashSession(
  input: OpenCashSessionInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<CashSessionSummaryDTO> {
  if (actor.role === 'CENTRAL_ACCOUNTING') {
    throw new ForbiddenError('Merkez muhasebe personeli mağaza adına kasa oturumu açamaz.');
  }

  let targetStoreId: string;
  let targetCashierId: string;

  if (actor.role === 'CASHIER') {
    if (!actor.storeId) {
      throw new ForbiddenError('Hesabınıza tanımlı bir mağaza bulunmamaktadır.');
    }
    if (input.storeId && input.storeId !== actor.storeId) {
      throw new ForbiddenError('Yalnızca kendi mağazanızda kasa oturumu açabilirsiniz.');
    }
    if (input.cashierId && input.cashierId !== actor.id) {
      throw new ForbiddenError('Kasiyer yalnızca kendi hesabı adına kasa oturumu açabilir.');
    }
    targetStoreId = actor.storeId;
    targetCashierId = actor.id;
  } else if (actor.role === 'STORE_MANAGER') {
    if (!actor.storeId) {
      throw new ForbiddenError('Hesabınıza tanımlı bir mağaza bulunmamaktadır.');
    }
    if (input.storeId && input.storeId !== actor.storeId) {
      throw new ForbiddenError('Yalnızca kendi mağazanızda kasa oturumu açabilirsiniz.');
    }
    targetStoreId = actor.storeId;
    targetCashierId = input.cashierId ?? actor.id;
  } else {
    // SYSTEM_ADMIN
    if (!input.storeId || !input.cashierId) {
      throw new ValidationError('Sistem yöneticisi kasa açarken mağaza ve kasiyer seçmelidir.');
    }
    targetStoreId = input.storeId;
    targetCashierId = input.cashierId;
  }

  const [store, cashier] = await Promise.all([
    prisma.store.findUnique({ where: { id: targetStoreId } }),
    prisma.user.findUnique({
      where: { id: targetCashierId },
      include: { role: true },
    }),
  ]);

  if (!store || !store.isActive || store.type !== 'STORE') {
    throw new ValidationError('Yalnızca aktif mağazalar için günlük kasa oturumu açılabilir.');
  }

  if (!cashier || !cashier.isActive) {
    throw new ValidationError('Seçilen kasiyer hesabı bulunamadı veya pasif durumda.');
  }

  if (cashier.storeId !== store.id) {
    throw new ForbiddenError('Seçilen kasiyer bu mağazaya bağlı değildir.');
  }

  const businessDate = parseIsoDateToUtcDate(input.businessDate);
  const openingCashDec = new Decimal(input.openingCash);
  if (openingCashDec.lt(0)) {
    throw new ValidationError('Açılış kasası negatif olamaz.');
  }

  const existingSameDay = await prisma.cashSession.findMany({
    where: {
      storeId: store.id,
      cashierId: cashier.id,
      businessDate,
    },
    orderBy: { shiftNo: 'desc' },
  });

  const activeOpen = existingSameDay.find((s) =>
    EDITABLE_STATUSES.has(s.status as CashSessionStatus),
  );
  if (activeOpen) {
    throw new ConflictError(
      'Bu kasiyer için seçilen tarihte zaten açık bir kasa oturumu bulunuyor. Yeni vardiya açmadan önce mevcut oturumu teslim edin.',
    );
  }

  const nextShiftNo = existingSameDay.length > 0 ? existingSameDay[0]!.shiftNo + 1 : 1;
  const openingFixed = formatFixed2(openingCashDec);

  const created = await prisma.$transaction(async (tx) => {
    const session = await tx.cashSession.create({
      data: {
        storeId: store.id,
        cashierId: cashier.id,
        businessDate,
        shiftNo: nextShiftNo,
        openingCash: openingFixed,
        expectedCash: openingFixed,
        status: 'OPEN',
        notes: input.notes ?? null,
      },
      include: {
        store: { select: { id: true, code: true, name: true } },
        cashier: { select: { id: true, username: true, fullName: true } },
        _count: { select: { transactions: { where: { isVoided: false } } } },
      },
    });

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: store.id,
        action: 'CASH_SESSION_OPENED',
        entityType: 'cash_session',
        entityId: session.id,
        afterJson: {
          businessDate: input.businessDate,
          cashierId: cashier.id,
          shiftNo: nextShiftNo,
          openingCash: openingFixed,
        },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return session;
  });

  return mapSessionSummary(created);
}

export async function addCashTransaction(
  sessionId: string,
  input: CreateCashTransactionInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<{ transaction: CashTransactionDTO; session: CashSessionSummaryDTO }> {
  if (actor.role === 'CENTRAL_ACCOUNTING') {
    throw new ForbiddenError('Merkez muhasebe personeli mağaza kasasına satış hareketi giremez.');
  }

  const session = await prisma.cashSession.findUnique({ where: { id: sessionId } });
  if (!session) {
    throw new NotFoundError('Kasa oturumu bulunamadı.');
  }

  assertStoreAccess(actor, session.storeId);
  if (actor.role === 'CASHIER' && session.cashierId !== actor.id) {
    throw new ForbiddenError('Yalnızca kendi kasa oturumunuza işlem ekleyebilirsiniz.');
  }

  if (session.isLocked || !EDITABLE_STATUSES.has(session.status as CashSessionStatus)) {
    throw new ConflictError(
      'Teslim edilmiş, onaylanmış veya kilitli kasa oturumuna yeni hareket eklenemez.',
    );
  }

  // Ödeme yöntemi ve işlem türü bütünlüğü
  if (
    input.paymentMethodCode === 'CREDIT_CARD' &&
    input.transactionType !== 'SALE' &&
    input.transactionType !== 'REFUND'
  ) {
    throw new ValidationError(
      'Kredi kartı ödeme yönteminde yalnızca Satış veya İade hareketi kaydedilebilir.',
    );
  }

  if (input.paymentMethodCode === 'BANK_TRANSFER') {
    if (input.transactionType === 'SALE') {
      throw new ValidationError(
        'Havale / EFT tahsilatları doğrudan manuel girilemez; yalnızca doğrulanmış ve onaylanmış IBAN dekontu üzerinden mutabakata dahil edilir.',
      );
    }
    if (input.transactionType !== 'REFUND') {
      throw new ValidationError(
        'Havale / EFT yönteminde manuel olarak yalnızca İade hareketi kaydedilebilir.',
      );
    }
  }

  const paymentMethod = await prisma.paymentMethod.findUnique({
    where: { code: input.paymentMethodCode },
  });
  if (!paymentMethod || !paymentMethod.isActive) {
    throw new ValidationError('Geçersiz ödeme yöntemi.');
  }

  const amountFixed = formatFixed2(new Decimal(input.amount));
  if (new Decimal(amountFixed).lte(0)) {
    throw new ValidationError('İşlem tutarı sıfırdan büyük olmalıdır.');
  }

  return prisma.$transaction(async (tx) => {
    const createdTx = await tx.cashTransaction.create({
      data: {
        cashSessionId: session.id,
        storeId: session.storeId,
        cashierId: session.cashierId,
        paymentMethodId: paymentMethod.id,
        transactionType: input.transactionType,
        amount: amountFixed,
        referenceNo: input.referenceNo ?? null,
        description: input.description ?? null,
        occurredAt: input.occurredAt ? new Date(input.occurredAt) : new Date(),
        createdById: actor.id,
      },
      include: {
        paymentMethod: { select: { code: true, name: true } },
        createdBy: { select: { id: true, username: true, fullName: true } },
        voidedBy: { select: { id: true, username: true, fullName: true } },
      },
    });

    const updatedSession = await recalculateCashSession(session.id, tx);

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: session.storeId,
        action: 'CASH_TRANSACTION_CREATED',
        entityType: 'cash_transaction',
        entityId: createdTx.id,
        afterJson: {
          cashSessionId: session.id,
          paymentMethod: input.paymentMethodCode,
          transactionType: input.transactionType,
          amount: amountFixed,
          expectedCashAfter: updatedSession.expectedCash,
        },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return {
      transaction: {
        id: createdTx.id,
        cashSessionId: createdTx.cashSessionId,
        paymentMethodCode: createdTx.paymentMethod.code as PaymentMethodCode,
        paymentMethodName: createdTx.paymentMethod.name,
        transactionType: createdTx.transactionType as CashTransactionType,
        transactionTypeLabel:
          CASH_TRANSACTION_TYPE_LABELS_TR[createdTx.transactionType as CashTransactionType],
        amount: formatFixed2(toDecimal(createdTx.amount.toString())),
        transferReceiptId: createdTx.transferReceiptId,
        referenceNo: createdTx.referenceNo,
        description: createdTx.description,
        occurredAt: createdTx.occurredAt.toISOString(),
        isVoided: createdTx.isVoided,
        voidReason: createdTx.voidReason,
        voidedAt: null,
        createdBy: createdTx.createdBy,
        voidedBy: createdTx.voidedBy,
        createdAt: createdTx.createdAt.toISOString(),
      },
      session: updatedSession,
    };
  });
}

export async function voidCashTransaction(
  sessionId: string,
  txId: string,
  input: VoidCashTransactionInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<CashSessionSummaryDTO> {
  if (actor.role === 'CENTRAL_ACCOUNTING') {
    throw new ForbiddenError('Merkez muhasebe mağaza içi kasa hareketini iptal edemez.');
  }

  const session = await prisma.cashSession.findUnique({ where: { id: sessionId } });
  if (!session) {
    throw new NotFoundError('Kasa oturumu bulunamadı.');
  }

  assertStoreAccess(actor, session.storeId);
  if (actor.role === 'CASHIER' && session.cashierId !== actor.id) {
    throw new ForbiddenError('Yalnızca kendi kasa oturumunuzdaki hareketi iptal edebilirsiniz.');
  }

  if (session.isLocked || !EDITABLE_STATUSES.has(session.status as CashSessionStatus)) {
    throw new ConflictError('Teslim edilmiş veya kilitli oturumdaki işlemler iptal edilemez.');
  }

  const existingTx = await prisma.cashTransaction.findFirst({
    where: { id: txId, cashSessionId: sessionId },
  });
  if (!existingTx) {
    throw new NotFoundError('İptal edilecek kasa hareketi bulunamadı.');
  }
  if (existingTx.isVoided) {
    throw new ConflictError('Bu hareket zaten iptal edilmiştir.');
  }
  if (existingTx.transferReceiptId) {
    throw new ConflictError(
      'Onaylı IBAN dekontuna bağlı hareket doğrudan iptal edilemez; dekont doğrulama akışını kullanın.',
    );
  }

  return prisma.$transaction(async (tx) => {
    await tx.cashTransaction.update({
      where: { id: txId },
      data: {
        isVoided: true,
        voidReason: input.reason,
        voidedById: actor.id,
        voidedAt: new Date(),
      },
    });

    const updatedSession = await recalculateCashSession(sessionId, tx);

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: session.storeId,
        action: 'CASH_TRANSACTION_VOIDED',
        entityType: 'cash_transaction',
        entityId: txId,
        beforeJson: { isVoided: false, amount: existingTx.amount.toString() },
        afterJson: {
          isVoided: true,
          expectedCashAfter: updatedSession.expectedCash,
        },
        reason: input.reason,
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return updatedSession;
  });
}

export async function submitCashSession(
  sessionId: string,
  input: SubmitCashSessionInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<CashSessionSummaryDTO> {
  if (actor.role === 'CENTRAL_ACCOUNTING') {
    throw new ForbiddenError('Merkez muhasebe kasiyer adına teslim beyanı yapamaz.');
  }

  const session = await prisma.cashSession.findUnique({ where: { id: sessionId } });
  if (!session) {
    throw new NotFoundError('Kasa oturumu bulunamadı.');
  }

  assertStoreAccess(actor, session.storeId);
  if (actor.role === 'CASHIER' && session.cashierId !== actor.id) {
    throw new ForbiddenError('Yalnızca kendi kasa oturumunuzu teslim edebilirsiniz.');
  }

  if (session.isLocked || !EDITABLE_STATUSES.has(session.status as CashSessionStatus)) {
    throw new ConflictError('Bu kasa oturumu teslim edilmeye uygun durumda değildir.');
  }

  const declaredFixed = formatFixed2(new Decimal(input.declaredCash));

  return prisma.$transaction(async (tx) => {
    await tx.cashSession.update({
      where: { id: sessionId },
      data: {
        declaredCash: declaredFixed,
        status: 'CASHIER_SUBMITTED',
        submittedAt: new Date(),
        ...(input.notes !== undefined ? { notes: input.notes } : {}),
      },
    });

    const updated = await recalculateCashSession(sessionId, tx);

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: session.storeId,
        action: 'CASH_SESSION_SUBMITTED',
        entityType: 'cash_session',
        entityId: sessionId,
        beforeJson: { status: session.status, declaredCash: session.declaredCash?.toString() ?? null },
        afterJson: {
          status: updated.status,
          expectedCash: updated.expectedCash,
          declaredCash: updated.declaredCash,
          cashDifference: updated.cashDifference,
        },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return updated;
  });
}

export async function storeApproveCashSession(
  sessionId: string,
  input: StoreApproveCashSessionInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<CashSessionSummaryDTO> {
  if (actor.role !== 'STORE_MANAGER' && actor.role !== 'SYSTEM_ADMIN') {
    throw new ForbiddenError('Günlük kasa kapanışını yalnızca mağaza yöneticisi merkeze gönderebilir.');
  }

  const session = await prisma.cashSession.findUnique({ where: { id: sessionId } });
  if (!session) {
    throw new NotFoundError('Kasa oturumu bulunamadı.');
  }

  assertStoreAccess(actor, session.storeId);

  if (session.isLocked || session.status !== 'CASHIER_SUBMITTED' || session.declaredCash === null) {
    throw new ConflictError(
      'Yalnızca kasiyer tarafından teslim edilmiş ve kilitlenmemiş oturumlar merkeze gönderilebilir.',
    );
  }

  return prisma.$transaction(async (tx) => {
    await tx.cashSession.update({
      where: { id: sessionId },
      data: {
        status: 'STORE_MANAGER_APPROVED',
        storeApprovedById: actor.id,
        storeApprovedAt: new Date(),
        ...(input.notes !== undefined ? { notes: input.notes } : {}),
      },
    });

    const updated = await recalculateCashSession(sessionId, tx);

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: session.storeId,
        action: 'CASH_SESSION_STORE_APPROVED',
        entityType: 'cash_session',
        entityId: sessionId,
        beforeJson: { status: session.status },
        afterJson: {
          status: updated.status,
          expectedCash: updated.expectedCash,
          declaredCash: updated.declaredCash,
          cashDifference: updated.cashDifference,
        },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return updated;
  });
}

export async function returnCashSessionForCorrection(
  sessionId: string,
  input: ReturnCashSessionInput,
  actor: Actor,
  meta: RequestMeta,
): Promise<CashSessionSummaryDTO> {
  if (actor.role === 'CASHIER') {
    throw new ForbiddenError('Kasiyer teslim edilmiş kapanışı kendi başına geri açamaz.');
  }

  const session = await prisma.cashSession.findUnique({ where: { id: sessionId } });
  if (!session) {
    throw new NotFoundError('Kasa oturumu bulunamadı.');
  }

  assertStoreAccess(actor, session.storeId);

  if (session.isLocked || session.status === 'CENTRAL_APPROVED' || session.status === 'LOCKED') {
    throw new ConflictError(
      'Merkez tarafından onaylanmış veya kilitlenmiş oturumlar doğrudan geri açılamaz; gerekçeli finansal düzeltme kaydı kullanılmalıdır.',
    );
  }

  if (actor.role === 'STORE_MANAGER' && session.status !== 'CASHIER_SUBMITTED') {
    throw new ConflictError(
      'Mağaza yöneticisi yalnızca henüz merkeze gönderilmemiş (Kasiyer Teslim Etti) oturumları düzeltmeye iade edebilir.',
    );
  }

  if (
    session.status !== 'CASHIER_SUBMITTED' &&
    session.status !== 'STORE_MANAGER_APPROVED'
  ) {
    throw new ConflictError('Bu oturum düzeltme iadesi için uygun durumda değildir.');
  }

  return prisma.$transaction(async (tx) => {
    await tx.cashSession.update({
      where: { id: sessionId },
      data: {
        status: 'RETURNED_FOR_CORRECTION',
        notes: input.reason,
      },
    });

    const updated = await recalculateCashSession(sessionId, tx);

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: session.storeId,
        action: 'CASH_SESSION_RETURNED',
        entityType: 'cash_session',
        entityId: sessionId,
        beforeJson: { status: session.status },
        afterJson: { status: updated.status },
        reason: input.reason,
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return updated;
  });
}
