import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../../config/prisma.js';
import { requireAuth } from '../../middlewares/auth.js';
import { requireRole } from '../../middlewares/rbac.js';
import { resolveScopedStoreId } from '../../middlewares/store-scope.js';
import { asyncHandler } from '../../utils/async-handler.js';

const auditQuerySchema = z.object({
  storeId: z.string().uuid().optional(),
  action: z.string().trim().min(1).max(100).optional(),
  entityType: z.string().trim().min(1).max(64).optional(),
  limit: z.coerce.number().int().min(1).max(200).default(50),
});

export const auditRouter = Router();

auditRouter.get(
  '/',
  requireAuth,
  requireRole('SYSTEM_ADMIN', 'CENTRAL_ACCOUNTING', 'STORE_MANAGER'),
  asyncHandler(async (req, res) => {
    const query = auditQuerySchema.parse(req.query);
    const scopedStoreId = resolveScopedStoreId(req.auth!.user, query.storeId);

    const logs = await prisma.auditLog.findMany({
      where: {
        ...(scopedStoreId ? { storeId: scopedStoreId } : {}),
        ...(query.action ? { action: query.action } : {}),
        ...(query.entityType ? { entityType: query.entityType } : {}),
      },
      include: {
        actor: {
          select: { id: true, username: true, fullName: true },
        },
        store: {
          select: { id: true, code: true, name: true },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: query.limit,
    });

    res.json({
      items: logs.map((l) => ({
        id: l.id,
        action: l.action,
        entityType: l.entityType,
        entityId: l.entityId,
        actorRole: l.actorRole,
        actor: l.actor,
        store: l.store,
        reason: l.reason,
        ipAddress: l.ipAddress,
        createdAt: l.createdAt.toISOString(),
      })),
    });
  }),
);
