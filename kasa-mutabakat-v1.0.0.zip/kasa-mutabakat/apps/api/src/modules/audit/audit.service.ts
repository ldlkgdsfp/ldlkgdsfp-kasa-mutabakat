import type { Prisma } from '@prisma/client';
import { prisma } from '../../config/prisma.js';

export interface AuditLogInput {
  actorUserId?: string | null;
  actorRole?: string | null;
  storeId?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  beforeJson?: unknown;
  afterJson?: unknown;
  reason?: string | null;
  ipAddress?: string | null;
  userAgent?: string | null;
  requestId?: string | null;
}

/**
 * Append-only denetim kaydı oluşturur. Güncelleme veya silme yöntemi bilinçli olarak sunulmaz.
 */
export async function recordAuditLog(
  input: AuditLogInput,
  tx: Prisma.TransactionClient | typeof prisma = prisma,
): Promise<void> {
  await tx.auditLog.create({
    data: {
      actorUserId: input.actorUserId ?? null,
      actorRole: input.actorRole ?? null,
      storeId: input.storeId ?? null,
      action: input.action,
      entityType: input.entityType,
      entityId: input.entityId ?? null,
      beforeJson: (input.beforeJson ?? undefined) as Prisma.InputJsonValue | undefined,
      afterJson: (input.afterJson ?? undefined) as Prisma.InputJsonValue | undefined,
      reason: input.reason ?? null,
      ipAddress: input.ipAddress ?? null,
      userAgent: input.userAgent ?? null,
      requestId: input.requestId ?? null,
    },
  });
}
