import { Router } from 'express';
import { z } from 'zod';
import { REPORT_TYPES, reportQuerySchema } from '@kasa/shared';
import { requireAuth } from '../../middlewares/auth.js';
import { recordAuditLog } from '../audit/audit.service.js';
import { asyncHandler } from '../../utils/async-handler.js';
import { buildReportCsv, buildReportXlsx } from './export.js';
import { generateReport } from './reports.service.js';

const reportTypeParamSchema = z.object({
  reportType: z.enum(REPORT_TYPES, {
    errorMap: () => ({ message: 'Geçersiz rapor türü.' }),
  }),
});

export const reportsRouter = Router();

reportsRouter.get(
  '/:reportType',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { reportType } = reportTypeParamSchema.parse(req.params);
    const query = reportQuerySchema.parse(req.query);
    const report = await generateReport(reportType, query, req.auth!.user);
    res.json(report);
  }),
);

reportsRouter.get(
  '/:reportType/export',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { reportType } = reportTypeParamSchema.parse(req.params);
    const query = reportQuerySchema.parse(req.query);
    const format = query.format === 'csv' ? 'csv' : 'xlsx';
    const report = await generateReport(reportType, query, req.auth!.user);

    await recordAuditLog({
      actorUserId: req.auth!.user.id,
      actorRole: req.auth!.user.role,
      storeId: report.filters.storeId ?? req.auth!.user.storeId,
      action: 'REPORT_EXPORTED',
      entityType: 'report',
      entityId: reportType,
      afterJson: {
        format,
        filters: report.filters,
        rowCount: report.rows.length,
      },
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });

    const filenameBase = `${reportType}_${report.filters.startDate}_${report.filters.endDate}`;

    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-store');

    if (format === 'csv') {
      const buffer = buildReportCsv(report);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${filenameBase}.csv"`);
      res.send(buffer);
      return;
    }

    const buffer = await buildReportXlsx(report);
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
    res.setHeader('Content-Disposition', `attachment; filename="${filenameBase}.xlsx"`);
    res.send(buffer);
  }),
);
