import ExcelJS from 'exceljs';
import { formatDateTR, type ReportColumnDefinition, type ReportPayloadDTO } from '@kasa/shared';

const FORMULA_TRIGGER_REGEX = /^[\s]*[=+\-@\t\r]/;

/**
 * OWASP CSV / Excel Formül Enjeksiyonu Koruması:
 * Metin sütunlarında '=', '+', '-', '@', tab veya CR ile başlayan değerleri etkisizleştirir.
 */
export function sanitizeSpreadsheetText(raw: string): string {
  if (FORMULA_TRIGGER_REGEX.test(raw)) {
    return `'${raw}`;
  }
  return raw;
}

function escapeCsvField(value: string): string {
  if (/[",\r\n]/.test(value)) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

function formatCellForCsv(
  col: ReportColumnDefinition,
  rawVal: string | number | boolean | null | undefined,
): string {
  if (rawVal === null || rawVal === undefined) return '';
  if (typeof rawVal === 'boolean') return rawVal ? 'Evet' : 'Hayır';

  if (col.type === 'currency' || col.type === 'number') {
    const str = String(rawVal);
    // Sayısal sütunlarda yalnızca geçerli imzalı sayıya izin ver; aksi halde formül sanitizasyonu uygula
    if (/^-?\d+(\.\d+)?$/.test(str)) {
      return str;
    }
    return sanitizeSpreadsheetText(str);
  }

  if (col.type === 'percent') {
    const str = String(rawVal);
    return /^-?\d+(\.\d+)?$/.test(str) ? `${str}%` : sanitizeSpreadsheetText(str);
  }

  if (col.type === 'date') {
    const str = String(rawVal);
    return /^\d{4}-\d{2}-\d{2}/.test(str) ? formatDateTR(str) : sanitizeSpreadsheetText(str);
  }

  return sanitizeSpreadsheetText(String(rawVal));
}

/**
 * Türkçe karakter uyumlu (UTF-8 BOM) ve formül enjeksiyonundan arındırılmış CSV üretir.
 */
export function buildReportCsv(report: ReportPayloadDTO): Buffer {
  const lines: string[] = [];
  lines.push(report.columns.map((c) => escapeCsvField(sanitizeSpreadsheetText(c.label))).join(','));

  for (const row of report.rows) {
    const fields = report.columns.map((col) =>
      escapeCsvField(formatCellForCsv(col, row[col.key])),
    );
    lines.push(fields.join(','));
  }

  const csvBody = `\uFEFF${lines.join('\r\n')}\r\n`;
  return Buffer.from(csvBody, 'utf8');
}

/**
 * Kurumsal biçimlendirmeli gerçek Excel (.xlsx) dosyası üretir.
 */
export async function buildReportXlsx(report: ReportPayloadDTO): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Kasa Mutabakat Sistemi';
  workbook.created = new Date();

  const sheetName = report.title.replace(/[\\/*?:[\]]/g, '').slice(0, 31) || 'Rapor';
  const sheet = workbook.addWorksheet(sheetName, {
    views: [{ state: 'frozen', ySplit: 4 }],
  });

  // Başlık bloğu
  sheet.addRow([sanitizeSpreadsheetText(report.title)]);
  const titleRow = sheet.getRow(1);
  titleRow.font = { bold: true, size: 14, color: { argb: 'FF0F172A' } };

  sheet.addRow([
    `Tarih Aralığı: ${formatDateTR(report.filters.startDate)} - ${formatDateTR(report.filters.endDate)}`,
  ]);
  sheet.getRow(2).font = { size: 10, color: { argb: 'FF475569' } };
  sheet.addRow([]);

  // Sütun başlıkları
  const headerRow = sheet.addRow(report.columns.map((c) => sanitizeSpreadsheetText(c.label)));
  headerRow.font = { bold: true, size: 10, color: { argb: 'FFFFFFFF' } };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FF0F172A' },
  };
  headerRow.alignment = { vertical: 'middle', horizontal: 'left' };
  headerRow.height = 24;

  // Veri satırları
  for (let i = 0; i < report.rows.length; i++) {
    const row = report.rows[i]!;
    const values = report.columns.map((col) => {
      const val = row[col.key];
      if (val === null || val === undefined) return '';
      if (typeof val === 'boolean') return val ? 'Evet' : 'Hayır';
      if (col.type === 'currency' || col.type === 'number') {
        const num = Number(val);
        return Number.isFinite(num) ? num : sanitizeSpreadsheetText(String(val));
      }
      if (col.type === 'percent') {
        const num = Number(val);
        return Number.isFinite(num) ? num / 100 : sanitizeSpreadsheetText(String(val));
      }
      if (col.type === 'date') {
        const str = String(val);
        return /^\d{4}-\d{2}-\d{2}/.test(str) ? formatDateTR(str) : sanitizeSpreadsheetText(str);
      }
      return sanitizeSpreadsheetText(String(val));
    });

    const excelRow = sheet.addRow(values);
    if (i % 2 === 1) {
      excelRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFF8FAFC' },
      };
    }

    report.columns.forEach((col, colIdx) => {
      const cell = excelRow.getCell(colIdx + 1);
      if (col.type === 'currency') {
        cell.numFmt = '#,##0.00 "₺"';
        cell.alignment = { horizontal: 'right' };
      } else if (col.type === 'percent') {
        cell.numFmt = '0.00%';
        cell.alignment = { horizontal: 'right' };
      } else if (col.type === 'number') {
        cell.alignment = { horizontal: 'right' };
      }
    });
  }

  // Sütun genişliklerini içeriğe göre ayarla
  report.columns.forEach((col, idx) => {
    const column = sheet.getColumn(idx + 1);
    let maxLen = col.label.length + 4;
    for (const row of report.rows) {
      const len = String(row[col.key] ?? '').length + 3;
      if (len > maxLen) maxLen = len;
    }
    column.width = Math.min(42, Math.max(14, maxLen));
  });

  const arrayBuffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(arrayBuffer);
}
