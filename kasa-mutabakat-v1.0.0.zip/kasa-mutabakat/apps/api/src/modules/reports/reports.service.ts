import {
  CASH_SESSION_STATUS_LABELS_TR,
  RECEIPT_STATUS_LABELS_TR,
  RECONCILIATION_STATUS_LABELS_TR,
  REPORT_LABELS_TR,
  type CashSessionStatus,
  type ReceiptStatus,
  type ReconciliationStatus,
  type ReportColumnDefinition,
  type ReportPayloadDTO,
  type ReportQueryInput,
  type ReportType,
  type RoleCode,
} from '@kasa/shared';
import { Decimal } from 'decimal.js';
import { prisma } from '../../config/prisma.js';
import { resolveScopedStoreId } from '../../middlewares/store-scope.js';
import { listCashSessions } from '../cash-sessions/cash-sessions.service.js';
import { listReceipts } from '../receipts/receipts.service.js';
import { formatFixed2, toDecimal } from '../reconciliation/calculator.js';
import { ForbiddenError } from '../../utils/errors.js';

type Actor = { id: string; role: RoleCode; storeId: string | null };
type ReportRow = Record<string, string | number | boolean | null>;

function getTodayIsoTR(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Istanbul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

function getMonthStartIsoTR(): string {
  const today = getTodayIsoTR();
  return `${today.slice(0, 7)}-01`;
}

function parseDateOnly(iso: string): Date {
  return new Date(`${iso}T00:00:00.000Z`);
}

function sortRows(
  rows: ReportRow[],
  columns: ReportColumnDefinition[],
  sortBy: string | undefined,
  sortDir: 'asc' | 'desc',
): ReportRow[] {
  if (!sortBy) return rows;
  const col = columns.find((c) => c.key === sortBy);
  if (!col) return rows;

  const factor = sortDir === 'asc' ? 1 : -1;
  return [...rows].sort((a, b) => {
    const av = a[sortBy];
    const bv = b[sortBy];
    if (av === bv) return 0;
    if (av === null || av === undefined) return 1;
    if (bv === null || bv === undefined) return -1;

    if (col.type === 'currency' || col.type === 'number' || col.type === 'percent') {
      const da = toDecimal(String(av));
      const db = toDecimal(String(bv));
      return da.comparedTo(db) * factor;
    }

    return String(av).localeCompare(String(bv), 'tr-TR') * factor;
  });
}

function pctString(part: Decimal, whole: Decimal): string {
  if (whole.lte(0)) return '0.00';
  return formatFixed2(part.div(whole).mul(100));
}

export async function generateReport(
  reportType: ReportType,
  query: ReportQueryInput,
  actor: Actor,
): Promise<ReportPayloadDTO> {
  const today = getTodayIsoTR();
  const startDate =
    query.startDate ??
    (reportType === 'monthly-summary' || reportType === 'date-range' || reportType === 'store-comparison'
      ? getMonthStartIsoTR()
      : today);
  const endDate = query.endDate ?? today;

  const scopedStoreId = resolveScopedStoreId(actor, query.storeId);

  if (actor.role === 'CASHIER' && query.cashierId && query.cashierId !== actor.id) {
    throw new ForbiddenError('Kasiyer yalnızca kendi verileri için rapor alabilir.');
  }
  const effectiveCashierId = actor.role === 'CASHIER' ? actor.id : query.cashierId;

  const filtersOut = {
    startDate,
    endDate,
    storeId: scopedStoreId ?? null,
    cashierId: effectiveCashierId ?? null,
  };

  const zero = new Decimal(0);

  if (reportType === 'daily-store') {
    const [sessionsRes, reconciliations] = await Promise.all([
      listCashSessions(actor, {
        storeId: scopedStoreId,
        cashierId: effectiveCashierId,
        startDate,
        endDate,
      }),
      prisma.centralReconciliation.findMany({
        where: {
          ...(scopedStoreId ? { storeId: scopedStoreId } : {}),
          businessDate: { gte: parseDateOnly(startDate), lte: parseDateOnly(endDate) },
        },
      }),
    ]);

    const reconMap = new Map<string, (typeof reconciliations)[number]>();
    for (const r of reconciliations) {
      reconMap.set(`${r.storeId}:${r.businessDate.toISOString().slice(0, 10)}`, r);
    }

    const groups = new Map<
      string,
      {
        businessDate: string;
        storeId: string;
        storeName: string;
        storeCode: string;
        sessionCount: number;
        cashSales: Decimal;
        cardSales: Decimal;
        bankTransfer: Decimal;
        refunds: Decimal;
        netSales: Decimal;
        expectedCash: Decimal;
        declaredCash: Decimal;
        shortage: Decimal;
        surplus: Decimal;
      }
    >();

    for (const s of sessionsRes.items) {
      const key = `${s.storeId}:${s.businessDate}`;
      const g = groups.get(key) ?? {
        businessDate: s.businessDate,
        storeId: s.storeId,
        storeName: s.store.name,
        storeCode: s.store.code,
        sessionCount: 0,
        cashSales: zero,
        cardSales: zero,
        bankTransfer: zero,
        refunds: zero,
        netSales: zero,
        expectedCash: zero,
        declaredCash: zero,
        shortage: zero,
        surplus: zero,
      };
      g.sessionCount += 1;
      g.cashSales = g.cashSales.plus(toDecimal(s.cashSalesTotal));
      g.cardSales = g.cardSales.plus(toDecimal(s.creditCardSalesTotal));
      g.bankTransfer = g.bankTransfer.plus(toDecimal(s.bankTransferTotal));
      g.refunds = g.refunds.plus(toDecimal(s.totalRefunds));
      g.netSales = g.netSales.plus(toDecimal(s.netSalesTotal));
      g.expectedCash = g.expectedCash.plus(toDecimal(s.expectedCash));
      if (s.declaredCash !== null) {
        g.declaredCash = g.declaredCash.plus(toDecimal(s.declaredCash));
      }
      g.shortage = g.shortage.plus(toDecimal(s.cashShortage));
      g.surplus = g.surplus.plus(toDecimal(s.cashSurplus));
      groups.set(key, g);
    }

    const columns: ReportColumnDefinition[] = [
      { key: 'businessDate', label: 'Tarih', type: 'date' },
      { key: 'storeName', label: 'Mağaza', type: 'text' },
      { key: 'sessionCount', label: 'Kasiyer Oturumu', type: 'number' },
      { key: 'cashSales', label: 'Nakit Satış', type: 'currency' },
      { key: 'cardSales', label: 'Kredi Kartı', type: 'currency' },
      { key: 'bankTransfer', label: 'Onaylı Havale / EFT', type: 'currency' },
      { key: 'refunds', label: 'İadeler', type: 'currency' },
      { key: 'netSales', label: 'Net Satış', type: 'currency' },
      { key: 'expectedCash', label: 'Beklenen Nakit', type: 'currency' },
      { key: 'declaredCash', label: 'Teslim Edilen Nakit', type: 'currency' },
      { key: 'shortage', label: 'Kasa Açığı', type: 'currency' },
      { key: 'surplus', label: 'Kasa Fazlası', type: 'currency' },
      { key: 'reconciliationStatus', label: 'Merkez Onay Durumu', type: 'text' },
    ];

    const rawRows: ReportRow[] = Array.from(groups.values()).map((g) => {
      const recon = reconMap.get(`${g.storeId}:${g.businessDate}`);
      const statusLabel = recon
        ? RECONCILIATION_STATUS_LABELS_TR[recon.status as ReconciliationStatus]
        : 'Kontrol Bekliyor';
      return {
        businessDate: g.businessDate,
        storeName: `${g.storeName} (${g.storeCode})`,
        sessionCount: g.sessionCount,
        cashSales: formatFixed2(g.cashSales),
        cardSales: formatFixed2(g.cardSales),
        bankTransfer: formatFixed2(g.bankTransfer),
        refunds: formatFixed2(g.refunds),
        netSales: formatFixed2(g.netSales),
        expectedCash: formatFixed2(g.expectedCash),
        declaredCash: formatFixed2(g.declaredCash),
        shortage: formatFixed2(g.shortage),
        surplus: formatFixed2(g.surplus),
        reconciliationStatus: statusLabel,
      };
    });

    const rows = sortRows(rawRows, columns, query.sortBy ?? 'businessDate', query.sortDir);
    const chartData = rows.map((r) => ({
      name: `${r.businessDate} · ${String(r.storeName).split(' (')[0]}`,
      Nakit: Number(r.cashSales),
      'Kredi Kartı': Number(r.cardSales),
      'Havale / EFT': Number(r.bankTransfer),
    }));

    return {
      reportType,
      title: REPORT_LABELS_TR[reportType],
      generatedAt: new Date().toISOString(),
      filters: filtersOut,
      columns,
      rows,
      summary: {
        rowCount: rows.length,
        netSalesTotal: sessionsRes.totals.netSalesTotal,
        cashSalesTotal: sessionsRes.totals.cashSalesTotal,
        creditCardSalesTotal: sessionsRes.totals.creditCardSalesTotal,
        bankTransferTotal: sessionsRes.totals.bankTransferTotal,
        totalShortage: sessionsRes.totals.totalShortage,
        totalSurplus: sessionsRes.totals.totalSurplus,
      },
      chartData,
    };
  }

  if (reportType === 'store-comparison') {
    const [stores, sessionsRes, reconciliations] = await Promise.all([
      prisma.store.findMany({
        where: {
          type: 'STORE',
          isActive: true,
          ...(scopedStoreId ? { id: scopedStoreId } : {}),
        },
        orderBy: { code: 'asc' },
      }),
      listCashSessions(actor, {
        storeId: scopedStoreId,
        cashierId: effectiveCashierId,
        startDate,
        endDate,
      }),
      prisma.centralReconciliation.findMany({
        where: {
          ...(scopedStoreId ? { storeId: scopedStoreId } : {}),
          businessDate: { gte: parseDateOnly(startDate), lte: parseDateOnly(endDate) },
          status: 'APPROVED',
        },
      }),
    ]);

    const approvedDaysByStore = new Map<string, number>();
    for (const r of reconciliations) {
      approvedDaysByStore.set(r.storeId, (approvedDaysByStore.get(r.storeId) ?? 0) + 1);
    }

    const totalAllSales = toDecimal(sessionsRes.totals.netSalesTotal);

    const columns: ReportColumnDefinition[] = [
      { key: 'storeName', label: 'Mağaza', type: 'text' },
      { key: 'activeDays', label: 'Aktif Gün', type: 'number' },
      { key: 'approvedDays', label: 'Onaylı Gün', type: 'number' },
      { key: 'cashSales', label: 'Nakit Satış', type: 'currency' },
      { key: 'cardSales', label: 'Kredi Kartı', type: 'currency' },
      { key: 'bankTransfer', label: 'Onaylı Havale / EFT', type: 'currency' },
      { key: 'refunds', label: 'İadeler', type: 'currency' },
      { key: 'netSales', label: 'Net Satış', type: 'currency' },
      { key: 'salesSharePct', label: 'Ciro Payı', type: 'percent' },
      { key: 'shortage', label: 'Toplam Açık', type: 'currency' },
      { key: 'surplus', label: 'Toplam Fazla', type: 'currency' },
    ];

    const rawRows: ReportRow[] = stores.map((store) => {
      const storeSessions = sessionsRes.items.filter((s) => s.storeId === store.id);
      const distinctDays = new Set(storeSessions.map((s) => s.businessDate)).size;
      const rollup = sessionsRes.byStore.find((b) => b.storeId === store.id)?.totals;

      const netSalesDec = rollup ? toDecimal(rollup.netSalesTotal) : zero;
      return {
        storeName: `${store.name} (${store.code})`,
        activeDays: distinctDays,
        approvedDays: approvedDaysByStore.get(store.id) ?? 0,
        cashSales: rollup?.cashSalesTotal ?? '0.00',
        cardSales: rollup?.creditCardSalesTotal ?? '0.00',
        bankTransfer: rollup?.bankTransferTotal ?? '0.00',
        refunds: rollup?.totalRefunds ?? '0.00',
        netSales: formatFixed2(netSalesDec),
        salesSharePct: pctString(netSalesDec, totalAllSales),
        shortage: rollup?.totalShortage ?? '0.00',
        surplus: rollup?.totalSurplus ?? '0.00',
      };
    });

    const rows = sortRows(rawRows, columns, query.sortBy ?? 'netSales', query.sortDir);
    const chartData = rows.map((r) => ({
      name: String(r.storeName).split(' (')[0]!,
      Nakit: Number(r.cashSales),
      'Kredi Kartı': Number(r.cardSales),
      'Havale / EFT': Number(r.bankTransfer),
      'Net Satış': Number(r.netSales),
    }));

    return {
      reportType,
      title: REPORT_LABELS_TR[reportType],
      generatedAt: new Date().toISOString(),
      filters: filtersOut,
      columns,
      rows,
      summary: {
        storeCount: rows.length,
        netSalesTotal: sessionsRes.totals.netSalesTotal,
        totalShortage: sessionsRes.totals.totalShortage,
        totalSurplus: sessionsRes.totals.totalSurplus,
      },
      chartData,
    };
  }

  if (reportType === 'cashier-variance') {
    const sessionsRes = await listCashSessions(actor, {
      storeId: scopedStoreId,
      cashierId: effectiveCashierId,
      startDate,
      endDate,
    });

    const columns: ReportColumnDefinition[] = [
      { key: 'cashierName', label: 'Kasiyer', type: 'text' },
      { key: 'storeName', label: 'Mağaza', type: 'text' },
      { key: 'sessionCount', label: 'Oturum Sayısı', type: 'number' },
      { key: 'cashSales', label: 'Nakit Satış', type: 'currency' },
      { key: 'cardSales', label: 'Kredi Kartı', type: 'currency' },
      { key: 'bankTransfer', label: 'Havale / EFT', type: 'currency' },
      { key: 'refunds', label: 'İade', type: 'currency' },
      { key: 'expectedCash', label: 'Beklenen Kasa', type: 'currency' },
      { key: 'declaredCash', label: 'Teslim Edilen', type: 'currency' },
      { key: 'shortage', label: 'Kasa Açığı', type: 'currency' },
      { key: 'surplus', label: 'Kasa Fazlası', type: 'currency' },
      { key: 'netVariance', label: 'Net Fark', type: 'currency' },
    ];

    const rawRows: ReportRow[] = sessionsRes.byCashier.map((c) => ({
      cashierName: `${c.cashierName} (${c.cashierUsername})`,
      storeName: c.storeName,
      sessionCount: c.sessionCount,
      cashSales: c.cashSalesTotal,
      cardSales: c.creditCardSalesTotal,
      bankTransfer: c.bankTransferTotal,
      refunds: c.totalRefunds,
      expectedCash: c.expectedCashTotal,
      declaredCash: c.declaredCashTotal,
      shortage: c.cashShortage,
      surplus: c.cashSurplus,
      netVariance: c.netCashVariance,
    }));

    const rows = sortRows(rawRows, columns, query.sortBy ?? 'shortage', query.sortDir);
    const chartData = rows.map((r) => ({
      name: String(r.cashierName).split(' (')[0]!,
      'Kasa Açığı': Number(r.shortage),
      'Kasa Fazlası': Number(r.surplus),
    }));

    return {
      reportType,
      title: REPORT_LABELS_TR[reportType],
      generatedAt: new Date().toISOString(),
      filters: filtersOut,
      columns,
      rows,
      summary: {
        cashierCount: rows.length,
        totalShortage: sessionsRes.totals.totalShortage,
        totalSurplus: sessionsRes.totals.totalSurplus,
        netCashVariance: sessionsRes.totals.netCashVariance,
      },
      chartData,
    };
  }

  if (reportType === 'payment-distribution') {
    const sessionsRes = await listCashSessions(actor, {
      storeId: scopedStoreId,
      cashierId: effectiveCashierId,
      startDate,
      endDate,
    });

    const byDate = new Map<
      string,
      { cash: Decimal; card: Decimal; transfer: Decimal }
    >();
    for (const s of sessionsRes.items) {
      const g = byDate.get(s.businessDate) ?? { cash: zero, card: zero, transfer: zero };
      g.cash = g.cash.plus(toDecimal(s.cashSalesTotal));
      g.card = g.card.plus(toDecimal(s.creditCardSalesTotal));
      g.transfer = g.transfer.plus(toDecimal(s.bankTransferTotal));
      byDate.set(s.businessDate, g);
    }

    const columns: ReportColumnDefinition[] = [
      { key: 'businessDate', label: 'Tarih', type: 'date' },
      { key: 'cashSales', label: 'Nakit', type: 'currency' },
      { key: 'cashPct', label: 'Nakit Payı', type: 'percent' },
      { key: 'cardSales', label: 'Kredi Kartı', type: 'currency' },
      { key: 'cardPct', label: 'Kart Payı', type: 'percent' },
      { key: 'bankTransfer', label: 'Onaylı Havale / EFT', type: 'currency' },
      { key: 'transferPct', label: 'Havale Payı', type: 'percent' },
      { key: 'grossTotal', label: 'Brüt Tahsilat', type: 'currency' },
    ];

    const rawRows: ReportRow[] = Array.from(byDate.entries()).map(([date, g]) => {
      const gross = g.cash.plus(g.card).plus(g.transfer);
      return {
        businessDate: date,
        cashSales: formatFixed2(g.cash),
        cashPct: pctString(g.cash, gross),
        cardSales: formatFixed2(g.card),
        cardPct: pctString(g.card, gross),
        bankTransfer: formatFixed2(g.transfer),
        transferPct: pctString(g.transfer, gross),
        grossTotal: formatFixed2(gross),
      };
    });

    const rows = sortRows(rawRows, columns, query.sortBy ?? 'businessDate', query.sortDir);
    const totalCash = toDecimal(sessionsRes.totals.cashSalesTotal);
    const totalCard = toDecimal(sessionsRes.totals.creditCardSalesTotal);
    const totalTransfer = toDecimal(sessionsRes.totals.bankTransferTotal);

    const chartData = [
      { name: 'Nakit', value: Number(formatFixed2(totalCash)) },
      { name: 'Kredi Kartı', value: Number(formatFixed2(totalCard)) },
      { name: 'Havale / EFT', value: Number(formatFixed2(totalTransfer)) },
    ];

    return {
      reportType,
      title: REPORT_LABELS_TR[reportType],
      generatedAt: new Date().toISOString(),
      filters: filtersOut,
      columns,
      rows,
      summary: {
        cashSalesTotal: formatFixed2(totalCash),
        creditCardSalesTotal: formatFixed2(totalCard),
        bankTransferTotal: formatFixed2(totalTransfer),
        grossTotal: formatFixed2(totalCash.plus(totalCard).plus(totalTransfer)),
      },
      chartData,
    };
  }

  if (reportType === 'iban-transfers') {
    const receiptsRes = await listReceipts(actor, {
      storeId: scopedStoreId,
      cashierId: effectiveCashierId,
      startDate,
      endDate,
    });

    const columns: ReportColumnDefinition[] = [
      { key: 'sessionBusinessDate', label: 'Kasa Günü', type: 'date' },
      { key: 'storeName', label: 'Mağaza', type: 'text' },
      { key: 'cashierName', label: 'Kasiyer', type: 'text' },
      { key: 'senderName', label: 'Gönderen', type: 'text' },
      { key: 'senderBank', label: 'Gönderen Banka', type: 'text' },
      { key: 'iban', label: 'IBAN', type: 'text' },
      { key: 'referenceNumber', label: 'Referans No', type: 'text' },
      { key: 'verifiedAmount', label: 'Tutar', type: 'currency' },
      { key: 'statusLabel', label: 'Durum', type: 'text' },
      { key: 'isDuplicate', label: 'Mükerrer', type: 'text' },
      { key: 'bankAccountVerified', label: 'Banka Teyidi', type: 'text' },
    ];

    const rawRows: ReportRow[] = receiptsRes.items.map((r) => ({
      sessionBusinessDate: r.sessionBusinessDate,
      storeName: r.store.name,
      cashierName: r.cashier.fullName,
      senderName: r.senderName ?? '-',
      senderBank: r.senderBank ?? '-',
      iban: r.iban ?? '-',
      referenceNumber: r.referenceNumber ?? '-',
      verifiedAmount: r.verifiedAmount ?? '0.00',
      statusLabel: RECEIPT_STATUS_LABELS_TR[r.status as ReceiptStatus],
      isDuplicate: r.isDuplicate ? 'Evet' : 'Hayır',
      bankAccountVerified: r.bankAccountVerified ? 'Teyitli' : 'Bekliyor',
    }));

    const rows = sortRows(rawRows, columns, query.sortBy ?? 'sessionBusinessDate', query.sortDir);

    const statusCounts = new Map<string, number>();
    for (const r of receiptsRes.items) {
      const lbl = RECEIPT_STATUS_LABELS_TR[r.status];
      statusCounts.set(lbl, (statusCounts.get(lbl) ?? 0) + 1);
    }
    const chartData = Array.from(statusCounts.entries()).map(([name, Adet]) => ({ name, Adet }));

    return {
      reportType,
      title: REPORT_LABELS_TR[reportType],
      generatedAt: new Date().toISOString(),
      filters: filtersOut,
      columns,
      rows,
      summary: {
        totalCount: receiptsRes.summary.totalCount,
        approvedTotal: receiptsRes.summary.approvedTotal,
        bankVerifiedTotal: receiptsRes.summary.bankVerifiedTotal,
        duplicateOrFailedCount: receiptsRes.summary.duplicateOrFailedCount,
      },
      chartData,
    };
  }

  if (reportType === 'pending-approvals') {
    const [sessionsRes, receiptsRes] = await Promise.all([
      listCashSessions(actor, {
        storeId: scopedStoreId,
        cashierId: effectiveCashierId,
        startDate,
        endDate,
      }),
      listReceipts(actor, {
        storeId: scopedStoreId,
        cashierId: effectiveCashierId,
        startDate,
        endDate,
      }),
    ]);

    const columns: ReportColumnDefinition[] = [
      { key: 'itemType', label: 'Kayıt Türü', type: 'text' },
      { key: 'businessDate', label: 'Tarih', type: 'date' },
      { key: 'storeName', label: 'Mağaza', type: 'text' },
      { key: 'cashierName', label: 'Kasiyer', type: 'text' },
      { key: 'amount', label: 'İlgili Tutar', type: 'currency' },
      { key: 'statusLabel', label: 'Mevcut Durum', type: 'text' },
      { key: 'detail', label: 'Açıklama / Referans', type: 'text' },
    ];

    const rawRows: ReportRow[] = [];

    for (const s of sessionsRes.items) {
      if (s.status !== 'CENTRAL_APPROVED' && s.status !== 'LOCKED') {
        rawRows.push({
          itemType: 'Kasa Kapanışı',
          businessDate: s.businessDate,
          storeName: s.store.name,
          cashierName: s.cashier.fullName,
          amount: s.declaredCash ?? s.expectedCash,
          statusLabel: CASH_SESSION_STATUS_LABELS_TR[s.status as CashSessionStatus],
          detail: `Vardiya #${s.shiftNo} · Beklenen: ${s.expectedCash} ₺`,
        });
      }
    }

    for (const r of receiptsRes.items) {
      if (
        r.status === 'EXTRACTED' ||
        r.status === 'MANUAL_REVIEW_REQUIRED' ||
        r.status === 'PENDING_CENTRAL_APPROVAL' ||
        r.status === 'FAILED_OCR'
      ) {
        rawRows.push({
          itemType: 'IBAN Dekontu',
          businessDate: r.sessionBusinessDate,
          storeName: r.store.name,
          cashierName: r.cashier.fullName,
          amount: r.verifiedAmount ?? '0.00',
          statusLabel: RECEIPT_STATUS_LABELS_TR[r.status as ReceiptStatus],
          detail: r.referenceNumber ?? r.originalFilename,
        });
      }
    }

    const rows = sortRows(rawRows, columns, query.sortBy ?? 'businessDate', query.sortDir);
    const closingCount = rows.filter((r) => r.itemType === 'Kasa Kapanışı').length;
    const receiptCount = rows.filter((r) => r.itemType === 'IBAN Dekontu').length;

    return {
      reportType,
      title: REPORT_LABELS_TR[reportType],
      generatedAt: new Date().toISOString(),
      filters: filtersOut,
      columns,
      rows,
      summary: {
        totalPending: rows.length,
        pendingClosings: closingCount,
        pendingReceipts: receiptCount,
      },
      chartData: [
        { name: 'Kasa Kapanışları', Adet: closingCount },
        { name: 'IBAN Dekontları', Adet: receiptCount },
      ],
    };
  }

  if (reportType === 'shortage-surplus') {
    const sessionsRes = await listCashSessions(actor, {
      storeId: scopedStoreId,
      cashierId: effectiveCashierId,
      startDate,
      endDate,
    });

    const columns: ReportColumnDefinition[] = [
      { key: 'businessDate', label: 'Tarih', type: 'date' },
      { key: 'storeName', label: 'Mağaza', type: 'text' },
      { key: 'cashierName', label: 'Kasiyer', type: 'text' },
      { key: 'expectedCash', label: 'Beklenen Nakit', type: 'currency' },
      { key: 'declaredCash', label: 'Teslim Edilen Nakit', type: 'currency' },
      { key: 'varianceType', label: 'Fark Türü', type: 'text' },
      { key: 'cashDifference', label: 'Fark Tutarı', type: 'currency' },
      { key: 'notes', label: 'Açıklama', type: 'text' },
    ];

    const rawRows: ReportRow[] = sessionsRes.items
      .filter((s) => s.cashDifferenceStatus === 'SHORTAGE' || s.cashDifferenceStatus === 'SURPLUS')
      .map((s) => ({
        businessDate: s.businessDate,
        storeName: s.store.name,
        cashierName: s.cashier.fullName,
        expectedCash: s.expectedCash,
        declaredCash: s.declaredCash ?? '0.00',
        varianceType: s.cashDifferenceStatus === 'SHORTAGE' ? 'Kasa Açığı' : 'Kasa Fazlası',
        cashDifference: s.cashDifference ?? '0.00',
        notes: s.notes ?? '-',
      }));

    const rows = sortRows(rawRows, columns, query.sortBy ?? 'businessDate', query.sortDir);
    const chartData = rows.map((r) => ({
      name: `${r.businessDate} · ${r.cashierName}`,
      Fark: Number(r.cashDifference),
    }));

    return {
      reportType,
      title: REPORT_LABELS_TR[reportType],
      generatedAt: new Date().toISOString(),
      filters: filtersOut,
      columns,
      rows,
      summary: {
        varianceCount: rows.length,
        totalShortage: sessionsRes.totals.totalShortage,
        totalSurplus: sessionsRes.totals.totalSurplus,
        netCashVariance: sessionsRes.totals.netCashVariance,
      },
      chartData,
    };
  }

  if (reportType === 'date-range') {
    const sessionsRes = await listCashSessions(actor, {
      storeId: scopedStoreId,
      cashierId: effectiveCashierId,
      startDate,
      endDate,
    });

    const byDate = new Map<
      string,
      {
        sessionCount: number;
        cash: Decimal;
        card: Decimal;
        transfer: Decimal;
        refunds: Decimal;
        netSales: Decimal;
        expectedCash: Decimal;
        declaredCash: Decimal;
        shortage: Decimal;
        surplus: Decimal;
      }
    >();

    for (const s of sessionsRes.items) {
      const g = byDate.get(s.businessDate) ?? {
        sessionCount: 0,
        cash: zero,
        card: zero,
        transfer: zero,
        refunds: zero,
        netSales: zero,
        expectedCash: zero,
        declaredCash: zero,
        shortage: zero,
        surplus: zero,
      };
      g.sessionCount += 1;
      g.cash = g.cash.plus(toDecimal(s.cashSalesTotal));
      g.card = g.card.plus(toDecimal(s.creditCardSalesTotal));
      g.transfer = g.transfer.plus(toDecimal(s.bankTransferTotal));
      g.refunds = g.refunds.plus(toDecimal(s.totalRefunds));
      g.netSales = g.netSales.plus(toDecimal(s.netSalesTotal));
      g.expectedCash = g.expectedCash.plus(toDecimal(s.expectedCash));
      if (s.declaredCash !== null) g.declaredCash = g.declaredCash.plus(toDecimal(s.declaredCash));
      g.shortage = g.shortage.plus(toDecimal(s.cashShortage));
      g.surplus = g.surplus.plus(toDecimal(s.cashSurplus));
      byDate.set(s.businessDate, g);
    }

    const columns: ReportColumnDefinition[] = [
      { key: 'businessDate', label: 'Tarih', type: 'date' },
      { key: 'sessionCount', label: 'Oturum', type: 'number' },
      { key: 'cashSales', label: 'Nakit Satış', type: 'currency' },
      { key: 'cardSales', label: 'Kredi Kartı', type: 'currency' },
      { key: 'bankTransfer', label: 'Havale / EFT', type: 'currency' },
      { key: 'refunds', label: 'İadeler', type: 'currency' },
      { key: 'netSales', label: 'Net Satış', type: 'currency' },
      { key: 'expectedCash', label: 'Beklenen Nakit', type: 'currency' },
      { key: 'declaredCash', label: 'Teslim Nakit', type: 'currency' },
      { key: 'shortage', label: 'Açık', type: 'currency' },
      { key: 'surplus', label: 'Fazla', type: 'currency' },
    ];

    const rawRows: ReportRow[] = Array.from(byDate.entries()).map(([date, g]) => ({
      businessDate: date,
      sessionCount: g.sessionCount,
      cashSales: formatFixed2(g.cash),
      cardSales: formatFixed2(g.card),
      bankTransfer: formatFixed2(g.transfer),
      refunds: formatFixed2(g.refunds),
      netSales: formatFixed2(g.netSales),
      expectedCash: formatFixed2(g.expectedCash),
      declaredCash: formatFixed2(g.declaredCash),
      shortage: formatFixed2(g.shortage),
      surplus: formatFixed2(g.surplus),
    }));

    const rows = sortRows(rawRows, columns, query.sortBy ?? 'businessDate', query.sortDir);
    const chartData = [...rows]
      .sort((a, b) => String(a.businessDate).localeCompare(String(b.businessDate)))
      .map((r) => ({
        name: String(r.businessDate),
        'Net Satış': Number(r.netSales),
        Nakit: Number(r.cashSales),
        'Kredi Kartı': Number(r.cardSales),
        'Havale / EFT': Number(r.bankTransfer),
      }));

    return {
      reportType,
      title: REPORT_LABELS_TR[reportType],
      generatedAt: new Date().toISOString(),
      filters: filtersOut,
      columns,
      rows,
      summary: {
        dayCount: rows.length,
        netSalesTotal: sessionsRes.totals.netSalesTotal,
        cashSalesTotal: sessionsRes.totals.cashSalesTotal,
        creditCardSalesTotal: sessionsRes.totals.creditCardSalesTotal,
        bankTransferTotal: sessionsRes.totals.bankTransferTotal,
        totalShortage: sessionsRes.totals.totalShortage,
        totalSurplus: sessionsRes.totals.totalSurplus,
      },
      chartData,
    };
  }

  // monthly-summary
  const [sessionsRes, reconciliations] = await Promise.all([
    listCashSessions(actor, {
      storeId: scopedStoreId,
      cashierId: effectiveCashierId,
      startDate,
      endDate,
    }),
    prisma.centralReconciliation.findMany({
      where: {
        ...(scopedStoreId ? { storeId: scopedStoreId } : {}),
        businessDate: { gte: parseDateOnly(startDate), lte: parseDateOnly(endDate) },
        status: 'APPROVED',
      },
    }),
  ]);

  const approvedByMonth = new Map<string, number>();
  for (const r of reconciliations) {
    const ym = r.businessDate.toISOString().slice(0, 7);
    approvedByMonth.set(ym, (approvedByMonth.get(ym) ?? 0) + 1);
  }

  const byMonth = new Map<
    string,
    {
      sessionCount: number;
      cash: Decimal;
      card: Decimal;
      transfer: Decimal;
      refunds: Decimal;
      netSales: Decimal;
      shortage: Decimal;
      surplus: Decimal;
    }
  >();

  for (const s of sessionsRes.items) {
    const ym = s.businessDate.slice(0, 7);
    const g = byMonth.get(ym) ?? {
      sessionCount: 0,
      cash: zero,
      card: zero,
      transfer: zero,
      refunds: zero,
      netSales: zero,
      shortage: zero,
      surplus: zero,
    };
    g.sessionCount += 1;
    g.cash = g.cash.plus(toDecimal(s.cashSalesTotal));
    g.card = g.card.plus(toDecimal(s.creditCardSalesTotal));
    g.transfer = g.transfer.plus(toDecimal(s.bankTransferTotal));
    g.refunds = g.refunds.plus(toDecimal(s.totalRefunds));
    g.netSales = g.netSales.plus(toDecimal(s.netSalesTotal));
    g.shortage = g.shortage.plus(toDecimal(s.cashShortage));
    g.surplus = g.surplus.plus(toDecimal(s.cashSurplus));
    byMonth.set(ym, g);
  }

  const columns: ReportColumnDefinition[] = [
    { key: 'month', label: 'Dönem (Yıl-Ay)', type: 'text' },
    { key: 'sessionCount', label: 'Oturum Sayısı', type: 'number' },
    { key: 'approvedReconciliations', label: 'Onaylı Gün/Mağaza', type: 'number' },
    { key: 'cashSales', label: 'Nakit Satış', type: 'currency' },
    { key: 'cardSales', label: 'Kredi Kartı', type: 'currency' },
    { key: 'bankTransfer', label: 'Onaylı Havale / EFT', type: 'currency' },
    { key: 'refunds', label: 'İadeler', type: 'currency' },
    { key: 'netSales', label: 'Aylık Net Satış', type: 'currency' },
    { key: 'shortage', label: 'Toplam Açık', type: 'currency' },
    { key: 'surplus', label: 'Toplam Fazla', type: 'currency' },
  ];

  const rawRows: ReportRow[] = Array.from(byMonth.entries()).map(([month, g]) => ({
    month,
    sessionCount: g.sessionCount,
    approvedReconciliations: approvedByMonth.get(month) ?? 0,
    cashSales: formatFixed2(g.cash),
    cardSales: formatFixed2(g.card),
    bankTransfer: formatFixed2(g.transfer),
    refunds: formatFixed2(g.refunds),
    netSales: formatFixed2(g.netSales),
    shortage: formatFixed2(g.shortage),
    surplus: formatFixed2(g.surplus),
  }));

  const rows = sortRows(rawRows, columns, query.sortBy ?? 'month', query.sortDir);
  const chartData = [...rows]
    .sort((a, b) => String(a.month).localeCompare(String(b.month)))
    .map((r) => ({
      name: String(r.month),
      Nakit: Number(r.cashSales),
      'Kredi Kartı': Number(r.cardSales),
      'Havale / EFT': Number(r.bankTransfer),
      'Net Satış': Number(r.netSales),
    }));

  return {
    reportType,
    title: REPORT_LABELS_TR[reportType],
    generatedAt: new Date().toISOString(),
    filters: filtersOut,
    columns,
    rows,
    summary: {
      monthCount: rows.length,
      netSalesTotal: sessionsRes.totals.netSalesTotal,
      totalShortage: sessionsRes.totals.totalShortage,
      totalSurplus: sessionsRes.totals.totalSurplus,
    },
    chartData,
  };
}
