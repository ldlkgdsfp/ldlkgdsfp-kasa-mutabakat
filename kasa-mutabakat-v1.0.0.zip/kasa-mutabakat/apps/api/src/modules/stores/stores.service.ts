import type { CreateStoreInput, StoreSummary, UpdateStoreInput } from '@kasa/shared';
import { prisma } from '../../config/prisma.js';
import { recordAuditLog } from '../audit/audit.service.js';
import type { RequestMeta } from '../auth/auth.service.js';
import { ConflictError, NotFoundError } from '../../utils/errors.js';

function mapStore(s: {
  id: string;
  code: string;
  name: string;
  type: 'STORE' | 'HEADQUARTERS';
  address: string | null;
  phone: string | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}): StoreSummary {
  return {
    id: s.id,
    code: s.code,
    name: s.name,
    type: s.type,
    address: s.address,
    phone: s.phone,
    isActive: s.isActive,
    createdAt: s.createdAt.toISOString(),
    updatedAt: s.updatedAt.toISOString(),
  };
}

export async function createStore(
  input: CreateStoreInput,
  actor: { id: string; role: string; storeId: string | null },
  meta: RequestMeta,
): Promise<StoreSummary> {
  const existing = await prisma.store.findUnique({ where: { code: input.code } });
  if (existing) {
    throw new ConflictError(`'${input.code}' koduna sahip bir mağaza zaten mevcut.`);
  }

  const created = await prisma.$transaction(async (tx) => {
    const store = await tx.store.create({
      data: {
        code: input.code,
        name: input.name,
        type: input.type,
        address: input.address ?? null,
        phone: input.phone ?? null,
        isActive: true,
      },
    });

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: store.id,
        action: 'STORE_CREATED',
        entityType: 'store',
        entityId: store.id,
        afterJson: { code: store.code, name: store.name, type: store.type },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return store;
  });

  return mapStore(created);
}

export async function updateStore(
  storeId: string,
  input: UpdateStoreInput,
  actor: { id: string; role: string; storeId: string | null },
  meta: RequestMeta,
): Promise<StoreSummary> {
  const existing = await prisma.store.findUnique({ where: { id: storeId } });
  if (!existing) {
    throw new NotFoundError('Güncellenecek mağaza bulunamadı.');
  }

  const updated = await prisma.$transaction(async (tx) => {
    const store = await tx.store.update({
      where: { id: storeId },
      data: {
        ...(input.name !== undefined ? { name: input.name } : {}),
        ...(input.address !== undefined ? { address: input.address } : {}),
        ...(input.phone !== undefined ? { phone: input.phone } : {}),
        ...(input.isActive !== undefined ? { isActive: input.isActive } : {}),
      },
    });

    const action =
      input.name !== undefined && input.name !== existing.name
        ? 'STORE_RENAMED'
        : 'STORE_UPDATED';

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: store.id,
        action,
        entityType: 'store',
        entityId: store.id,
        beforeJson: {
          name: existing.name,
          address: existing.address,
          phone: existing.phone,
          isActive: existing.isActive,
        },
        afterJson: {
          name: store.name,
          address: store.address,
          phone: store.phone,
          isActive: store.isActive,
        },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return store;
  });

  return mapStore(updated);
}
