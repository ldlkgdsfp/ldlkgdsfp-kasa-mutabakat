import { Router } from 'express';
import { z } from 'zod';
import { createStoreSchema, updateStoreSchema } from '@kasa/shared';
import { prisma } from '../../config/prisma.js';
import { requireAuth } from '../../middlewares/auth.js';
import { csrfProtection } from '../../middlewares/csrf.js';
import { requireRole } from '../../middlewares/rbac.js';
import {
  enforceStoreScopeParam,
  hasGlobalStoreAccess,
} from '../../middlewares/store-scope.js';
import { asyncHandler } from '../../utils/async-handler.js';
import { NotFoundError } from '../../utils/errors.js';
import { createStore, updateStore } from './stores.service.js';

const storeIdParamSchema = z.object({
  storeId: z.string().uuid('Geçersiz mağaza kimliği.'),
});

export const storesRouter = Router();

storesRouter.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = req.auth!.user;
    const where = hasGlobalStoreAccess(user.role)
      ? {}
      : { id: user.storeId ?? '00000000-0000-0000-0000-000000000000' };

    const stores = await prisma.store.findMany({
      where,
      orderBy: [{ type: 'asc' }, { code: 'asc' }],
    });

    res.json({
      items: stores.map((s) => ({
        id: s.id,
        code: s.code,
        name: s.name,
        type: s.type,
        address: s.address,
        phone: s.phone,
        isActive: s.isActive,
        createdAt: s.createdAt.toISOString(),
        updatedAt: s.updatedAt.toISOString(),
      })),
    });
  }),
);

storesRouter.post(
  '/',
  requireAuth,
  csrfProtection,
  requireRole('SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const input = createStoreSchema.parse(req.body);
    const created = await createStore(input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(201).json(created);
  }),
);

storesRouter.get(
  '/:storeId',
  requireAuth,
  asyncHandler(async (req, res, next) => {
    storeIdParamSchema.parse(req.params);
    next();
  }),
  enforceStoreScopeParam('storeId'),
  asyncHandler(async (req, res) => {
    const { storeId } = storeIdParamSchema.parse(req.params);
    const store = await prisma.store.findUnique({ where: { id: storeId } });
    if (!store) {
      throw new NotFoundError('Mağaza bulunamadı.');
    }

    res.json({
      id: store.id,
      code: store.code,
      name: store.name,
      type: store.type,
      address: store.address,
      phone: store.phone,
      isActive: store.isActive,
      createdAt: store.createdAt.toISOString(),
      updatedAt: store.updatedAt.toISOString(),
    });
  }),
);

storesRouter.patch(
  '/:storeId',
  requireAuth,
  csrfProtection,
  requireRole('SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const { storeId } = storeIdParamSchema.parse(req.params);
    const input = updateStoreSchema.parse(req.body);
    const updated = await updateStore(storeId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);
