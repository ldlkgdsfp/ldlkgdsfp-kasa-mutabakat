import {
  ROLE_LABELS_TR,
  type CreateUserInput,
  type RoleCode,
  type StoreType,
  type UpdateUserInput,
  type UserSummary,
} from '@kasa/shared';
import { prisma } from '../../config/prisma.js';
import { resolveScopedStoreId } from '../../middlewares/store-scope.js';
import { recordAuditLog } from '../audit/audit.service.js';
import type { RequestMeta } from '../auth/auth.service.js';
import { ConflictError, NotFoundError, ValidationError } from '../../utils/errors.js';
import { hashPassword } from '../../utils/password.js';

const STORE_REQUIRED_ROLES = new Set<RoleCode>(['STORE_MANAGER', 'CASHIER']);

function mapUser(u: {
  id: string;
  username: string;
  email: string;
  fullName: string;
  role: { code: string };
  storeId: string | null;
  store: { id: string; code: string; name: string; type: string } | null;
  isActive: boolean;
  lastLoginAt: Date | null;
  createdAt: Date;
}): UserSummary {
  const roleCode = u.role.code as RoleCode;
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    fullName: u.fullName,
    role: roleCode,
    roleLabel: ROLE_LABELS_TR[roleCode],
    storeId: u.storeId,
    store: u.store
      ? {
          id: u.store.id,
          code: u.store.code,
          name: u.store.name,
          type: u.store.type as StoreType,
        }
      : null,
    isActive: u.isActive,
    lastLoginAt: u.lastLoginAt ? u.lastLoginAt.toISOString() : null,
    createdAt: u.createdAt.toISOString(),
  };
}

export async function listUsers(
  actor: { id: string; role: RoleCode; storeId: string | null },
  filters: { storeId?: string; roleCode?: RoleCode; onlyActive?: boolean },
): Promise<UserSummary[]> {
  const scopedStoreId = resolveScopedStoreId(actor, filters.storeId);

  const users = await prisma.user.findMany({
    where: {
      ...(scopedStoreId ? { storeId: scopedStoreId } : {}),
      ...(filters.roleCode ? { role: { code: filters.roleCode } } : {}),
      ...(filters.onlyActive ? { isActive: true } : {}),
      ...(actor.role === 'CASHIER' ? { id: actor.id } : {}),
    },
    include: {
      role: true,
      store: true,
    },
    orderBy: [{ isActive: 'desc' }, { fullName: 'asc' }],
  });

  return users.map(mapUser);
}

export async function createUser(
  input: CreateUserInput,
  actor: { id: string; role: RoleCode; storeId: string | null },
  meta: RequestMeta,
): Promise<UserSummary> {
  const role = await prisma.role.findUnique({ where: { code: input.roleCode } });
  if (!role) {
    throw new ValidationError('Geçersiz rol seçimi.');
  }

  let resolvedStoreId = input.storeId ?? null;
  if (STORE_REQUIRED_ROLES.has(input.roleCode)) {
    if (!resolvedStoreId) {
      throw new ValidationError(
        'Mağaza yöneticisi ve kasiyer rolleri için mağaza seçimi zorunludur.',
      );
    }
    const store = await prisma.store.findUnique({ where: { id: resolvedStoreId } });
    if (!store || !store.isActive) {
      throw new ValidationError('Seçilen mağaza bulunamadı veya pasif durumda.');
    }
    if (store.type !== 'STORE') {
      throw new ValidationError('Mağaza yöneticisi ve kasiyer yalnızca bir mağazaya atanabilir.');
    }
  } else if (resolvedStoreId) {
    const store = await prisma.store.findUnique({ where: { id: resolvedStoreId } });
    if (!store) {
      throw new ValidationError('Seçilen birim bulunamadı.');
    }
  }

  const normalizedUsername = input.username.trim().toLowerCase();
  const normalizedEmail = input.email.trim().toLowerCase();

  const conflict = await prisma.user.findFirst({
    where: {
      OR: [
        { username: { equals: normalizedUsername, mode: 'insensitive' } },
        { email: { equals: normalizedEmail, mode: 'insensitive' } },
      ],
    },
  });

  if (conflict) {
    throw new ConflictError('Bu kullanıcı adı veya e-posta adresi zaten kullanılıyor.');
  }

  const passwordHash = await hashPassword(input.password);

  const created = await prisma.$transaction(async (tx) => {
    const user = await tx.user.create({
      data: {
        username: normalizedUsername,
        email: normalizedEmail,
        fullName: input.fullName.trim(),
        passwordHash,
        roleId: role.id,
        storeId: resolvedStoreId,
        isActive: true,
      },
      include: {
        role: true,
        store: true,
      },
    });

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: user.storeId,
        action: 'USER_CREATED',
        entityType: 'user',
        entityId: user.id,
        afterJson: {
          username: user.username,
          email: user.email,
          fullName: user.fullName,
          role: user.role.code,
          storeId: user.storeId,
        },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return user;
  });

  return mapUser(created);
}

export async function updateUser(
  userId: string,
  input: UpdateUserInput,
  actor: { id: string; role: RoleCode; storeId: string | null },
  meta: RequestMeta,
): Promise<UserSummary> {
  const existing = await prisma.user.findUnique({
    where: { id: userId },
    include: { role: true, store: true },
  });

  if (!existing) {
    throw new NotFoundError('Güncellenecek kullanıcı bulunamadı.');
  }

  if (existing.id === actor.id && input.isActive === false) {
    throw new ValidationError('Kendi yönetici hesabınızı pasifleştiremezsiniz.');
  }

  const nextRoleCode = (input.roleCode ?? existing.role.code) as RoleCode;
  const nextRole =
    input.roleCode !== undefined
      ? await prisma.role.findUnique({ where: { code: input.roleCode } })
      : existing.role;

  if (!nextRole) {
    throw new ValidationError('Geçersiz rol seçimi.');
  }

  const nextStoreId = input.storeId !== undefined ? input.storeId : existing.storeId;

  if (STORE_REQUIRED_ROLES.has(nextRoleCode)) {
    if (!nextStoreId) {
      throw new ValidationError(
        'Mağaza yöneticisi ve kasiyer rolleri için mağaza seçimi zorunludur.',
      );
    }
    const store = await prisma.store.findUnique({ where: { id: nextStoreId } });
    if (!store || store.type !== 'STORE') {
      throw new ValidationError('Mağaza yöneticisi ve kasiyer yalnızca aktif bir mağazaya atanabilir.');
    }
  } else if (nextStoreId) {
    const store = await prisma.store.findUnique({ where: { id: nextStoreId } });
    if (!store) {
      throw new ValidationError('Seçilen birim bulunamadı.');
    }
  }

  if (input.email && input.email.toLowerCase() !== existing.email.toLowerCase()) {
    const emailConflict = await prisma.user.findFirst({
      where: {
        id: { not: userId },
        email: { equals: input.email.trim().toLowerCase(), mode: 'insensitive' },
      },
    });
    if (emailConflict) {
      throw new ConflictError('Bu e-posta adresi başka bir kullanıcı tarafından kullanılıyor.');
    }
  }

  const nextPasswordHash = input.newPassword
    ? await hashPassword(input.newPassword)
    : undefined;

  const updated = await prisma.$transaction(async (tx) => {
    const user = await tx.user.update({
      where: { id: userId },
      data: {
        ...(input.email !== undefined ? { email: input.email.trim().toLowerCase() } : {}),
        ...(input.fullName !== undefined ? { fullName: input.fullName.trim() } : {}),
        ...(input.roleCode !== undefined ? { roleId: nextRole.id } : {}),
        ...(input.storeId !== undefined ? { storeId: nextStoreId } : {}),
        ...(input.isActive !== undefined ? { isActive: input.isActive } : {}),
        ...(nextPasswordHash !== undefined ? { passwordHash: nextPasswordHash } : {}),
      },
      include: {
        role: true,
        store: true,
      },
    });

    // Pasifleştirme veya parola sıfırlamada aktif oturumları anında iptal et
    if (input.isActive === false || nextPasswordHash !== undefined) {
      await tx.userSession.updateMany({
        where: { userId, revokedAt: null },
        data: { revokedAt: new Date() },
      });
    }

    await recordAuditLog(
      {
        actorUserId: actor.id,
        actorRole: actor.role,
        storeId: user.storeId,
        action: 'USER_UPDATED',
        entityType: 'user',
        entityId: user.id,
        beforeJson: {
          email: existing.email,
          fullName: existing.fullName,
          role: existing.role.code,
          storeId: existing.storeId,
          isActive: existing.isActive,
        },
        afterJson: {
          email: user.email,
          fullName: user.fullName,
          role: user.role.code,
          storeId: user.storeId,
          isActive: user.isActive,
          passwordReset: Boolean(nextPasswordHash),
        },
        ipAddress: meta.ipAddress,
        userAgent: meta.userAgent,
        requestId: meta.requestId,
      },
      tx,
    );

    return user;
  });

  return mapUser(updated);
}
