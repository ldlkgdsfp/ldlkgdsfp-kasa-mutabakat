import { Router } from 'express';
import { z } from 'zod';
import { createUserSchema, ROLE_CODES, updateUserSchema } from '@kasa/shared';
import { prisma } from '../../config/prisma.js';
import { requireAuth } from '../../middlewares/auth.js';
import { csrfProtection } from '../../middlewares/csrf.js';
import { requireRole } from '../../middlewares/rbac.js';
import { asyncHandler } from '../../utils/async-handler.js';
import { createUser, listUsers, updateUser } from './users.service.js';

const userIdParamSchema = z.object({
  userId: z.string().uuid('Geçersiz kullanıcı kimliği.'),
});

const listUsersQuerySchema = z.object({
  storeId: z.string().uuid().optional(),
  roleCode: z.enum(ROLE_CODES).optional(),
  onlyActive: z
    .enum(['true', 'false'])
    .optional()
    .transform((v) => (v === undefined ? undefined : v === 'true')),
});

export const usersRouter = Router();

usersRouter.get(
  '/roles',
  requireAuth,
  asyncHandler(async (_req, res) => {
    const roles = await prisma.role.findMany({ orderBy: { code: 'asc' } });
    res.json({
      items: roles.map((r) => ({
        id: r.id,
        code: r.code,
        name: r.name,
        description: r.description,
      })),
    });
  }),
);

usersRouter.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const query = listUsersQuerySchema.parse(req.query);
    const items = await listUsers(req.auth!.user, query);
    res.json({ items });
  }),
);

usersRouter.post(
  '/',
  requireAuth,
  csrfProtection,
  requireRole('SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const input = createUserSchema.parse(req.body);
    const created = await createUser(input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(201).json(created);
  }),
);

usersRouter.patch(
  '/:userId',
  requireAuth,
  csrfProtection,
  requireRole('SYSTEM_ADMIN'),
  asyncHandler(async (req, res) => {
    const { userId } = userIdParamSchema.parse(req.params);
    const input = updateUserSchema.parse(req.body);
    const updated = await updateUser(userId, input, req.auth!.user, {
      ipAddress: req.clientIp,
      userAgent: req.header('user-agent') ?? null,
      requestId: req.requestId,
    });
    res.status(200).json(updated);
  }),
);
