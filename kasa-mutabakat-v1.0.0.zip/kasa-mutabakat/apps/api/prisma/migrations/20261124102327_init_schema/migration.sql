-- CreateEnum
CREATE TYPE "RoleCode" AS ENUM ('SYSTEM_ADMIN', 'STORE_MANAGER', 'CASHIER', 'CENTRAL_ACCOUNTING');

-- CreateEnum
CREATE TYPE "StoreType" AS ENUM ('STORE', 'HEADQUARTERS');

-- CreateEnum
CREATE TYPE "PaymentMethodCode" AS ENUM ('CASH', 'CREDIT_CARD', 'BANK_TRANSFER');

-- CreateEnum
CREATE TYPE "CashTransactionType" AS ENUM ('SALE', 'REFUND', 'CASH_IN', 'CASH_OUT');

-- CreateEnum
CREATE TYPE "CashSessionStatus" AS ENUM ('OPEN', 'CASHIER_SUBMITTED', 'STORE_MANAGER_APPROVED', 'RETURNED_FOR_CORRECTION', 'CENTRAL_APPROVED', 'LOCKED');

-- CreateEnum
CREATE TYPE "ReceiptStatus" AS ENUM ('UPLOADED', 'OCR_PROCESSING', 'EXTRACTED', 'MANUAL_REVIEW_REQUIRED', 'PENDING_CENTRAL_APPROVAL', 'APPROVED', 'REJECTED', 'DUPLICATE', 'FAILED_OCR');

-- CreateEnum
CREATE TYPE "VerificationStage" AS ENUM ('CASHIER_CONFIRM', 'STORE_MANAGER_REVIEW', 'CENTRAL_VERIFICATION', 'BANK_STATEMENT_CHECK');

-- CreateEnum
CREATE TYPE "VerificationAction" AS ENUM ('CONFIRMED', 'EDITED_AND_CONFIRMED', 'SENT_TO_MANUAL_REVIEW', 'APPROVED', 'REJECTED', 'MARKED_DUPLICATE');

-- CreateEnum
CREATE TYPE "ReconciliationStatus" AS ENUM ('PENDING', 'IN_REVIEW', 'APPROVED', 'RETURNED', 'DISPUTED');

-- CreateTable
CREATE TABLE "roles" (
    "id" UUID NOT NULL,
    "code" "RoleCode" NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "roles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "stores" (
    "id" UUID NOT NULL,
    "code" VARCHAR(32) NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "type" "StoreType" NOT NULL DEFAULT 'STORE',
    "address" TEXT,
    "phone" VARCHAR(32),
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "stores_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "users" (
    "id" UUID NOT NULL,
    "username" VARCHAR(64) NOT NULL,
    "email" VARCHAR(150) NOT NULL,
    "full_name" VARCHAR(150) NOT NULL,
    "password_hash" TEXT NOT NULL,
    "role_id" UUID NOT NULL,
    "store_id" UUID,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "last_login_at" TIMESTAMPTZ(6),
    "failed_login_attempts" INTEGER NOT NULL DEFAULT 0,
    "locked_until" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_sessions" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "token_hash" VARCHAR(64) NOT NULL,
    "csrf_token" VARCHAR(64) NOT NULL,
    "ip_address" VARCHAR(64),
    "user_agent" TEXT,
    "expires_at" TIMESTAMPTZ(6) NOT NULL,
    "revoked_at" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "payment_methods" (
    "id" UUID NOT NULL,
    "code" "PaymentMethodCode" NOT NULL,
    "name" VARCHAR(80) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "payment_methods_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "cash_sessions" (
    "id" UUID NOT NULL,
    "store_id" UUID NOT NULL,
    "cashier_id" UUID NOT NULL,
    "business_date" DATE NOT NULL,
    "shift_no" INTEGER NOT NULL DEFAULT 1,
    "opening_cash" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "cash_sales_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "credit_card_sales_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "bank_transfer_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "cash_refund_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "card_refund_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "transfer_refund_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "other_cash_in_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "other_cash_out_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "expected_cash" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "declared_cash" DECIMAL(14,2),
    "cash_difference" DECIMAL(14,2),
    "status" "CashSessionStatus" NOT NULL DEFAULT 'OPEN',
    "notes" TEXT,
    "submitted_at" TIMESTAMPTZ(6),
    "store_approved_by" UUID,
    "store_approved_at" TIMESTAMPTZ(6),
    "central_approved_by" UUID,
    "central_approved_at" TIMESTAMPTZ(6),
    "is_locked" BOOLEAN NOT NULL DEFAULT false,
    "version" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "cash_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "cash_transactions" (
    "id" UUID NOT NULL,
    "cash_session_id" UUID NOT NULL,
    "store_id" UUID NOT NULL,
    "cashier_id" UUID NOT NULL,
    "payment_method_id" UUID NOT NULL,
    "transaction_type" "CashTransactionType" NOT NULL,
    "amount" DECIMAL(14,2) NOT NULL,
    "transfer_receipt_id" UUID,
    "reference_no" VARCHAR(120),
    "description" TEXT,
    "occurred_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "is_voided" BOOLEAN NOT NULL DEFAULT false,
    "void_reason" TEXT,
    "voided_by" UUID,
    "voided_at" TIMESTAMPTZ(6),
    "created_by" UUID NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "cash_transactions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "transfer_receipts" (
    "id" UUID NOT NULL,
    "store_id" UUID NOT NULL,
    "cashier_id" UUID NOT NULL,
    "cash_session_id" UUID NOT NULL,
    "original_filename" VARCHAR(255) NOT NULL,
    "stored_path" TEXT NOT NULL,
    "mime_type" VARCHAR(100) NOT NULL,
    "file_size_bytes" INTEGER NOT NULL,
    "file_sha256" VARCHAR(64) NOT NULL,
    "perceptual_hash" VARCHAR(64),
    "status" "ReceiptStatus" NOT NULL DEFAULT 'UPLOADED',
    "verified_amount" DECIMAL(14,2),
    "transaction_date" DATE,
    "transaction_time" VARCHAR(16),
    "sender_name" VARCHAR(200),
    "receiver_name" VARCHAR(200),
    "sender_bank" VARCHAR(150),
    "receiver_bank" VARCHAR(150),
    "iban" VARCHAR(40),
    "reference_number" VARCHAR(120),
    "description" TEXT,
    "is_duplicate" BOOLEAN NOT NULL DEFAULT false,
    "duplicate_of_receipt_id" UUID,
    "duplicate_reason" VARCHAR(120),
    "bank_account_verified" BOOLEAN NOT NULL DEFAULT false,
    "bank_verified_by" UUID,
    "bank_verified_at" TIMESTAMPTZ(6),
    "included_in_reconciliation" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "transfer_receipts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "receipt_ocr_results" (
    "id" UUID NOT NULL,
    "transfer_receipt_id" UUID NOT NULL,
    "provider" VARCHAR(64) NOT NULL,
    "raw_text" TEXT NOT NULL,
    "raw_response_json" JSONB,
    "extracted_amount" DECIMAL(14,2),
    "detected_amounts_json" JSONB,
    "excluded_balance_amounts_json" JSONB,
    "transaction_date" DATE,
    "transaction_time" VARCHAR(16),
    "sender_name" VARCHAR(200),
    "receiver_name" VARCHAR(200),
    "sender_bank" VARCHAR(150),
    "receiver_bank" VARCHAR(150),
    "iban" VARCHAR(40),
    "reference_number" VARCHAR(120),
    "description" TEXT,
    "confidence_score" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "field_confidences_json" JSONB,
    "warnings_json" JSONB,
    "processing_time_ms" INTEGER,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "receipt_ocr_results_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "receipt_verifications" (
    "id" UUID NOT NULL,
    "transfer_receipt_id" UUID NOT NULL,
    "stage" "VerificationStage" NOT NULL,
    "action" "VerificationAction" NOT NULL,
    "previous_values_json" JSONB,
    "new_values_json" JSONB,
    "reason" TEXT,
    "verified_by" UUID NOT NULL,
    "verified_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "receipt_verifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "central_reconciliations" (
    "id" UUID NOT NULL,
    "store_id" UUID NOT NULL,
    "business_date" DATE NOT NULL,
    "expected_cash_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "declared_cash_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "central_verified_cash" DECIMAL(14,2),
    "cash_variance" DECIMAL(14,2),
    "declared_vs_central_diff" DECIMAL(14,2),
    "credit_card_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "approved_transfer_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "bank_verified_transfer_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "refund_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "grand_sales_total" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "status" "ReconciliationStatus" NOT NULL DEFAULT 'PENDING',
    "notes" TEXT,
    "checked_by" UUID,
    "checked_at" TIMESTAMPTZ(6),
    "approved_by" UUID,
    "approved_at" TIMESTAMPTZ(6),
    "is_locked" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "central_reconciliations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "reconciliation_items" (
    "id" UUID NOT NULL,
    "central_reconciliation_id" UUID NOT NULL,
    "cash_session_id" UUID,
    "cashier_id" UUID,
    "payment_method_id" UUID NOT NULL,
    "expected_amount" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "declared_amount" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "verified_amount" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "variance_amount" DECIMAL(14,2) NOT NULL DEFAULT 0,
    "notes" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "reconciliation_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "financial_adjustments" (
    "id" UUID NOT NULL,
    "central_reconciliation_id" UUID NOT NULL,
    "entity_type" VARCHAR(64) NOT NULL,
    "entity_id" UUID NOT NULL,
    "field_name" VARCHAR(64) NOT NULL,
    "previous_value" DECIMAL(14,2) NOT NULL,
    "adjusted_value" DECIMAL(14,2) NOT NULL,
    "delta_amount" DECIMAL(14,2) NOT NULL,
    "reason" TEXT NOT NULL,
    "created_by" UUID NOT NULL,
    "approved_by" UUID,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "financial_adjustments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" UUID NOT NULL,
    "actor_user_id" UUID,
    "actor_role" VARCHAR(64),
    "store_id" UUID,
    "action" VARCHAR(100) NOT NULL,
    "entity_type" VARCHAR(64) NOT NULL,
    "entity_id" VARCHAR(64),
    "before_json" JSONB,
    "after_json" JSONB,
    "reason" TEXT,
    "ip_address" VARCHAR(64),
    "user_agent" TEXT,
    "request_id" VARCHAR(64),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "system_settings" (
    "key" VARCHAR(100) NOT NULL,
    "value_json" JSONB NOT NULL,
    "description" TEXT,
    "category" VARCHAR(64) NOT NULL,
    "updated_by" UUID,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "system_settings_pkey" PRIMARY KEY ("key")
);

-- CreateIndex
CREATE UNIQUE INDEX "roles_code_key" ON "roles"("code");

-- CreateIndex
CREATE UNIQUE INDEX "stores_code_key" ON "stores"("code");

-- CreateIndex
CREATE INDEX "stores_type_is_active_idx" ON "stores"("type", "is_active");

-- CreateIndex
CREATE UNIQUE INDEX "users_username_key" ON "users"("username");

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE INDEX "users_store_id_is_active_idx" ON "users"("store_id", "is_active");

-- CreateIndex
CREATE INDEX "users_role_id_is_active_idx" ON "users"("role_id", "is_active");

-- CreateIndex
CREATE UNIQUE INDEX "user_sessions_token_hash_key" ON "user_sessions"("token_hash");

-- CreateIndex
CREATE INDEX "user_sessions_user_id_expires_at_idx" ON "user_sessions"("user_id", "expires_at");

-- CreateIndex
CREATE UNIQUE INDEX "payment_methods_code_key" ON "payment_methods"("code");

-- CreateIndex
CREATE INDEX "cash_sessions_store_id_business_date_idx" ON "cash_sessions"("store_id", "business_date");

-- CreateIndex
CREATE INDEX "cash_sessions_cashier_id_business_date_idx" ON "cash_sessions"("cashier_id", "business_date");

-- CreateIndex
CREATE INDEX "cash_sessions_status_business_date_idx" ON "cash_sessions"("status", "business_date");

-- CreateIndex
CREATE UNIQUE INDEX "cash_sessions_store_id_cashier_id_business_date_shift_no_key" ON "cash_sessions"("store_id", "cashier_id", "business_date", "shift_no");

-- CreateIndex
CREATE UNIQUE INDEX "cash_transactions_transfer_receipt_id_key" ON "cash_transactions"("transfer_receipt_id");

-- CreateIndex
CREATE INDEX "cash_transactions_cash_session_id_is_voided_idx" ON "cash_transactions"("cash_session_id", "is_voided");

-- CreateIndex
CREATE INDEX "cash_transactions_store_id_occurred_at_idx" ON "cash_transactions"("store_id", "occurred_at");

-- CreateIndex
CREATE INDEX "cash_transactions_cashier_id_occurred_at_idx" ON "cash_transactions"("cashier_id", "occurred_at");

-- CreateIndex
CREATE INDEX "cash_transactions_payment_method_id_transaction_type_idx" ON "cash_transactions"("payment_method_id", "transaction_type");

-- CreateIndex
CREATE INDEX "transfer_receipts_file_sha256_idx" ON "transfer_receipts"("file_sha256");

-- CreateIndex
CREATE INDEX "transfer_receipts_perceptual_hash_idx" ON "transfer_receipts"("perceptual_hash");

-- CreateIndex
CREATE INDEX "transfer_receipts_reference_number_idx" ON "transfer_receipts"("reference_number");

-- CreateIndex
CREATE INDEX "transfer_receipts_store_id_status_created_at_idx" ON "transfer_receipts"("store_id", "status", "created_at");

-- CreateIndex
CREATE INDEX "transfer_receipts_cash_session_id_status_idx" ON "transfer_receipts"("cash_session_id", "status");

-- CreateIndex
CREATE INDEX "transfer_receipts_transaction_date_verified_amount_idx" ON "transfer_receipts"("transaction_date", "verified_amount");

-- CreateIndex
CREATE INDEX "receipt_ocr_results_transfer_receipt_id_created_at_idx" ON "receipt_ocr_results"("transfer_receipt_id", "created_at");

-- CreateIndex
CREATE INDEX "receipt_verifications_transfer_receipt_id_verified_at_idx" ON "receipt_verifications"("transfer_receipt_id", "verified_at");

-- CreateIndex
CREATE INDEX "central_reconciliations_business_date_status_idx" ON "central_reconciliations"("business_date", "status");

-- CreateIndex
CREATE UNIQUE INDEX "central_reconciliations_store_id_business_date_key" ON "central_reconciliations"("store_id", "business_date");

-- CreateIndex
CREATE INDEX "reconciliation_items_central_reconciliation_id_cashier_id_idx" ON "reconciliation_items"("central_reconciliation_id", "cashier_id");

-- CreateIndex
CREATE INDEX "financial_adjustments_central_reconciliation_id_created_at_idx" ON "financial_adjustments"("central_reconciliation_id", "created_at");

-- CreateIndex
CREATE INDEX "financial_adjustments_entity_type_entity_id_idx" ON "financial_adjustments"("entity_type", "entity_id");

-- CreateIndex
CREATE INDEX "audit_logs_entity_type_entity_id_idx" ON "audit_logs"("entity_type", "entity_id");

-- CreateIndex
CREATE INDEX "audit_logs_actor_user_id_created_at_idx" ON "audit_logs"("actor_user_id", "created_at");

-- CreateIndex
CREATE INDEX "audit_logs_store_id_created_at_idx" ON "audit_logs"("store_id", "created_at");

-- CreateIndex
CREATE INDEX "audit_logs_action_created_at_idx" ON "audit_logs"("action", "created_at");

-- CreateIndex
CREATE INDEX "system_settings_category_idx" ON "system_settings"("category");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_store_id_fkey" FOREIGN KEY ("store_id") REFERENCES "stores"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_sessions" ADD CONSTRAINT "user_sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_sessions" ADD CONSTRAINT "cash_sessions_store_id_fkey" FOREIGN KEY ("store_id") REFERENCES "stores"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_sessions" ADD CONSTRAINT "cash_sessions_cashier_id_fkey" FOREIGN KEY ("cashier_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_sessions" ADD CONSTRAINT "cash_sessions_store_approved_by_fkey" FOREIGN KEY ("store_approved_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_sessions" ADD CONSTRAINT "cash_sessions_central_approved_by_fkey" FOREIGN KEY ("central_approved_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_transactions" ADD CONSTRAINT "cash_transactions_cash_session_id_fkey" FOREIGN KEY ("cash_session_id") REFERENCES "cash_sessions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_transactions" ADD CONSTRAINT "cash_transactions_store_id_fkey" FOREIGN KEY ("store_id") REFERENCES "stores"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_transactions" ADD CONSTRAINT "cash_transactions_cashier_id_fkey" FOREIGN KEY ("cashier_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_transactions" ADD CONSTRAINT "cash_transactions_payment_method_id_fkey" FOREIGN KEY ("payment_method_id") REFERENCES "payment_methods"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_transactions" ADD CONSTRAINT "cash_transactions_transfer_receipt_id_fkey" FOREIGN KEY ("transfer_receipt_id") REFERENCES "transfer_receipts"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_transactions" ADD CONSTRAINT "cash_transactions_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "cash_transactions" ADD CONSTRAINT "cash_transactions_voided_by_fkey" FOREIGN KEY ("voided_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "transfer_receipts" ADD CONSTRAINT "transfer_receipts_store_id_fkey" FOREIGN KEY ("store_id") REFERENCES "stores"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "transfer_receipts" ADD CONSTRAINT "transfer_receipts_cashier_id_fkey" FOREIGN KEY ("cashier_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "transfer_receipts" ADD CONSTRAINT "transfer_receipts_cash_session_id_fkey" FOREIGN KEY ("cash_session_id") REFERENCES "cash_sessions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "transfer_receipts" ADD CONSTRAINT "transfer_receipts_duplicate_of_receipt_id_fkey" FOREIGN KEY ("duplicate_of_receipt_id") REFERENCES "transfer_receipts"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "transfer_receipts" ADD CONSTRAINT "transfer_receipts_bank_verified_by_fkey" FOREIGN KEY ("bank_verified_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "receipt_ocr_results" ADD CONSTRAINT "receipt_ocr_results_transfer_receipt_id_fkey" FOREIGN KEY ("transfer_receipt_id") REFERENCES "transfer_receipts"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "receipt_verifications" ADD CONSTRAINT "receipt_verifications_transfer_receipt_id_fkey" FOREIGN KEY ("transfer_receipt_id") REFERENCES "transfer_receipts"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "receipt_verifications" ADD CONSTRAINT "receipt_verifications_verified_by_fkey" FOREIGN KEY ("verified_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "central_reconciliations" ADD CONSTRAINT "central_reconciliations_store_id_fkey" FOREIGN KEY ("store_id") REFERENCES "stores"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "central_reconciliations" ADD CONSTRAINT "central_reconciliations_checked_by_fkey" FOREIGN KEY ("checked_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "central_reconciliations" ADD CONSTRAINT "central_reconciliations_approved_by_fkey" FOREIGN KEY ("approved_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reconciliation_items" ADD CONSTRAINT "reconciliation_items_central_reconciliation_id_fkey" FOREIGN KEY ("central_reconciliation_id") REFERENCES "central_reconciliations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reconciliation_items" ADD CONSTRAINT "reconciliation_items_cash_session_id_fkey" FOREIGN KEY ("cash_session_id") REFERENCES "cash_sessions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reconciliation_items" ADD CONSTRAINT "reconciliation_items_cashier_id_fkey" FOREIGN KEY ("cashier_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reconciliation_items" ADD CONSTRAINT "reconciliation_items_payment_method_id_fkey" FOREIGN KEY ("payment_method_id") REFERENCES "payment_methods"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "financial_adjustments" ADD CONSTRAINT "financial_adjustments_central_reconciliation_id_fkey" FOREIGN KEY ("central_reconciliation_id") REFERENCES "central_reconciliations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "financial_adjustments" ADD CONSTRAINT "financial_adjustments_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "financial_adjustments" ADD CONSTRAINT "financial_adjustments_approved_by_fkey" FOREIGN KEY ("approved_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_actor_user_id_fkey" FOREIGN KEY ("actor_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_store_id_fkey" FOREIGN KEY ("store_id") REFERENCES "stores"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "system_settings" ADD CONSTRAINT "system_settings_updated_by_fkey" FOREIGN KEY ("updated_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Finansal bütünlük kısıtları ve onaylı dekont kısmi benzersizlik indeksleri
ALTER TABLE "cash_transactions"
  ADD CONSTRAINT "cash_transactions_amount_positive" CHECK ("amount" > 0);

CREATE UNIQUE INDEX "transfer_receipts_approved_sha256_unique"
  ON "transfer_receipts" ("file_sha256")
  WHERE "status" = 'APPROVED' AND "is_duplicate" = false;

CREATE UNIQUE INDEX "transfer_receipts_approved_ref_unique"
  ON "transfer_receipts" (LOWER(TRIM("reference_number")))
  WHERE "status" = 'APPROVED'
    AND "is_duplicate" = false
    AND "reference_number" IS NOT NULL
    AND TRIM("reference_number") <> '';
