import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { PrismaClient, RoleCode, StoreType, PaymentMethodCode } from '@prisma/client';
import { hashPassword } from '../src/utils/password.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.resolve(__dirname, '../../../.env') });

const prisma = new PrismaClient();

async function main(): Promise<void> {
  const defaultPassword = process.env.SEED_DEFAULT_PASSWORD;
  if (!defaultPassword || defaultPassword.length < 8) {
    throw new Error(
      'SEED_DEFAULT_PASSWORD ortam değişkeni zorunludur ve en az 8 karakter olmalıdır.',
    );
  }

  // 1. Roller (4 sabit rol)
  const rolesData: Array<{ code: RoleCode; name: string; description: string }> = [
    {
      code: RoleCode.SYSTEM_ADMIN,
      name: 'Sistem Yöneticisi',
      description: 'Tüm mağaza, personel, rol ve sistem ayarlarını yönetir.',
    },
    {
      code: RoleCode.STORE_MANAGER,
      name: 'Mağaza Yöneticisi',
      description: 'Yalnızca kendi mağazasının günlük kapanış, personel ve dekontlarını yönetir.',
    },
    {
      code: RoleCode.CASHIER,
      name: 'Kasiyer',
      description: 'Kendi kasa oturumunda tahsilat kaydeder, IBAN dekontu yükler ve teslim beyanı girer.',
    },
    {
      code: RoleCode.CENTRAL_ACCOUNTING,
      name: 'Merkez Muhasebe / Kontrol',
      description: 'Tüm mağazaların kasa kapanışlarını ve IBAN dekontlarını kontrol eder, onaylar veya iade eder.',
    },
  ];

  const rolesByCode = new Map<RoleCode, string>();
  for (const r of rolesData) {
    const role = await prisma.role.upsert({
      where: { code: r.code },
      update: { name: r.name, description: r.description },
      create: r,
    });
    rolesByCode.set(role.code, role.id);
  }

  // 2. Ödeme Yöntemleri (Yalnızca 3 ana kategori)
  const paymentMethodsData: Array<{ code: PaymentMethodCode; name: string; sortOrder: number }> = [
    { code: PaymentMethodCode.CASH, name: 'Nakit', sortOrder: 1 },
    { code: PaymentMethodCode.CREDIT_CARD, name: 'Kredi Kartı', sortOrder: 2 },
    { code: PaymentMethodCode.BANK_TRANSFER, name: 'Havale / EFT', sortOrder: 3 },
  ];

  for (const pm of paymentMethodsData) {
    await prisma.paymentMethod.upsert({
      where: { code: pm.code },
      update: { name: pm.name, sortOrder: pm.sortOrder },
      create: pm,
    });
  }

  // 3. Başlangıç 3 Mağaza + 1 Merkez Ofis (isimler yönetim panelinden düzenlenebilir)
  const storesData: Array<{ code: string; name: string; type: StoreType }> = [
    { code: 'MERKEZ', name: 'Merkez Ofis', type: StoreType.HEADQUARTERS },
    { code: 'MAG-01', name: 'Mağaza 1', type: StoreType.STORE },
    { code: 'MAG-02', name: 'Mağaza 2', type: StoreType.STORE },
    { code: 'MAG-03', name: 'Mağaza 3', type: StoreType.STORE },
  ];

  const storesByCode = new Map<string, string>();
  for (const s of storesData) {
    const store = await prisma.store.upsert({
      where: { code: s.code },
      update: {}, // Yönetim panelinden değiştirilen mağaza adını ezme
      create: s,
    });
    storesByCode.set(store.code, store.id);
  }

  // 4. Başlangıç Sistem Ayarları
  const settingsData: Array<{ key: string; valueJson: unknown; description: string; category: string }> = [
    {
      key: 'company_name',
      valueJson: 'Kasa Mutabakat Yönetimi',
      description: 'Kurum / merkez ofis görünen adı',
      category: 'general',
    },
    {
      key: 'currency_code',
      valueJson: 'TRY',
      description: 'Sistem para birimi kodu',
      category: 'financial',
    },
    {
      key: 'timezone',
      valueJson: 'Europe/Istanbul',
      description: 'İş günü ve tarih/saat zaman dilimi',
      category: 'general',
    },
    {
      key: 'ocr_min_confidence_score',
      valueJson: 80,
      description: 'Bu skorun altındaki dekontlar zorunlu manuel doğrulamaya yönlendirilir',
      category: 'ocr',
    },
    {
      key: 'duplicate_time_window_minutes',
      valueJson: 10,
      description: 'Aynı tutar ve gönderen için şüpheli mükerrer zaman penceresi (dakika)',
      category: 'ocr',
    },
    {
      key: 'max_upload_file_size_mb',
      valueJson: 10,
      description: 'Dekont başına izin verilen maksimum dosya boyutu (MB)',
      category: 'security',
    },
    {
      key: 'cash_variance_alert_threshold',
      valueJson: '50.00',
      description: 'Merkez panelinde yüksek öncelikli uyarı gösterecek kasa farkı eşiği (₺)',
      category: 'financial',
    },
    {
      key: 'require_bank_verification_for_reconciliation',
      valueJson: false,
      description: 'Aktifse Havale/EFT toplamına yalnızca banka hesabı teyitli onaylı dekontlar girer',
      category: 'financial',
    },
  ];

  for (const setting of settingsData) {
    await prisma.systemSetting.upsert({
      where: { key: setting.key },
      update: {},
      create: {
        key: setting.key,
        valueJson: setting.valueJson as never,
        description: setting.description,
        category: setting.category,
      },
    });
  }

  // 5. Başlangıç Kurulum Kullanıcı Hesapları (sahte finansal işlem KESİNLİKLE oluşturulmaz)
  const passwordHash = await hashPassword(defaultPassword);
  const initialUsers: Array<{
    username: string;
    email: string;
    fullName: string;
    roleCode: RoleCode;
    storeCode: string | null;
  }> = [
    {
      username: 'admin',
      email: 'admin@kasamutabakat.local',
      fullName: 'Sistem Yöneticisi',
      roleCode: RoleCode.SYSTEM_ADMIN,
      storeCode: 'MERKEZ',
    },
    {
      username: 'merkez.muhasebe',
      email: 'muhasebe@kasamutabakat.local',
      fullName: 'Merkez Muhasebe Kontrol',
      roleCode: RoleCode.CENTRAL_ACCOUNTING,
      storeCode: 'MERKEZ',
    },
    {
      username: 'magaza1.yonetici',
      email: 'yonetici1@kasamutabakat.local',
      fullName: 'Mağaza 1 Yöneticisi',
      roleCode: RoleCode.STORE_MANAGER,
      storeCode: 'MAG-01',
    },
    {
      username: 'magaza1.kasiyer1',
      email: 'kasiyer1.m1@kasamutabakat.local',
      fullName: 'Mağaza 1 Kasiyer 1',
      roleCode: RoleCode.CASHIER,
      storeCode: 'MAG-01',
    },
    {
      username: 'magaza2.yonetici',
      email: 'yonetici2@kasamutabakat.local',
      fullName: 'Mağaza 2 Yöneticisi',
      roleCode: RoleCode.STORE_MANAGER,
      storeCode: 'MAG-02',
    },
    {
      username: 'magaza2.kasiyer1',
      email: 'kasiyer1.m2@kasamutabakat.local',
      fullName: 'Mağaza 2 Kasiyer 1',
      roleCode: RoleCode.CASHIER,
      storeCode: 'MAG-02',
    },
    {
      username: 'magaza3.yonetici',
      email: 'yonetici3@kasamutabakat.local',
      fullName: 'Mağaza 3 Yöneticisi',
      roleCode: RoleCode.STORE_MANAGER,
      storeCode: 'MAG-03',
    },
    {
      username: 'magaza3.kasiyer1',
      email: 'kasiyer1.m3@kasamutabakat.local',
      fullName: 'Mağaza 3 Kasiyer 1',
      roleCode: RoleCode.CASHIER,
      storeCode: 'MAG-03',
    },
  ];

  for (const u of initialUsers) {
    const roleId = rolesByCode.get(u.roleCode);
    if (!roleId) throw new Error(`Rol bulunamadı: ${u.roleCode}`);
    const storeId = u.storeCode ? (storesByCode.get(u.storeCode) ?? null) : null;

    await prisma.user.upsert({
      where: { username: u.username },
      update: {},
      create: {
        username: u.username,
        email: u.email,
        fullName: u.fullName,
        passwordHash,
        roleId,
        storeId,
        isActive: true,
      },
    });
  }

  console.log('Seed tamamlandı: 4 rol, 3 ödeme yöntemi, 3 mağaza + 1 merkez ofis, 8 başlangıç hesabı ve sistem ayarları hazır.');
}

main()
  .catch((err) => {
    console.error('Seed hatası:', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
