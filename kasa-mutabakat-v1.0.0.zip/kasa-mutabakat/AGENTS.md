# Mağaza ve Merkez Günlük Kasa Takip ve Mutabakat Sistemi – Proje Kılavuzu

Bu depo, 3 mağaza ve 1 merkez ofis için geliştirilmiş **Günlük Kasa Takip, IBAN Dekont OCR/Doğrulama ve Merkez Mutabakat Sistemi**nin tek doğruluk kaynağıdır.

## Zorunlu Değişiklik Protokolü

Herhangi bir yeni özellik, hata düzeltmesi veya refactor öncesinde sırayla şu adımları izle:
1. Önce [docs/BLUEPRINT.md](docs/BLUEPRINT.md) ve [docs/MODULE_MAP.md](docs/MODULE_MAP.md) belgelerini oku.
2. Göreve karşılık gelen Skill dosyasını `.agents/skills/<skill-ad>/SKILL.md` altından oku.
3. Etkilenecek modülleri ve veritabanı şema etkisini belirle; kapsam dışı modüllere dokunma.
4. Veritabanı değişikliklerinde mutlaka Prisma migration hazırla (`prisma/migrations`).
5. İlgili unit, integration ve finansal hesaplama testlerini çalıştır ve geçtiğini gözlemle.
6. İlgili `docs/*.md` belgelerini ve `docs/CHANGELOG.md` dosyasını gerçek kodla eşitle.

## Değiştirilemez Mimari ve Finansal İlkeler

- **Gerçek Veri & Gerçek Backend:** Sahte finansal veri üretme, gerçek banka bağlantısı varmış gibi davranma, API anahtarı uydurma.
- **Kesin Ondalık Hesaplama:** Tüm parasal tutarlar PostgreSQL'de `DECIMAL(14,2)`, backend'de `Decimal.js` ile işlenir. Frontend'de finansal hesaplama yapılmaz; yalnızca backend sonuçları `₺` (TRY) ve `GG.AA.YYYY` formatında gösterilir.
- **Ödeme Yöntemi Ayrımı:** Yalnızca 3 ana kategori (`CASH`, `CREDIT_CARD`, `BANK_TRANSFER`). Kredi kartı ve Havale/EFT hiçbir zaman beklenen nakit hesabına girmez.
- **IBAN Dekont Güvenliği:** Hesap bakiyesi asla transfer tutarı kabul edilmez; OCR sonucu kesin doğrulama sayılmaz; mükerrer dekont günlük toplama eklenmez; orijinal dekont dosyası asla silinmez.
- **Mağaza İzolasyonu ve Denetim:** Her kullanıcı yalnızca yetkili olduğu rol ve mağaza kapsamındaki veriye erişir. Onaylı/kilitli finansal kayıtlar doğrudan değiştirilmez; tüm düzeltmeler gerekçeli düzeltme kaydı ve `audit_logs` ile izlenir.
- **GitHub Güvenliği:** Kullanıcı onayı olmadan `git push` yapma, üretim verisini silme veya değiştirme.

## Hızlı Referans

- Kurallar: `.agents/rules/` (`project_rules.md`, `coding_standards.md`, `security_rules.md`, `database_rules.md`, `financial_calculation_rules.md`)
- Alan Skills ve İş Akışları: `.agents/skills/<ad>/SKILL.md` (dizin: `docs/WORKFLOWS_INDEX.md`)
- Mimari ve Şema Belgeleri: `docs/BLUEPRINT.md`, `docs/SYSTEM_ARCHITECTURE.md`, `docs/DATABASE_SCHEMA.md`, `docs/API_DOCUMENTATION.md`
