-- Test veritabanını geliştirme veritabanından izole biçimde oluştur
SELECT 'CREATE DATABASE kasa_mutabakat_test'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'kasa_mutabakat_test')\gexec
