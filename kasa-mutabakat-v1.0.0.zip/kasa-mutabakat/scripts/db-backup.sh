#!/usr/bin/env bash
set -euo pipefail

# PostgreSQL 16 güvenli mantıksal yedekleme betiği
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BACKUP_DIR="${BACKUP_DIR:-$REPO_ROOT/backups}"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
CONTAINER_NAME="${POSTGRES_CONTAINER:-kasa_mutabakat_postgres}"
PG_USER="${POSTGRES_USER:-kasa_user}"
PG_DB="${POSTGRES_DB:-kasa_mutabakat}"

mkdir -p "$BACKUP_DIR"
OUTPUT_FILE="$BACKUP_DIR/${PG_DB}_${TIMESTAMP}.sql.gz"

echo "Yedekleme başlatılıyor: $OUTPUT_FILE"
docker exec "$CONTAINER_NAME" pg_dump -U "$PG_USER" -d "$PG_DB" --no-owner --no-acl | gzip -9 > "$OUTPUT_FILE"
sha256sum "$OUTPUT_FILE" > "${OUTPUT_FILE}.sha256"

echo "Yedekleme tamamlandı: $OUTPUT_FILE"
echo "Bütünlük özeti: ${OUTPUT_FILE}.sha256"
