#!/usr/bin/env bash
set -euo pipefail

# PostgreSQL 16 kontrollü geri yükleme betiği
if [[ $# -lt 1 ]]; then
  echo "Kullanım: $0 <yedek_dosyasi.sql.gz> [--confirm-overwrite]"
  exit 1
fi

BACKUP_FILE="$1"
CONFIRM="${2:-}"
CONTAINER_NAME="${POSTGRES_CONTAINER:-kasa_mutabakat_postgres}"
PG_USER="${POSTGRES_USER:-kasa_user}"
PG_DB="${POSTGRES_DB:-kasa_mutabakat}"

if [[ ! -f "$BACKUP_FILE" ]]; then
  echo "Hata: Yedek dosyası bulunamadı: $BACKUP_FILE"
  exit 1
fi

if [[ -f "${BACKUP_FILE}.sha256" ]]; then
  echo "SHA-256 bütünlük doğrulaması yapılıyor..."
  sha256sum -c "${BACKUP_FILE}.sha256"
fi

if [[ "$CONFIRM" != "--confirm-overwrite" ]]; then
  echo "UYARI: Bu işlem '$PG_DB' veritabanındaki mevcut verilerin üzerine yazar."
  echo "Devam etmek için '--confirm-overwrite' parametresiyle tekrar çalıştırın."
  exit 1
fi

echo "Geri yükleme başlatılıyor ($PG_DB)..."
gunzip -c "$BACKUP_FILE" | docker exec -i "$CONTAINER_NAME" psql -v ON_ERROR_STOP=1 -U "$PG_USER" -d "$PG_DB"
echo "Geri yükleme başarıyla tamamlandı."
