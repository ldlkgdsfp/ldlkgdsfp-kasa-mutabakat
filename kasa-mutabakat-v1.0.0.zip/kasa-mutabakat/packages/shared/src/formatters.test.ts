import { describe, expect, it } from 'vitest';
import { formatCurrencyTRY, formatDateTR, formatDateTimeTR } from './formatters.js';

describe('formatters', () => {
  it('formats positive and negative decimal strings as TRY without float drift', () => {
    expect(formatCurrencyTRY('0.00')).toBe('0,00 ₺');
    expect(formatCurrencyTRY('1250.50')).toBe('1.250,50 ₺');
    expect(formatCurrencyTRY('-45250.75')).toBe('-45.250,75 ₺');
    expect(formatCurrencyTRY('999999999999.99')).toBe('999.999.999.999,99 ₺');
    expect(formatCurrencyTRY(null)).toBe('0,00 ₺');
  });

  it('formats dates and timestamps in Turkish locale and Europe/Istanbul timezone', () => {
    expect(formatDateTR('2026-11-24T12:00:00.000Z')).toBe('24.11.2026');
    expect(formatDateTimeTR('2026-11-24T12:30:00.000Z')).toBe('24.11.2026 15:30');
    expect(formatDateTR(null)).toBe('-');
  });
});
