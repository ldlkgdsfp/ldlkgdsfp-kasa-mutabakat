const TR_LOCALE = 'tr-TR';
const TR_TIMEZONE = 'Europe/Istanbul';

/**
 * Backend'den gelen ondalık string tutarı Türk Lirası (₺) biçiminde görüntüler.
 * Finansal aritmetik yapmaz; yalnızca görsel formatlama sağlar.
 */
export function formatCurrencyTRY(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === '') {
    return '0,00 ₺';
  }

  const raw = typeof value === 'number' ? value.toFixed(2) : value.trim();
  const match = /^(-)?(\d+)(?:\.(\d+))?$/.exec(raw);
  if (!match) {
    return `${raw} ₺`;
  }

  const sign = match[1] ? '-' : '';
  const intPart = match[2] ?? '0';
  const fracRaw = match[3] ?? '00';
  const fracPart = fracRaw.padEnd(2, '0').slice(0, 2);
  const groupedInt = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, '.');

  return `${sign}${groupedInt},${fracPart} ₺`;
}

/**
 * ISO tarih veya Date değerini Türkiye biçiminde (GG.AA.YYYY) formatlar.
 */
export function formatDateTR(value: string | Date | null | undefined): string {
  if (!value) return '-';
  const date = typeof value === 'string' ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return '-';

  return new Intl.DateTimeFormat(TR_LOCALE, {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    timeZone: TR_TIMEZONE,
  }).format(date);
}

/**
 * ISO zaman damgasını Türkiye tarih-saat biçiminde (GG.AA.YYYY SS:DD) formatlar.
 */
export function formatDateTimeTR(value: string | Date | null | undefined): string {
  if (!value) return '-';
  const date = typeof value === 'string' ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return '-';

  return new Intl.DateTimeFormat(TR_LOCALE, {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: TR_TIMEZONE,
  }).format(date);
}
