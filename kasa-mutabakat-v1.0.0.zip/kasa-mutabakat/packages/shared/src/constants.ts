export const ROLE_CODES = [
  'SYSTEM_ADMIN',
  'STORE_MANAGER',
  'CASHIER',
  'CENTRAL_ACCOUNTING',
] as const;

export type RoleCode = (typeof ROLE_CODES)[number];

export const ROLE_LABELS_TR: Record<RoleCode, string> = {
  SYSTEM_ADMIN: 'Sistem Yöneticisi',
  STORE_MANAGER: 'Mağaza Yöneticisi',
  CASHIER: 'Kasiyer',
  CENTRAL_ACCOUNTING: 'Merkez Muhasebe / Kontrol',
};

export const STORE_TYPES = ['STORE', 'HEADQUARTERS'] as const;
export type StoreType = (typeof STORE_TYPES)[number];

export const STORE_TYPE_LABELS_TR: Record<StoreType, string> = {
  STORE: 'Mağaza',
  HEADQUARTERS: 'Merkez Ofis',
};

/**
 * Yalnızca 3 ana ödeme yöntemi desteklenir; birbirine karıştırılamaz.
 */
export const PAYMENT_METHOD_CODES = [
  'CASH',
  'CREDIT_CARD',
  'BANK_TRANSFER',
] as const;

export type PaymentMethodCode = (typeof PAYMENT_METHOD_CODES)[number];

export const PAYMENT_METHOD_LABELS_TR: Record<PaymentMethodCode, string> = {
  CASH: 'Nakit',
  CREDIT_CARD: 'Kredi Kartı',
  BANK_TRANSFER: 'Havale / EFT',
};

export const CASH_TRANSACTION_TYPES = [
  'SALE',
  'REFUND',
  'CASH_IN',
  'CASH_OUT',
] as const;

export type CashTransactionType = (typeof CASH_TRANSACTION_TYPES)[number];

export const CASH_TRANSACTION_TYPE_LABELS_TR: Record<CashTransactionType, string> = {
  SALE: 'Satış',
  REFUND: 'İade',
  CASH_IN: 'Diğer Nakit Girişi',
  CASH_OUT: 'Diğer Nakit Çıkışı',
};

export const CASH_SESSION_STATUSES = [
  'OPEN',
  'CASHIER_SUBMITTED',
  'STORE_MANAGER_APPROVED',
  'RETURNED_FOR_CORRECTION',
  'CENTRAL_APPROVED',
  'LOCKED',
] as const;

export type CashSessionStatus = (typeof CASH_SESSION_STATUSES)[number];

export const CASH_SESSION_STATUS_LABELS_TR: Record<CashSessionStatus, string> = {
  OPEN: 'Açık',
  CASHIER_SUBMITTED: 'Kasiyer Teslim Etti',
  STORE_MANAGER_APPROVED: 'Merkeze Gönderildi',
  RETURNED_FOR_CORRECTION: 'Düzeltme İçin İade',
  CENTRAL_APPROVED: 'Merkez Onayladı',
  LOCKED: 'Kilitli',
};

export const RECEIPT_STATUSES = [
  'UPLOADED',
  'OCR_PROCESSING',
  'EXTRACTED',
  'MANUAL_REVIEW_REQUIRED',
  'PENDING_CENTRAL_APPROVAL',
  'APPROVED',
  'REJECTED',
  'DUPLICATE',
  'FAILED_OCR',
] as const;

export type ReceiptStatus = (typeof RECEIPT_STATUSES)[number];

export const RECEIPT_STATUS_LABELS_TR: Record<ReceiptStatus, string> = {
  UPLOADED: 'Yüklendi',
  OCR_PROCESSING: 'OCR İşleniyor',
  EXTRACTED: 'Bilgiler Çıkarıldı',
  MANUAL_REVIEW_REQUIRED: 'Manuel Doğrulama Bekliyor',
  PENDING_CENTRAL_APPROVAL: 'Merkez Onayı Bekliyor',
  APPROVED: 'Onaylandı',
  REJECTED: 'Reddedildi',
  DUPLICATE: 'Mükerrer',
  FAILED_OCR: 'Hatalı / Okunamadı',
};

export const RECONCILIATION_STATUSES = [
  'PENDING',
  'IN_REVIEW',
  'APPROVED',
  'RETURNED',
  'DISPUTED',
] as const;

export type ReconciliationStatus = (typeof RECONCILIATION_STATUSES)[number];

export const RECONCILIATION_STATUS_LABELS_TR: Record<ReconciliationStatus, string> = {
  PENDING: 'Kontrol Bekliyor',
  IN_REVIEW: 'İnceleniyor',
  APPROVED: 'Onaylandı',
  RETURNED: 'Düzeltme İçin İade',
  DISPUTED: 'Uyuşmazlık Var',
};
