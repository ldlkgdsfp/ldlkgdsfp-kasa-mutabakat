import { z } from 'zod';
import {
  CASH_SESSION_STATUSES,
  CASH_TRANSACTION_TYPES,
  PAYMENT_METHOD_CODES,
  ROLE_CODES,
  STORE_TYPES,
} from '../constants.js';

/**
 * Parasal tutar string doğrulaması (en fazla 12 tam hane + opsiyonel 2 ondalık basamak).
 * Kayan noktalı sayı sapmalarını önlemek için API sözleşmesinde tutarlar string taşınır.
 */
export const decimalAmountStringSchema = z
  .string()
  .trim()
  .regex(/^\d{1,12}(\.\d{1,2})?$/, 'Geçerli bir tutar girin (ör. 1250.50).');

export const positiveDecimalAmountSchema = decimalAmountStringSchema.refine(
  (val) => Number.parseFloat(val) > 0,
  'Tutar 0,00 ₺ değerinden büyük olmalıdır.',
);

export const isoDateOnlySchema = z
  .string()
  .trim()
  .regex(/^\d{4}-\d{2}-\d{2}$/, 'Tarih YYYY-AA-GG formatında olmalıdır.');

// --- Mağaza Şemaları ---
export const createStoreSchema = z.object({
  code: z
    .string()
    .trim()
    .min(2, 'Mağaza kodu en az 2 karakter olmalıdır.')
    .max(32, 'Mağaza kodu en fazla 32 karakter olabilir.')
    .regex(/^[A-Z0-9_-]+$/, 'Mağaza kodu yalnızca büyük harf, rakam, tire veya alt çizgi içerebilir.'),
  name: z
    .string()
    .trim()
    .min(2, 'Mağaza adı en az 2 karakter olmalıdır.')
    .max(150, 'Mağaza adı en fazla 150 karakter olabilir.'),
  type: z.enum(STORE_TYPES).default('STORE'),
  address: z.string().trim().max(500).nullable().optional(),
  phone: z.string().trim().max(32).nullable().optional(),
});

export type CreateStoreInput = z.infer<typeof createStoreSchema>;

export const updateStoreSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, 'Mağaza adı en az 2 karakter olmalıdır.')
    .max(150, 'Mağaza adı en fazla 150 karakter olabilir.')
    .optional(),
  address: z.string().trim().max(500).nullable().optional(),
  phone: z.string().trim().max(32).nullable().optional(),
  isActive: z.boolean().optional(),
});

export type UpdateStoreInput = z.infer<typeof updateStoreSchema>;

// --- Personel & Kullanıcı Şemaları ---
export const createUserSchema = z.object({
  username: z
    .string()
    .trim()
    .min(3, 'Kullanıcı adı en az 3 karakter olmalıdır.')
    .max(64)
    .regex(/^[a-zA-Z0-9._-]+$/, 'Kullanıcı adı yalnızca harf, rakam, nokta, tire veya alt çizgi içerebilir.'),
  email: z.string().trim().email('Geçerli bir e-posta adresi girin.').max(150),
  fullName: z.string().trim().min(2, 'Ad soyad en az 2 karakter olmalıdır.').max(150),
  password: z
    .string()
    .min(8, 'Parola en az 8 karakter olmalıdır.')
    .max(128, 'Parola en fazla 128 karakter olabilir.'),
  roleCode: z.enum(ROLE_CODES),
  storeId: z.string().uuid('Geçerli bir mağaza seçin.').nullable().optional(),
});

export type CreateUserInput = z.infer<typeof createUserSchema>;

export const updateUserSchema = z.object({
  email: z.string().trim().email('Geçerli bir e-posta adresi girin.').max(150).optional(),
  fullName: z.string().trim().min(2, 'Ad soyad en az 2 karakter olmalıdır.').max(150).optional(),
  roleCode: z.enum(ROLE_CODES).optional(),
  storeId: z.string().uuid('Geçerli bir mağaza seçin.').nullable().optional(),
  isActive: z.boolean().optional(),
  newPassword: z
    .string()
    .min(8, 'Yeni parola en az 8 karakter olmalıdır.')
    .max(128)
    .optional(),
});

export type UpdateUserInput = z.infer<typeof updateUserSchema>;

export interface UserSummary {
  id: string;
  username: string;
  email: string;
  fullName: string;
  role: (typeof ROLE_CODES)[number];
  roleLabel: string;
  storeId: string | null;
  store: {
    id: string;
    code: string;
    name: string;
    type: (typeof STORE_TYPES)[number];
  } | null;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
}

// --- Günlük Kasa Oturumu ve Kasa Hareketleri Şemaları ---
export const openCashSessionSchema = z.object({
  storeId: z.string().uuid().optional(),
  cashierId: z.string().uuid().optional(),
  businessDate: isoDateOnlySchema,
  openingCash: decimalAmountStringSchema.default('0.00'),
  notes: z.string().trim().max(1000).nullable().optional(),
});

export type OpenCashSessionInput = z.infer<typeof openCashSessionSchema>;

export const createCashTransactionSchema = z.object({
  paymentMethodCode: z.enum(PAYMENT_METHOD_CODES),
  transactionType: z.enum(CASH_TRANSACTION_TYPES),
  amount: positiveDecimalAmountSchema,
  referenceNo: z.string().trim().max(120).nullable().optional(),
  description: z.string().trim().max(500).nullable().optional(),
  occurredAt: z.string().datetime().optional(),
});

export type CreateCashTransactionInput = z.infer<typeof createCashTransactionSchema>;

export const voidCashTransactionSchema = z.object({
  reason: z
    .string()
    .trim()
    .min(5, 'İptal gerekçesi en az 5 karakter olmalıdır.')
    .max(500, 'İptal gerekçesi en fazla 500 karakter olabilir.'),
});

export type VoidCashTransactionInput = z.infer<typeof voidCashTransactionSchema>;

export const submitCashSessionSchema = z.object({
  declaredCash: decimalAmountStringSchema,
  notes: z.string().trim().max(1000).nullable().optional(),
});

export type SubmitCashSessionInput = z.infer<typeof submitCashSessionSchema>;

export const returnCashSessionSchema = z.object({
  reason: z
    .string()
    .trim()
    .min(5, 'Düzeltme iade gerekçesi en az 5 karakter olmalıdır.')
    .max(500, 'Gerekçe en fazla 500 karakter olabilir.'),
});

export type ReturnCashSessionInput = z.infer<typeof returnCashSessionSchema>;

export const storeApproveCashSessionSchema = z.object({
  notes: z.string().trim().max(1000).nullable().optional(),
});

export type StoreApproveCashSessionInput = z.infer<typeof storeApproveCashSessionSchema>;

export type CashDifferenceStatus = 'SHORTAGE' | 'SURPLUS' | 'EQUAL' | 'PENDING';

export interface CashSessionSummaryDTO {
  id: string;
  storeId: string;
  store: { id: string; code: string; name: string };
  cashierId: string;
  cashier: { id: string; username: string; fullName: string };
  businessDate: string;
  shiftNo: number;
  openingCash: string;
  cashSalesTotal: string;
  creditCardSalesTotal: string;
  bankTransferTotal: string;
  cashRefundTotal: string;
  cardRefundTotal: string;
  transferRefundTotal: string;
  totalRefunds: string;
  otherCashInTotal: string;
  otherCashOutTotal: string;
  expectedCash: string;
  declaredCash: string | null;
  cashDifference: string | null;
  cashDifferenceStatus: CashDifferenceStatus;
  cashShortage: string;
  cashSurplus: string;
  netSalesTotal: string;
  status: (typeof CASH_SESSION_STATUSES)[number];
  statusLabel: string;
  notes: string | null;
  submittedAt: string | null;
  storeApprovedAt: string | null;
  centralApprovedAt: string | null;
  isLocked: boolean;
  transactionCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface CashTransactionDTO {
  id: string;
  cashSessionId: string;
  paymentMethodCode: (typeof PAYMENT_METHOD_CODES)[number];
  paymentMethodName: string;
  transactionType: (typeof CASH_TRANSACTION_TYPES)[number];
  transactionTypeLabel: string;
  amount: string;
  transferReceiptId: string | null;
  referenceNo: string | null;
  description: string | null;
  occurredAt: string;
  isVoided: boolean;
  voidReason: string | null;
  voidedAt: string | null;
  createdBy: { id: string; username: string; fullName: string };
  voidedBy: { id: string; username: string; fullName: string } | null;
  createdAt: string;
}

export interface CashSessionDetailDTO extends CashSessionSummaryDTO {
  transactions: CashTransactionDTO[];
}

export interface SystemSettingDTO {
  key: string;
  valueJson: unknown;
  description: string | null;
  category: string;
  updatedAt: string;
}

export const updateSystemSettingSchema = z.object({
  valueJson: z.unknown(),
  description: z.string().trim().max(500).optional(),
});
