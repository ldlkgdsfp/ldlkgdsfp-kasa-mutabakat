import { z } from 'zod';
import { RECEIPT_STATUSES, type ReceiptStatus } from '../constants.js';
import { isoDateOnlySchema, positiveDecimalAmountSchema } from './core.js';

export const RECEIPT_VERIFICATION_STAGES = [
  'CASHIER_CONFIRM',
  'STORE_MANAGER_REVIEW',
  'CENTRAL_VERIFICATION',
  'BANK_STATEMENT_CHECK',
] as const;

export type ReceiptVerificationStage = (typeof RECEIPT_VERIFICATION_STAGES)[number];

export const RECEIPT_CENTRAL_ACTIONS = [
  'APPROVE',
  'REJECT',
  'MARK_DUPLICATE',
  'SEND_TO_MANUAL_REVIEW',
] as const;

export type ReceiptCentralAction = (typeof RECEIPT_CENTRAL_ACTIONS)[number];

export const confirmReceiptSchema = z.object({
  verifiedAmount: positiveDecimalAmountSchema,
  transactionDate: isoDateOnlySchema.nullable().optional(),
  transactionTime: z.string().trim().max(16).nullable().optional(),
  senderName: z.string().trim().max(200).nullable().optional(),
  receiverName: z.string().trim().max(200).nullable().optional(),
  senderBank: z.string().trim().max(150).nullable().optional(),
  receiverBank: z.string().trim().max(150).nullable().optional(),
  iban: z.string().trim().max(40).nullable().optional(),
  referenceNumber: z.string().trim().max(120).nullable().optional(),
  description: z.string().trim().max(1000).nullable().optional(),
  note: z.string().trim().max(500).nullable().optional(),
});

export type ConfirmReceiptInput = z.infer<typeof confirmReceiptSchema>;

export const centralReviewReceiptSchema = z.object({
  action: z.enum(RECEIPT_CENTRAL_ACTIONS),
  verifiedAmount: positiveDecimalAmountSchema.optional(),
  transactionDate: isoDateOnlySchema.nullable().optional(),
  transactionTime: z.string().trim().max(16).nullable().optional(),
  senderName: z.string().trim().max(200).nullable().optional(),
  receiverName: z.string().trim().max(200).nullable().optional(),
  senderBank: z.string().trim().max(150).nullable().optional(),
  receiverBank: z.string().trim().max(150).nullable().optional(),
  iban: z.string().trim().max(40).nullable().optional(),
  referenceNumber: z.string().trim().max(120).nullable().optional(),
  description: z.string().trim().max(1000).nullable().optional(),
  bankAccountVerified: z.boolean().optional(),
  duplicateOfReceiptId: z.string().uuid().nullable().optional(),
  reason: z.string().trim().max(500).nullable().optional(),
});

export type CentralReviewReceiptInput = z.infer<typeof centralReviewReceiptSchema>;

export const bankVerifyReceiptSchema = z.object({
  bankAccountVerified: z.boolean(),
  reason: z.string().trim().max(500).nullable().optional(),
});

export type BankVerifyReceiptInput = z.infer<typeof bankVerifyReceiptSchema>;

export interface DetectedAmountItem {
  raw: string;
  amount: string;
  line: string;
  classification: 'TRANSFER_CANDIDATE' | 'BALANCE' | 'FEE' | 'UNKNOWN';
}

export interface ReceiptOcrResultDTO {
  id: string;
  provider: string;
  rawText: string;
  extractedAmount: string | null;
  detectedAmounts: DetectedAmountItem[];
  excludedBalanceAmounts: DetectedAmountItem[];
  transactionDate: string | null;
  transactionTime: string | null;
  senderName: string | null;
  receiverName: string | null;
  senderBank: string | null;
  receiverBank: string | null;
  iban: string | null;
  referenceNumber: string | null;
  description: string | null;
  confidenceScore: string;
  warnings: string[];
  processingTimeMs: number | null;
  createdAt: string;
}

export interface ReceiptVerificationDTO {
  id: string;
  stage: ReceiptVerificationStage;
  action: string;
  reason: string | null;
  verifiedBy: { id: string; username: string; fullName: string };
  verifiedAt: string;
}

export interface TransferReceiptSummaryDTO {
  id: string;
  storeId: string;
  store: { id: string; code: string; name: string };
  cashierId: string;
  cashier: { id: string; username: string; fullName: string };
  cashSessionId: string;
  sessionBusinessDate: string;
  originalFilename: string;
  mimeType: string;
  fileSizeBytes: number;
  status: ReceiptStatus;
  statusLabel: string;
  verifiedAmount: string | null;
  transactionDate: string | null;
  transactionTime: string | null;
  senderName: string | null;
  receiverName: string | null;
  senderBank: string | null;
  receiverBank: string | null;
  iban: string | null;
  referenceNumber: string | null;
  description: string | null;
  isDuplicate: boolean;
  duplicateOfReceiptId: string | null;
  duplicateReason: string | null;
  bankAccountVerified: boolean;
  bankVerifiedAt: string | null;
  includedInReconciliation: boolean;
  latestConfidenceScore: string | null;
  latestWarnings: string[];
  createdAt: string;
  updatedAt: string;
}

export interface TransferReceiptDetailDTO extends TransferReceiptSummaryDTO {
  ocrResults: ReceiptOcrResultDTO[];
  verifications: ReceiptVerificationDTO[];
}

export const receiptListQuerySchema = z.object({
  storeId: z.string().uuid().optional(),
  cashSessionId: z.string().uuid().optional(),
  cashierId: z.string().uuid().optional(),
  status: z.enum(RECEIPT_STATUSES).optional(),
  isDuplicate: z
    .enum(['true', 'false'])
    .optional()
    .transform((v) => (v === undefined ? undefined : v === 'true')),
  bankAccountVerified: z
    .enum(['true', 'false'])
    .optional()
    .transform((v) => (v === undefined ? undefined : v === 'true')),
  startDate: isoDateOnlySchema.optional(),
  endDate: isoDateOnlySchema.optional(),
});
