import { z } from 'zod';
import { ROLE_CODES, STORE_TYPES } from '../constants.js';

export const loginRequestSchema = z.object({
  identifier: z
    .string()
    .trim()
    .min(3, 'Kullanıcı adı veya e-posta en az 3 karakter olmalıdır.')
    .max(120, 'Kullanıcı adı veya e-posta en fazla 120 karakter olabilir.'),
  password: z
    .string()
    .min(8, 'Parola en az 8 karakter olmalıdır.')
    .max(128, 'Parola en fazla 128 karakter olabilir.'),
});

export type LoginRequest = z.infer<typeof loginRequestSchema>;

export const authStoreSchema = z.object({
  id: z.string().uuid(),
  code: z.string(),
  name: z.string(),
  type: z.enum(STORE_TYPES),
});

export type AuthStore = z.infer<typeof authStoreSchema>;

export const authUserSchema = z.object({
  id: z.string().uuid(),
  username: z.string(),
  email: z.string().email(),
  fullName: z.string(),
  role: z.enum(ROLE_CODES),
  roleLabel: z.string(),
  storeId: z.string().uuid().nullable(),
  store: authStoreSchema.nullable(),
  isActive: z.boolean(),
});

export type AuthUser = z.infer<typeof authUserSchema>;

export const authSessionResponseSchema = z.object({
  user: authUserSchema,
  csrfToken: z.string().min(16),
  expiresAt: z.string().datetime(),
});

export type AuthSessionResponse = z.infer<typeof authSessionResponseSchema>;

export const storeSummarySchema = z.object({
  id: z.string().uuid(),
  code: z.string(),
  name: z.string(),
  type: z.enum(STORE_TYPES),
  address: z.string().nullable(),
  phone: z.string().nullable(),
  isActive: z.boolean(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
});

export type StoreSummary = z.infer<typeof storeSummarySchema>;

export const apiErrorSchema = z.object({
  error: z.object({
    code: z.string(),
    message: z.string(),
    details: z.unknown().optional(),
  }),
});

export type ApiErrorResponse = z.infer<typeof apiErrorSchema>;
