import { z } from 'zod';
import { RECONCILIATION_STATUSES, type ReconciliationStatus } from '../constants.js';
import {
  decimalAmountStringSchema,
  isoDateOnlySchema,
  type CashSessionSummaryDTO,
} from './core.js';
import type { TransferReceiptSummaryDTO } from './receipts.js';

export const CENTRAL_RECONCILIATION_ACTIONS = [
  'SAVE_REVIEW',
  'APPROVE',
  'RETURN',
  'DISPUTE',
] as const;

export type CentralReconciliationAction = (typeof CENTRAL_RECONCILIATION_ACTIONS)[number];

export const verifyCentralReconciliationSchema = z.object({
  storeId: z.string().uuid('Geçerli bir mağaza seçin.'),
  businessDate: isoDateOnlySchema,
  centralVerifiedCash: decimalAmountStringSchema,
  action: z.enum(CENTRAL_RECONCILIATION_ACTIONS),
  notes: z.string().trim().max(1000).nullable().optional(),
});

export type VerifyCentralReconciliationInput = z.infer<typeof verifyCentralReconciliationSchema>;

export const ADJUSTABLE_FIELDS = [
  'central_verified_cash',
  'credit_card_total',
  'approved_transfer_total',
] as const;

export type AdjustableFieldName = (typeof ADJUSTABLE_FIELDS)[number];

export const createFinancialAdjustmentSchema = z.object({
  fieldName: z.enum(ADJUSTABLE_FIELDS),
  adjustedValue: decimalAmountStringSchema,
  reason: z
    .string()
    .trim()
    .min(10, 'Onaylı finansal kayıtta düzeltme gerekçesi en az 10 karakter olmalıdır.')
    .max(1000, 'Gerekçe en fazla 1000 karakter olabilir.'),
});

export type CreateFinancialAdjustmentInput = z.infer<typeof createFinancialAdjustmentSchema>;

export interface ReconciliationItemDTO {
  id: string;
  cashSessionId: string | null;
  cashierId: string | null;
  cashierName: string | null;
  paymentMethodCode: string;
  paymentMethodName: string;
  expectedAmount: string;
  declaredAmount: string;
  verifiedAmount: string;
  varianceAmount: string;
  notes: string | null;
}

export interface FinancialAdjustmentDTO {
  id: string;
  fieldName: string;
  previousValue: string;
  adjustedValue: string;
  deltaAmount: string;
  reason: string;
  createdBy: { id: string; username: string; fullName: string };
  approvedBy: { id: string; username: string; fullName: string } | null;
  createdAt: string;
}

export interface CentralReconciliationDTO {
  id: string;
  storeId: string;
  store: { id: string; code: string; name: string };
  businessDate: string;
  expectedCashTotal: string;
  declaredCashTotal: string;
  centralVerifiedCash: string | null;
  cashVariance: string | null;
  declaredVsCentralDiff: string | null;
  creditCardTotal: string;
  approvedTransferTotal: string;
  bankVerifiedTransferTotal: string;
  refundTotal: string;
  grandSalesTotal: string;
  status: ReconciliationStatus;
  statusLabel: string;
  notes: string | null;
  checkedBy: { id: string; username: string; fullName: string } | null;
  checkedAt: string | null;
  approvedBy: { id: string; username: string; fullName: string } | null;
  approvedAt: string | null;
  isLocked: boolean;
  items: ReconciliationItemDTO[];
  adjustments: FinancialAdjustmentDTO[];
  createdAt: string;
  updatedAt: string;
}

export interface CentralStoreDailyStatusDTO {
  store: { id: string; code: string; name: string };
  reconciliation: CentralReconciliationDTO | null;
  sessionCount: number;
  submittedSessionCount: number;
  openSessionCount: number;
  pendingReceiptCount: number;
  problematicReceiptCount: number;
  cashSalesTotal: string;
  creditCardTotal: string;
  approvedTransferTotal: string;
  bankVerifiedTransferTotal: string;
  refundTotal: string;
  grandSalesTotal: string;
  expectedCashTotal: string;
  declaredCashTotal: string;
  centralVerifiedCash: string | null;
  cashVariance: string | null;
  declaredVsCentralDiff: string | null;
  shortageTotal: string;
  surplusTotal: string;
  sessions: CashSessionSummaryDTO[];
}

export interface CentralDashboardResponseDTO {
  businessDate: string;
  overall: {
    grandSalesTotal: string;
    cashSalesTotal: string;
    creditCardTotal: string;
    approvedTransferTotal: string;
    bankVerifiedTransferTotal: string;
    refundTotal: string;
    expectedCashTotal: string;
    declaredCashTotal: string;
    centralVerifiedCashTotal: string;
    totalShortage: string;
    totalSurplus: string;
    pendingClosingCount: number;
    pendingReceiptCount: number;
    problematicReceiptCount: number;
  };
  stores: CentralStoreDailyStatusDTO[];
  pendingReceiptsQueue: TransferReceiptSummaryDTO[];
  problematicReceiptsQueue: TransferReceiptSummaryDTO[];
}

export const reconciliationListQuerySchema = z.object({
  storeId: z.string().uuid().optional(),
  startDate: isoDateOnlySchema.optional(),
  endDate: isoDateOnlySchema.optional(),
  status: z.enum(RECONCILIATION_STATUSES).optional(),
});
