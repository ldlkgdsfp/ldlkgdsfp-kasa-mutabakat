import { z } from 'zod';
import { isoDateOnlySchema } from './core.js';

export const REPORT_TYPES = [
  'daily-store',
  'store-comparison',
  'cashier-variance',
  'payment-distribution',
  'iban-transfers',
  'pending-approvals',
  'shortage-surplus',
  'date-range',
  'monthly-summary',
] as const;

export type ReportType = (typeof REPORT_TYPES)[number];

export const REPORT_LABELS_TR: Record<ReportType, string> = {
  'daily-store': 'Günlük Mağaza Raporu',
  'store-comparison': 'Mağazalar Arası Karşılaştırma',
  'cashier-variance': 'Kasiyer Bazlı Kasa Farkı',
  'payment-distribution': 'Günlük Ödeme Yöntemi Dağılımı',
  'iban-transfers': 'IBAN Transfer Raporu',
  'pending-approvals': 'Onay Bekleyen İşlemler',
  'shortage-surplus': 'Açık ve Fazla Raporu',
  'date-range': 'Tarih Aralığı Raporu',
  'monthly-summary': 'Aylık Özet',
};

export const reportQuerySchema = z.object({
  startDate: isoDateOnlySchema.optional(),
  endDate: isoDateOnlySchema.optional(),
  storeId: z.string().uuid().optional(),
  cashierId: z.string().uuid().optional(),
  sortBy: z.string().trim().max(64).optional(),
  sortDir: z.enum(['asc', 'desc']).default('desc'),
  format: z.enum(['json', 'csv', 'xlsx']).default('json'),
});

export type ReportQueryInput = z.infer<typeof reportQuerySchema>;

export interface ReportColumnDefinition {
  key: string;
  label: string;
  type: 'text' | 'date' | 'currency' | 'percent' | 'number';
}

export interface ReportPayloadDTO {
  reportType: ReportType;
  title: string;
  generatedAt: string;
  filters: {
    startDate: string;
    endDate: string;
    storeId: string | null;
    cashierId: string | null;
  };
  columns: ReportColumnDefinition[];
  rows: Array<Record<string, string | number | boolean | null>>;
  summary: Record<string, string | number>;
  chartData: Array<Record<string, string | number>>;
}
