import { execFileSync } from 'node:child_process';
import path from 'node:path';

const repoRoot = path.resolve(__dirname, '..');

export default async function globalSetup() {
  execFileSync('pnpm', ['--filter', '@kasa/api', 'exec', 'tsx', '../../e2e/seed-e2e.ts'], {
    cwd: repoRoot,
    stdio: 'inherit',
  });
}
