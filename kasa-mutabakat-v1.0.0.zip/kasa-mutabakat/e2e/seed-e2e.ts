import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { PrismaClient, RoleCode, StoreType, PaymentMethodCode } from '@prisma/client';
import { hashPassword } from '../apps/api/src/utils/password.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(__dirname, '..');
dotenv.config({ path: path.join(repoRoot, '.env') });

const testDbUrl = process.env.TEST_DATABASE_URL;
if (!testDbUrl) {
  throw new Error('E2E testleri için TEST_DATABASE_URL zorunludur.');
}

const prisma = new PrismaClient({ datasourceUrl: testDbUrl });
const E2E_PASSWORD = process.env.E2E_TEST_PASSWORD ?? 'E2eTest2026!Guvenli';

async function main() {
  // E2E izole dekont depolama klasörünü temizle
  await fs.rm(path.join(repoRoot, 'storage/receipts-e2e'), { recursive: true, force: true });

  // Sadece kasa_mutabakat_test içindeki önceki test kayıtlarını FK sırasıyla temizle
  await prisma.auditLog.deleteMany({});
  await prisma.financialAdjustment.deleteMany({});
  await prisma.reconciliationItem.deleteMany({});
  await prisma.centralReconciliation.deleteMany({});
  await prisma.receiptVerification.deleteMany({});
  await prisma.receiptOcrResult.deleteMany({});
  await prisma.cashTransaction.deleteMany({});
  await prisma.transferReceipt.deleteMany({});
  await prisma.cashSession.deleteMany({});
  await prisma.userSession.deleteMany({});

  // Roller
  const roles = [
    { code: RoleCode.SYSTEM_ADMIN, name: 'Sistem Yöneticisi' },
    { code: RoleCode.STORE_MANAGER, name: 'Mağaza Yöneticisi' },
    { code: RoleCode.CASHIER, name: 'Kasiyer' },
    { code: RoleCode.CENTRAL_ACCOUNTING, name: 'Merkez Muhasebe / Kontrol' },
  ];
  for (const r of roles) {
    await prisma.role.upsert({ where: { code: r.code }, update: { name: r.name }, create: r });
  }

  // Ödeme yöntemleri
  const methods = [
    { code: PaymentMethodCode.CASH, name: 'Nakit', sortOrder: 1 },
    { code: PaymentMethodCode.CREDIT_CARD, name: 'Kredi Kartı', sortOrder: 2 },
    { code: PaymentMethodCode.BANK_TRANSFER, name: 'Havale / EFT', sortOrder: 3 },
  ];
  for (const m of methods) {
    await prisma.paymentMethod.upsert({
      where: { code: m.code },
      update: { name: m.name, sortOrder: m.sortOrder },
      create: m,
    });
  }

  // Birimler
  const stores = [
    { code: 'MERKEZ', name: 'Merkez Ofis', type: StoreType.HEADQUARTERS },
    { code: 'MAG-01', name: 'Mağaza 1', type: StoreType.STORE },
    { code: 'MAG-02', name: 'Mağaza 2', type: StoreType.STORE },
    { code: 'MAG-03', name: 'Mağaza 3', type: StoreType.STORE },
  ];
  for (const s of stores) {
    await prisma.store.upsert({
      where: { code: s.code },
      update: { name: s.name, isActive: true },
      create: s,
    });
  }

  // Sistem ayarları
  await prisma.systemSetting.upsert({
    where: { key: 'require_bank_verification_for_reconciliation' },
    update: { valueJson: false },
    create: {
      key: 'require_bank_verification_for_reconciliation',
      valueJson: false,
      category: 'reconciliation',
      description: 'Banka teyidi zorunluluğu',
    },
  });
  await prisma.systemSetting.upsert({
    where: { key: 'ocr_min_confidence_score' },
    update: { valueJson: 75 },
    create: {
      key: 'ocr_min_confidence_score',
      valueJson: 75,
      category: 'ocr',
      description: 'Minimum OCR güven skoru',
    },
  });

  const roleMap = new Map((await prisma.role.findMany()).map((r) => [r.code, r.id]));
  const storeMap = new Map((await prisma.store.findMany()).map((s) => [s.code, s.id]));
  const passwordHash = await hashPassword(E2E_PASSWORD);

  const e2eUsers = [
    {
      username: 'e2e.admin',
      email: 'e2e.admin@local.test',
      fullName: 'E2E Sistem Yöneticisi',
      roleId: roleMap.get(RoleCode.SYSTEM_ADMIN)!,
      storeId: storeMap.get('MERKEZ')!,
    },
    {
      username: 'e2e.merkez',
      email: 'e2e.merkez@local.test',
      fullName: 'E2E Merkez Muhasebe',
      roleId: roleMap.get(RoleCode.CENTRAL_ACCOUNTING)!,
      storeId: storeMap.get('MERKEZ')!,
    },
    {
      username: 'e2e.m1.yonetici',
      email: 'e2e.m1.yonetici@local.test',
      fullName: 'E2E Mağaza 1 Yöneticisi',
      roleId: roleMap.get(RoleCode.STORE_MANAGER)!,
      storeId: storeMap.get('MAG-01')!,
    },
    {
      username: 'e2e.m1.kasiyer',
      email: 'e2e.m1.kasiyer@local.test',
      fullName: 'E2E Mağaza 1 Kasiyeri',
      roleId: roleMap.get(RoleCode.CASHIER)!,
      storeId: storeMap.get('MAG-01')!,
    },
  ];

  for (const u of e2eUsers) {
    await prisma.user.upsert({
      where: { username: u.username },
      update: {
        passwordHash,
        isActive: true,
        failedLoginAttempts: 0,
        lockedUntil: null,
      },
      create: {
        ...u,
        passwordHash,
      },
    });
  }
}

main()
  .catch((err) => {
    console.error('E2E seed hatası:', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
