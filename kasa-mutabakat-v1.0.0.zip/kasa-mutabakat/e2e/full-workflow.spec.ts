import { expect, test, type Page } from '@playwright/test';

const E2E_PASSWORD = process.env.E2E_TEST_PASSWORD ?? 'E2eTest2026!Guvenli';

function getTodayIsoTR(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Istanbul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

function getTodayDateTR(): string {
  const [y, m, d] = getTodayIsoTR().split('-');
  return `${d}.${m}.${y}`;
}

/**
 * Gerçek pdftotext ile okunabilen geçerli banka dekontu PDF'i üretir.
 */
function buildBankReceiptPdfBuffer(dateTR: string): Buffer {
  const lines = [
    'T.C. ZIRAAT BANKASI A.S.',
    'FAST PARA TRANSFERI DEKONTU',
    `Islem Tarihi: ${dateTR}`,
    'Islem Saati: 14:25',
    'Gonderen: CANER YILMAZ',
    'Alici: KASA MUTABAKAT A.S.',
    'Alici Banka: Garanti BBVA',
    'Alici IBAN: TR330006100519786457841326',
    'FAST Sorgu No: FSTE2E20261124001',
    'Transfer Tutari: 950,00 TL',
    'Islem Masrafi: 4,49 TL',
    'Kullanilabilir Bakiye: 62.400,00 TL',
    'Aciklama: E2E Magaza 1 Siparis',
  ];

  let y = 760;
  const textCommands = lines
    .map((line) => {
      const safe = line.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
      const cmd = `BT /F1 12 Tf 50 ${y} Td (${safe}) Tj ET`;
      y -= 20;
      return cmd;
    })
    .join('\n');

  const objects = [
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj',
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj',
    '3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj',
    `4 0 obj << /Length ${Buffer.byteLength(textCommands, 'utf8')} >> stream\n${textCommands}\nendstream endobj`,
    '5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj',
  ];

  let pdf = '%PDF-1.4\n';
  const offsets: number[] = [0];
  for (const obj of objects) {
    offsets.push(Buffer.byteLength(pdf, 'utf8'));
    pdf += `${obj}\n`;
  }
  const xrefPos = Buffer.byteLength(pdf, 'utf8');
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i < offsets.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`;
  return Buffer.from(pdf, 'utf8');
}

async function login(page: Page, username: string) {
  await page.goto('/giris');
  await expect(page.locator('#login-identifier')).toBeVisible();
  await page.locator('#login-identifier').fill(username);
  await page.locator('#login-password').fill(E2E_PASSWORD);
  await page.locator('#login-submit-button').click();
  await expect(page.locator('#logout-button')).toBeVisible();
}

async function logout(page: Page) {
  await page.locator('#logout-button').click();
  await expect(page.locator('#login-identifier')).toBeVisible();
}

test.describe('Mağaza ve Merkez Günlük Kasa Mutabakat E2E Akışı', () => {
  test('Kasiyer → IBAN PDF OCR → Mağaza Yöneticisi → Merkez Mutabakat Kilidi → Düzeltme → Rapor ve Dışa Aktarma', async ({
    page,
  }) => {
    const todayTR = getTodayDateTR();

    // 1. Kasiyer giriş yapar ve Türkçe tarih formatını doğrular
    await login(page, 'e2e.m1.kasiyer');
    const topHeader = page.locator('header').first();
    const sidebarNav = page.getByRole('navigation', { name: 'Ana menü' });
    await expect(topHeader).toContainText(todayTR);
    await expect(topHeader).toContainText('Mağaza 1 (MAG-01)');

    // 2. Kasiyer günlük kasa oturumu açar (500.00 ₺ açılış)
    await sidebarNav.getByRole('link', { name: 'Günlük Kasa', exact: true }).click();
    await expect(page.locator('#open-cash-session-btn')).toBeVisible();
    await page.locator('#open-cash-session-btn').click();
    await page.locator('#open-cash').fill('500.00');
    await page.locator('dialog[open]').getByRole('button', { name: 'Oturumu Aç', exact: true }).click();
    await expect(page).toHaveURL(/\/kasa\/[0-9a-f-]+$/);
    const sessionUrl = page.url();

    // 3. Nakit satış (1200.00) ve Kredi Kartı satış (850.00) kaydeder
    await page.locator('#tx-method').selectOption('CASH');
    await page.locator('#tx-amount').fill('1200.00');
    await page.locator('#tx-desc').fill('E2E nakit satış');
    await page.getByRole('button', { name: 'Ekle', exact: true }).click();
    await expect(page.locator('main')).toContainText('1.700,00 ₺');

    await page.locator('#tx-method').selectOption('CREDIT_CARD');
    await page.locator('#tx-amount').fill('850.00');
    await page.locator('#tx-desc').fill('E2E POS satış');
    await page.getByRole('button', { name: 'Ekle', exact: true }).click();
    await expect(page.locator('main')).toContainText('850,00 ₺');
    // Kredi kartı nakit hesabına dahil edilmez: Beklenen Nakit hâlâ 1.700,00 ₺
    await expect(page.locator('section[aria-label="Oturum finansal özeti"]')).toContainText(
      '1.700,00 ₺',
    );

    // 4. Oturumdan IBAN Dekontları modülüne geçip gerçek PDF banka dekontu yükler
    await page.getByRole('link', { name: /Bu Oturumun IBAN Dekontlarını Yönet/ }).click();
    await expect(page.locator('#upload-receipt-btn')).toBeVisible();
    await page.locator('#upload-receipt-btn').click();

    const pdfBuffer = buildBankReceiptPdfBuffer(todayTR);
    await page.locator('#up-file').setInputFiles({
      name: 'ziraat-e2e-dekont.pdf',
      mimeType: 'application/pdf',
      buffer: pdfBuffer,
    });
    await page
      .locator('dialog[open]')
      .getByRole('button', { name: 'Yükle ve OCR ile Oku', exact: true })
      .click();
    await expect(page).toHaveURL(/\/dekontlar\/[0-9a-f-]+$/);
    const receiptUrl = page.url();

    // Gerçek OCR çıktısı ve Hesap Bakiyesi Dışlama kuralını doğrula
    await expect(page.locator('#r-amount')).toHaveValue('950.00');
    await expect(page.locator('main')).toContainText('Hesap Bakiyesi Dışlama Kuralı Uygulandı');
    await expect(page.locator('main')).toContainText('62.400,00 ₺');

    // Kasiyer teyit edip merkez onayına gönderir
    await page.locator('#confirm-receipt-btn').click();
    await expect(page.locator('main')).toContainText('Merkez Onayı Bekliyor');

    // 5. Kasiyer kasa oturumuna dönüp 1680.00 ₺ gerçek nakit teslim beyanı yapar (20,00 ₺ açık)
    await page.goto(sessionUrl);
    await page.locator('#declared-cash').fill('1680.00');
    await page.locator('#submit-notes').fill('E2E gün sonu sayımı: 20 TL eksik');
    await page.locator('#submit-cash-session-btn').click();
    await expect(page.locator('main')).toContainText('Kasiyer Teslim Etti');
    await expect(page.locator('main')).toContainText('-20,00 ₺');

    await logout(page);

    // 6. Mağaza Yöneticisi giriş yapar ve kapanışı merkeze onaylar
    await login(page, 'e2e.m1.yonetici');
    await page.goto(sessionUrl);
    await expect(page.locator('#store-approve-btn')).toBeVisible();
    await page.locator('#store-approve-btn').click();
    await expect(page.locator('main')).toContainText('Merkeze Gönderildi');

    await logout(page);

    // 7. Merkez Muhasebe giriş yapar: önce IBAN dekontunu onaylar ve ayrı banka teyidi verir
    await login(page, 'e2e.merkez');
    await page.goto(receiptUrl);
    await expect(page.locator('#central-approve-receipt-btn')).toBeVisible();
    await page.locator('#central-approve-receipt-btn').click();
    await expect(page.locator('main')).toContainText('Onaylandı');

    await page
      .getByRole('button', { name: 'Bankada Hesaba Geçtiğini Teyit Et', exact: true })
      .click();
    await expect(page.locator('main')).toContainText('Banka Teyitli');

    // 8. Merkez Kontrol Paneli üzerinden Mağaza 1 mutabakatını onaylar ve kilitler
    await sidebarNav.getByRole('link', { name: 'Merkez Mutabakat', exact: true }).click();
    await expect(page.getByRole('heading', { name: /Merkez Muhasebe ve Mutabakat Paneli/ })).toBeVisible();

    const mag1Row = page.locator('tbody tr', { hasText: 'Mağaza 1' }).first();
    await expect(mag1Row).toContainText('950,00 ₺');
    await expect(mag1Row).toContainText('1.700,00 ₺');
    await mag1Row.getByRole('button', { name: 'Kontrol Et', exact: true }).click();

    await page.locator('#central-cash').fill('1680.00');
    await page.locator('#central-notes').fill('Merkez sayımı mağaza beyanı ile eşleşti.');
    await page.locator('#central-approve-recon-btn').click();

    await expect(mag1Row).toContainText('Onaylandı');
    await expect(mag1Row).toContainText('İncele / Düzelt');

    // 9. Kilitli mutabakatta gerekçeli finansal düzeltme kaydı eklenir
    await mag1Row.getByRole('button', { name: 'İncele / Düzelt', exact: true }).click();
    await expect(page.locator('dialog[open]')).toContainText(
      'Merkez Tarafından Onaylandı ve Kilitlendi',
    );
    await page
      .locator('dialog[open]')
      .getByRole('button', { name: 'Gerekçeli Düzeltme Kaydı Ekle', exact: true })
      .click();
    await page.locator('#adj-val').fill('1690.00');
    await page
      .locator('#adj-reason')
      .fill('Merkez yeniden sayımında 10,00 TL bozuk para farkı tespit edildi.');
    await page
      .locator('dialog[open]')
      .getByRole('button', { name: 'Düzeltme Kaydını Onayla', exact: true })
      .click();
    await expect(mag1Row).toContainText('1.690,00 ₺');
    await mag1Row.getByRole('button', { name: 'İncele / Düzelt', exact: true }).click();
    await expect(page.locator('dialog[open]')).toContainText(
      'Merkez yeniden sayımında 10,00 TL bozuk para farkı tespit edildi.',
    );
    await page.locator('dialog[open]').getByRole('button', { name: 'Kapat', exact: true }).click();

    // 10. Raporlama sayfasında rapor sekmeleri, grafikler ve Excel/CSV dışa aktarma doğrulanır
    await sidebarNav.getByRole('link', { name: 'Raporlar', exact: true }).click();
    await expect(page.getByRole('heading', { name: /Raporlama ve Finansal Analiz/ })).toBeVisible();
    await expect(page.locator('main')).toContainText('Mağaza 1');
    await expect(page.locator('.recharts-responsive-container')).toBeVisible();

    // Diğer rapor sekmelerine geçiş
    await page.getByRole('button', { name: 'Kasiyer Bazlı Kasa Farkı', exact: true }).click();
    await expect(page.locator('main')).toContainText('E2E Mağaza 1 Kasiyeri');

    await page.getByRole('button', { name: 'IBAN Transfer Raporu', exact: true }).click();
    await expect(page.locator('main')).toContainText('FSTE2E20261124001');

    // Excel (.xlsx) ve CSV (.csv) dışa aktarma indirmelerini doğrula
    const [xlsxDownload] = await Promise.all([
      page.waitForEvent('download'),
      page.locator('#export-xlsx-btn').click(),
    ]);
    expect(xlsxDownload.suggestedFilename()).toMatch(/^iban-transfers_.*\.xlsx$/);
    expect(await xlsxDownload.failure()).toBeNull();

    const [csvDownload] = await Promise.all([
      page.waitForEvent('download'),
      page.locator('#export-csv-btn').click(),
    ]);
    expect(csvDownload.suggestedFilename()).toMatch(/^iban-transfers_.*\.csv$/);
    expect(await csvDownload.failure()).toBeNull();
  });

  test('Mobil responsive görünüm (390x844) ve kasiyer için yetkisiz rota koruması çalışır', async ({
    page,
  }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await login(page, 'e2e.m1.kasiyer');

    // Mobil menü düğmesi görünür ve tıklanınca navigasyon açılır
    const openMenuBtn = page.getByRole('button', { name: 'Ana menüyü aç' });
    const sidebarNav = page.getByRole('navigation', { name: 'Ana menü' });
    await expect(openMenuBtn).toBeVisible();
    await openMenuBtn.click();
    await expect(sidebarNav.getByRole('link', { name: 'Günlük Kasa', exact: true })).toBeVisible();
    await expect(
      sidebarNav.getByRole('link', { name: 'Merkez Mutabakat', exact: true }),
    ).toHaveCount(0);
    await page.getByRole('button', { name: 'Menüyü kapat' }).click();

    // Yatay taşma olmadığını doğrula
    const hasHorizontalOverflow = await page.evaluate(
      () => document.documentElement.scrollWidth > window.innerWidth + 2,
    );
    expect(hasHorizontalOverflow).toBe(false);

    // Kasiyer doğrudan /merkez ve /ayarlar yollarına giderse yetkisiz ekran / yönlendirme ile engellenir
    await page.goto('/merkez');
    await expect(page.getByRole('heading', { name: /Merkez Muhasebe ve Mutabakat Paneli/ })).toHaveCount(0);

    await page.goto('/ayarlar');
    await expect(page.getByRole('heading', { name: /Sistem Ayarları/ })).toHaveCount(0);
  });
});
