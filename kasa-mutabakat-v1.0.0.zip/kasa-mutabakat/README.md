# Mağaza ve Merkez Günlük Kasa Takip ve Mutabakat Sistemi

Üç mağaza ve bir merkez ofis için geliştirilmiş; **günlük kasa kapanışları**, **kasiyer bazlı tahsilat ve açık/fazla takibi**, **IBAN / Havale dekontu yükleme + yerel OCR + 4 katmanlı mükerrer engelleme**, **merkez muhasebe mutabakatı** ve **9 finansal rapor + Excel/CSV dışa aktarma** özelliklerini tek çatı altında sunan kurumsal web uygulamasıdır.

- **Sürüm:** `1.0.0`
- **Dil / Yerelleştirme:** Türkçe (`tr-TR`), Para Birimi: Türk Lirası (`₺` / `TRY`), Tarih: `GG.AA.YYYY`, Zaman Dilimi: `Europe/Istanbul`

---

## Temel Özellikler

### 1. Rol Tabanlı Yetkilendirme (RBAC) ve Mağaza İzolasyonu
- **Sistem Yöneticisi (`SYSTEM_ADMIN`):** Tüm mağazaları (dinamik ad düzenleme dahil), personeli, rolleri ve sistem ayarlarını yönetir.
- **Mağaza Yöneticisi (`STORE_MANAGER`):** Yalnızca kendi mağazasının günlük kapanışlarını, personel hareketlerini ve dekontlarını izler; kapanışı merkeze gönderir veya düzeltme için kasiyere iade eder.
- **Kasiyer (`CASHIER`):** Kendi kayıtlı hesabıyla kasa oturumu açar (serbest metin kasiyer adı yasaktır), gün içi tahsilatları işler, IBAN dekontu yükler ve gün sonu teslim edilen gerçek nakdi beyan eder. Aynı mağazada aynı gün birden fazla kasiyer bağımsız vardiya oturumu yürütebilir.
- **Merkez Muhasebe / Kontrol (`CENTRAL_ACCOUNTING`):** Tüm mağazaların günlük durumunu tek panelden izler, IBAN dekontlarını onaylar/reddeder, banka hesabı ekstresi teyidini ayrı aşama olarak işler, gerçek teslim edilen nakdi kaydedip mutabakatı onaylayarak kilitler.

### 2. Kesin Ondalık Finansal Motor ve Ödeme Yöntemi Ayrımı
- Tüm parasal alanlar PostgreSQL'de `DECIMAL(14,2)`, backend'de `Decimal.js` (`ROUND_HALF_UP`) ile hesaplanır; frontend'de finansal hesaplama yapılmaz.
- Yalnızca **3 ana ödeme yöntemi** desteklenir ve birbirine karıştırılmaz:
  1. **Nakit (`CASH`)**
  2. **Kredi Kartı (`CREDIT_CARD`)** — hiçbir zaman beklenen nakit hesabına girmez.
  3. **Havale / EFT (`BANK_TRANSFER`)** — manuel satış olarak girilemez; yalnızca doğrulanmış, onaylanmış ve mükerrer olmayan dekontlardan günlük toplama dahil edilir.
- **Beklenen Nakit:** `Açılış Kasası + Nakit Satış + Diğer Nakit Girişi − Nakit İade − Diğer Nakit Çıkışı`
- **Kasa Farkı:** `Teslim Edilen Gerçek Nakit − Beklenen Nakit` (`< 0` kasa açığı, `> 0` kasa fazlası, `= 0` kasa eşit).
- **Onaylı Kayıt Değişmezliği:** Onaylanan ve kilitlenen mutabakatlar doğrudan değiştirilemez; sonradan yapılan tüm düzeltmeler en az 10 karakterlik gerekçe ile `financial_adjustments` tablosuna delta olarak ve `audit_logs` denetim günlüğüne işlenir.

### 3. IBAN / Havale Dekontu, Yerel OCR ve 4 Katmanlı Mükerrer Engeli
- **Dosya Güvenliği:** Yalnızca gerçek `JPG`, `JPEG`, `PNG` ve `PDF` kabul edilir (uzantı + magic-bytes imzası + `sharp` görsel bütünlük doğrulaması). Orijinal dosyalar web kökü dışında (`storage/receipts/YYYY/MM/<uuid>.<ext>`) saklanır ve **asla silinmez**; önizleme yalnızca yetki kontrollü API üzerinden `X-Content-Type-Options: nosniff` ve `Content-Security-Policy: sandbox` başlıklarıyla yapılır.
- **Gerçek Yerel OCR + Türk Banka Ayrıştırıcısı:** `poppler-utils` (`pdftotext`, `pdftoppm`) + `sharp` + `tesseract-ocr` (`tur+eng`) ile çalışır; `.env` üzerinden opsiyonel harici AI Vision sağlayıcısı arayüzü hazırdır.
- **Hesap Bakiyesi Dışlama Kuralı:** Dekonttaki hesap bakiyesi ve işlem masrafı tutarları hiçbir zaman transfer tutarı kabul edilmez; dışlanan bakiyeler kullanıcıya açıkça raporlanır.
- **4 Katmanlı Mükerrer Kontrolü + DB Koruması:**
  1. Dosya `SHA-256` özeti eşleşmesi
  2. İşlem / Referans / FAST Sorgu numarası eşleşmesi
  3. Görsel algısal özet (`dHash`, Hamming mesafesi ≤ 4)
  4. Bileşik alan eşleşmesi (aynı tutar + tarih + yakın saat + gönderen/IBAN -> manuel kontrole düşürür)
  - Ek olarak PostgreSQL üzerinde onaylı dekontlar için kısmi benzersizlik indeksleri bulunur.
- **9 Durumlu İş Akışı ve Ayrı Banka Teyidi:** `Yüklendi` -> `OCR İşleniyor` -> `Bilgiler Çıkarıldı` -> `Manuel Doğrulama Bekliyor` / `Merkez Onayı Bekliyor` -> `Onaylandı` / `Reddedildi` / `Mükerrer` / `Hatalı / Okunamadı`. Dekontun okunması veya onaylanması paranın banka hesabına geçtiğini otomatik kanıtlamaz; `bank_account_verified` ayrı kontrol edilir.

### 4. Raporlama ve Excel / CSV Dışa Aktarma
9 finansal rapor gerçek PostgreSQL verilerinden filtrelenebilir, sıralanabilir, grafikli (Recharts) ve Excel (`.xlsx`) / UTF-8 BOM CSV (`.csv`, OWASP formül enjeksiyonu korumalı) olarak sunulur:
1. Günlük Mağaza Raporu (`daily-store`)
2. Mağazalar Arası Karşılaştırma (`store-comparison`)
3. Kasiyer Bazlı Kasa Farkı (`cashier-variance`)
4. Günlük Ödeme Yöntemi Dağılımı (`payment-distribution`)
5. IBAN Transfer Raporu (`iban-transfers`)
6. Onay Bekleyen İşlemler (`pending-approvals`)
7. Açık ve Fazla Raporu (`shortage-surplus`)
8. Tarih Aralığı Raporu (`date-range`)
9. Aylık Özet (`monthly-summary`)

---

## Teknoloji Yığını ve Proje Yapısı

- **Monorepo:** `pnpm` workspaces
  - `packages/shared` (`@kasa/shared`): Ortak TypeScript tipleri, Zod şemaları, rol/durum sabitleri, Türkçe `₺` ve `GG.AA.YYYY` formatlayıcılar.
  - `apps/api` (`@kasa/api`): Node.js 22, TypeScript (strict), Express 4, Prisma 6, PostgreSQL 16, `decimal.js`, `multer`, `sharp`, `exceljs`, `helmet`, `pino`.
  - `apps/web` (`@kasa/web`): React 19, TypeScript (strict), Vite 7, Tailwind CSS v4, React Router v7, TanStack Query, Recharts, Lucide Icons.
  - `e2e/`: Playwright uçtan uca testleri.
  - `scripts/`: PostgreSQL başlatma, yedekleme (`db-backup.sh`) ve geri yükleme (`db-restore.sh`) betikleri.
  - `docs/`: Mimari, veritabanı, API, güvenlik, test planı ve değişiklik günlüğü.
  - `AGENTS.md`, `.agents/rules/`, `.agents/skills/`: Antigravity kuralları, 15 alan becerisi ve 11 modern iş akışı.

---

## Kurulum ve Çalıştırma

### Ön Koşullar
- **Node.js** `>= 22` ve **pnpm** `>= 10`
- **Docker** ve **Docker Compose** (PostgreSQL 16 için)
- Yerel OCR araçları (Ubuntu/Debian):
  ```bash
  sudo apt-get install -y tesseract-ocr tesseract-ocr-tur poppler-utils
  ```

### 1. Ortam Değişkenlerini Hazırlayın
```bash
cp .env.example .env
```
`.env` dosyasında en az şu alanları kendi güvenli değerlerinizle doldurun:
- `POSTGRES_PASSWORD`
- `DATABASE_URL` ve `TEST_DATABASE_URL` (aynı parola ile)
- `SEED_DEFAULT_PASSWORD` (en az 8 karakter; ilk kurulum hesapları için)

> **Güvenlik Notu:** `.env`, `storage/` ve `backups/` dizinleri `.gitignore` ile korunur; asla sürüm kontrolüne eklenmez.

### 2. Bağımlılıkları Kurun ve Veritabanını Başlatın
```bash
pnpm install
pnpm db:up
```
Docker konteyneri (`kasa_mutabakat_postgres`) sağlıklı duruma geldikten sonra şemayı ve başlangıç referans kayıtlarını uygulayın:
```bash
pnpm db:generate
pnpm --filter @kasa/api db:deploy
pnpm db:seed
```
Test veritabanına da migration uygulamak için:
```bash
DATABASE_URL="$(grep '^TEST_DATABASE_URL=' .env | cut -d= -f2-)" pnpm --filter @kasa/api db:deploy
```

### 3. Başlangıç Hesapları (`seed.ts` — Yalnızca Referans Verisi, Sıfır Sahte Finansal İşlem)

| Kullanıcı Adı | E-posta | Rol | Birim |
| :--- | :--- | :--- | :--- |
| `admin` | `admin@kasamutabakat.local` | Sistem Yöneticisi | Merkez Ofis |
| `merkez.muhasebe` | `muhasebe@kasamutabakat.local` | Merkez Muhasebe / Kontrol | Merkez Ofis |
| `magaza1.yonetici` | `yonetici1@kasamutabakat.local` | Mağaza Yöneticisi | Mağaza 1 (`MAG-01`) |
| `magaza1.kasiyer1` | `kasiyer1.m1@kasamutabakat.local` | Kasiyer | Mağaza 1 (`MAG-01`) |
| `magaza2.yonetici` | `yonetici2@kasamutabakat.local` | Mağaza Yöneticisi | Mağaza 2 (`MAG-02`) |
| `magaza2.kasiyer1` | `kasiyer1.m2@kasamutabakat.local` | Kasiyer | Mağaza 2 (`MAG-02`) |
| `magaza3.yonetici` | `yonetici3@kasamutabakat.local` | Mağaza Yöneticisi | Mağaza 3 (`MAG-03`) |
| `magaza3.kasiyer1` | `kasiyer1.m3@kasamutabakat.local` | Kasiyer | Mağaza 3 (`MAG-03`) |

Tüm başlangıç hesapları `.env` dosyasındaki `SEED_DEFAULT_PASSWORD` değeri ile oluşturulur. Üretim ortamında ilk girişten sonra mutlaka güçlü parolalarla değiştirilmelidir.

### 4. Uygulamayı Geliştirme Modunda Çalıştırın
İki ayrı terminalde (veya tek bir process yöneticisiyle):
```bash
# Terminal 1 – REST API (http://localhost:4000)
pnpm dev:api

# Terminal 2 – React Frontend (http://localhost:5173)
pnpm dev:web
```
Sağlık kontrolü: `GET http://localhost:4000/api/v1/health`

### 5. Üretim Derlemesi
```bash
pnpm typecheck
pnpm build
pnpm --filter @kasa/api start
```

---

## Test ve Kalite Doğrulama Komutları

Tüm otomatik testler geliştirme veritabanından izole `kasa_mutabakat_test` veritabanında ve ayrı depolama klasörlerinde (`storage/receipts-test`, `storage/receipts-e2e`) çalışır:

```bash
# Tip kontrolü (tüm workspace)
pnpm typecheck

# Unit + Gerçek PostgreSQL Integration + Web Bileşen Testleri (40 test)
pnpm test

# Playwright E2E Testleri (Gerçek Chrome + Production Preview + Gerçek API & OCR)
pnpm build
pnpm test:e2e

# Tümü (Unit + Integration + E2E)
pnpm test:all
```

---

## Veritabanı Yedekleme ve Geri Yükleme

```bash
# Sıkıştırılmış PostgreSQL yedeği + SHA-256 bütünlük özeti alma (backups/ altına)
./scripts/db-backup.sh

# Kontrollü geri yükleme (SHA-256 doğrular; açık onay bayrağı zorunludur)
./scripts/db-restore.sh backups/<yedek_dosyasi>.sql.gz --confirm-overwrite
```

---

## Dokümantasyon ve Antigravity Geliştirici Kılavuzu

- [AGENTS.md](AGENTS.md) — Zorunlu değişiklik protokolü ve değiştirilemez finansal/güvenlik ilkeleri
- [docs/BLUEPRINT.md](docs/BLUEPRINT.md) — Proje planı ve sürüm özeti
- [docs/SYSTEM_ARCHITECTURE.md](docs/SYSTEM_ARCHITECTURE.md) — Katmanlı sistem mimarisi
- [docs/DATABASE_SCHEMA.md](docs/DATABASE_SCHEMA.md) — 15 tablo, kısıtlar ve kısmi benzersizlik indeksleri
- [docs/API_DOCUMENTATION.md](docs/API_DOCUMENTATION.md) — REST API uç noktaları ve güvenlik başlıkları
- [docs/MODULE_MAP.md](docs/MODULE_MAP.md) — Backend/Frontend modül ve Skill haritası
- [docs/SECURITY_PLAN.md](docs/SECURITY_PLAN.md) — Güvenlik kontrolleri ve denetim sonuçları
- [docs/TEST_PLAN.md](docs/TEST_PLAN.md) — Aşama bazlı gerçek test sonuçları
- [docs/WORKFLOWS_INDEX.md](docs/WORKFLOWS_INDEX.md) — Antigravity Rules, 15 Domain Skill ve 11 Workflow Skill dizini
- [docs/CHANGELOG.md](docs/CHANGELOG.md) — Sürüm geçmişi
